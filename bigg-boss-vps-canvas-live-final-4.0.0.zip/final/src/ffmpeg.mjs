import { spawn } from "node:child_process";
import { once } from "node:events";
import { config } from "./config.mjs";
import { runtime } from "./runtime.mjs";

function bitrateKbps(value) {
  const match = String(value).trim().match(/^(\d+(?:\.\d+)?)([kKmM]?)$/);
  if (!match) return 3500;
  const n = Number(match[1]);
  const unit = match[2].toLowerCase();
  return Math.round(unit === "m" ? n * 1000 : n);
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export function createEncoder() {
  if (!config.streamKey) throw new Error("Missing YouTube stream key");

  const outputUrl = `${config.rtmpUrl}/${config.streamKey}`;
  const bitrate = bitrateKbps(config.bitrate);
  const scale = config.renderWidth === config.width && config.renderHeight === config.height
    ? null
    : `scale=${config.width}:${config.height}:flags=fast_bilinear`;

  const args = [
    "-hide_banner",
    "-nostdin",
    "-loglevel", "info",
    "-f", "rawvideo",
    "-pixel_format", "rgba",
    "-video_size", `${config.renderWidth}x${config.renderHeight}`,
    "-framerate", String(config.fps),
    "-i", "pipe:0",
    "-f", "lavfi",
    "-i", "anullsrc=r=44100:cl=stereo",
    "-map", "0:v:0",
    "-map", "1:a:0",
  ];

  if (scale) args.push("-vf", scale);

  args.push(
    "-c:v", "libx264",
    "-preset", config.preset,
    "-tune", "zerolatency",
    "-threads", String(config.encoderThreads),
    "-pix_fmt", "yuv420p",
    "-b:v", config.bitrate,
    "-maxrate", config.bitrate,
    "-bufsize", `${bitrate * 2}k`,
    "-g", String(config.fps * config.gopSeconds),
    "-keyint_min", String(config.fps * config.gopSeconds),
    "-sc_threshold", "0",
    "-c:a", "aac",
    "-b:a", "128k",
    "-ar", "44100",
    "-ac", "2",
    "-f", "flv",
    outputUrl,
  );

  const child = spawn("ffmpeg", args, { stdio: ["pipe", "ignore", "pipe"] });
  runtime.encoder.status = "starting";
  runtime.encoder.pid = child.pid ?? null;
  runtime.encoder.starts++;

  let lastLog = "";
  child.stderr.setEncoding("utf8");
  child.stderr.on("data", chunk => {
    const text = String(chunk).replace(/\r/g, "\n");
    const lines = text.split("\n").map(v => v.trim()).filter(Boolean);
    for (const line of lines) {
      const lower = line.toLowerCase();
      if (
        lower.includes("error") || lower.includes("failed") || lower.includes("connection") ||
        lower.includes("server error") || lower.includes("broken pipe") || lower.includes("invalid")
      ) {
        runtime.encoder.lastError = line.slice(-1000);
        console.error(`[ffmpeg] ${line}`);
      }
      if (lower.includes("output #0") || lower.includes("flv") || lower.includes("frame=")) {
        runtime.encoder.connectedHint = true;
      }
      if (line !== lastLog && /frame=|speed=|bitrate=/.test(line)) {
        runtime.encoder.lastLogAt = Date.now();
        lastLog = line;
      }
    }
  });

  child.once("spawn", () => {
    runtime.encoder.status = "running";
  });

  child.once("error", error => {
    runtime.encoder.status = "error";
    runtime.encoder.lastError = error.message;
    console.error(`[ffmpeg] process error: ${error.message}`);
  });

  child.once("exit", (code, signal) => {
    runtime.encoder.status = "stopped";
    runtime.encoder.lastExitCode = code;
    runtime.encoder.lastSignal = signal;
    runtime.encoder.pid = null;
    if (code !== 0 || signal) {
      runtime.encoder.lastError ||= `exited code=${code ?? "null"} signal=${signal ?? "none"}`;
      console.error(`[ffmpeg] exited code=${code ?? "null"} signal=${signal ?? "none"}`);
    }
  });

  console.log(`[ffmpeg] started pid=${child.pid ?? "?"} render=${config.renderWidth}x${config.renderHeight} output=${config.width}x${config.height}@${config.fps} ${config.bitrate}`);
  return child;
}

export async function waitForEncoderStart(child) {
  await Promise.race([
    once(child, "spawn").catch(() => {}),
    wait(config.encoderStartupGraceMs),
  ]);
  if (child.exitCode !== null || child.killed) return false;
  return true;
}

export async function writeFrame(child, buffer) {
  if (!child || child.exitCode !== null || child.killed || !child.stdin || child.stdin.destroyed) return false;

  try {
    const accepted = child.stdin.write(buffer);
    if (accepted) return true;

    await Promise.race([
      once(child.stdin, "drain"),
      once(child, "exit"),
      wait(config.frameWriteTimeoutMs).then(() => { throw new Error("FFmpeg stdin drain timeout"); }),
    ]);

    return child.exitCode === null && !child.killed && !child.stdin.destroyed;
  } catch (error) {
    runtime.encoder.lastError = error.message;
    console.error(`[ffmpeg] frame pipe stalled: ${error.message}`);
    return false;
  }
}

export async function stopEncoder(child) {
  if (!child) return;
  try { child.stdin?.end(); } catch {}

  await new Promise(resolve => {
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      clearTimeout(termTimer);
      clearTimeout(killTimer);
      resolve();
    };
    const termTimer = setTimeout(() => {
      try { child.kill("SIGTERM"); } catch {}
    }, 1500);
    const killTimer = setTimeout(() => {
      try { child.kill("SIGKILL"); } catch {}
      finish();
    }, 5000);
    child.once("close", finish);
  });
}
