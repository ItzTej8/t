import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { config } from "./config.mjs";

const now = () => Date.now();

function makeContestants() {
  return Object.fromEntries(config.contestants.map((name, index) => [
    index + 1,
    { no: index + 1, name, votes: 0 }
  ]));
}

function initialState() {
  return {
    version: 4,
    round: 1,
    roundStartedAt: now(),
    contestants: makeContestants(),
    voters: {},
    recentChat: [],
    recentVotes: [],
    totalAcceptedVotes: 0,
    lastVote: null,
    lastVoteAt: 0,
    ownerId: null,
    ownerName: null,
    updatedAt: now(),
  };
}

export const state = initialState();
let saveChain = Promise.resolve();

function sanitizeLoaded(raw) {
  const fresh = initialState();
  if (!raw || typeof raw !== "object") return fresh;

  const loadedContestants = raw.contestants && typeof raw.contestants === "object" ? raw.contestants : {};
  for (const [key, freshRow] of Object.entries(fresh.contestants)) {
    const old = loadedContestants[key];
    if (old && typeof old === "object") {
      fresh.contestants[key] = {
        no: freshRow.no,
        name: String(old.name ?? freshRow.name),
        votes: Number.isFinite(Number(old.votes)) ? Math.max(0, Math.floor(Number(old.votes))) : 0,
      };
    }
  }

  fresh.version = 4;
  fresh.round = Number.isFinite(Number(raw.round)) ? Math.max(1, Math.floor(Number(raw.round))) : 1;
  fresh.roundStartedAt = Number.isFinite(Number(raw.roundStartedAt)) ? Number(raw.roundStartedAt) : now();
  fresh.voters = raw.voters && typeof raw.voters === "object" ? raw.voters : {};
  fresh.recentChat = Array.isArray(raw.recentChat) ? raw.recentChat.slice(-20) : [];
  fresh.recentVotes = Array.isArray(raw.recentVotes) ? raw.recentVotes.slice(-10) : [];
  fresh.totalAcceptedVotes = Number.isFinite(Number(raw.totalAcceptedVotes)) ? Math.max(0, Math.floor(Number(raw.totalAcceptedVotes))) : 0;
  fresh.lastVote = raw.lastVote && typeof raw.lastVote === "object" ? raw.lastVote : null;
  fresh.lastVoteAt = Number.isFinite(Number(raw.lastVoteAt)) ? Number(raw.lastVoteAt) : 0;
  fresh.ownerId = raw.ownerId ?? null;
  fresh.ownerName = raw.ownerName ?? null;
  fresh.updatedAt = Number.isFinite(Number(raw.updatedAt)) ? Number(raw.updatedAt) : now();
  return fresh;
}

export async function loadState() {
  try {
    const raw = JSON.parse(await readFile(resolve(config.stateFile), "utf8"));
    Object.assign(state, sanitizeLoaded(raw));
    console.log(`[state] loaded round ${state.round}, total votes ${state.totalAcceptedVotes}`);
  } catch (error) {
    if (error?.code !== "ENOENT") console.warn(`[state] load failed: ${error.message}`);
    console.log("[state] starting fresh");
  }
}

export function saveState() {
  saveChain = saveChain.then(async () => {
    state.updatedAt = now();
    const path = resolve(config.stateFile);
    await mkdir(dirname(path), { recursive: true });
    const temp = `${path}.tmp-${process.pid}`;
    await writeFile(temp, JSON.stringify(state, null, 2), "utf8");
    await rename(temp, path);
  }).catch(error => {
    console.error(`[state] save failed: ${error.message}`);
  });
  return saveChain;
}

export function setOwner(id, name) {
  if (!state.ownerId && id) {
    state.ownerId = id;
    state.ownerName = name || "Owner";
  }
}

export function addChat(name, text) {
  state.recentChat.push({ name: String(name || "Viewer").slice(0, 80), text: String(text || "").slice(0, 300), at: now() });
  if (state.recentChat.length > 20) state.recentChat.splice(0, state.recentChat.length - 20);
}

export function acceptVote(userId, contestant, name) {
  const key = String(contestant);
  if (!state.contestants[key]) return false;
  if (!userId || state.voters[userId]) return false;

  const timestamp = now();
  const viewerName = String(name || "Viewer").slice(0, 80);
  state.voters[userId] = { contestant: Number(contestant), name: viewerName, at: timestamp };
  state.contestants[key].votes++;
  state.totalAcceptedVotes++;
  state.lastVote = { contestant: Number(contestant), name: viewerName, at: timestamp };
  state.lastVoteAt = timestamp;
  state.recentVotes.push(state.lastVote);
  if (state.recentVotes.length > 10) state.recentVotes.shift();
  return true;
}

export function resetRound() {
  state.round++;
  state.roundStartedAt = now();
  state.voters = {};
  state.recentVotes = [];
  state.lastVote = null;
  state.lastVoteAt = 0;
}

export function stats() {
  return Object.values(state.contestants).sort((a, b) => b.votes - a.votes || a.no - b.no);
}
