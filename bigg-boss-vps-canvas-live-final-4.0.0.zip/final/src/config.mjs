const num = (key, fallback) => {
  const value = Number(process.env[key]);
  return Number.isFinite(value) ? value : fallback;
};

const positiveInt = (key, fallback, min = 1) => Math.max(min, Math.floor(num(key, fallback)));

const csv = (key, fallback) => String(process.env[key] ?? fallback)
  .split(",")
  .map(v => v.trim())
  .filter(Boolean);

const width = positiveInt("WIDTH", 1080, 320);
const height = positiveInt("HEIGHT", 1920, 320);
const renderWidth = Math.min(width, positiveInt("RENDER_WIDTH", 720, 320));
const renderHeight = Math.min(height, positiveInt("RENDER_HEIGHT", Math.round(renderWidth * height / width), 320));

export const config = Object.freeze({
  rtmpUrl: String(process.env.YOUTUBE_RTMP_URL || "rtmp://a.rtmp.youtube.com/live2").replace(/\/+$/, ""),
  streamKey: String(process.env.YOUTUBE_STREAM_KEY || "").trim(),
  videoId: String(process.env.YOUTUBE_VIDEO_ID || "").trim(),

  width,
  height,
  renderWidth,
  renderHeight,
  fps: positiveInt("FPS", 30),
  bitrate: String(process.env.BITRATE || "3500k"),
  preset: String(process.env.PRESET || "ultrafast"),
  encoderThreads: positiveInt("ENCODER_THREADS", 3),
  gopSeconds: positiveInt("GOP_SECONDS", 2),

  voteCommand: String(process.env.VOTE_COMMAND || "!vote").trim() || "!vote",
  voteDurationSeconds: positiveInt("VOTE_DURATION_SECONDS", 60, 10),
  contestants: csv("CONTESTANTS", "Contestant 1,Contestant 2,Contestant 3,Contestant 4"),

  healthPort: positiveInt("HEALTH_PORT", 8787),
  stateFile: String(process.env.STATE_FILE || "data/state.json"),
  backgroundImage: String(process.env.BACKGROUND_IMAGE || "").trim(),

  encoderRestartMinMs: Math.max(1000, Math.floor(num("ENCODER_RESTART_MIN_MS", 3000))),
  encoderRestartMaxMs: Math.max(5000, Math.floor(num("ENCODER_RESTART_MAX_MS", 30000))),
  encoderStartupGraceMs: Math.max(500, Math.floor(num("ENCODER_STARTUP_GRACE_MS", 3000))),
  frameWriteTimeoutMs: Math.max(1000, Math.floor(num("FRAME_WRITE_TIMEOUT_MS", 5000))),
  memoryWarnMB: Math.max(256, Math.floor(num("MEMORY_WARN_MB", 900))),
  memoryExitMB: Math.max(512, Math.floor(num("MEMORY_EXIT_MB", 1500))),
});

export function validateConfig() {
  const errors = [];
  const warnings = [];

  if (!config.streamKey || /PUT_YOUR|YOUR_|CHANGE_ME/i.test(config.streamKey)) errors.push("YOUTUBE_STREAM_KEY is not configured");
  if (!config.videoId || /PUT_YOUR|YOUR_|CHANGE_ME/i.test(config.videoId)) errors.push("YOUTUBE_VIDEO_ID is not configured");
  if (config.width !== 1080 || config.height !== 1920) warnings.push(`YouTube output is ${config.width}x${config.height}`);
  if (config.fps < 24) warnings.push(`FPS is ${config.fps}; 30 FPS is recommended for smooth UI animation`);
  if (config.renderWidth * config.renderHeight > 1280 * 1920) errors.push("Internal render resolution is too large");
  if (config.renderWidth > config.width || config.renderHeight > config.height) errors.push("Internal render dimensions cannot exceed output dimensions");
  if (config.streamKey.length < 10) warnings.push("Stream key looks unusually short; verify it in YouTube Studio");

  return { errors, warnings };
}
