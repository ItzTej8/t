import { createCanvas, loadImage } from "@napi-rs/canvas";
import { readFile } from "node:fs/promises";
import { config } from "./config.mjs";
import { state, stats } from "./state.mjs";
import { runtime } from "./runtime.mjs";
import { createEncoder, waitForEncoderStart, writeFrame, stopEncoder } from "./ffmpeg.mjs";

const canvas = createCanvas(config.renderWidth, config.renderHeight);
const ctx = canvas.getContext("2d");
const W = config.renderWidth;
const H = config.renderHeight;
const sx = W / 1080;
const sy = H / 1920;
const s = Math.min(sx, sy);
const X = v => v * sx;
const Y = v => v * sy;
const S = v => v * s;

let background = null;
let encoder = null;
let running = false;
let encoderRetryAt = 0;
let encoderRetryMs = config.encoderRestartMinMs;
let startedAt = Date.now();
let lastLogFrame = 0;

const particles = Array.from({ length: 14 }, (_, i) => ({
  x: (i * 149.17) % 1080,
  y: (i * 257.31) % 1920,
  r: 1.5 + (i % 3),
  speed: 4 + (i % 5),
  phase: i * 0.83,
}));

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

async function loadBackground() {
  if (!config.backgroundImage) return;
  try {
    background = await loadImage(await readFile(config.backgroundImage));
  } catch (error) {
    console.warn(`[renderer] background unavailable: ${error.message}`);
  }
}

function rr(x, y, w, h, r) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
}

function backgroundFrame(t) {
  ctx.globalAlpha = 1;
  ctx.fillStyle = "#07060d";
  ctx.fillRect(0, 0, W, H);

  // Two slowly moving light fields. Deliberately simple: no blur/shadow per frame.
  for (let i = 0; i < 2; i++) {
    const px = X(280 + i * 520 + Math.sin(t * 0.00018 + i) * 100);
    const py = Y(500 + i * 650 + Math.cos(t * 0.00014 + i) * 80);
    const radius = S(280);
    const g = ctx.createRadialGradient(px, py, 0, px, py, radius);
    g.addColorStop(0, i === 0 ? "rgba(255,30,95,.12)" : "rgba(100,70,255,.10)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.fillRect(px - radius, py - radius, radius * 2, radius * 2);
  }

  if (background) {
    ctx.globalAlpha = 0.08;
    ctx.drawImage(background, 0, 0, W, H);
    ctx.globalAlpha = 1;
  }

  const elapsed = t / 1000;
  ctx.fillStyle = "#fff";
  for (const p of particles) {
    const y0 = (p.y - elapsed * p.speed) % 1920;
    const py = Y(y0 < 0 ? y0 + 1920 : y0);
    const px = X(p.x + Math.sin(elapsed * 0.4 + p.phase) * 8);
    ctx.globalAlpha = 0.08 + 0.04 * Math.sin(elapsed + p.phase);
    ctx.beginPath();
    ctx.arc(px, py, S(p.r), 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}

function header(t) {
  rr(X(40), Y(42), X(1000), Y(230), S(34));
  ctx.fillStyle = "rgba(255,255,255,.065)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,.11)";
  ctx.stroke();

  rr(X(70), Y(75), X(145), Y(54), S(27));
  ctx.fillStyle = "#ff315f";
  ctx.fill();

  const pulse = 1 + Math.sin(t * 0.006) * 0.08;
  ctx.save();
  ctx.translate(X(100), Y(102));
  ctx.scale(pulse, pulse);
  ctx.fillStyle = "#fff";
  ctx.beginPath();
  ctx.arc(0, 0, S(8), 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  ctx.fillStyle = "#fff";
  ctx.font = `bold ${S(25)}px Arial`;
  ctx.fillText("LIVE", X(123), Y(111));
  ctx.font = `900 ${S(58)}px Arial`;
  ctx.fillText("BIGG BOSS", X(70), Y(190));
  ctx.font = `bold ${S(25)}px Arial`;
  ctx.fillStyle = "rgba(255,255,255,.60)";
  ctx.fillText("LIVE VOTING • 24/7", X(72), Y(232));

  ctx.textAlign = "right";
  ctx.fillStyle = "rgba(255,255,255,.76)";
  ctx.font = `bold ${S(28)}px Arial`;
  ctx.fillText(`ROUND ${state.round}`, X(1010), Y(108));
  ctx.font = `bold ${S(24)}px Arial`;
  ctx.fillText(`${state.totalAcceptedVotes.toLocaleString()} TOTAL VOTES`, X(1010), Y(145));
  ctx.textAlign = "left";
}

function votePanel() {
  rr(X(40), Y(300), X(1000), Y(180), S(30));
  ctx.fillStyle = "rgba(255,255,255,.05)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,.09)";
  ctx.stroke();
  ctx.fillStyle = "#ff3d72";
  ctx.font = `bold ${S(25)}px Arial`;
  ctx.fillText("HOW TO VOTE", X(70), Y(350));
  ctx.fillStyle = "#fff";
  ctx.font = `900 ${S(48)}px Arial`;
  ctx.fillText(`${config.voteCommand} 1`, X(70), Y(415));
  ctx.fillStyle = "rgba(255,255,255,.60)";
  ctx.font = `bold ${S(23)}px Arial`;
  ctx.fillText("Replace 1 with the contestant number", X(70), Y(452));
}

function results(t) {
  const rows = stats();
  const top = 525;
  const cardH = Math.min(205, Math.floor((1920 - 800) / Math.max(rows.length, 1)));
  const maxVotes = Math.max(1, ...rows.map(row => row.votes));

  ctx.fillStyle = "#fff";
  ctx.font = `900 ${S(30)}px Arial`;
  ctx.fillText("LIVE RESULTS", X(50), Y(515));

  rows.forEach((row, index) => {
    const y = top + index * (cardH + 14);
    const ratio = row.votes / maxVotes;
    rr(X(50), Y(y), X(980), Y(cardH), S(28));
    ctx.fillStyle = "rgba(255,255,255,.06)";
    ctx.fill();

    rr(X(70), Y(y + 18), X(62), Y(62), S(18));
    ctx.fillStyle = index === 0 ? "#ff315f" : "rgba(255,255,255,.15)";
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.textAlign = "center";
    ctx.font = `900 ${S(30)}px Arial`;
    ctx.fillText(String(index + 1), X(101), Y(y + 59));
    ctx.textAlign = "left";

    ctx.font = `900 ${S(30)}px Arial`;
    ctx.fillText(row.name, X(155), Y(y + 46));
    ctx.font = `bold ${S(22)}px Arial`;
    ctx.fillStyle = "rgba(255,255,255,.55)";
    ctx.fillText(`${row.votes.toLocaleString()} votes`, X(155), Y(y + 76));

    const barY = y + cardH - 38;
    rr(X(70), Y(barY), X(940), Y(15), S(8));
    ctx.fillStyle = "rgba(255,255,255,.08)";
    ctx.fill();
    const barWidth = Math.max(ratio > 0 ? S(8) : 0, X(940) * ratio);
    rr(X(70), Y(barY), barWidth, Y(15), S(8));
    ctx.fillStyle = index === 0 ? "#ff315f" : "#7c5cff";
    ctx.fill();

    if (index === 0 && row.votes > 0) {
      const shimmer = (Math.sin(t * 0.003) + 1) * 0.5;
      ctx.globalAlpha = 0.15 + shimmer * 0.15;
      rr(X(70) + barWidth * 0.55, Y(barY), Math.min(X(160), barWidth * 0.3), Y(15), S(8));
      ctx.fillStyle = "#fff";
      ctx.fill();
      ctx.globalAlpha = 1;
      ctx.fillStyle = "#ff7795";
      ctx.font = `bold ${S(19)}px Arial`;
      ctx.fillText("LEADING", X(850), Y(y + 48));
    }
  });

  const elapsed = Math.max(0, Date.now() - state.roundStartedAt);
  const duration = config.voteDurationSeconds * 1000;
  const pct = Math.max(0, Math.min(1, 1 - elapsed / duration));
  const py = 1770;
  rr(X(50), Y(py), X(980), Y(12), S(6));
  ctx.fillStyle = "rgba(255,255,255,.08)";
  ctx.fill();
  rr(X(50), Y(py), X(980) * pct, Y(12), S(6));
  ctx.fillStyle = "#ff315f";
  ctx.fill();

  ctx.fillStyle = "rgba(255,255,255,.55)";
  ctx.font = `bold ${S(21)}px Arial`;
  ctx.textAlign = "left";
  ctx.fillText("VOTE NOW • RESULTS UPDATE LIVE", X(50), Y(1825));
  ctx.textAlign = "right";
  ctx.fillText(`${config.width}×${config.height} • ${config.fps} FPS`, X(1030), Y(1825));
  ctx.textAlign = "left";
}

function render(timestamp) {
  backgroundFrame(timestamp);
  header(timestamp);
  votePanel();
  results(timestamp);
  const imageData = ctx.getImageData(0, 0, W, H);
  return Buffer.from(imageData.data.buffer, imageData.data.byteOffset, imageData.data.byteLength);
}

async function startEncoderIfNeeded() {
  const now = Date.now();
  if (encoder && encoder.exitCode === null && !encoder.killed && !encoder.stdin.destroyed) return true;
  if (now < encoderRetryAt) return false;

  try {
    encoder = createEncoder();
    const ok = await waitForEncoderStart(encoder);
    if (!ok) throw new Error("FFmpeg exited during startup");
    encoderRetryMs = config.encoderRestartMinMs;
    encoderRetryAt = 0;
    runtime.encoder.restarts++;
    return true;
  } catch (error) {
    runtime.encoder.lastError = error.message;
    console.error(`[ffmpeg] startup failed: ${error.message}`);
    try { await stopEncoder(encoder); } catch {}
    encoder = null;
    encoderRetryAt = now + encoderRetryMs;
    encoderRetryMs = Math.min(encoderRetryMs * 2, config.encoderRestartMaxMs);
    return false;
  }
}

async function restartEncoder(reason) {
  const current = encoder;
  encoder = null;
  if (current) await stopEncoder(current);
  encoderRetryAt = Date.now() + encoderRetryMs;
  encoderRetryMs = Math.min(encoderRetryMs * 2, config.encoderRestartMaxMs);
  runtime.encoder.lastError = reason;
}

export async function startRenderer() {
  await loadBackground();
  running = true;
  startedAt = Date.now();
  let nextDeadline = performance.now();
  const frameInterval = 1000 / config.fps;

  console.log(`[renderer] internal ${W}x${H}@${config.fps}, output ${config.width}x${config.height}`);

  while (running) {
    const now = performance.now();
    if (now < nextDeadline) {
      await sleep(Math.min(8, Math.max(1, nextDeadline - now)));
      continue;
    }

    nextDeadline += frameInterval;
    if (nextDeadline < now - frameInterval * 2) nextDeadline = now + frameInterval;

    const rssMB = Math.round(process.memoryUsage().rss / 1024 / 1024);
    if (rssMB >= config.memoryExitMB) {
      throw new Error(`memory guard: RSS ${rssMB}MB >= ${config.memoryExitMB}MB`);
    }
    if (rssMB >= config.memoryWarnMB && Date.now() - runtime.encoder.lastLogAt > 10000) {
      console.warn(`[memory] RSS ${rssMB}MB`);
      runtime.encoder.lastLogAt = Date.now();
    }

    if (!(await startEncoderIfNeeded())) {
      await sleep(100);
      continue;
    }

    const raw = render(now);
    const ok = await writeFrame(encoder, raw);
    if (!ok) {
      runtime.renderer.dropped++;
      await restartEncoder("frame pipe unavailable or stalled");
      continue;
    }

    runtime.renderer.frames++;
    runtime.renderer.lastFrameAt = Date.now();
    if (Date.now() - startedAt > 0) {
      runtime.renderer.fps = runtime.renderer.frames / ((Date.now() - startedAt) / 1000);
    }

    if (runtime.renderer.frames - lastLogFrame >= config.fps * 10) {
      lastLogFrame = runtime.renderer.frames;
      console.log(`[renderer] frames=${runtime.renderer.frames} dropped=${runtime.renderer.dropped} uptime=${Math.floor((Date.now() - startedAt) / 1000)}s rss=${rssMB}MB encoder=${runtime.encoder.status}`);
    }
  }
}

export async function stopRenderer() {
  running = false;
  const current = encoder;
  encoder = null;
  await stopEncoder(current);
}
