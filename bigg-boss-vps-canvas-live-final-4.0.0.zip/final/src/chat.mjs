import { Masterchat, stringify } from "@stu43005/masterchat";
import { config } from "./config.mjs";
import { addChat, acceptVote, saveState, setOwner } from "./state.mjs";
import { runtime } from "./runtime.mjs";

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function authorId(action) {
  return action?.authorChannelId || action?.channelId || action?.author?.channelId || action?.author?.id || null;
}
function isOwner(action) {
  return Boolean(action?.isChatOwner || action?.isOwner || action?.authorIsChatOwner || action?.author?.isChatOwner);
}
function isModerator(action) {
  return Boolean(action?.isChatModerator || action?.isModerator || action?.author?.isChatModerator);
}
function parseVote(text) {
  const escaped = config.voteCommand.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = String(text).match(new RegExp(`^\\s*${escaped}\\s+(\\d+)\\s*$`, "i"));
  return match ? Number(match[1]) : null;
}
function getText(action) {
  try { return stringify(action?.message ?? action?.messageRuns ?? ""); } catch { return ""; }
}

export function startChatLoop({ onChat, onVote, signal }) {
  const task = (async () => {
    let delay = 5000;

    while (!signal.aborted) {
      let mc = null;
      runtime.chat.status = "connecting";

      try {
        console.log(`[chat] connecting to ${config.videoId}`);
        mc = await Masterchat.init(config.videoId);
        if (signal.aborted) break;

        console.log("[chat] connected");
        runtime.chat.status = "connected";
        runtime.chat.lastError = null;
        delay = 5000;

        const iterable = mc?.iterate?.();
        if (!iterable || typeof iterable[Symbol.asyncIterator] !== "function") {
          throw new Error("Masterchat iterate() did not return an async iterable");
        }

        for await (const action of iterable) {
          if (signal.aborted) break;
          if (!action || action.type !== "addChatItemAction") continue;

          const text = getText(action);
          const name = action.authorName || action.author?.name || "Viewer";
          const id = authorId(action);
          const owner = isOwner(action);
          const moderator = isModerator(action);

          runtime.chat.lastEventAt = Date.now();
          if (owner && id) setOwner(id, name);
          if (text) addChat(name, text);

          const vote = parseVote(text);
          if (vote !== null && id && acceptVote(id, vote, name)) {
            console.log(`[vote] ${name} -> contestant ${vote}`);
            onVote?.({ contestant: vote, name, userId: id });
            await saveState();
          }

          onChat?.({ name, text, userId: id, isOwner: owner, isModerator: moderator });
        }
      } catch (error) {
        runtime.chat.status = "error";
        runtime.chat.lastError = error?.message || String(error);
        if (!signal.aborted) console.error(`[chat] disconnected: ${runtime.chat.lastError}`);
      } finally {
        runtime.chat.reconnects++;
        try { mc?.stop?.(); } catch {}
      }

      if (signal.aborted) break;
      runtime.chat.status = "waiting";
      console.log(`[chat] retrying in ${Math.ceil(delay / 1000)}s`);
      await sleep(delay);
      delay = Math.min(delay * 2, 60000);
    }

    runtime.chat.status = "stopped";
  })();

  return task;
}
