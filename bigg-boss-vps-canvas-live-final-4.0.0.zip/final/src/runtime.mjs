export const runtime = {
  startedAt: Date.now(),
  stopping: false,
  renderer: {
    frames: 0,
    dropped: 0,
    lastFrameAt: 0,
    fps: 0,
  },
  encoder: {
    status: "stopped",
    pid: null,
    starts: 0,
    restarts: 0,
    lastExitCode: null,
    lastSignal: null,
    lastError: null,
    connectedHint: false,
    lastLogAt: 0,
  },
  chat: {
    status: "stopped",
    reconnects: 0,
    lastError: null,
    lastEventAt: 0,
  },
  lastHealthAt: Date.now(),
};
