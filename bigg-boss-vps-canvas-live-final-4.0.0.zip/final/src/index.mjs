import { config, validateConfig } from "./config.mjs";
import { loadState, saveState, resetRound, state } from "./state.mjs";
import { startChatLoop } from "./chat.mjs";
import { startRenderer, stopRenderer } from "./renderer.mjs";
import { startHealthServer } from "./health.mjs";
import { runtime } from "./runtime.mjs";

let shutdownPromise = null;
const controller = new AbortController();

async function main() {
  const validation = validateConfig();
  if (validation.errors.length) {
    console.error("Configuration errors:");
    validation.errors.forEach(error => console.error(` - ${error}`));
    process.exitCode = 1;
    return;
  }
  validation.warnings.forEach(warning => console.warn(`[config] ${warning}`));

  await loadState();
  const health = startHealthServer();

  console.log("==========================================");
  console.log(" Bigg Boss VPS Canvas Live — FINAL");
  console.log(` output ${config.width}x${config.height}@${config.fps}`);
  console.log(` render ${config.renderWidth}x${config.renderHeight}`);
  console.log("==========================================");

  let roundBusy = false;
  const roundTimer = setInterval(async () => {
    if (roundBusy || runtime.stopping) return;
    if (Date.now() - state.roundStartedAt < config.voteDurationSeconds * 1000) return;
    roundBusy = true;
    try {
      resetRound();
      await saveState();
      console.log(`[vote] round ${state.round} started`);
    } finally {
      roundBusy = false;
    }
  }, 1000);

  const saveTimer = setInterval(() => {
    if (!runtime.stopping) saveState();
  }, 15000);

  startChatLoop({ signal: controller.signal }).catch(error => {
    if (!controller.signal.aborted) console.error(`[chat] fatal: ${error.message}`);
  });

  try {
    await startRenderer();
  } finally {
    clearInterval(roundTimer);
    clearInterval(saveTimer);
    controller.abort();
    await stopRenderer();
    await saveState();
    health.stop();
  }
}

async function shutdown(signal) {
  if (shutdownPromise) return shutdownPromise;
  shutdownPromise = (async () => {
    runtime.stopping = true;
    console.log(`[main] received ${signal}`);
    controller.abort();
    await stopRenderer();
    await saveState();
    process.exit(0);
  })();
  return shutdownPromise;
}

process.on("SIGINT", () => { void shutdown("SIGINT"); });
process.on("SIGTERM", () => { void shutdown("SIGTERM"); });
process.on("uncaughtException", error => {
  console.error(`[main] uncaught exception: ${error.stack || error.message}`);
  void shutdown("uncaughtException");
});
process.on("unhandledRejection", error => {
  console.error(`[main] unhandled rejection: ${error?.stack || error}`);
});

main().catch(error => {
  console.error(`[main] fatal: ${error.stack || error.message}`);
  void shutdown("fatal");
});
