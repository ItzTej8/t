import { createCanvas } from "@napi-rs/canvas";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { config } from "./config.mjs";

function fail(message) {
  console.error(`SELF-CHECK FAILED: ${message}`);
  process.exit(1);
}

const canvas = createCanvas(config.renderWidth, config.renderHeight);
const ctx = canvas.getContext("2d");
ctx.fillStyle = "#111";
ctx.fillRect(0, 0, config.renderWidth, config.renderHeight);
ctx.fillStyle = "#fff";
ctx.fillRect(0, 0, 2, 2);
const imageData = ctx.getImageData(0, 0, config.renderWidth, config.renderHeight);
const frame = Buffer.from(imageData.data.buffer, imageData.data.byteOffset, imageData.data.byteLength);
const expected = config.renderWidth * config.renderHeight * 4;
if (frame.length !== expected) fail(`RGBA frame is ${frame.length}, expected ${expected}`);

const ffmpeg = spawn("ffmpeg", [
  "-hide_banner", "-loglevel", "error",
  "-f", "rawvideo", "-pixel_format", "rgba",
  "-video_size", `${config.renderWidth}x${config.renderHeight}`,
  "-framerate", "1", "-i", "pipe:0",
  "-frames:v", "1", "-f", "null", "-"
], { stdio: ["pipe", "pipe", "pipe"] });

ffmpeg.stdin.end(frame);
const [code] = await once(ffmpeg, "close");
if (code !== 0) fail(`FFmpeg rawvideo validation exited with code ${code}`);

console.log("SELF-CHECK OK");
console.log(`Canvas: ${config.renderWidth}x${config.renderHeight}`);
console.log(`RGBA frame: ${frame.length} bytes`);
console.log(`Output: ${config.width}x${config.height}@${config.fps}`);
console.log("FFmpeg rawvideo pipe: OK");
