import { config } from "./config.mjs";
import { state } from "./state.mjs";
import { runtime } from "./runtime.mjs";

export function startHealthServer() {
  const server = Bun.serve({
    hostname: "127.0.0.1",
    port: config.healthPort,
    fetch(req) {
      if (new URL(req.url).pathname !== "/") return new Response("Not Found", { status: 404 });
      const rss = Math.round(process.memoryUsage().rss / 1024 / 1024);
      return Response.json({
        ok: !runtime.stopping,
        uptimeSeconds: Math.floor(process.uptime()),
        round: state.round,
        totalVotes: state.totalAcceptedVotes,
        memoryMB: rss,
        pid: process.pid,
        renderer: runtime.renderer,
        encoder: runtime.encoder,
        chat: runtime.chat,
      });
    }
  });
  console.log(`[health] http://127.0.0.1:${config.healthPort}`);
  return server;
}
