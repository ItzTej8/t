#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/bigg-boss-vps-canvas"
SERVICE_FILE="/etc/systemd/system/bigg-boss-vps-canvas.service"

if [[ "$(id -u)" != "0" ]]; then
  echo "Run this script with sudo."
  exit 1
fi

mkdir -p "$APP_DIR"
cp -a ./. "$APP_DIR/"
chown -R admin:admin "$APP_DIR"
install -m 0644 systemd-bigg-boss.service "$SERVICE_FILE"
sed -i 's#^WorkingDirectory=.*#WorkingDirectory=/opt/bigg-boss-vps-canvas#' "$SERVICE_FILE"
sed -i 's#^ExecStart=.*#ExecStart=/usr/local/bin/bun run src/index.mjs#' "$SERVICE_FILE"
systemctl daemon-reload
systemctl enable --now bigg-boss-vps-canvas.service
systemctl --no-pager --full status bigg-boss-vps-canvas.service
