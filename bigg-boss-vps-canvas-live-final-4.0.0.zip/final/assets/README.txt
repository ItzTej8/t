Optional assets go here.

Set BACKGROUND_IMAGE in .env to a licensed image path.
Do not place secrets in this directory.
