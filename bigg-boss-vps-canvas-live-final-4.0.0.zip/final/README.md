# Bigg Boss VPS Canvas Live — FINAL 4.0.0

A browser-free 24/7 vertical YouTube Live renderer for Debian VPS.

## Production architecture

YouTube Live Chat → Masterchat 2.1 → Bun state/voting → native `@napi-rs/canvas` → bounded RGBA pipe → FFmpeg/libx264 → YouTube RTMP.

No Chromium, Puppeteer, X11, OBS, or browser screenshots.

`@napi-rs/canvas` is a native Skia-backed canvas implementation; this project intentionally uses 2D Canvas rather than browser WebGL because the target VPS is CPU-oriented and does not require a browser/GPU stack. The project renders at 720×1280 internally and scales once in FFmpeg to 1080×1920. @napi-rs/canvas: https://github.com/Brooooooklyn/canvas

## Important fixes in 4.0.0

### FFmpeg pipe/backpressure

The renderer **does not call `stdin.write()` and immediately render another frame forever**. A raw 720×1280 RGBA frame is about 3.69 MB. The code waits for FFmpeg's `drain` event when the pipe is full and has a timeout. This keeps memory bounded instead of allowing an unlimited queue of raw frames.

### Encoder recovery

If FFmpeg exits or its pipe stalls, the renderer closes the failed encoder and starts it again using exponential backoff. The main process stays alive so systemd does not need to restart the whole application for a transient encoder failure.

### Memory protection

The application logs memory usage and has a configurable RSS guard. The included systemd service also has a 2 GB memory ceiling and automatic restart.

### Masterchat

The installed package is `@stu43005/masterchat@2.1.0`. Its runtime API is handled as:

```js
for await (const action of mc.iterate()) {
  // ...
}
```

There is deliberately no `.filter()` chained onto `iterate()` because the runtime object exposes an async iterable rather than an Array.

### State safety

State writes are serialized and written to a temporary file before atomic rename. A crash during a save therefore does not intentionally overwrite the last complete state file with partial JSON.

### Shutdown

SIGINT/SIGTERM abort chat, stop the renderer, close FFmpeg cleanly, save state, and then exit. The raw-video `Packet corrupt` messages caused by killing FFmpeg while a frame is half-written are avoided as far as the process can control them.

## Recommended Contabo 4 vCPU / 8 GB profile

```env
WIDTH=1080
HEIGHT=1920
FPS=30
BITRATE=3500k
PRESET=ultrafast
ENCODER_THREADS=3
RENDER_WIDTH=720
RENDER_HEIGHT=1280
```

The internal Canvas is deliberately 720×1280. Do **not** switch it to 1080×1920 until the VPS has demonstrated stable CPU/RSS for a long run.

If CPU remains high, the safest next step is to stream 720×1280 directly instead of trying to make the animation renderer more complex.

## Setup

```bash
bun install
cp .env.example .env
nano .env
bun run check
bun start
```

Required:

```env
YOUTUBE_STREAM_KEY=YOUR_REAL_STREAM_KEY
YOUTUBE_VIDEO_ID=YOUR_CURRENT_LIVE_VIDEO_ID
```

Never commit the stream key.

## Health endpoint

The process exposes health information only on localhost:

```text
http://127.0.0.1:8787/
```

Example:

```bash
curl http://127.0.0.1:8787/
```

It reports renderer frames, dropped frames, encoder state, chat state, RSS, uptime and voting totals.

## 24/7 systemd

Copy the project to `/opt/bigg-boss-vps-canvas`, make sure `/usr/local/bin/bun` exists, then:

```bash
sudo ./install-systemd.sh
```

Check:

```bash
systemctl status bigg-boss-vps-canvas
journalctl -u bigg-boss-vps-canvas -f
```

## What the logs mean

Normal:

```text
[ffmpeg] started pid=...
[chat] connected
[renderer] frames=300 dropped=0 ...
```

A temporary encoder problem should look like:

```text
[ffmpeg] frame pipe stalled: ...
[ffmpeg] exited ...
```

followed by a controlled restart rather than an immediate process death.

If you see:

```text
memory guard: RSS ...
```

the application intentionally exits so systemd can restart it instead of allowing uncontrolled memory growth.

## Assets and copyright

Only use contestant images, logos, music, video clips and other media that you have the rights or permission to rebroadcast.
