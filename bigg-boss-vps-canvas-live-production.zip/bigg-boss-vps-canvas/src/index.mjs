import { config, validateConfig } from "./config.mjs";
import { loadState, saveState, resetRound, state } from "./state.mjs";
import { runChatLoop } from "./chat.mjs";
import { startRenderer, stopRenderer } from "./renderer.mjs";
import { startHealthServer } from "./health.mjs";

let stopping = false;

async function main() {
  const errors = validateConfig();
  if (errors.length) {
    console.error("Configuration errors:");
    for (const e of errors) console.error(` - ${e}`);
    process.exit(1);
  }

  await loadState();
  state.roundStartedAt ??= Date.now();
  const health = startHealthServer();

  console.log("==========================================");
  console.log(" Bigg Boss VPS Canvas Live");
  console.log(` ${config.width}x${config.height}@${config.fps}`);
  console.log("==========================================");

  const saveTimer = setInterval(() => {
    saveState().catch(e => console.error("[state] save:", e.message));
  }, 15000);

  const roundTimer = setInterval(async () => {
    if (Date.now() - (state.roundStartedAt || Date.now()) >= config.voteDurationSeconds * 1000) {
      resetRound();
      state.roundStartedAt = Date.now();
      await saveState();
      console.log(`[vote] round ${state.round} started`);
    }
  }, 1000);

  runChatLoop({
    onChat: () => {},
    onVote: () => {}
  }).catch(e => console.error("[chat] fatal:", e));

  try {
    await startRenderer();
  } finally {
    clearInterval(saveTimer);
    clearInterval(roundTimer);
    health.stop();
    await saveState();
  }
}

async function shutdown(signal) {
  if (stopping) return;
  stopping = true;
  console.log(`[main] received ${signal}`);
  await stopRenderer();
  await saveState().catch(() => {});
  process.exit(0);
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

main().catch(async e => {
  console.error("[main] fatal:", e);
  await shutdown("fatal");
});
