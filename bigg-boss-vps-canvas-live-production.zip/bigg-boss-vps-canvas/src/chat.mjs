import { Masterchat, stringify } from "@stu43005/masterchat";
import { config } from "./config.mjs";
import { addChat, acceptVote, saveState, setOwner } from "./state.mjs";

const sleep = ms => new Promise(r => setTimeout(r, ms));

function authorId(a) {
  return a?.authorChannelId || a?.channelId || a?.author?.channelId || a?.author?.id || null;
}
function isOwner(a) {
  return Boolean(a?.isChatOwner || a?.isOwner || a?.authorIsChatOwner || a?.author?.isChatOwner);
}
function isModerator(a) {
  return Boolean(a?.isChatModerator || a?.isModerator || a?.author?.isChatModerator);
}
function parseVote(text) {
  const command = config.voteCommand.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const m = String(text).match(new RegExp(`^\\s*${command}\\s+(\\d+)\\s*$`, "i"));
  return m ? Number(m[1]) : null;
}
function textOf(a) {
  try { return stringify(a?.message ?? a?.messageRuns ?? ""); } catch { return ""; }
}

export async function runChatLoop({ onChat, onVote }) {
  let delay = 5000;

  while (true) {
    let mc;
    try {
      console.log(`[chat] connecting to ${config.videoId}`);
      mc = await Masterchat.init(config.videoId);
      console.log("[chat] connected");
      delay = 5000;

      // Masterchat 2.x exposes an async iterable named `iterate()`.
      for await (const action of mc.iterate()) {
        if (!action || action.type !== "addChatItemAction") continue;

        const text = textOf(action);
        const name = action.authorName || action.author?.name || "Viewer";
        const id = authorId(action);
        const owner = isOwner(action);
        const moderator = isModerator(action);

        if (owner && id) setOwner(id, name);
        if (text) addChat(name, text);

        const vote = parseVote(text);
        if (vote !== null && id && acceptVote(id, vote, name)) {
          console.log(`[vote] ${name} -> ${vote}`);
          onVote?.({ contestant: vote, name, userId: id });
          await saveState();
        }

        onChat?.({ name, text, userId: id, isOwner: owner, isModerator: moderator });
      }
    } catch (error) {
      console.error(`[chat] disconnected: ${error?.message || error}`);
    } finally {
      try { mc?.stop?.(); } catch {}
    }

    console.log(`[chat] retrying in ${Math.round(delay / 1000)}s`);
    await sleep(delay);
    delay = Math.min(delay * 2, 60000);
  }
}
