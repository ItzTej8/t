const num = (key, fallback) => {
  const n = Number(process.env[key]);
  return Number.isFinite(n) ? n : fallback;
};

const csv = (key, fallback) =>
  String(process.env[key] ?? fallback)
    .split(",")
    .map(s => s.trim())
    .filter(Boolean);

export const config = {
  rtmpUrl: String(process.env.YOUTUBE_RTMP_URL || "rtmp://a.rtmp.youtube.com/live2").replace(/\/$/, ""),
  streamKey: String(process.env.YOUTUBE_STREAM_KEY || ""),
  videoId: String(process.env.YOUTUBE_VIDEO_ID || ""),

  width: Math.max(320, Math.floor(num("WIDTH", 1080))),
  height: Math.max(320, Math.floor(num("HEIGHT", 1920))),
  fps: Math.max(1, Math.floor(num("FPS", 30))),
  bitrate: String(process.env.BITRATE || "3500k"),
  preset: String(process.env.PRESET || "superfast"),
  encoderThreads: Math.max(1, Math.floor(num("ENCODER_THREADS", 3))),
  gopSeconds: Math.max(1, Math.floor(num("GOP_SECONDS", 2))),

  voteCommand: String(process.env.VOTE_COMMAND || "!vote"),
  voteDurationSeconds: Math.max(10, Math.floor(num("VOTE_DURATION_SECONDS", 60))),
  contestants: csv("CONTESTANTS", "Contestant 1,Contestant 2,Contestant 3,Contestant 4"),

  healthPort: Math.max(1, Math.floor(num("HEALTH_PORT", 8787))),
  stateFile: String(process.env.STATE_FILE || "data/state.json"),
  backgroundImage: String(process.env.BACKGROUND_IMAGE || "")
};

export function validateConfig() {
  const errors = [];
  if (!config.streamKey || config.streamKey.includes("PUT_YOUR")) errors.push("YOUTUBE_STREAM_KEY is not configured");
  if (!config.videoId || config.videoId.includes("PUT_YOUR")) errors.push("YOUTUBE_VIDEO_ID is not configured");
  if (config.width * config.height > 1080 * 1920) errors.push("Resolution is larger than the supported production target");
  return errors;
}
