import { state } from "./state.mjs";
import { config } from "./config.mjs";

export function startHealthServer() {
  const server = Bun.serve({
    hostname: "127.0.0.1",
    port: config.healthPort,
    fetch() {
      return Response.json({
        ok: true,
        uptimeSeconds: Math.floor(process.uptime()),
        round: state.round,
        totalVotes: state.totalAcceptedVotes,
        memoryMB: Math.round(process.memoryUsage().rss / 1024 / 1024),
        fps: config.fps,
        resolution: `${config.width}x${config.height}`
      });
    }
  });
  console.log(`[health] http://127.0.0.1:${server.port}`);
  return server;
}
