import { spawn } from "node:child_process";
import { config } from "./config.mjs";

export function createEncoder() {
  const url = `${config.rtmpUrl}/${config.streamKey}`;
  const args = [
    "-hide_banner",
    "-loglevel", "warning",
    "-f", "rawvideo",
    "-pix_fmt", "rgba",
    "-video_size", `${config.width}x${config.height}`,
    "-framerate", String(config.fps),
    "-i", "pipe:0",

    "-f", "lavfi",
    "-i", "anullsrc=r=44100:cl=stereo",

    "-map", "0:v:0",
    "-map", "1:a:0",
    "-c:v", "libx264",
    "-preset", config.preset,
    "-tune", "zerolatency",
    "-threads", String(config.encoderThreads),
    "-pix_fmt", "yuv420p",
    "-b:v", config.bitrate,
    "-maxrate", config.bitrate,
    "-bufsize", `${parseInt(config.bitrate, 10) * 2}k`,
    "-g", String(config.fps * config.gopSeconds),
    "-keyint_min", String(config.fps * config.gopSeconds),
    "-sc_threshold", "0",
    "-c:a", "aac",
    "-b:a", "128k",
    "-ar", "44100",
    "-f", "flv",
    url
  ];

  const child = spawn("ffmpeg", args, { stdio: ["pipe", "ignore", "pipe"] });
  child.stderr.on("data", d => {
    const s = d.toString().trim();
    if (s) console.log(`[ffmpeg] ${s}`);
  });
  return child;
}

export function writeFrame(child, buffer) {
  if (!child || child.exitCode !== null || !child.stdin.writable) return false;
  return child.stdin.write(buffer);
}
