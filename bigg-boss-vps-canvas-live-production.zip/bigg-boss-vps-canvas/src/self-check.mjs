import { createCanvas } from "@napi-rs/canvas";
import { config } from "./config.mjs";
const c = createCanvas(config.width, config.height);
const x = c.getContext("2d");
x.fillStyle = "#000";
x.fillRect(0, 0, 4, 4);
console.log("Canvas OK:", c.width, c.height);
console.log("Resolution:", `${config.width}x${config.height}`);
console.log("FPS:", config.fps);
