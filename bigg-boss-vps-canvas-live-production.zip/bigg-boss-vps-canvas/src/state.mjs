import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { config } from "./config.mjs";

const initial = () => ({
  version: 3,
  round: 1,
  contestants: Object.fromEntries(config.contestants.map((name, i) => [
    i + 1,
    { no: i + 1, name, votes: 0 }
  ])),
  voters: {},
  recentChat: [],
  recentVotes: [],
  totalAcceptedVotes: 0,
  lastVote: null,
  lastVoteAt: 0,
  ownerId: null,
  ownerName: null,
  updatedAt: Date.now()
});

export const state = initial();

export async function loadState() {
  try {
    const raw = JSON.parse(await readFile(config.stateFile, "utf8"));
    if (raw?.contestants) Object.assign(state, raw);
    console.log(`[state] loaded round ${state.round}, total votes ${state.totalAcceptedVotes}`);
  } catch {
    console.log("[state] starting fresh");
  }
}

export async function saveState() {
  state.updatedAt = Date.now();
  await mkdir(dirname(config.stateFile), { recursive: true });
  await writeFile(config.stateFile, JSON.stringify(state, null, 2));
}

export function setOwner(id, name) {
  if (!state.ownerId) {
    state.ownerId = id;
    state.ownerName = name;
  }
}

export function addChat(name, text) {
  state.recentChat.push({ name, text, at: Date.now() });
  if (state.recentChat.length > 12) state.recentChat.shift();
}

export function acceptVote(userId, contestant, name) {
  if (!state.contestants[contestant]) return false;
  if (state.voters[userId]) return false;

  state.voters[userId] = {
    contestant,
    name: name || "Viewer",
    at: Date.now()
  };

  state.contestants[contestant].votes++;
  state.totalAcceptedVotes++;
  state.lastVote = {
    contestant,
    name: name || "Viewer",
    at: Date.now()
  };
  state.lastVoteAt = Date.now();

  state.recentVotes.push(state.lastVote);
  if (state.recentVotes.length > 8) state.recentVotes.shift();

  return true;
}

export function resetRound() {
  state.round++;
  state.voters = {};
  state.recentVotes = [];
  state.lastVote = null;
  state.lastVoteAt = 0;
}

export function stats() {
  return Object.values(state.contestants)
    .sort((a, b) => b.votes - a.votes || a.no - b.no);
}
