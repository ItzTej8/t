import { createCanvas, loadImage } from "@napi-rs/canvas";
import { readFile } from "node:fs/promises";
import { config } from "./config.mjs";
import { state, stats } from "./state.mjs";
import { createEncoder, writeFrame } from "./ffmpeg.mjs";

const canvas = createCanvas(config.width, config.height);
const ctx = canvas.getContext("2d");

let encoder = null;
let running = false;
let startAt = Date.now();
let bgImage = null;

const particles = Array.from({ length: 26 }, (_, i) => ({
  x: (i * 137.7) % config.width,
  y: (i * 251.3) % config.height,
  r: 2 + (i % 4),
  speed: 6 + (i % 7),
  phase: i * 0.7
}));

async function loadBackground() {
  if (!config.backgroundImage) return;
  try {
    const data = await readFile(config.backgroundImage);
    bgImage = await loadImage(data);
  } catch {
    console.log("[renderer] background image unavailable; using generated background");
  }
}

function roundedRect(x, y, w, h, r) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
}

function drawBackground(t) {
  const g = ctx.createLinearGradient(0, 0, config.width, config.height);
  g.addColorStop(0, "#080611");
  g.addColorStop(0.5, "#14091f");
  g.addColorStop(1, "#05050b");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, config.width, config.height);

  const pulse = 0.5 + 0.5 * Math.sin(t * 0.00035);
  for (let i = 0; i < 3; i++) {
    const x = config.width * (0.2 + i * 0.32) + Math.sin(t * 0.00018 + i) * 90;
    const y = config.height * (0.25 + i * 0.25);
    const r = 280 + pulse * 70;
    const rg = ctx.createRadialGradient(x, y, 0, x, y, r);
    rg.addColorStop(0, i === 0 ? "rgba(255,45,120,.13)" : "rgba(100,70,255,.11)");
    rg.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = rg;
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
  }

  if (bgImage) {
    ctx.globalAlpha = 0.12;
    ctx.drawImage(bgImage, 0, 0, config.width, config.height);
    ctx.globalAlpha = 1;
  }

  for (const p of particles) {
    const y = (p.y - ((t / 1000) * p.speed)) % config.height;
    ctx.globalAlpha = 0.12 + 0.08 * Math.sin(t * 0.001 + p.phase);
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(p.x, y < 0 ? y + config.height : y, p.r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}

function drawHeader(t) {
  roundedRect(40, 42, config.width - 80, 230, 34);
  ctx.fillStyle = "rgba(255,255,255,.075)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,.13)";
  ctx.stroke();

  ctx.fillStyle = "#ff315f";
  roundedRect(70, 75, 145, 54, 27);
  ctx.fill();

  const pulse = 1 + Math.sin(t * 0.006) * 0.08;
  ctx.save();
  ctx.translate(100, 102);
  ctx.scale(pulse, pulse);
  ctx.fillStyle = "#fff";
  ctx.beginPath();
  ctx.arc(0, 0, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  ctx.font = "bold 25px Arial";
  ctx.fillStyle = "#fff";
  ctx.fillText("LIVE", 123, 111);

  ctx.font = "900 58px Arial";
  ctx.fillStyle = "#fff";
  ctx.fillText("BIGG BOSS", 70, 190);

  ctx.font = "bold 25px Arial";
  ctx.fillStyle = "rgba(255,255,255,.62)";
  ctx.fillText("LIVE VOTING • 24/7", 72, 232);

  ctx.textAlign = "right";
  ctx.font = "bold 28px Arial";
  ctx.fillStyle = "rgba(255,255,255,.75)";
  ctx.fillText(`ROUND ${state.round}`, config.width - 70, 108);
  ctx.font = "bold 24px Arial";
  ctx.fillText(`${state.totalAcceptedVotes.toLocaleString()} TOTAL VOTES`, config.width - 70, 145);
  ctx.textAlign = "left";
}

function drawVotingPanel() {
  roundedRect(40, 300, config.width - 80, 180, 30);
  ctx.fillStyle = "rgba(255,255,255,.055)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,.1)";
  ctx.stroke();

  ctx.font = "bold 25px Arial";
  ctx.fillStyle = "#ff3d72";
  ctx.fillText("HOW TO VOTE", 70, 350);

  ctx.font = "900 48px Arial";
  ctx.fillStyle = "#fff";
  ctx.fillText(`${config.voteCommand} 1`, 70, 415);

  ctx.font = "bold 23px Arial";
  ctx.fillStyle = "rgba(255,255,255,.62)";
  ctx.fillText("Replace 1 with the contestant number", 70, 452);
}

function drawResults(t) {
  const rows = stats();
  const top = 525;
  const cardH = Math.min(205, Math.floor((config.height - 800) / Math.max(rows.length, 1)));
  const maxVotes = Math.max(1, ...rows.map(x => x.votes));

  ctx.font = "900 30px Arial";
  ctx.fillStyle = "#fff";
  ctx.fillText("LIVE RESULTS", 50, 515);

  rows.forEach((row, index) => {
    const y = top + index * (cardH + 14);
    const ratio = row.votes / maxVotes;
    const targetW = (config.width - 100) * ratio;

    roundedRect(50, y, config.width - 100, cardH, 28);
    ctx.fillStyle = "rgba(255,255,255,.065)";
    ctx.fill();

    ctx.fillStyle = index === 0 ? "#ff315f" : "rgba(255,255,255,.16)";
    roundedRect(70, y + 18, 62, 62, 18);
    ctx.fill();

    ctx.fillStyle = "#fff";
    ctx.textAlign = "center";
    ctx.font = "900 30px Arial";
    ctx.fillText(String(index + 1), 101, y + 59);
    ctx.textAlign = "left";

    ctx.font = "900 30px Arial";
    ctx.fillStyle = "#fff";
    ctx.fillText(row.name, 155, y + 46);

    ctx.font = "bold 22px Arial";
    ctx.fillStyle = "rgba(255,255,255,.55)";
    ctx.fillText(`${row.votes.toLocaleString()} votes`, 155, y + 76);

    const barY = y + cardH - 38;
    roundedRect(70, barY, config.width - 140, 15, 8);
    ctx.fillStyle = "rgba(255,255,255,.09)";
    ctx.fill();

    roundedRect(70, barY, Math.max(8, (config.width - 140) * ratio), 15, 8);
    ctx.fillStyle = index === 0 ? "#ff315f" : "#7c5cff";
    ctx.fill();

    if (index === 0) {
      ctx.font = "bold 19px Arial";
      ctx.fillStyle = "#ff7795";
      ctx.fillText("🔥 LEADING", config.width - 235, y + 48);
    }
  });

  const left = Math.max(0, config.voteDurationSeconds * 1000 - (Date.now() - state.roundStartedAt || 0));
  const pct = Math.max(0, Math.min(1, left / (config.voteDurationSeconds * 1000)));
  const py = config.height - 150;
  roundedRect(50, py, config.width - 100, 12, 6);
  ctx.fillStyle = "rgba(255,255,255,.08)";
  ctx.fill();
  roundedRect(50, py, (config.width - 100) * pct, 12, 6);
  ctx.fillStyle = "#ff315f";
  ctx.fill();

  ctx.font = "bold 21px Arial";
  ctx.fillStyle = "rgba(255,255,255,.55)";
  ctx.fillText("VOTE NOW • RESULTS UPDATE LIVE", 50, config.height - 95);
  ctx.textAlign = "right";
  ctx.fillText(`1080×1920 • ${config.fps} FPS`, config.width - 50, config.height - 95);
  ctx.textAlign = "left";
}

function render(t) {
  drawBackground(t);
  drawHeader(t);
  drawVotingPanel();
  drawResults(t);

  const imageData = ctx.getImageData(0, 0, config.width, config.height);
  return Buffer.from(imageData.data.buffer, imageData.data.byteOffset, imageData.data.byteLength);
}

export async function startRenderer() {
  await loadBackground();
  encoder = createEncoder();
  running = true;
  startAt = Date.now();

  let frame = 0;
  let next = performance.now();

  while (running && encoder.exitCode === null) {
    const now = performance.now();
    if (now < next) {
      await new Promise(r => setTimeout(r, Math.max(0, next - now)));
      continue;
    }

    // Never try to "catch up" after CPU stalls.
    next = performance.now() + 1000 / config.fps;

    const raw = render(now);
    const ok = writeFrame(encoder, raw);

    if (!ok) {
      await new Promise(r => setTimeout(r, 5));
    }

    frame++;
    if (frame % (config.fps * 10) === 0) {
      console.log(`[renderer] ${frame} frames, uptime ${Math.floor((Date.now() - startAt) / 1000)}s`);
    }
  }
}

export async function stopRenderer() {
  running = false;
  try { encoder?.stdin.end(); } catch {}
  try { encoder?.kill("SIGINT"); } catch {}
}
