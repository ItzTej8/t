# Bigg Boss VPS Canvas Live

Production-oriented 24/7 YouTube vertical live renderer for a Debian VPS.

## Architecture

YouTube Live Chat
→ Masterchat 2.x
→ Bun voting/state
→ native @napi-rs/canvas renderer
→ raw RGBA pipe
→ FFmpeg/libx264
→ YouTube RTMP

There is no Chromium, Puppeteer, OBS, X11 or browser screenshot capture.

## Why Canvas instead of WebGL?

For a CPU-only VPS, native Canvas is the safer choice. WebGL normally needs an OpenGL/EGL implementation and often falls back to software rendering on a VPS. That can consume as much or more CPU than native Canvas. This project therefore uses `@napi-rs/canvas`.

## Recommended Contabo profile

4 vCPU / 8 GB:

WIDTH=1080
HEIGHT=1920
FPS=30
BITRATE=3500k
PRESET=superfast
ENCODER_THREADS=3

If sustained CPU is too high, use 720x1280 at 30 FPS.

## Install

bun install
cp .env.example .env
nano .env
bun run check
bun start

## Important

Never commit your YouTube stream key. Use `.env`.

Use only visual assets, music and footage you are licensed to rebroadcast.
