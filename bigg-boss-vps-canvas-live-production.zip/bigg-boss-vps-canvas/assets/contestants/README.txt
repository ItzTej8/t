Optional PNG/JPG contestant images can be placed here. The current renderer does not require them.
