# TalkInChat Music Bot v5.5.6

## Critical OWNER detection fix

The v5.5.5 build had a runtime regression: `findBotInUsers()` and role-change handling called `botNames()`, but that helper existed only in the multi-room supervisor and was missing from `src/index.js`.

This produced `botNames is not defined`, so the authoritative `you_joined.users` and `room_admin/occupants_list` rosters were received correctly but never reconciled. As a result the worker remained `OWNER=false`, blocked playback, and did not bootstrap the publisher.

### Fixed
- Added `botNames()` to the worker itself.
- Matches bot by configured username, authenticated username, authenticated userId, or loginInfo username.
- `you_joined.users[]` now reaches authoritative role reconciliation.
- `room_admin.occupants[]` reaches the same reconciliation path.
- Role-change events can identify the bot without throwing.
- Explicit log now reports `owner=true/false`.
- Preserves demotion snapshot/stop behavior.
- Preserves automatic publisher bootstrap when authoritative role becomes `owner`.

## Debug evidence from the supplied log
The server already reported the correct role:

```text
users: [ { username: 'aryan', role: 'owner' }, ... ]
```

and `room_admin/occupants_list` also reported:

```text
{ username: 'aryan', role: 'owner' }
```

The immediate failure after the first roster was:

```text
[PROCESS UNHANDLEDREJECTION] botNames is not defined
[SECURITY] roster role reconciliation failed: botNames is not defined
```

Therefore the failure was in the Node worker's role reconciliation, not in the ChatP roster data.
