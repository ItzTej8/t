# TalkInChat Music Bot v5.5.3

## Multi-room command and authorization hardening

### Fixed room command reception
- Normalized APK/ChatP `ResultMessage.roomEvent` text packets to `roomMessage` / `room_message` events.
- Room commands such as `.play`, `.help`, `.queue`, `.masters`, `.master add` now reach the room worker through the dedicated room-message path.
- Duplicate delivery is still deduplicated so a packet surfaced through both aliases does not produce duplicate replies.

### Fixed owner-promotion flow
- Open-room invitation remains password-optional.
- When the bot joins as `member`, the supervisor remains subscribed and polls room occupants while waiting for OWNER promotion.
- Owner promotion is detected from `your_role_changed`, `role_changed`, `newRole`, `tUsername`, or occupant-list state.
- The bot worker is only authorized for playback after the bot itself is confirmed as OWNER.
- Playback remains blocked for `member`/`admin`/other roles as required by the multi-room security rule.

### SQLite-only room settings
- Removed `.bot-settings.json` from the active settings path.
- Per-room settings are stored in SQLite together with masters, queue and playback state.
- Existing JSON room database migration remains one-time compatibility logic only; SQLite is the active database.

### Validation
- Syntax checks passed.
- Room-message protobuf normalization passed.
- Multi-room/master/SQLite tests passed.
- Async completion/AutoDJ tests passed.
- Publisher, Voice/Active visibility, Smart Radio and audio-quality regression tests passed.

Live ChatP/LiveKit operation still requires testing against the real TalkInChat server/account.
