# TalkInChat Music Bot v5.5.1

## Fixes

### Private-message command reception
- Fixed the ChatP protobuf event normalization so incoming `ChatMessage` packets emit both `chatMessage` and APK-compatible `chat_message` events.
- PM commands such as `.invite india`, `.join india`, `.addbot india`, and `.bot invite india` are now routed to the multi-room supervisor.
- Added duplicate PM suppression so the same packet cannot trigger two invitation attempts.
- Supervisor logs received PM commands for diagnostics.

### Multi-room invitation flow
- The supervisor explicitly enables PM and invite profile settings on startup.
- A user can request a room join from the bot's private chat.
- The bot may join as a normal member; it does NOT stream or play until its own role is OWNER.
- If the bot is not OWNER, the supervisor stays in the room and waits for an OWNER promotion instead of immediately leaving.
- OWNER promotion is detected through `your_role_changed` / compatible `role_changed` events.
- Once OWNER, the supervisor queries room occupants and only grants the first bot-master slot automatically when the PM requester is actually a room owner.
- Non-owner requesters never receive master privileges merely because they invited the bot.
- Existing authorized rooms with OWNER state resume even if their master list is empty.

### Protobuf compatibility
- Added decoding of nested `RoomAdmin.occupants`, `RoomAdmin.users`, and `RoomAdmin.logs` entries so owner verification can use actual UserItem roles.

### Setup
- The bootstrap now requires Node.js 22+ for `better-sqlite3@13.0.3` instead of accepting Node 20 and continuing with an unsupported native dependency.

## Validation
- JavaScript syntax checks passed for modified files.
- Private `chat_message` alias test passed.
- Multi-room static checks passed.
- Live ChatP/LiveKit integration still requires testing against the real TalkInChat service/account.

## Database
- SQLite remains the only active room database. No JSON room database is used.
- The one-time legacy JSON migration code remains only for upgrading old v5.4 installations.
