# TalkInChat Music Bot v5.5.0

## Multi-room architecture

- Added a multi-room supervisor.
- Each authorized room runs an isolated worker with its own:
  - YouTube player
  - queue
  - playback/resume state
  - AutoDJ/Radio state
  - volume/FX
  - recovery state
  - LiveKit voice publisher
- A failure or slow download in one room does not serialize commands or playback in another room.

## SQLite database — no JSON room database

Room persistence is now SQLite at `data/talkinchat-room.db` by default.

Tables include:

- `rooms`
- `room_settings`
- `room_masters`
- `room_queue`
- `room_playback`

SQLite WAL mode and a busy timeout are enabled. Room settings are stored as scalar database fields/rows rather than a JSON document.

## Room masters

The user who successfully invites the bot while being the room OWNER becomes the first bot master.

Room commands:

- `.masters`
- `.master list`
- `.master add <username>`
- `.master remove <username>`

A bot master can control the music for that room. Room owner/admin can also manage masters.

## Private-message room invitation

Send the bot a private message:

- `.invite <room>`
- `.addbot <room>`
- `.add-bot <room>`

Optional password is accepted as a second argument.

The supervisor joins the room to verify the inviter and the bot's role. The inviter must be the room OWNER. The dedicated worker then takes over the room.

## Owner-gated playback

The bot will **not stream or play music unless its own ChatP role in that room is OWNER**.

If the bot loses OWNER role:

1. playback is stopped;
2. LiveKit voice is disconnected;
3. room playback remains persisted;
4. the room owner is notified;
5. playback can resume after the bot is promoted back to OWNER.

## First setup

`npm start` automatically runs the bootstrap process before starting the supervisor. It installs declared Node dependencies, including `better-sqlite3`, and attempts to install FFmpeg for the platform.

No APK source is included.
