# TalkInChat Music Bot v5.5.9

## Windows audio-cache concurrency fix

Fixed a Windows/NTFS cache failure where two yt-dlp operations could write the same track at the same time. The second process could fail while renaming its temporary `.part` file to the final `.mp4`, producing `WinError 32` / `The process cannot access the file because it is being used by another process`.

### Changes
- Added one in-flight cache download promise per track key.
- Playback recovery and AutoDJ prefetch now share the same download instead of starting duplicate yt-dlp processes.
- Cache downloader process identity is keyed by `cache:<trackKey>` rather than the playback ID, so cancelling/replacing a track does not accidentally create duplicate writers for the same cache file.
- Existing completed cache files are reused before starting yt-dlp.
- Cache eviction never removes a track whose download is still in flight.
- Preserved high-quality local caching and HTTP-only FFmpeg reconnect options.

## Result

The error:

`Unable to rename file ... .part -> ... .mp4 (WinError 32)`

should no longer occur from overlapping playback/prefetch downloads inside the same bot process.
