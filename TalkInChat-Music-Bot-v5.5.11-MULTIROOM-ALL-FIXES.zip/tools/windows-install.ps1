$ErrorActionPreference = "Stop"
Write-Host "=== TalkInChat Music Bot Windows Setup v1.2.1 ==="

$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) { throw "Node.js 18+ is required. Install the current Node.js LTS, then reopen PowerShell." }
$nodeVersion = (& node -p "process.versions.node").Trim()
$major = [int]((& node -p "process.versions.node.split('.')[0]").Trim())
if ($major -lt 18) { throw "Node.js $nodeVersion is too old. Node.js 18+ is required." }
Write-Host "Node.js: $nodeVersion"

Write-Host "Checking npm registry..."
& npm.cmd config set registry https://registry.npmjs.org/
if ($LASTEXITCODE -ne 0) { throw "Could not configure npm registry." }
& npm.cmd cache verify

if (Get-Command ffmpeg -ErrorAction SilentlyContinue) {
  Write-Host "FFmpeg: already installed."
} elseif (Get-Command winget -ErrorAction SilentlyContinue) {
  Write-Host "Installing FFmpeg with winget..."
  & winget install --id Gyan.FFmpeg -e --source winget --accept-package-agreements --accept-source-agreements
} elseif (Get-Command choco -ErrorAction SilentlyContinue) {
  Write-Host "Installing FFmpeg with Chocolatey..."
  & choco install ffmpeg -y
} else {
  throw "FFmpeg is not installed and neither winget nor Chocolatey is available. Install FFmpeg manually and reopen PowerShell."
}

Write-Host "Installing Node dependencies..."
& npm.cmd install --include=optional --no-audit --no-fund --prefer-online --fetch-retries=5
if ($LASTEXITCODE -ne 0) {
  Write-Host ""
  Write-Host "npm install failed. Run this to see the complete error:" -ForegroundColor Yellow
  Write-Host "npm.cmd install --include=optional --no-audit --no-fund --verbose" -ForegroundColor Yellow
  exit $LASTEXITCODE
}

Write-Host ""
Write-Host "Setup complete. Run: npm start" -ForegroundColor Green
