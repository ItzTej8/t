#!/usr/bin/env bash
set -euo pipefail

export DEBIAN_FRONTEND=noninteractive

sudo apt-get update
sudo apt-get install -y ca-certificates curl ffmpeg build-essential python3 make g++ git

# Install a current Node.js LTS when Node is missing or too old.
if ! command -v node >/dev/null 2>&1 || [ "$(node -p 'Number(process.versions.node.split(".")[0])')" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi

node -v
npm -v
ffmpeg -version | head -n 1

cd "$(dirname "$0")/.."
npm start
