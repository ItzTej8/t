# TalkInChat Music Bot v5.4.0

## Multi-room persistence + first-run setup

### Room-isolated database
Each TalkInChat room now gets its own persistent profile in:

`data/talkinchat-room-db.json`

Stored independently per room:
- 24/7 / always-on
- auto-resume
- welcome setting
- audio quality
- queue limit
- autoplay / AutoDJ
- loop mode
- shuffle
- volume
- all voice FX/filter state
- Radio/Smart Radio seed and mode
- AutoDJ automation settings
- queue
- playback snapshot and exact resume position

A room's settings are never copied from another room after the first profile is created.

### Room switching
When moving from one room to another, the bot saves the old room profile first, then loads the target room's profile and queue/playback state.

`.rooms` shows stored room profiles.

`.roomsettings` shows the active room's complete persisted configuration.

### Async database writes
Database writes are serialized and atomic in the background so command handling does not wait for disk I/O.

### First-run installation
`npm start` / `node scripts/platform-start.mjs` automatically:
- installs missing Node dependencies
- repairs the TUI dependencies
- detects/installs FFmpeg when supported by the host package manager
- creates the room database directory/file on first start
- initializes the room database schema automatically

No manual database creation is required.

### Compatibility
- No APK source included.
- No native database dependency was added, so the room database works on Debian/Linux, Windows, macOS and Termux/Proot without a separate database server.
- Existing `.bot-settings.json` remains supported as a legacy/global fallback.
