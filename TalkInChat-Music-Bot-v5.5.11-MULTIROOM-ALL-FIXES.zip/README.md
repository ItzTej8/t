# TalkInChat Music Bot v5.5.8

A multi-room TalkInChat music bot with isolated room workers, SQLite persistence, room masters, owner-gated playback, Hi-Fi LiveKit audio, Smart AutoDJ and Smart Radio.

## First setup

```bash
npm start
```

The startup bootstrap automatically installs the declared Node dependencies and attempts to install FFmpeg.

## Multi-room invitation

Send the bot a private message:

```text
.invite india
```

Open rooms do not need a password. For protected rooms: `.invite india MyPassword` or `.invite india --password=MyPassword`.

Aliases:

```text
.addbot india
.add-bot india
```

Any user can request the bot to join an open/accessible room. The bot will not stream or play until the bot account itself has OWNER role. The room owner can then authorize masters with `.master add <username>`.

## Room masters

The room owner who successfully invites the bot becomes the first bot master.

```text
.masters
.master add sam
.master remove sam
```

Masters can control playback for that room without being the room owner themselves.

## Database

Room data is stored in:

```text
data/talkinchat-room.db
```

SQLite tables store room settings, masters, queues and playback state. There is no JSON room database.

## Important security rule

The bot never starts or resumes music unless its own room role is `owner`. If the bot loses owner role, its playback and LiveKit publisher are stopped automatically.

## Architecture

`npm start` → multi-room supervisor → one isolated Node worker per authorized room.

This prevents one room's YouTube download, AutoDJ search, FFmpeg recovery or LiveKit failure from blocking another room.


## v5.5.8 important fixes

Room chat commands are normalized from the APK-compatible `ResultMessage.roomEvent` transport into `roomMessage`, so `.play`, `.help`, `.queue`, `.masters` and other commands are handled by the correct room worker. Open-room invitations do not require a password. The supervisor polls occupants until the bot is promoted to OWNER when a role-change event is unavailable. Active room settings are stored in SQLite rather than `.bot-settings.json`. v5.5.8 also fixes the local audio-cache option error, the LiveKit `inputUrl` publisher crash, and makes AutoDJ discovery asynchronous.
