# TalkInChat Music Bot v5.3.8

## Async command engine
- Room commands no longer share one global Promise chain.
- Long yt-dlp/cache/Smart Radio/LiveKit work runs concurrently.
- Playback state mutations remain serialized inside YouTubePlayer.
- This removes command stalls caused by waiting for a previous long operation.

## Playback completion protection
- Playback clock starts when the media source is actually ready.
- Clean FFmpeg EOF is checked against the track duration.
- Truncated/early EOF is retried up to two times instead of immediately advancing to the next track.
- Corrupt cached audio is invalidated before retry.
- Active yt-dlp cache downloads are cancelled when a track is replaced/skipped.

## AutoDJ / Radio
- Radio uses the current track as the next discovery seed; the original radio seed is only a fallback.
- Stronger same-artist and related-title search lanes.
- Better rejection of non-music/commentary/reaction/tutorial results.
- Hybrid mode deliberately keeps a same-artist portion when available, then fills with related candidates.
