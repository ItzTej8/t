# TalkInChat Music Bot v5.5.5

## Critical OWNER-role fix from APK protobuf

The APK source was rechecked at the generated protobuf level.

The important detail is that `RoomEvent.users` (field 40) is a repeated `UserItem` list. A `UserItem` contains `username`, `userId`, and `role`.

The Node decoder now normalizes this list directly.

The ResultMessage decoder now guarantees that repeated fields such as `users`, `rooms`, and `sessions` are arrays even when there is only one item.

This fixes a subtle bug where `ResultMessage.users` with one user was decoded as an object rather than an array, so the OWNER reconciliation code could skip the roster completely.

## Roster reconciliation

The bot checks:
- `you_joined.users[]`
- `you_rejoined.users[]`
- `ResultMessage.users[]` (field 11)
- `RoomAdmin.occupants[]`
- `RoomAdmin.users[]`
- role-change events (`newRole`, `oldRole`, `tUsername`, `userId`)
- periodic `room_admin/occupants_list`

The bot is identified by username OR authenticated user ID.

`RoomEvent.role` is not authoritative by itself.

## OWNER gate

If authoritative roster role is `owner`, playback and publisher bootstrap are allowed.

If authoritative role changes to anything else, playback is snapshotted, player/LiveKit are stopped, recovery is disabled, and playback commands are blocked. OWNER return can resume the publisher according to room settings.

## APK protocol report

Added `APK_PROTOCOL_HANDLERS_EVENTS_V5.5.5.txt` with protobuf messages, fields, Query parameters, room/voice actions, observed handler IDs, room events, OWNER detection sequence, and source files used.

## Database

Room state remains SQLite-only; no JSON room database is introduced.
