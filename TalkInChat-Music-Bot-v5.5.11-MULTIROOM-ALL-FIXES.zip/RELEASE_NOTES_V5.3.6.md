# TalkInChat Music Bot v5.3.6

## Voice join/playback fix

- Keeps the APK-compatible direct `room_stream/publish` attempt first.
- If the ChatP server does not return `publish_stream` within the direct-publish window, v5.3.6 performs exactly one owner self-invitation bootstrap (`room_stream/invite` to the bot account).
- Accepts the resulting `you_invited` token and requests `publish_stream`.
- Does not automatically send `unpublish` or `stop_stream` during recovery.
- Prevents repeated invite/revoke/rejoin loops.
- Pending YouTube audio is automatically published when LiveKit connects.
- Recovery remains single-flight so `.play` can resolve while the voice publisher handshake is in progress.

The fallback is necessary for ChatP deployments where a direct owner publish request does not return publisher credentials, while the invitation handshake does.
