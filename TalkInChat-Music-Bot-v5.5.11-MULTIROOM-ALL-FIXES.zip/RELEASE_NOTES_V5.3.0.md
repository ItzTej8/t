# TalkInChat Music Bot v5.3.0

## Core fixes
- Smart AutoDJ no longer searches the entire current title as its only recommendation seed.
- AutoDJ now builds a candidate pool from artist, similar artists, related songs, recommendations, genre/tag hints and mood/description hints, then scores candidates while suppressing recent/repeated tracks.
- `.radio <query>` now uses the requested query as the radio seed even when another song is already playing.
- `.autodjmode hybrid|artist|genre|mood|related|recommended` selects and persists AutoDJ discovery mode.
- Radio/AutoDJ can refill multiple tracks instead of adding a single "related" result.
- Runtime settings are persisted atomically: welcome, 24/7, auto-resume, autoplay/AutoDJ, AutoDJ mode, quality, loop, shuffle, queue limit, volume and all active voice filters.
- Startup restores player/voice settings before the voice session starts; reconnects keep the same runtime state.
- Shutdown flushes runtime settings before the process exits.
- Stream lifecycle handling accepts both nested `streamEvent` messages and top-level ChatP stream events.
- Room-list `RoomItem.isStreaming` is observed as an additional Voice/Active directory confirmation.

## New voice character presets
- man
- lady
- kidboy
- kidgirl
- oldman
- oldwoman

Additional SFX/character styles include vinyl, distorted, dream, darkhall, cavewide and radiofx, alongside the existing robot, alien, ghost, cave, space, walkie, vintage, megaphone, telephone and other effects.

These are FFmpeg-based pitch/formant-style approximations applied to the complete music stream; they are not AI voice cloning and cannot reproduce a real person's voice.

## 60+ Smart Power commands
Added command shortcuts for recommendations, radio modes, queue filling, persistence/state inspection, volume steps, mute/unmute, FX reset, replay, speed/pitch/bass/treble steps, 8D controls and individual DSP toggles.

Run `.help all` after startup to see the complete catalog.

## Important Voice/Active note
The bot now follows the APK-compatible publisher sequence already used by this project: ChatP room join -> publisher invitation -> publisher acceptance -> `publish_stream` LiveKit credentials -> LiveKit track publication -> server stream-state/directory confirmation. It does **not** perform the unsafe `room_join(intValue=1)` refresh while a healthy publisher is live, because that can revoke a publisher on some ChatP deployments.

If the server still does not list the room in Voice/Active after these changes, the remaining cause is server-side directory publication/authorization rather than the local LiveKit audio pump. `.voicehealth`, `.stream-check <room>` and debug logging can be used to distinguish those states.
