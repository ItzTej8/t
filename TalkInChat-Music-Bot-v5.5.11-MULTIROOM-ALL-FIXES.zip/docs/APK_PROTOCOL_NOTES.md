# APK protocol notes

Recovered from the supplied TalkInChat/ChatP Android traces and protocol source.

## Voice/Active rooms

The Android client caches room `streamingEnabled` / `RoomEvent.isStreaming` state and uses that cached state for its Voice/Active presentation. Trending/public room APIs are not a substitute for this state.

## Streaming sequence

The safe publisher flow reproduced from the supplied Android/runtime material is:

1. `room_join` with the normal `intValue=0` text-room join
2. `room_stream type=invite to=<username>`
3. server sends `you_invited` with a temporary publish value
4. client sends `room_stream type=publish to=<invitation token>`
5. server sends `publish_stream` with LiveKit URL/token
   - Some observed ChatP server sessions also accept `room_stream type=publish` with an empty `to` while a valid invitation is pending. The bot tries the token form first, then performs at most one empty-`to` fallback before requesting a fresh invitation.
6. client immediately connects to LiveKit and publishes the audio track
7. server/room state supplies `RoomEvent.isStreaming=1` / `stream_enabled` when the stream is advertised
8. the Android Voice/Active cache can then show the room

A previous bot experiment added `room_join intValue=1` after publication. The current server responds by emitting `user_left`/`you_left` and can revoke the publisher, producing the exact invite/revoke/DC loop shown in the user's screenshot. Therefore the stable bot must NOT use `room_join(intValue=1)` as a post-publish visibility hack. The normal text-room join is preserved and the bot waits for the server's real streaming advertisement.

## Bot safety rules

- `join_stream` is subscriber/audience credentials and must never be used as publisher credentials.
- `publish_stream` is the publisher LiveKit credential event.
- Never send `room_join(intValue=1)` from the active publisher path. It can tear down the ChatP text-room membership and cause an invite/revoke loop.
- Heartbeats use `check_is_streaming` only; they never rejoin the text room.
- A `revoked` notification must not cause an invite storm while a healthy LiveKit publisher remains connected.
- Invitation de-duplication is keyed by the temporary invitation token, not `sessionId`, because the server can reuse one stream session while issuing fresh invitation tokens.
- Recovery uses a single state machine with a fixed 5-second retry cadence; the first retry is non-destructive and stale unpublish is used only on a later recovery attempt.
- Real LiveKit disconnection still triggers controlled recovery with fresh publisher credentials.
- LiveKit connection begins immediately when `publish_stream` arrives. The only fixed timing is the 5-second connection timeout and 5-second retry interval.


## v5.2.3 controlled directory synchronization

If LiveKit publishing is healthy but the server has not advertised `isStreaming=1`, the bot performs at most one Android-style `room_join(intValue=1)` directory synchronization for the current room session. It is never repeated during automatic recovery. This preserves Voice/Active visibility on deployments that require the APK refresh while avoiding the historical invite/revoke storm.
