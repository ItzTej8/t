# APK Publisher Flow

The supplied APK source was used as the protocol reference. `RoomActivity.z()` constructs a Query with:

- action: `room_stream`
- type: `publish`
- `to`: the stream password (blank by default)
- `room`: current room

The APK then consumes the `publish_stream` StreamEvent and starts its LiveKit publisher.

The Node bot now follows this owner/publisher path instead of treating itself as an invited subscriber.
