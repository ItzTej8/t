# TalkInChat Music Bot v5.3.5

## Voice publisher fix
- Removed automatic `room_stream/invite(to=self)` fallback.
- Removed automatic `room_stream/unpublish` + `stop_stream` during recovery.
- Recovery now preserves the server stream registration and retries the APK-compatible `room_stream/publish` operation.
- If the bot is already inside the target text room, recovery no longer calls `room_join` again.
- This prevents the visible invite/revoke/rejoin loop shown in the TalkinChat room.

## Important
The APK publisher request is `room_stream/publish` with the room's stream password/value. The supplied APK source shows the owner publisher path does not self-invite itself.
