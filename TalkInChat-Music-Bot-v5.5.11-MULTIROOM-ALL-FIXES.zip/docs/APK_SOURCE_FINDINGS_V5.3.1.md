# TalkInChat APK source findings — v5.3.1

The supplied APK source was inspected from `apkSource.zip`.

## Voice / Active directory

The APK contains an `active_rooms_update` application event. The rooms/Voice UI refreshes when that event arrives. This is separate from simply having a LiveKit connection.

Relevant recovered protocol/data types:

- `RoomItem.isStreaming` = protobuf field 7.
- `RoomEvent.isStreaming` = protobuf field 30.
- `ResultMessage.streamEvent` = protobuf field 8.
- `StreamEvent` fields include `type`, `token`, `sessionId`, `url`, `room`, and `id`.
- `RoomActivity` explicitly handles `stream_exists`, `publish_stream`, `stream_enabled`, and `stop_stream`.
- The APK's publish request uses `action=room_stream`, `type=publish`, the current room and the pending publish value/token.

The bot therefore treats these as separate states:

1. ChatP text-room membership.
2. ChatP publisher credential (`publish_stream`).
3. LiveKit connection.
4. LiveKit audio-track publication.
5. ChatP/server streaming advertisement (`stream_enabled`, `RoomEvent.isStreaming`, `RoomItem.isStreaming`, or active-room refresh).

A LiveKit success message is NOT interpreted as proof that the global Voice/Active directory has updated.

## Important limitation

The Android APK is a client. The final `RoomItem.isStreaming` value is produced by the ChatP server. The bot cannot fabricate that value in another user's app. If the bot logs a successful LiveKit publication but the server never emits `stream_enabled`, never reports `RoomItem.isStreaming=1`, and never sends the `active_rooms_update` refresh, the remaining problem is server-side state publication rather than audio encoding.

## Audio reliability

The bot now treats an FFmpeg/PCM stall separately from a LiveKit transport failure. A stalled media pipeline is recovered without unnecessarily tearing down a healthy LiveKit publisher first. Current watchdog thresholds are 15 seconds with FFmpeg alive and 10 seconds when FFmpeg has exited.

## Smart AutoDJ

The previous implementation gave too much weight to title token overlap. A seed such as `Justin Bieber - Baby` could therefore attract unrelated tracks containing `Baby`.

v5.3.1 uses stronger artist identity scoring, weak title similarity, metadata/tag/category overlap, mood overlap, recent-track suppression, variant suppression, and a second-stage similar-artist expansion.
