# TalkInChat Music Bot v5.3.3

## Voice startup fix

- Starts the voice publisher handshake immediately when `.play` begins instead of waiting for YouTube resolution to finish.
- Uses the Android APK-compatible `room_stream/publish` operation first.
- If the server does not return `publish_stream` credentials, automatically attempts **one** legacy `room_stream/invite -> you_invited -> room_stream/publish` publisher handshake.
- The fallback is single-flight and does not create an invite/rejoin storm.
- Set `DISABLE_LEGACY_PUBLISH_FALLBACK=true` only if the deployment is known to reject the legacy publisher handshake.
- Existing LiveKit/PCM and null-stream guards remain in place.

## Validation

- `node --check` passed for `index.js`, `player.js`, `client.js`, and `voice.js`.
- Full live ChatP/LiveKit end-to-end playback was not available in the build environment; test with a real TalkInChat room.
