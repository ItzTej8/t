# TalkInChat Music Bot v5.3.2

## Critical Voice/Active fix

The Android APK source was inspected directly. Its room-owner publisher path uses `room_stream/publish` from `RoomActivity.z()` and waits for `publish_stream` credentials. The previous Node build incorrectly preferred a self `room_stream/invite`, which created subscriber-style `join_stream` events.

v5.3.2 now uses the APK-compatible direct publisher flow:

1. `room_stream/check_is_streaming`
2. `room_stream/publish`
3. wait for `publish_stream`
4. connect LiveKit
5. publish 48 kHz stereo PCM
6. verify ChatP `isStreaming` / `stream_enabled` / room-directory state

v5.3.3 adds an automatic ONE-shot compatibility fallback: direct APK publisher first, then a single legacy publisher invitation if the server does not return publisher credentials. Set `DISABLE_LEGACY_PUBLISH_FALLBACK=true` to disable this fallback.

## Media stability

The null `.on` playback crash is guarded. FFmpeg/YouTube media failures are retried without unnecessarily tearing down a healthy LiveKit publisher.

## AutoDJ / Radio

- Smart discovery is artist/related/genre/mood/recommended based.
- Full title matching is intentionally weak.
- Background queue prefill keeps several tracks ahead of the current track.
- Radio retains its own seed and discovery mode.
- Recent/repeated tracks are suppressed.

## Persistence

Welcome, 24/7, auto-resume, autoplay, audio quality, loop, shuffle, queue limit, volume, filters, Radio seed/mode, and other runtime state are persisted atomically.

## Streaming service activation

`upgrade_streaming` is available through `.streamupgrade 1|7|30`. It is **not** automatically purchased by default. If a deployment explicitly requires it, set `AUTO_UPGRADE_STREAMING=true` and `STREAM_UPGRADE_DURATION=30`.
