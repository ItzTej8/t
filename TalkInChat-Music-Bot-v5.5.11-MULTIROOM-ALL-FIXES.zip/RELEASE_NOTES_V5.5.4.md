# TalkInChat Music Bot v5.5.4

## Owner-authority and multi-room streaming hardening

This release fixes the multi-room case where the TalkInChat UI shows the bot account as OWNER, while the `you_joined` event reports `member`. The bot now treats the room participant/occupant roster as authoritative.

### Role handling
- After `you_joined` / `you_rejoined`, the worker immediately requests `occupants_list`.
- If nested `RoomEvent.users` is present, it is checked first.
- `ResultMessage.roomAdmin.occupants` / `users` are reconciled against the authenticated bot username and user ID.
- `your_role_changed` and `role_changed` are both handled when the target is the bot.
- A lightweight 12-second occupant poll is used as a fallback for ChatP deployments that do not broadcast role changes to every websocket.
- The bot automatically starts its publisher after authoritative OWNER confirmation.
- Losing OWNER immediately stops playback and LiveKit publishing.
- The last playback position/queue are saved before forced demotion stop so the room can resume after promotion.

### Publisher behavior
- Uses the existing APK-compatible direct `room_stream/publish` publisher flow.
- Does not use `join_stream` as a publisher credential.
- Does not repeatedly `room_join(intValue=1)` while publishing.
- Publisher starts are single-flight so duplicate role/occupant events cannot create multiple publish handshakes.
- `AUTO_PUBLISH_ON_OWNER=true` by default; set false for manual publisher startup.

### Command anti-spam
- Anti-spam state is scoped by room + user.
- Failed OWNER/master authorization checks do not consume anti-spam strikes.
- This prevents a series of `.play` attempts made while the bot is not OWNER from creating a long cooldown after the bot is promoted.

### Persistence
- Room settings, masters, queues and playback remain SQLite-only in `data/talkinchat-room.db`.
- No JSON room database is used.

### Validation
- v5.5.4 owner-role reconciliation test: PASS
- v5.5.3 multi-room command regression test: PASS
- v5.5.2 multi-room hardening regression test: PASS
- v5.3.8 async/completion/radio regression test: PASS
- Voice/Active visibility regression test: PASS
- APK publisher-flow regression test: PASS
- JavaScript syntax checks: PASS

Live ChatP/LiveKit behavior still requires testing against the actual TalkInChat account/server.
