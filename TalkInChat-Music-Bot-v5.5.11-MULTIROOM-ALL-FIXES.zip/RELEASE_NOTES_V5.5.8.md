# TalkInChat Music Bot v5.5.8

## Critical media fixes

### Fixed local cached audio failure
v5.5.7 passed HTTP-only FFmpeg reconnect options to local cached files. On some FFmpeg builds this produced:

`Option reconnect not found.`

v5.5.8 now adds `-reconnect*`, `-multiple_requests`, `-rw_timeout`, HTTP headers and the browser user-agent **only for HTTP/HTTPS sources**. Local cached files use a clean file-input argument set.

### Fixed resume position multiplying on every media retry
The playback clock already stores `seekOffset` separately. v5.5.7 also subtracted that offset from `startedAt`, causing the offset to be counted twice.

Example failure:

`3:43 -> 7:26 -> 14:52 -> 29:44`

v5.5.8 starts the wall clock at the moment the media source becomes ready and lets `getElapsedSeconds()` add `seekOffset` exactly once.

### Result
- Local cached MP4/M4A/WebM files can be opened by FFmpeg without HTTP reconnect options.
- Remote YouTube URLs retain reconnect protection.
- Media retries resume from the actual current position instead of exponentially jumping forward.
- LiveKit publisher is not unnecessarily disconnected for this FFmpeg source error.
