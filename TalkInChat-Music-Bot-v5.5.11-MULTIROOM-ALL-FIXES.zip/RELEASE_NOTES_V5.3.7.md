# TalkInChat Music Bot v5.3.7

## Audio quality / glitch fixes
- Added local high-quality audio caching before playback (`AUDIO_CACHE_MODE=always` by default). This removes most YouTube HTTP delivery stalls, URL expiry interruptions, and network jitter from the real-time LiveKit PCM pipeline.
- Cached sources are fed to FFmpeg as local files; direct HTTP streaming remains the fallback if caching fails.
- Increased LiveKit AudioSource queue to 1500 ms by default.
- Increased startup PCM buffer to 1 second and default environment jitter buffer to 4 seconds.
- Preserved 48 kHz stereo s16le throughout the FFmpeg -> LiveKit path.
- Retained 510 kbps stereo Opus as the maximum requested LiveKit music bitrate; LiveKit documents 510 kbps stereo as its maximum-quality setting, while actual listener playback can still be lower depending on the client/network.

## AutoDJ / Radio fixes
- AutoDJ now uses the currently playing track as the evolving discovery seed instead of repeatedly searching from the original radio seed.
- Same-artist songs are strongly preferred for normal hybrid AutoDJ.
- Related-artist searches are secondary.
- Added duration and non-music filtering to reject reviews, tutorials, reactions, gaming, news, makeup, podcasts, trailers, etc.
- Removed random scoring noise so identical inputs produce stable recommendation ordering.
- Radio/AutoDJ excludes recently played tracks more aggressively.
- Enabling AutoDJ while a song is already playing immediately starts a background smart queue refill.
- Radio continues to refill ahead of the current track.

## Packaging
- This release contains only the Node.js bot project. APK source is intentionally excluded.
