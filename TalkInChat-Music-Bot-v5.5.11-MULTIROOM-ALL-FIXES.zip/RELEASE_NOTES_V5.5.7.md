# TalkInChat Music Bot v5.5.7

## Fixes from v5.5.6

### Audio playback
- Fixed `yt-dlp --no-no-part` cache failure caused by passing `noPart: false`.
- Fixed `inputUrl is not defined` in the LiveKit/FFmpeg publisher. The publisher now validates the actual `inputSource` variable.
- Local high-quality cache is used normally, with direct YouTube fallback if caching fails.
- Early EOF protection remains enabled so truncated media is retried instead of immediately advancing to the next song.
- Added next-track cache prefetching to reduce gaps between songs.

### Async operation handling
- Smart AutoDJ/Radio discovery no longer holds the player transition lock while yt-dlp searches.
- Slow discovery runs in the background and automatically starts the discovered track if the queue became empty.
- Room commands continue to be dispatched independently; long YouTube/Radio/voice operations no longer block unrelated commands.

### OWNER / Voice
- Authoritative OWNER detection from `you_joined.users` and `room_admin.occupants` remains enabled.
- Bot automatically starts the publisher flow when its authoritative role is OWNER.
- Demotion handling remains active.
- The server's Voice/Active advertisement remains authoritative.

### TUI
- Automatically falls back to the classic console when stdin does not support `setRawMode`, avoiding the startup `Raw mode is not supported` error common in VPS/Bitvise/redirected terminals.

## New commands

- `.cache` — show audio cache status
- `.cache clear` — clear cached audio (DJ/Admin)
- `.source` / `.sourceinfo` — show current media source and quality
- `.latency` — show WebSocket/LiveKit/PCM health
- `.roominfo` — show room role, masters, DJ/AutoDJ/Radio state
- `.controllers` — show room bot masters and DJ users
- `.version` / `.about` — show bot version/build capabilities

Command catalog now contains 261 entries/aliases.

## Validation

Static syntax validation passed for project JS/MJS files.
Focused tests passed for:
- v5.5.7 media/async/diagnostic fixes
- OWNER detection/roster reconciliation
- multi-room commands
- SQLite-only room persistence
- multi-room invitation/password handling
- v5.3.8 async completion/Radio regression checks

No live ChatP/LiveKit production session was performed in this build environment; live server behavior still needs to be verified on the user's VPS.
