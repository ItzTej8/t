# TalkInChat Music Bot v5.5.2

## Multi-room hardening
- Fixed PM `.invite`/`.join` parsing for ChatP room names containing punctuation such as `!`, `-`, `.`, and `#`.
- Room passwords are optional; `.invite room` joins an open room with the APK-compatible empty password.
- Added explicit `--password` syntax for protected rooms.
- Fixed supervisor handling of room-join error/result variants.
- Fixed supervisor-to-worker handoff so an authorized room is not immediately left before the worker takes over.
- Expanded protobuf `RoomEvent` decoding through the current field set, including `isStreaming`, `newRole`, `oldRole`, `tUsername`, and nested users.
- SQLite remains the only active room database; no JSON room DB is used.
- Startup now requires Node.js 22+ and automatically attempts Node 22 installation on Debian/Ubuntu Linux.
