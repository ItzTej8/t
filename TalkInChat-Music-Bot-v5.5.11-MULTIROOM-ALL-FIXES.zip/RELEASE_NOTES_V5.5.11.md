# TalkInChat Music Bot v5.5.11

## Multi-room / role handling
- `you_joined.role` is treated as provisional; authoritative participant rosters decide the bot role.
- PM `.join` / `.invite` now replies that it is verifying the role instead of incorrectly saying `member` before roster reconciliation.
- Supervisor checks both `roomAdmin.occupants/users` and top-level `ResultMessage.users`.
- Repeated identical OWNER roster polls no longer spam `[SECURITY]` logs or restart the publisher.
- OWNER -> automatic publisher bootstrap; loss of OWNER -> save, stop playback and disconnect voice.
- Room state remains isolated by worker room.

## Persistence
- Room settings, masters, queues, playback and advanced/pro/community state are SQLite-backed.
- Advanced/pro state is scoped to the room worker.
- User profiles, anti-spam, command counts, track counts and audio profiles are scoped to room + user.
- No JSON state files are used by `advanced_features.js` or `pro_features.js`.

## Commands
- Added/fixed `.say <message>` for room masters/owner/admin.
- Added/fixed `.width <0-150>`.
- Help aliases now cover audio/fx, profiles/system and Smart Radio/Power Tools page names.
- Catalog was reconciled against the actual room dispatcher: every catalog command now has a dispatcher case.
- Host-only `.login` / `.exit` are no longer advertised as room commands.

## Audio stability
- Default LiveKit music bitrate: 320 kbps (configurable up to 510 kbps).
- Default decoded PCM jitter buffer: 8 seconds.
- Default startup buffer: 2 seconds.
- Default LiveKit AudioSource queue: 2000 ms.
- Local high-quality cache and single-flight cache downloads retained.
- Next-track prefetch retained to reduce transition gaps.

## Upgrade note
Existing `.env` values are preserved. For a VPS where music is still lagging, use:

```env
LIVEKIT_AUDIO_BITRATE=320000
AUDIO_JITTER_BUFFER_SECONDS=8
AUDIO_START_BUFFER_SECONDS=2.0
LIVEKIT_AUDIO_QUEUE_MS=2000
AUDIO_CACHE_MODE=always
```

If the listener network is excellent and stable, `LIVEKIT_AUDIO_BITRATE=510000` can still be selected manually.
