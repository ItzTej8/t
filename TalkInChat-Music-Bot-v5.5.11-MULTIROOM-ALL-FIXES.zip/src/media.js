/*
 * HTTP media helpers used by the app's media/message flows.
 * Endpoints are configurable because the APK contains host/path references
 * that can vary by server deployment.
 */

function withFetchTimeout(options = {}, timeoutMs = Number(process.env.HTTP_TIMEOUT_MS || 30000)) {
  if (options.signal) return { options, cancel: () => {} };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(new Error(`HTTP timeout after ${timeoutMs}ms`)), timeoutMs); timer.unref?.();
  return { options: { ...options, signal: controller.signal }, cancel: () => clearTimeout(timer) };
}

export async function downloadFile(url, destination) {
  const fs = await import("node:fs/promises");
  const t = withFetchTimeout();
  try {
    const r = await fetch(url, t.options);
    if (!r.ok) throw new Error(`download HTTP ${r.status}`);
    await fs.writeFile(destination, Buffer.from(await r.arrayBuffer()));
  } finally { t.cancel(); }
  return destination;
}

export async function fetchJson(url, options = {}) {
  const t = withFetchTimeout(options);
  try {
    const r = await fetch(url, t.options);
    const text = await r.text();
    if (!r.ok) throw new Error(`HTTP ${r.status}: ${text}`);
    try { return JSON.parse(text); } catch { return text; }
  } finally { t.cancel(); }
}

export { VoiceManager } from "./voice.js";
export { YouTubePlayer } from "./player.js";
