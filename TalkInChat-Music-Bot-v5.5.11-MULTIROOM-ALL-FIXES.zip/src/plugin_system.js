import fs from 'node:fs'; import path from 'node:path'; import {hooks} from './platform_core.js';
const dir=path.resolve(process.env.BOT_PLUGIN_DIR||'plugins'); fs.mkdirSync(dir,{recursive:true});
export async function loadPlugins(log=()=>{}){const files=fs.readdirSync(dir).filter(f=>f.endsWith('.mjs')||f.endsWith('.js'));for(const f of files){try{const mod=await import(path.toNamespacedPath(path.join(dir,f)));if(typeof mod.register==='function')await mod.register({hooks,dir});log(`[Plugin] Loaded ${f}`);}catch(e){log(`[Plugin] Failed ${f}: ${e.message}`);}}}
export {hooks};
