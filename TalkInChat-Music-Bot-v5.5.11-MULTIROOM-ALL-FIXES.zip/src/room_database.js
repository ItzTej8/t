import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';

const DB_FILE_CONFIG = String(process.env.ROOM_DATABASE_PATH || 'data/talkinchat-room.db').trim();
const DB_FILE = path.isAbsolute(DB_FILE_CONFIG) ? DB_FILE_CONFIG : path.resolve(process.cwd(), DB_FILE_CONFIG);
const DB_DIR = path.dirname(DB_FILE);
fs.mkdirSync(DB_DIR, { recursive: true });

const db = new Database(DB_FILE);
db.pragma('journal_mode = WAL');
db.pragma('synchronous = NORMAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

db.exec(`
CREATE TABLE IF NOT EXISTS schema_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS rooms (
  room TEXT PRIMARY KEY,
  inviter_username TEXT NOT NULL DEFAULT '',
  inviter_user_id TEXT NOT NULL DEFAULT '',
  bot_role TEXT NOT NULL DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS room_settings (
  room TEXT NOT NULL,
  key TEXT NOT NULL,
  value TEXT,
  value_type TEXT NOT NULL DEFAULT 'string',
  PRIMARY KEY (room, key),
  FOREIGN KEY (room) REFERENCES rooms(room) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS room_masters (
  room TEXT NOT NULL,
  user_id TEXT NOT NULL DEFAULT '',
  username TEXT NOT NULL,
  added_by_user_id TEXT NOT NULL DEFAULT '',
  added_by_username TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  PRIMARY KEY (room, username),
  FOREIGN KEY (room) REFERENCES rooms(room) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_room_masters_user ON room_masters(user_id);
CREATE TABLE IF NOT EXISTS room_queue (
  room TEXT NOT NULL,
  position INTEGER NOT NULL,
  url TEXT NOT NULL,
  title TEXT NOT NULL DEFAULT '',
  duration TEXT NOT NULL DEFAULT '',
  duration_seconds REAL NOT NULL DEFAULT 0,
  requested_by TEXT NOT NULL DEFAULT '',
  author TEXT NOT NULL DEFAULT '',
  thumbnail TEXT NOT NULL DEFAULT '',
  added_at INTEGER NOT NULL,
  PRIMARY KEY (room, position),
  FOREIGN KEY (room) REFERENCES rooms(room) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS room_playback (
  room TEXT PRIMARY KEY,
  url TEXT NOT NULL,
  title TEXT NOT NULL DEFAULT '',
  duration TEXT NOT NULL DEFAULT '',
  duration_seconds REAL NOT NULL DEFAULT 0,
  requested_by TEXT NOT NULL DEFAULT '',
  author TEXT NOT NULL DEFAULT '',
  thumbnail TEXT NOT NULL DEFAULT '',
  offset_seconds REAL NOT NULL DEFAULT 0,
  saved_at INTEGER NOT NULL,
  FOREIGN KEY (room) REFERENCES rooms(room) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS state_entries (
  room TEXT NOT NULL,
  namespace TEXT NOT NULL,
  key TEXT NOT NULL,
  value TEXT,
  value_type TEXT NOT NULL DEFAULT 'string',
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (room, namespace, key),
  FOREIGN KEY (room) REFERENCES rooms(room) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_state_entries_ns ON state_entries(room, namespace);
`);

db.prepare(`INSERT INTO schema_meta(key,value) VALUES('version','3') ON CONFLICT(key) DO UPDATE SET value=excluded.value`).run();

const defaults = {
  alwaysOn: true, autoResume: true, welcomeEnabled: true, defaultRoom: '',
  player: { autoplay: false, audioQuality: 'highest', loopMode: 'off', shuffleEnabled: false, queueLimit: 100 },
  voice: { volume: 1, filters: null },
  radio: { enabled: false, seedMode: 'hybrid', seed: null, maxQueue: 12, avoidRecent: 15, sameArtistChance: 0.35, sameGenreChance: 0.25, moodChance: 0.20, relatedChance: 0.20 },
  automation: { autoDj: false, autoRadio: false, refillThreshold: 3 },
  featureFlags: {}
};

const ensureRoomStmt = db.prepare(`INSERT INTO rooms(room,created_at,updated_at) VALUES(?,?,?) ON CONFLICT(room) DO UPDATE SET updated_at=excluded.updated_at`);
const touchRoomStmt = db.prepare(`UPDATE rooms SET updated_at=? WHERE room=?`);
const setSettingStmt = db.prepare(`INSERT INTO room_settings(room,key,value,value_type) VALUES(?,?,?,?) ON CONFLICT(room,key) DO UPDATE SET value=excluded.value,value_type=excluded.value_type`);
const deleteSettingStmt = db.prepare(`DELETE FROM room_settings WHERE room=? AND key=?`);
const getSettingsStmt = db.prepare(`SELECT key,value,value_type FROM room_settings WHERE room=?`);
const queueDeleteStmt = db.prepare(`DELETE FROM room_queue WHERE room=?`);
const queueInsertStmt = db.prepare(`INSERT INTO room_queue(room,position,url,title,duration,duration_seconds,requested_by,author,thumbnail,added_at) VALUES(@room,@position,@url,@title,@duration,@duration_seconds,@requested_by,@author,@thumbnail,@added_at)`);
const masterUpsertStmt = db.prepare(`INSERT INTO room_masters(room,user_id,username,added_by_user_id,added_by_username,created_at) VALUES(?,?,?,?,?,?) ON CONFLICT(room,username) DO UPDATE SET user_id=excluded.user_id,added_by_user_id=excluded.added_by_user_id,added_by_username=excluded.added_by_username`);
const masterDeleteStmt = db.prepare(`DELETE FROM room_masters WHERE room=? AND lower(username)=lower(?)`);
const masterListStmt = db.prepare(`SELECT username,user_id,added_by_username,created_at FROM room_masters WHERE room=? ORDER BY created_at ASC`);
const masterGetStmt = db.prepare(`SELECT username,user_id,added_by_username,created_at FROM room_masters WHERE room=? AND (lower(username)=lower(?) OR (user_id<>'' AND user_id=?)) LIMIT 1`);
const roomGetStmt = db.prepare(`SELECT * FROM rooms WHERE room=?`);

function ensureRoom(room) {
  const key = String(room || '').trim();
  if (!key) return null;
  const now = Date.now();
  ensureRoomStmt.run(key, now, now);
  return key;
}

function clone(v) { return v == null ? v : structuredClone(v); }
function flatten(obj, prefix = '', out = []) {
  if (!obj || typeof obj !== 'object') return out;
  for (const [k, v] of Object.entries(obj)) {
    const key = prefix ? `${prefix}.${k}` : k;
    if (v && typeof v === 'object' && !Array.isArray(v)) flatten(v, key, out);
    else if (v !== undefined) out.push([key, v]);
  }
  return out;
}
function setNested(out, dotted, value) {
  const parts = dotted.split('.'); let cur = out;
  for (let i = 0; i < parts.length - 1; i++) cur = cur[parts[i]] ||= {};
  cur[parts.at(-1)] = value;
}
function decodeValue(value, type) {
  if (type === 'boolean') return value === '1';
  if (type === 'number') return Number(value);
  if (type === 'null') return null;
  return value ?? '';
}
function encodeValue(value) {
  if (value === null) return ['','null'];
  if (typeof value === 'boolean') return [value ? '1' : '0','boolean'];
  if (typeof value === 'number') return [String(value),'number'];
  if (typeof value === 'string') return [value,'string'];
  // The room settings schema is deliberately scalar. Complex values such as
  // radio seeds/filters are expanded into dotted scalar keys before reaching here.
  return [String(value),'string'];
}
function merge(base, patch) {
  const out = clone(base) || {};
  if (!patch || typeof patch !== 'object') return out;
  for (const [k,v] of Object.entries(patch)) {
    if (v && typeof v === 'object' && !Array.isArray(v) && out[k] && typeof out[k] === 'object' && !Array.isArray(out[k])) out[k] = merge(out[k], v);
    else out[k] = clone(v);
  }
  return out;
}

export async function persistRoomDatabase() { return true; }

export async function initRoomDatabase() {
  // One-time migration from v5.4's JSON room database. The JSON file is only
  // read for migration; after a successful import it is renamed so SQLite is
  // the sole room database.
  const legacy = path.resolve(process.cwd(), 'data/talkinchat-room-db.json');
  const migratedMarker = `${legacy}.migrated`;
  if (fs.existsSync(legacy) && !fs.existsSync(migratedMarker)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(legacy, 'utf8'));
      const rooms = parsed?.rooms && typeof parsed.rooms === 'object' ? parsed.rooms : {};
      for (const [room, record] of Object.entries(rooms)) {
        if (!room) continue;
        if (record?.settings) setRoomSettings(room, record.settings);
        if (Array.isArray(record?.queue)) setRoomQueue(room, record.queue);
        if (record?.playback) setRoomPlayback(room, record.playback);
      }
      fs.renameSync(legacy, migratedMarker);
    } catch (err) {
      console.warn(`[RoomDB] Legacy JSON migration failed: ${err.message}`);
    }
  }
  return db;
}
export function getRoomDatabaseFile() { return DB_FILE; }

export function getRoomRecord(room, create = true) {
  const key = String(room || '').trim();
  if (!key) return null;
  if (create) ensureRoom(key);
  return roomGetStmt.get(key) || null;
}

export function getRoomSettings(room) {
  const key = String(room || '').trim();
  if (!key) return null;
  const rows = getSettingsStmt.all(key);
  if (!rows.length) return null;
  const out = {};
  for (const row of rows) setNested(out, row.key, decodeValue(row.value, row.value_type));
  return clone(out);
}

const writeSettingsTx = db.transaction((room, settings) => {
  ensureRoom(room);
  for (const [key, value] of flatten(settings)) {
    const [encoded,type] = encodeValue(value);
    setSettingStmt.run(room,key,encoded,type);
  }
  touchRoomStmt.run(Date.now(), room);
});

export function setRoomSettings(room, settings) {
  const key = ensureRoom(room); if (!key) return null;
  // Replace known settings rather than accumulating deleted keys.
  db.prepare('DELETE FROM room_settings WHERE room=?').run(key);
  writeSettingsTx(key, settings || {});
  return getRoomSettings(key);
}
export function patchRoomSettings(room, patch) {
  const key = ensureRoom(room); if (!key) return null;
  const next = merge(getRoomSettings(key) || defaults, patch || {});
  writeSettingsTx(key, next);
  return getRoomSettings(key);
}

export function listRoomProfiles() {
  const rooms = db.prepare(`SELECT r.room,r.created_at,r.updated_at,
    (SELECT COUNT(*) FROM room_queue q WHERE q.room=r.room) AS queue_length,
    p.title AS playback_title,p.offset_seconds AS playback_offset,
    (SELECT COUNT(*) FROM room_masters m WHERE m.room=r.room) AS master_count,
    r.inviter_username,r.bot_role,r.enabled
    FROM rooms r LEFT JOIN room_playback p ON p.room=r.room ORDER BY r.updated_at DESC`).all();
  return rooms.map(r => ({ room:r.room, createdAt:r.created_at, updatedAt:r.updated_at, hasSettings:Boolean(getSettingsStmt.get(r.room)), queueLength:Number(r.queue_length), playback:r.playback_title ? {title:r.playback_title,offset:r.playback_offset} : null, masterCount:Number(r.master_count), inviter:r.inviter_username, botRole:r.bot_role, enabled:Boolean(r.enabled) }));
}

export function setRoomMeta(room, patch = {}) {
  const key = ensureRoom(room); if (!key) return null;
  const current = roomGetStmt.get(key);
  db.prepare(`UPDATE rooms SET inviter_username=?,inviter_user_id=?,bot_role=?,enabled=?,updated_at=? WHERE room=?`).run(
    patch.inviterUsername ?? current.inviter_username,
    patch.inviterUserId ?? current.inviter_user_id,
    patch.botRole ?? current.bot_role,
    patch.enabled == null ? current.enabled : (patch.enabled ? 1 : 0),
    Date.now(), key);
  return roomGetStmt.get(key);
}

export function getRoomMeta(room) { return getRoomRecord(room, false); }

export function setRoomQueue(room, queue) {
  const key = ensureRoom(room); if (!key) return [];
  const items = Array.isArray(queue) ? queue : [];
  const tx = db.transaction(() => {
    queueDeleteStmt.run(key);
    items.forEach((t,i) => queueInsertStmt.run({room:key,position:i,url:String(t.url||''),title:String(t.title||''),duration:String(t.duration||''),duration_seconds:Number(t.durationSeconds||0),requested_by:String(t.requestedBy||''),author:String(t.author||t.uploader||''),thumbnail:String(t.thumbnail||''),added_at:Number(t.addedAt||Date.now())}));
    touchRoomStmt.run(Date.now(),key);
  });
  tx(); return getRoomQueue(key);
}
export function getRoomQueue(room) {
  const key = String(room||'').trim(); if (!key) return [];
  return db.prepare(`SELECT url,title,duration,duration_seconds AS durationSeconds,requested_by AS requestedBy,author,thumbnail,added_at AS addedAt FROM room_queue WHERE room=? ORDER BY position`).all(key);
}

export function setRoomPlayback(room, playback) {
  const key = ensureRoom(room); if (!key) return null;
  if (!playback?.track?.url) return clearRoomPlayback(key);
  const t = playback.track;
  db.prepare(`INSERT INTO room_playback(room,url,title,duration,duration_seconds,requested_by,author,thumbnail,offset_seconds,saved_at)
    VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(room) DO UPDATE SET url=excluded.url,title=excluded.title,duration=excluded.duration,duration_seconds=excluded.duration_seconds,requested_by=excluded.requested_by,author=excluded.author,thumbnail=excluded.thumbnail,offset_seconds=excluded.offset_seconds,saved_at=excluded.saved_at`).run(
      key,String(t.url),String(t.title||''),String(t.duration||''),Number(t.durationSeconds||0),String(t.requestedBy||''),String(t.author||t.uploader||''),String(t.thumbnail||''),Number(playback.offset||0),Number(playback.savedAt||Date.now()));
  touchRoomStmt.run(Date.now(),key);
  return getRoomPlayback(key);
}
export function getRoomPlayback(room) {
  const key = String(room||'').trim(); if (!key) return null;
  const r = db.prepare(`SELECT url,title,duration,duration_seconds AS durationSeconds,requested_by AS requestedBy,author,thumbnail,offset_seconds AS offset,saved_at AS savedAt FROM room_playback WHERE room=?`).get(key);
  if (!r) return null;
  return { room:key, track:{url:r.url,title:r.title,duration:r.duration,durationSeconds:r.durationSeconds,requestedBy:r.requestedBy,author:r.author,thumbnail:r.thumbnail}, offset:r.offset, savedAt:r.savedAt, queue:getRoomQueue(key) };
}
export function clearRoomPlayback(room) { const key=String(room||'').trim(); if(!key)return; db.prepare('DELETE FROM room_playback WHERE room=?').run(key); touchRoomStmt.run(Date.now(),key); }

export function addRoomMaster(room, user, addedBy = {}) {
  const key=ensureRoom(room); if(!key) return null;
  const username=String(user?.username||user||'').trim(); if(!username) return null;
  const userId=String(user?.userId||'').trim();
  masterUpsertStmt.run(key,userId,username,String(addedBy?.userId||''),String(addedBy?.username||''),Date.now());
  return getRoomMaster(key, username, userId);
}
export function removeRoomMaster(room, username) { const key=String(room||'').trim(); if(!key)return false; return masterDeleteStmt.run(key,String(username||'').trim()).changes>0; }
export function listRoomMasters(room) { return masterListStmt.all(String(room||'').trim()); }
export function getRoomMaster(room, username, userId='') { return masterGetStmt.get(String(room||'').trim(),String(username||'').trim(),String(userId||'')) || null; }
export function isRoomMaster(room, username, userId='') { return Boolean(getRoomMaster(room,username,userId)); }
export function clearRoomMasters(room) { return db.prepare('DELETE FROM room_masters WHERE room=?').run(String(room||'').trim()).changes; }

export function importLegacyRoom(room, settings, queue = [], playback = null) {
  const key=ensureRoom(room); if(!key)return;
  if (!getRoomSettings(key)) setRoomSettings(key, settings || defaults);
  if (!getRoomQueue(key).length && Array.isArray(queue)) setRoomQueue(key, queue);
  if (!getRoomPlayback(key) && playback) setRoomPlayback(key, playback);
}



export function getStateEntries(room, namespace) {
  const r = String(room || '').trim(); const ns = String(namespace || '').trim();
  if (!r || !ns) return {};
  const rows = db.prepare('SELECT key,value,value_type FROM state_entries WHERE room=? AND namespace=?').all(r, ns);
  const out = {};
  for (const row of rows) setNested(out, row.key, decodeValue(row.value, row.value_type));
  return clone(out);
}

export function setStateEntries(room, namespace, value) {
  const r = ensureRoom(room); const ns = String(namespace || '').trim();
  if (!r || !ns) return null;
  const rows = flatten(value || {});
  const tx = db.transaction(() => {
    db.prepare('DELETE FROM state_entries WHERE room=? AND namespace=?').run(r, ns);
    const stmt = db.prepare('INSERT INTO state_entries(room,namespace,key,value,value_type,updated_at) VALUES(?,?,?,?,?,?)');
    const now = Date.now();
    for (const [key,val] of rows) { const [encoded,type] = encodeValue(val); stmt.run(r,ns,key,encoded,type,now); }
    touchRoomStmt.run(now,r);
  });
  tx();
  return getStateEntries(r,ns);
}

export function getStateValue(room, namespace, key, fallback = null) {
  const row = db.prepare('SELECT value,value_type FROM state_entries WHERE room=? AND namespace=? AND key=?').get(String(room||'').trim(),String(namespace||'').trim(),String(key||'').trim());
  return row ? decodeValue(row.value,row.value_type) : fallback;
}

export function setStateValue(room, namespace, key, value) {
  const r=ensureRoom(room); const ns=String(namespace||'').trim(); const k=String(key||'').trim();
  if(!r||!ns||!k)return null;
  const [encoded,type]=encodeValue(value);
  db.prepare('INSERT INTO state_entries(room,namespace,key,value,value_type,updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(room,namespace,key) DO UPDATE SET value=excluded.value,value_type=excluded.value_type,updated_at=excluded.updated_at').run(r,ns,k,encoded,type,Date.now());
  touchRoomStmt.run(Date.now(),r); return value;
}

export function deleteStateValue(room, namespace, key) {
  const r=String(room||'').trim(); const ns=String(namespace||'').trim(); const k=String(key||'').trim();
  if(!r||!ns||!k)return false;
  return db.prepare('DELETE FROM state_entries WHERE room=? AND namespace=? AND key=?').run(r,ns,k).changes>0;
}

export function deleteStatePrefix(room, namespace, prefix) {
  const r=String(room||'').trim(); const ns=String(namespace||'').trim(); const p=String(prefix||'').trim();
  if(!r||!ns)return 0;
  const pattern=p ? `${p}.%` : '%';
  return db.prepare('DELETE FROM state_entries WHERE room=? AND namespace=? AND (key=? OR key LIKE ?)').run(r,ns,p,pattern).changes;
}
export function closeRoomDatabase() { try { db.close(); } catch {} }
