/* SQLite-only advanced state. Every value is scoped to ROOM_WORKER_ROOM and,
 * for user data, to that room + user. No JSON database files are used. */
import { getStateEntries, getStateValue, setStateValue, setStateEntries, deleteStatePrefix } from './room_database.js';
const ROOM = String(process.env.ROOM_WORKER_ROOM || process.env.DEFAULT_ROOM || 'global').trim() || 'global';
const NS='advanced';
const DEFAULT={
  audioProfiles:{},songSettings:{},userProfiles:{},
  radioPresets:{hits:'latest popular music',punjabi:'latest Punjabi songs',bollywood:'latest Bollywood songs',lofi:'lofi chill music',edm:'EDM dance music'},
  antiSpam:{enabled:true,windowMs:5000,maxCommands:7,strikes:{}},vote:{enabled:true,percent:50,minVotes:2,durationMs:30000},schedules:[],recentArtists:[]
};
const clone=v=>v==null?v:structuredClone(v);
const state=()=>({ ...clone(DEFAULT), ...getStateEntries(ROOM,NS) });
const write=s=>setStateEntries(ROOM,NS,s);
const key=u=>String(u||'User').trim().toLowerCase();
const songKey=t=>String(t?.url||'').slice(0,1000);
export function flushPersistence(){return true}
const profileKey=(owner,name)=>`${key(owner||'global')}::${key(name)}`;
export function saveAudioProfile(name,filters,owner='global'){const s=state(),k=profileKey(owner,name);s.audioProfiles[k]={name:String(name),owner:key(owner),filters:clone(filters)};write(s);return s.audioProfiles[k]}
export function getAudioProfile(name,owner='global'){return state().audioProfiles[profileKey(owner,name)]||null}
export function listAudioProfiles(owner='global'){const o=key(owner);return Object.values(state().audioProfiles).filter(x=>!x.owner||x.owner===o)}
export function saveSongSettings(track,settings){const k=songKey(track);if(!k)return null;const s=state();s.songSettings[k]={...clone(settings),title:track.title||'',url:k};write(s);return s.songSettings[k]}
export function getSongSettings(track){return state().songSettings[songKey(track)]||null}
export function setUserProfile(user,patch){const s=state(),k=key(user);s.userProfiles[k]={...(s.userProfiles[k]||{}),...clone(patch)};write(s);return s.userProfiles[k]}
export function getUserProfile(user){return state().userProfiles[key(user)]||{}}
export function getRadioPresets(){return clone(state().radioPresets)}
export function saveRadioPreset(name,query){const s=state();s.radioPresets[key(name)]=String(query);write(s);return String(query)}
export function removeRadioPreset(name){const s=state(),k=key(name);if(!s.radioPresets[k])return false;delete s.radioPresets[k];write(s);return true}
export function antiSpamCheck(user){
  if(!user)return {ok:true,strikes:0}; const k=key(user), now=Date.now();
  const base=state().antiSpam; if(!base.enabled)return {ok:true,strikes:0};
  const prefix=`antiSpam.strikes.${k}`;
  const timesRaw=String(getStateValue(ROOM,NS,`${prefix}.times`,'')||'');
  let times=timesRaw?timesRaw.split(',').map(Number).filter(Number.isFinite):[];
  let strikes=Number(getStateValue(ROOM,NS,`${prefix}.strikes`,0))||0;
  let blockedUntil=Number(getStateValue(ROOM,NS,`${prefix}.blockedUntil`,0))||0;
  times=times.filter(t=>now-t<base.windowMs);
  if(blockedUntil>now){setStateValue(ROOM,NS,`${prefix}.times`,times.join(','));return {ok:false,remaining:blockedUntil-now,strikes};}
  times.push(now);
  if(times.length>base.maxCommands){strikes++;times=[];blockedUntil=now+Math.min(60000,5000*Math.pow(2,strikes-1));}
  setStateValue(ROOM,NS,`${prefix}.times`,times.join(','));setStateValue(ROOM,NS,`${prefix}.strikes`,strikes);setStateValue(ROOM,NS,`${prefix}.blockedUntil`,blockedUntil);
  return {ok:blockedUntil<=now,remaining:Math.max(0,blockedUntil-now),strikes};
}
export function getVoteConfig(){const s=state().vote;return {enabled:s.enabled!==false,percent:Number(s.percent)||50,minVotes:Number(s.minVotes)||2,durationMs:Number(s.durationMs)||30000}}
export function setVoteConfig(patch){const s=state();s.vote={...s.vote,...clone(patch)};write(s);return clone(s.vote)}
function scheduleMap(){ return getStateEntries(ROOM,NS).schedules || {}; }
export function addSchedule(item){ const id=String(item?.id||Date.now()); const s=state(); const map=scheduleMap(); map[id]=clone(item); delete s.schedules; setStateEntries(ROOM,NS,{...s,schedules:map}); return item }
export function listAdvancedSchedules(){ return Object.entries(scheduleMap()).map(([id,v])=>({id,...v})).sort((a,b)=>Number(a.at||0)-Number(b.at||0)); }
export function removeSchedule(id){ const before=listAdvancedSchedules().length; const map=scheduleMap(); delete map[String(id)]; const s=state(); delete s.schedules; setStateEntries(ROOM,NS,{...s,schedules:map}); return listAdvancedSchedules().length<before }
export function updateSchedule(id,patch){ const map=scheduleMap(); const k=String(id); if(!map[k])return null; map[k]={...map[k],...clone(patch)}; const s=state(); delete s.schedules; setStateEntries(ROOM,NS,{...s,schedules:map}); return clone(map[k]) }
export function getAdvancedState(){return state()}
