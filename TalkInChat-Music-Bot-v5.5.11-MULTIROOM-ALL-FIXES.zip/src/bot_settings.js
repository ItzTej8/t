import { getRoomSettings, setRoomSettings, listRoomProfiles } from "./room_database.js";

const DEFAULTS = {
  alwaysOn: true,
  autoResume: true,
  welcomeEnabled: true,
  defaultRoom: "",
  player: { autoplay: false, audioQuality: "highest", loopMode: "off", shuffleEnabled: false, queueLimit: 100 },
  voice: { volume: 1, filters: null },
  radio: { enabled: false, seedMode: "hybrid", seed: null, maxQueue: 12, avoidRecent: 15, sameArtistChance: 0.35, sameGenreChance: 0.25, moodChance: 0.20, relatedChance: 0.20 },
  automation: { autoDj: false, autoRadio: false, refillThreshold: 3 },
  featureFlags: {}
};

let activeRoom = "";

function merge(base, value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return structuredClone(base);
  const out = { ...structuredClone(base), ...value };
  for (const k of Object.keys(base)) {
    if (base[k] && typeof base[k] === "object" && !Array.isArray(base[k])) out[k] = merge(base[k], value?.[k]);
  }
  return out;
}

export function setActiveRoom(room = "") { activeRoom = String(room || "").trim(); return activeRoom; }
export function getActiveRoom() { return activeRoom; }

export function loadSettings(room = activeRoom) {
  const target = String(room || activeRoom || "").trim();
  if (!target) return structuredClone(DEFAULTS);
  const saved = getRoomSettings(target);
  if (saved) return merge(DEFAULTS, saved);
  const fresh = structuredClone(DEFAULTS);
  setRoomSettings(target, fresh);
  return fresh;
}

export function saveSettings(values = {}, room = activeRoom) {
  const target = String(room || activeRoom || "").trim();
  if (!target) return merge(DEFAULTS, values);
  const next = merge(loadSettings(target), values);
  setRoomSettings(target, next);
  return next;
}

export function updateSettings(patch = {}, room = activeRoom) { return saveSettings(patch, room); }
export function getSettingsFile() { return null; }
export function getRoomSettingsList() { return listRoomProfiles(); }
export function getDefaults() { return structuredClone(DEFAULTS); }
export function ensureLegacySettingsFile() { return false; }
