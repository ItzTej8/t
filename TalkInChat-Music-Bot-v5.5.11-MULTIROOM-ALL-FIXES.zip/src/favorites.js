import fs from "node:fs";
import path from "node:path";
import { log, debug } from "./config.js";
import { atomicWriteJson } from "./platform_core.js";

const FAVORITES_FILE = path.resolve(process.cwd(), ".favorites.json");

export function loadFavorites() {
  try {
    if (fs.existsSync(FAVORITES_FILE)) {
      return JSON.parse(fs.readFileSync(FAVORITES_FILE, "utf8"));
    }
  } catch (err) {
    debug("[Favorites Load Error]", err.message);
  }
  return {};
}

export function saveFavorites(favs) {
  try {
    atomicWriteJson(FAVORITES_FILE, favs);
    return true;
  } catch (err) {
    log(`[Favorites Save Error] ${err.message}`);
    return false;
  }
}

export function addFavorite(userId, track) {
  if (!userId || !track || !track.title) throw new Error("Invalid user or track");
  const favs = loadFavorites();
  const uid = String(userId);
  if (!favs[uid]) favs[uid] = [];

  const exists = favs[uid].some(t => t.url === track.url || t.title === track.title);
  if (exists) return { added: false, count: favs[uid].length };

  favs[uid].push({
    title: track.title,
    url: track.url,
    duration: track.duration,
    durationSeconds: track.durationSeconds,
    artist: track.artist || "YouTube",
    thumbnail: track.thumbnail || "",
    addedAt: Date.now()
  });

  saveFavorites(favs);
  return { added: true, count: favs[uid].length };
}

export function removeFavorite(userId, indexOrTitle) {
  const favs = loadFavorites();
  const uid = String(userId);
  if (!favs[uid] || !favs[uid].length) return false;

  const idx = Number(indexOrTitle) - 1;
  if (Number.isInteger(idx) && idx >= 0 && idx < favs[uid].length) {
    favs[uid].splice(idx, 1);
    saveFavorites(favs);
    return true;
  }

  const query = String(indexOrTitle).toLowerCase();
  const foundIdx = favs[uid].findIndex(t => t.title.toLowerCase().includes(query));
  if (foundIdx !== -1) {
    favs[uid].splice(foundIdx, 1);
    saveFavorites(favs);
    return true;
  }

  return false;
}

export function getFavorites(userId) {
  const favs = loadFavorites();
  return favs[String(userId)] || [];
}

export function clearFavorites(userId) {
  const favs = loadFavorites();
  const uid = String(userId);
  if (favs[uid]) {
    delete favs[uid];
    saveFavorites(favs);
    return true;
  }
  return false;
}
