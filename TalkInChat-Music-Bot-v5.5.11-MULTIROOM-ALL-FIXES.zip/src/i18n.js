const dict={en:{playing:'Now playing',queued:'Added to queue',noMusic:'No music is playing.',recovered:'Voice recovered.'},hi:{playing:'अभी बज रहा है',queued:'क्यू में जोड़ा गया',noMusic:'कोई संगीत नहीं बज रहा है।',recovered:'वॉइस कनेक्शन ठीक हो गया।'},mr:{playing:'आत्ता वाजत आहे',queued:'क्यूमध्ये जोडले',noMusic:'सध्या संगीत वाजत नाही.',recovered:'व्हॉइस कनेक्शन पुन्हा सुरू झाले.'}};
export function t(lang,key,...args){let s=(dict[lang]||dict.en)[key]||dict.en[key]||key;args.forEach((v,i)=>s=s.replace(`{${i}}`,String(v)));return s;}
export function languages(){return Object.keys(dict);}
