export const ACTIVITIES = Object.freeze([
  "net.chatp.activity.AuthActivity",
  "net.chatp.activity.StoreActivity",
  "net.chatp.activity.VoiceCallActivity",
  "net.chatp.activity.TestActivity",
  "net.chatp.view.activity.RoomsSearchActivity",
  "net.chatp.view.activity.ChatActivity",
  "net.chatp.view.activity.RoomActivity",
  "net.chatp.activity.SessionsActivity",
  "net.chatp.activity.UpdateActivity",
  "net.chatp.activity.RestoreActivity",
  "net.chatp.activity.RequestsActivity",
  "net.chatp.activity.RoomLogsActivity",
  "net.chatp.activity.RoomRolesActivity",
  "net.chatp.activity.RoomSettingsActivity",
  "net.chatp.activity.CreateRoomActivity",
  "net.chatp.activity.BlockedListActivity",
  "net.chatp.activity.SettingsActivity",
  "net.chatp.activity.ProfileActivity",
  "net.chatp.activity.ConfirmImageActivity",
  "net.chatp.activity.ImageViewActivity",
  "net.chatp.ui.crop.CropImageActivity",
  "net.chatp.view.activity.MainActivity"
]);

export const SERVICES = Object.freeze([
  "net.chatp.main.Client",
  "net.chatp.main.FCMService",
  "net.chatp.main.VoiceCallService"
]);

export const ACTIONS = Object.freeze({
  auth: ["login","register"],
  rooms: [
    "room_create","room_join","room_join_captcha","room_leave",
    "room_info","room_stream","room_admin"
  ],
  chat: ["chat_message","ok_msg"],
  profile: ["profile_mine","profile_other","profile_update"],
  user: ["blocked_list","sessions_log","last_activity"],
  gifts: ["gifts"],
  calls: ["call_handler_new","end_call"],
  store: ["store"],
  abuse: ["report_abuse"],
  setup: ["id_setup"],
  transportHelpers: ["send_text","send_raw","reconnect"],
  http: ["new_messages"]
});

export const ROOM_INFO_TYPES = [
  "public_rooms","trending_rooms","favourite_rooms","search_rooms",
  "room_value","user_value","add_favourite","remove_favourite"
];

export const ROOM_STREAM_TYPES = [
  "publish","unpublish","check_is_streaming","invite","join_stream","stop_stream"
];

export const ROOM_ADMIN_TYPES = [
  "occupants_list","admins_list","members_list","owners_list","outcast_list",
  "room_logs","room_settings","change_role","kick","ban_ip","reset_ip","reset_room"
];

export const PROFILE_UPDATE_TYPES = [
  "gender","allow_pm","allow_invites","set_visibility","auto_join_stream",
  "calls","email","country","birthdate","photo","password",
  "send_friend_request","send_requests","accept_friend_request",
  "reject_friend_request","remove_friend","block","unblock","remove_account"
];

export const GIFT_TYPES = [
  "send_gift","new_gifts","gifts_list","gifts_list_new","public_gifts"
];

export const STORE_TYPES = [
  "store_data","remove_color","upgrade_streaming","consume_purchase",
  "purchase","transactions_list","colors_list"
];

export const INCOMING_EVENTS = [
  "connected","reconnect","publish_stream","stream_exists","stop_stream",
  "stream_enabled","stop_streaming_service","join_stream","sent_invitation",
  "you_invited","revoked","user_joined","user_left","you_joined","you_rejoined",
  "role_changed","your_role_changed","subject_changed","update_users_count",
  "hide_user_layout","enable_user_layout","hide_all_layout","gift_new",
  "room_switched","room_full","room_needs_password","room_wrong_password",
  "room_needs_captcha","room_unauthorized","room_membership_required",
  "room_report_violation","room_create_exists","room_create_empty_balance",
  "room_boost_empty_balance","boost_room","chat_message","chat_state",
  "new_messages","update_message_status","ack_msg","ok_msg","new_call",
  "join_call","call_started","update_call_status","ringing","ready","busy",
  "answer","hang","end","stop_dialing","finish_call_activity",
  "load_store","load_list_new","show_list","show_list_new","colors_list",
  "gifts_list","gifts_list_new","public_gifts","purchase","consume_purchase",
  "purchase_validated","transactions_list","new_balance","stream_upgrade"
];

export function printCatalog() {
  console.log("=== ChatP APK-derived v4 catalog ===");
  console.log("\nACTIVITIES/SCREENS:");
  for (const x of ACTIVITIES) console.log("  ", x);
  console.log("\nSERVICES:");
  for (const x of SERVICES) console.log("  ", x);
  console.log("\nOUTBOUND ACTIONS:");
  for (const [k,v] of Object.entries(ACTIONS)) console.log(`  ${k}: ${v.join(", ")}`);
  console.log("\nROOM INFO TYPES:", ROOM_INFO_TYPES.join(", "));
  console.log("ROOM STREAM TYPES:", ROOM_STREAM_TYPES.join(", "));
  console.log("ROOM ADMIN TYPES:", ROOM_ADMIN_TYPES.join(", "));
  console.log("PROFILE UPDATE TYPES:", PROFILE_UPDATE_TYPES.join(", "));
  console.log("GIFT TYPES:", GIFT_TYPES.join(", "));
  console.log("STORE TYPES:", STORE_TYPES.join(", "));
  console.log("\nINCOMING EVENT CATALOG:");
  for (const x of INCOMING_EVENTS) console.log("  ", x);
}
