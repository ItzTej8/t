import youtubedl from 'youtube-dl-exec';
import { log } from './config.js';
const META_TIMEOUT=Math.max(15000,Number(process.env.YTDLP_META_TIMEOUT_MS||45000));
const AUDIO_FORMAT='bestaudio/best', MAX_SEARCHES=7, MIN_SONG_SECONDS=90, MAX_SONG_SECONDS=900;
const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
const norm=s=>clean(s).toLowerCase().replace(/\([^)]*\)|\[[^\]]*\]/g,' ').replace(/[^\p{L}\p{N}\s-]/gu,' ').replace(/\s+/g,' ').trim();
const words=s=>new Set(norm(s).split(/\s+/).filter(x=>x.length>2));
const overlap=(a,b)=>{const A=words(a),B=words(b);if(!A.size||!B.size)return 0;let n=0;for(const x of A)if(B.has(x))n++;return n/Math.max(1,Math.min(A.size,B.size));};
const artistNorm=s=>norm(s).replace(/\b(official|vevo|topic|records?|music|channel|official artist)\b/g,' ').replace(/\s+/g,' ').trim();
const sameArtist=(a,b)=>{const A=artistNorm(a),B=artistNorm(b);return Boolean(A&&B&&(A===B||A.includes(B)||B.includes(A)));};
const titleCore=(s,artist='')=>{let t=norm(s),a=artistNorm(artist);if(a)t=t.replace(a,' ');return t.replace(/\b(official|video|audio|lyrics?|visualizer|4k|hd|remaster(ed)?|live|performance|topic|vevo|official music video)\b/g,' ').replace(/\s+/g,' ').trim();};
function parse(info){const es=Array.isArray(info?.entries)?info.entries:[info];return es.filter(e=>e?.title).map(e=>({title:e.title,url:e.webpage_url||e.original_url||(e.id?`https://www.youtube.com/watch?v=${e.id}`:''),id:e.id||'',artist:e.uploader||e.channel||'',channel:e.channel||e.uploader||'',durationSeconds:Number(e.duration)||0,thumbnail:e.thumbnail||e.thumbnails?.[0]?.url||'',categories:Array.isArray(e.categories)?e.categories:[],tags:Array.isArray(e.tags)?e.tags:[],description:clean(e.description||'')}));}
async function search(query,count=8){const q=clean(query);if(!q)return[];const p=youtubedl.exec(`ytsearch${Math.max(1,Math.min(15,count))}:${q}`,{dumpSingleJson:true,noWarnings:true,preferFreeFormats:true,format:AUDIO_FORMAT,extractorArgs:'youtube:player_client=android,web',retries:2,extractorRetries:2,socketTimeout:12});let out='',err='';p.stdout?.on('data',d=>{out+=d.toString();if(out.length>15e6)out=out.slice(-15e6)});p.stderr?.on('data',d=>{err+=d.toString();if(err.length>5e5)err=err.slice(-5e5)});return await new Promise((res,rej)=>{const timer=setTimeout(()=>{try{p.kill('SIGKILL')}catch{};rej(new Error(`Smart discovery timed out: ${q}`))},META_TIMEOUT);timer.unref?.();p.on('error',e=>{clearTimeout(timer);rej(e)});p.on('close',code=>{clearTimeout(timer);if(code!==0)return rej(new Error(err.trim()||`yt-dlp exited ${code}`));try{res(parse(JSON.parse(out)))}catch(e){rej(e)}});p.catch?.(()=>{});});}
function musicCandidate(t){const title=norm(t?.title),desc=norm(t?.description),cat=(t?.categories||[]).map(norm).join(' '),d=Number(t?.durationSeconds||0);if(d&&(d<MIN_SONG_SECONDS||d>MAX_SONG_SECONDS))return false;if(/\b(review|tutorial|reaction|reacts|makeup|palette|news|podcast|interview|gameplay|gaming|vlog|trailer|teaser|shorts?|how to|unboxing|explained|analysis|documentary|live stream|livestream)\b/i.test(title)||/\b(review|tutorial|reaction|makeup|news|podcast|gameplay|gaming|vlog|trailer|unboxing)\b/i.test(desc.slice(0,500)))return false;if(cat&&/\b(gaming|news|education|people|howto|comedy)\b/i.test(cat)&&!/\b(music|song|audio)\b/i.test(cat))return false;return true;}
function enrich(seed){
  const title=clean(seed?.title),artist=clean(seed?.artist),cat=(seed?.categories||[]).join(' '),tags=(seed?.tags||[]).slice(0,40).join(' '),desc=clean(seed?.description||'');
  const genre=clean(`${cat} ${tags}`),core=titleCore(title,artist),queries=[];
  if(artist){
    // Exact artist lanes are deliberately strong. Generic YouTube searches
    // such as "songs like <artist>" often return commentary/reaction videos.
    queries.push({lane:'artist',q:`"${artist}" official audio`});
    queries.push({lane:'artist',q:`"${artist}" official music`});
    queries.push({lane:'artist',q:`"${artist}" songs`});
    queries.push({lane:'related',q:`artists similar to "${artist}"`});
  }
  if(core){
    queries.push({lane:'relatedTitle',q:`songs like "${core}" "${artist}"`});
    queries.push({lane:'relatedTitle',q:`similar songs to "${core}"`});
  }
  if(genre) queries.push({lane:'genre',q:`${genre.slice(0,100)} music ${artist||core}`});
  return{...seed,artist,genreHints:genre,moodHints:clean(`${tags} ${desc}`).slice(0,700),titleOnly:core,queries};
}
const key=t=>String(t?.id||t?.url||'').toLowerCase();
function variant(t){return /karaoke|cover|nightcore|8d|sped\s*up|slowed|reverb|instrumental|fan.?made|reaction|tutorial|lyrics?\s+video|remix|bootleg|mashup|compilation/i.test(t||'');}
function score(t,s,mode,recentTitles){
  let v=0;
  const same=sameArtist(t.artist,s.artist);
  const tt=titleCore(t.title,t.artist);
  const titleOverlap=overlap(tt,s.titleOnly);
  const metaOverlap=overlap(`${t.categories?.join(' ')} ${t.tags?.join(' ')} ${t.description||''}`,s.genreHints);
  if(same) v+=mode==='artist'?260:mode==='related'?210:170;
  else if(['related','recommended','hybrid','mood','genre'].includes(mode)) v+=8;
  v+=Math.min(35,titleOverlap*35);
  v+=Math.min(25,metaOverlap*25);
  if(mode==='artist'&&!same) v-=90;
  if(mode==='related'&&!same && titleOverlap<0.15) v-=18;
  if(mode==='genre'&&!metaOverlap) v-=35;
  if(mode==='mood'&&!metaOverlap && titleOverlap<0.15) v-=20;
  if(variant(t.title)) v-=65;
  if(!musicCandidate(t)) v-=180;
  if(recentTitles.some(x=>overlap(x,t.title)>.82)) v-=120;
  if(/\b(official audio|official music video|topic|vevo)\b/i.test(t.title)) v+=12;
  if(Number(t.durationSeconds||0)>=150&&Number(t.durationSeconds||0)<=420)v+=10;
  return v;
}
export async function discover(seed,{count=12,recent=[],mode='hybrid'}={}){
  if(!seed)return[];
  const s=enrich(seed);
  const recentKeys=new Set(recent.map(key).filter(Boolean));
  const recentTitles=recent.map(x=>x?.title||'');
  const pool=new Map();
  const add=rows=>{for(const t of rows||[]){const k=key(t);if(k&&!pool.has(k))pool.set(k,t);}};
  const lanes = mode==='artist'
    ? ['artist']
    : mode==='genre'
      ? ['genre','artist']
      : mode==='mood'
        ? ['relatedTitle','genre','artist']
        : mode==='related'
          ? ['relatedTitle','related','artist']
          : ['artist','relatedTitle','related','genre'];
  let searches=0;
  for(const lane of lanes){
    for(const q of s.queries.filter(x=>x.lane===lane).slice(0,3)){
      if(searches++>=MAX_SEARCHES)break;
      try{add(await search(q.q,10));}catch(e){log(`[SmartDJ] ${lane} query failed: ${q.q} — ${e.message}`);}
    }
    if(searches>=MAX_SEARCHES)break;
  }
  // Expand through artists discovered from the related-artist lane, but only
  // after exact/current-artist candidates have been collected.
  if(['hybrid','related','recommended','mood'].includes(mode)&&s.artist){
    const artists=[];
    for(const t of pool.values()){
      const a=clean(t.artist);
      if(!a||sameArtist(a,s.artist)||artists.some(x=>artistNorm(x)===artistNorm(a)))continue;
      if(!musicCandidate(t))continue;
      artists.push(a);
      if(artists.length>=3)break;
    }
    for(const a of artists){
      if(searches++>=MAX_SEARCHES)break;
      try{add(await search(`"${a}" official audio`,8));}catch(e){log(`[SmartDJ] related artist query failed: ${a} — ${e.message}`);}
    }
  }
  const out=[...pool.values()]
    .filter(t=>t.url&&!recentKeys.has(key(t))&&musicCandidate(t))
    .sort((a,b)=>score(b,s,mode,recentTitles)-score(a,s,mode,recentTitles));
  // Hybrid stations should not be flooded by unrelated artists when exact
  // artist tracks exist. Keep a predictable same-artist front section, then
  // fill with genuinely related candidates.
  if(['hybrid','recommended'].includes(mode)&&s.artist){
    const same=out.filter(t=>sameArtist(t.artist,s.artist));
    const other=out.filter(t=>!sameArtist(t.artist,s.artist));
    const sameTake=Math.min(Math.max(2,Math.ceil(count*0.55)),same.length);
    return [...same.slice(0,sameTake),...other].slice(0,count).map(x=>({...x,requestedBy:'AutoDJ'}));
  }
  return out.slice(0,count).map(x=>({...x,requestedBy:'AutoDJ'}));
}
