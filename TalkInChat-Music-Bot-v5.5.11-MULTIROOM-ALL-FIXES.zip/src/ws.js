import WebSocket from "ws";
import { EventEmitter } from "node:events";
import { config, log, debug } from "./config.js";
import { ProtocolHandlers } from "./handlers.js";
import { encode } from "./proto.js";

export class ChatPSocket extends EventEmitter {
  constructor({ url, headers = {}, enablePing = true, auth = null } = {}) {
    super();
    this.url = url;
    this.headers = headers;
    this.enablePing = enablePing;
    this.auth = auth;
    this.ws = null;
    this.handlers = new ProtocolHandlers();
    this.connected = false;
    this.reconnectTimer = null;
    this.pingTimer = null;
    this.stopped = false;
    this.reconnectAttempt = 0;
    this.connectionGeneration = 0;

    // Prevent unhandled 'error' event crash
    this.on("error", (err) => {
      debug("[WS Catch-all]", err.message);
    });
  }

  connect() {
    this.stopped = false;
    const generation = ++this.connectionGeneration;
    const previous = this.ws;
    if (previous && previous.readyState !== WebSocket.CLOSED) { try { previous.close(1000, "superseded"); } catch {} }
    this.ws = new WebSocket(this.url, {
      headers: this.headers,
      perMessageDeflate: false,
      // Verify TLS certificates by default. Set CHATP_WS_TLS_INSECURE=true
      // only for a known development/self-signed server.
      rejectUnauthorized: process.env.CHATP_WS_TLS_INSECURE === "true" ? false : true
    });

    this.ws.binaryType = "arraybuffer";

    this.ws.on("open", () => {
      if (generation !== this.connectionGeneration) return;
      this.connected = true;
      this.reconnectAttempt = 0;
      log("[WS] connected", this.url);
      this.startPing();
      this.emit("open");
      this.emit("connected");
    });

    this.ws.on("message", (data, isBinary) => {
      if (generation !== this.connectionGeneration) return;
      const payload = this.handlers.handle(Buffer.from(data), isBinary);
      if (payload?.handlerId === 99) {
        try {
          this.send(encode("Query", { action: "ok" }));
          debug("[WS] Handled application heartbeat handlerId: 99 -> sent ok");
        } catch {}
      }
      this.emit("message", payload);
    });

    this.ws.on("ping", data => {
      if (generation !== this.connectionGeneration) return;
      debug("[WS] server ping");
      this.emit("ping", data);
      // ws automatically sends pong for received protocol ping.
    });

    this.ws.on("pong", data => {
      if (generation !== this.connectionGeneration) return;
      debug("[WS] pong");
      this.emit("pong", data);
    });

    this.ws.on("close", (code, reason) => {
      if (generation !== this.connectionGeneration) return;
      this.connected = false;
      this.stopPing();
      log("[WS] closed", code, reason?.toString?.() || "");
      this.emit("close", code, reason);
      this.scheduleReconnect();
    });

    this.ws.on("error", err => {
      if (generation !== this.connectionGeneration) return;
      log("[WS] error", err.message);
      this.emit("error", err);
    });

    return this;
  }

  startPing() {
    this.stopPing();
    if (!this.enablePing) return;
    this.pingTimer = setInterval(() => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        this.ws.ping();
        this.emit("pingSent");
      }
    }, config.pingIntervalMs);
  }

  stopPing() {
    if (this.pingTimer) clearInterval(this.pingTimer);
    this.pingTimer = null;
  }

  send(buffer) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN)
      throw new Error("WebSocket is not open");
    this.ws.send(Buffer.from(buffer));
  }

  close(code = 1000, reason = "client stop") {
    this.stopped = true;
    this.connectionGeneration++;
    this.stopPing();
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = null;
    this.ws?.close(code, reason);
  }

  scheduleReconnect() {
    if (this.stopped || !config.reconnect || this.reconnectTimer) return;
    // ChatP recovery is deliberately fixed-delay and unlimited. Exponential
    // backoff can leave a music bot invisible for minutes after a mobile
    // network change. The server connection itself is retried until it opens.
    const baseDelay = Math.max(10000, Number(config.reconnectDelayMs || 10000));
    const maxDelay = Math.max(baseDelay, Number(config.maxReconnectDelayMs || baseDelay));
    const delay = Math.min(maxDelay, baseDelay);
    this.reconnectAttempt++;
    log(`[WS] reconnect attempt #${this.reconnectAttempt} in ${delay}ms`);
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.emit("reconnect");
      this.connect();
    }, delay);
  }

  onEvent(name, fn) {
    this.handlers.on(name, fn);
    return this;
  }
}
