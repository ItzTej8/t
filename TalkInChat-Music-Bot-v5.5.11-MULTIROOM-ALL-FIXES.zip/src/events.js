/*
 * Incoming values seen in the supplied APK.
 * These are deliberately separated into protocol/event catalogs.
 */

export const SERVER_ROOM_EVENTS = Object.freeze([
  "user_joined", "user_left", "you_joined", "you_rejoined",
  "role_changed", "your_role_changed", "subject_changed",
  "publish_stream", "stream_exists", "stop_stream", "join_stream",
  "stream_enabled", "stop_streaming_service", "sent_invitation",
  "you_invited", "revoked", "room_switched", "room_full",
  "room_needs_password", "room_wrong_password", "room_needs_captcha",
  "room_unauthorized", "room_membership_required", "room_report_violation",
  "room_create_exists", "room_create_empty_balance", "room_boost_empty_balance",
  "boost_room", "update_users_count", "hide_user_layout",
  "enable_user_layout", "hide_all_layout", "show_welcome_message",
  "gift_new", "chat_notification"
]);

export const SERVER_MESSAGE_EVENTS = Object.freeze([
  "chat_message", "chat_state", "update_message_status", "ack_msg",
  "new_messages", "new_messages_count", "ok_msg"
]);

export const CALL_EVENTS = Object.freeze([
  "new_call", "join_call", "call_started", "update_call_status",
  "ringing", "ready", "busy", "answer", "hang", "end",
  "stop_dialing", "finish_call_activity"
]);

export const STORE_EVENTS = Object.freeze([
  "load_store", "load_list_new", "show_list", "show_list_new",
  "colors_list", "gifts_list", "gifts_list_new", "public_gifts",
  "purchase", "consume_purchase", "purchase_validated",
  "transactions_list", "new_balance", "stream_upgrade"
]);

export const LOCAL_APP_EVENTS = Object.freeze([
  "connected", "reconnect", "send_text", "send_raw", "send_text",
  "refresh_friend_requests", "refresh_my_photo", "close_main",
  "close_room_activity", "close_rooms_search", "close_restore_page",
  "close_create_room", "logout_main", "play_gift", "animate_gift",
  "play_user_voice", "mute_button", "speaker_button", "join_progress",
  "show_invitation_dialog", "show_occupants_dialog", "hide_keyboard"
]);

export function eventCatalog() {
  return {
    serverRoom: [...SERVER_ROOM_EVENTS],
    serverMessages: [...SERVER_MESSAGE_EVENTS],
    calls: [...CALL_EVENTS],
    store: [...STORE_EVENTS],
    localApp: [...LOCAL_APP_EVENTS]
  };
}
