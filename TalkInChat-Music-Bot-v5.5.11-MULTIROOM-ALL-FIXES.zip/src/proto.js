/*
 * Minimal protobuf wire encoder/decoder.
 * The supplied APK uses protobuf-generated Query/AuthRequest and ResultMessage
 * messages. This implementation keeps unknown fields so protocol additions
 * are visible instead of silently discarded.
 */

const TYPE = {
  Query: {
    action: 1, type: 2, length: 3, to: 4, body: 5, room: 6, url: 7, uid: 8,
    password: 9, state: 10, value: 11, value1: 12, intValue: 13, longValue: 14,
    useBin: 15, captchaCode: 16, captchaUrl: 17, id: 18, productId: 19,
    orderId: 20, purchaseTime: 21, purchaseState: 22, payload: 23, token: 24
  },
  AuthRequest: {
    type: 1, username: 2, password: 3, captchaCode: 4, captchaUrl: 5, sid: 6,
    sdk: 7, os: 8, ver: 9, clientVer: 10, deviceId: 11, deviceModel: 12,
    language: 13, method: 14
  },
  AuthResult: {
    result: 1, userId: 2, photoUrl: 3, photoVersion: 4, id: 5, message: 6,
    server: 7, method: 8, enablePing: 9, enableRoomAck: 10
  },
  ResultMessage: {
    handlerId: 1, type: 2, page: 3, uid: 4, value: 5, intValue: 6,
    streamEvent: 8, chatMessage: 9, roomEvent: 10, users: 11, rooms: 12,
    callInfo: 13, roomAdmin: 14, loginInfo: 15, sessions: 16
  },
  UserItem: { username: 1, userId: 2, photo: 3, status: 4, online: 5, role: 6 },
  RoomItem: {
    name: 1, usersCount: 2, maxUsers: 3, membersOnly: 4, passwordProtected: 5,
    isVip: 6, isStreaming: 7
  },
  SessionItem: { country: 1, isActive: 2, timestamp: 3 },
  RoomLog: { actor: 1, username: 2, oldRole: 3, newRole: 4, loggedTime: 5 },
  RoomAdmin: {
    type: 1, room: 2, password: 3, membersOnly: 4, ownersCount: 5, adminsCount: 6,
    membersCount: 7, outcastCount: 8, bannedIpCount: 9, occupants: 10, users: 11,
    logs: 12, streamExpire: 13
  },
  ChatMessage: {
    type: 1, id: 2, from: 3, to: 4, body: 5, url: 6, length: 7, uid: 8,
    state: 9, offline: 10, timestamp: 11, isMine: 12
  },
  StreamEvent: {
    type: 1, from: 2, to: 3, autoJoin: 4, token: 5, sessionId: 6, url: 7,
    room: 8, id: 9
  },
  CallInfo: {
    action: 1, peer: 2, url: 3, room: 4, id: 5, token: 6
  },
  LoginInfo: {
    photoVersion: 1, hasNotification: 2, currentType: 3, photoUrl: 4, userId: 5
  },
  RoomEvent: {
    type: 1, from: 2, to: 3, toId: 4, toRoom: 5, body: 6, url: 7, role: 8,
    isAgent: 9, avatarUrl: 10, textColor: 11, idColor: 12, room: 13,
    userId: 14, isEmoji: 15, timestamp: 16, actor: 17, gift: 18, resources: 19,
    animation: 20, repeats: 21, username: 22, currentCount: 23, reconnected: 24,
    subject: 25, subjectAuthor: 26, boostResource: 27, isFavourite: 28,
    private: 29, isStreaming: 30, newRole: 31, oldRole: 32, tUsername: 33,
    badgeUrl: 34, badgeSize: 35, isMerchant: 36, agentBadge: 37, isVip: 38,
    captchaUrl: 39, users: 40, id: 41, borderColor: 42
  }
};

// APK schema note: RoomEvent.users (field 40) is a repeated UserItem in the
// generated APK protobuf class. Some older logging paths stringify its encoded
// protobuf bytes as `\n\x05username2\x05role`; decode() normalizes it to UserItem[].

function vi(n) {
  let x = BigInt(n);
  const out = [];
  while (x >= 0x80n) {
    out.push(Number((x & 0x7fn) | 0x80n));
    x >>= 7n;
  }
  out.push(Number(x));
  return Buffer.from(out);
}

function readVi(buf, off) {
  let x = 0n, shift = 0n, i = off;
  for (let count = 0; i < buf.length && count < 10; count++) {
    const b = buf[i++];
    // A protobuf varint is at most 10 bytes for an unsigned 64-bit value.
    // The tenth byte may only carry the low bit (bit 63).
    if (count === 9 && (b & 0x7e)) throw new Error("invalid protobuf varint");
    x |= BigInt(b & 0x7f) << shift;
    if (!(b & 0x80)) return [x, i];
    shift += 7n;
  }
  if (i >= buf.length) throw new Error("truncated protobuf varint");
  throw new Error("invalid protobuf varint");
}

function fieldBytes(field, data) {
  const b = Buffer.from(data);
  return Buffer.concat([vi((field << 3) | 2), vi(b.length), b]);
}
function fieldString(field, value) {
  if (value === undefined || value === null) return Buffer.alloc(0);
  return fieldBytes(field, Buffer.from(String(value), "utf8"));
}
function fieldVarint(field, value) {
  if (value === undefined || value === null) return Buffer.alloc(0);
  return Buffer.concat([vi(field << 3), vi(value)]);
}
const FIELD_KINDS = {
  AuthResult: { enablePing: "bool", enableRoomAck: "bool" },
  ResultMessage: { handlerId: "int", page: "int", intValue: "int" },
  UserItem: { online: "int" },
  RoomItem: { usersCount: "int", maxUsers: "int", membersOnly: "bool", passwordProtected: "bool", isVip: "bool", isStreaming: "bool" },
  SessionItem: { isActive: "int" },
  RoomLog: { loggedTime: "long" },
  RoomAdmin: { ownersCount: "int", adminsCount: "int", membersCount: "int", outcastCount: "int", bannedIpCount: "int", streamExpire: "long" },
  ChatMessage: { offline: "int", isMine: "int" },
  LoginInfo: { hasNotification: "int", currentType: "int" },
  RoomEvent: { animation: "int", repeats: "int", currentCount: "int", badgeSize: "int" },
  Query: { intValue: "int", useBin: "int", longValue: "long" }
};

function fieldKind(type, name) {
  return FIELD_KINDS[type]?.[name] || "string";
}

export function encode(type, obj = {}) {
  const map = TYPE[type];
  if (!map) throw new Error(`Unknown protobuf type: ${type}`);
  const parts = [];
  for (const [name, field] of Object.entries(map)) {
    if (!(name in obj)) continue;
    const raw = obj[name];
    const values = Array.isArray(raw) ? raw : [raw];
    for (const v of values) {
      const kind = fieldKind(type, name);
      if (kind === "int" || kind === "long" || kind === "bool") {
        parts.push(fieldVarint(field, v === true ? 1 : v === false ? 0 : v));
      } else if (Buffer.isBuffer(v) || v instanceof Uint8Array) {
        parts.push(fieldBytes(field, v));
      } else {
        parts.push(fieldString(field, v));
      }
    }
  }
  return Buffer.concat(parts);
}

const MAX_PROTO_MESSAGE_BYTES = Math.max(1024, Number(process.env.MAX_PROTO_MESSAGE_BYTES || 8 * 1024 * 1024));
const MAX_PROTO_FIELD_BYTES = Math.max(1024, Number(process.env.MAX_PROTO_FIELD_BYTES || 4 * 1024 * 1024));
const MAX_PROTO_GROUP_DEPTH = Math.max(1, Number(process.env.MAX_PROTO_GROUP_DEPTH || 32));

function checkedLength(len, next, bufLength, label = "protobuf bytes") {
  if (len > BigInt(MAX_PROTO_FIELD_BYTES)) throw new Error(`protobuf ${label} exceeds limit`);
  const n = Number(len);
  if (!Number.isSafeInteger(n) || next + n > bufLength) throw new Error(`truncated ${label}`);
  return next + n;
}

function skipGroup(buf, off, depth = 1) {
  if (depth > MAX_PROTO_GROUP_DEPTH) throw new Error("protobuf group nesting limit exceeded");
  const start = off;
  while (off < buf.length) {
    const [key, afterKey] = readVi(buf, off);
    off = afterKey;
    const wire = Number(key & 7n);
    if (wire === 0) {
      [, off] = readVi(buf, off);
    } else if (wire === 1) {
      if (off + 8 > buf.length) throw new Error("truncated fixed64 in group");
      off += 8;
    } else if (wire === 2) {
      const [len, next] = readVi(buf, off);
      off = checkedLength(len, next, buf.length, "group bytes");
    } else if (wire === 3) {
      const nested = skipGroup(buf, off, depth + 1);
      off = nested.next;
    } else if (wire === 4) {
      return { value: buf.subarray(start, off), next: off };
    } else if (wire === 5) {
      if (off + 4 > buf.length) throw new Error("truncated fixed32 in group");
      off += 4;
    } else {
      throw new Error(`unsupported protobuf wire type ${wire} inside group`);
    }
  }
  throw new Error("unterminated protobuf group");
}

function decodeFields(buf) {
  if (buf.length > MAX_PROTO_MESSAGE_BYTES) throw new Error("protobuf message exceeds limit");
  const fields = [];
  let off = 0;
  while (off < buf.length) {
    const [key, afterKey] = readVi(buf, off);
    off = afterKey;
    const fieldNo = Number(key >> 3n);
    const wire = Number(key & 7n);
    if (wire === 0) {
      const [value, next] = readVi(buf, off);
      fields.push({ fieldNo, wire, value });
      off = next;
    } else if (wire === 2) {
      const [len, next] = readVi(buf, off);
      const end = checkedLength(len, next, buf.length);
      fields.push({ fieldNo, wire, value: buf.subarray(next, end) });
      off = end;
    } else if (wire === 1) {
      if (off + 8 > buf.length) throw new Error("truncated fixed64");
      fields.push({ fieldNo, wire, value: buf.subarray(off, off + 8) });
      off += 8;
    } else if (wire === 5) {
      if (off + 4 > buf.length) throw new Error("truncated fixed32");
      fields.push({ fieldNo, wire, value: buf.subarray(off, off + 4) });
      off += 4;
    } else if (wire === 3) {
      // Deprecated protobuf groups are rare, but older/foreign clients can
      // still emit them. Skip the complete group recursively instead of
      // tearing down the WebSocket with "unsupported protobuf wire type 3".
      // Keep a marker so callers can inspect that an unknown group existed.
      const group = skipGroup(buf, off);
      fields.push({ fieldNo, wire, value: group.value });
      off = group.next;
    } else if (wire === 4) {
      // A top-level END_GROUP is malformed, but tolerate it as an unknown
      // zero-width field. This is important for compatibility with legacy
      // ChatP/proxy frames: one odd packet must never tear down the socket.
      fields.push({ fieldNo, wire, value: Buffer.alloc(0), malformed: true });
    } else {
      throw new Error(`unsupported protobuf wire type ${wire}`);
    }
  }
  return fields;
}

function decodeScalarField(field, kind = "string") {
  if (kind === "varint") return Number(field.value);
  if (kind === "bool") return Number(field.value) !== 0;
  if (kind === "bigint") return BigInt(field.value);
  if (kind === "bytes") return Buffer.from(field.value);
  return Buffer.from(field.value).toString("utf8");
}

function decodePackedVarints(bytes, kind = "varint") {
  const buf = Buffer.from(bytes);
  const out = [];
  let off = 0;
  while (off < buf.length) {
    const [value, next] = readVi(buf, off);
    off = next;
    out.push(kind === "bool" ? value !== 0n : kind === "bigint" ? value : Number(value));
  }
  return out;
}

function assignDecoded(out, name, value) {
  if (!(name in out)) {
    out[name] = value;
  } else if (Array.isArray(out[name])) {
    if (Array.isArray(value)) out[name].push(...value);
    else out[name].push(value);
  } else {
    out[name] = Array.isArray(value) ? [out[name], ...value] : [out[name], value];
  }
}

function decodeMessage(type, buf) {
  const map = TYPE[type];
  if (!map) return { _type: type, raw: Buffer.from(buf) };
  const fields = decodeFields(buf);
  const byNo = new Map(Object.entries(map).map(([k,v]) => [v,k]));
  const out = { _type: type };
  for (const f of fields) {
    const name = byNo.get(f.fieldNo);
    if (!name) {
      (out._unknown ??= []).push({ fieldNo: f.fieldNo, wire: f.wire,
        value: Buffer.isBuffer(f.value) ? f.value.toString("base64") : String(f.value) });
      continue;
    }

    const kind = fieldKind(type, name);
    if (f.wire === 2 && kind !== "string") {
      // Protobuf permits repeated numeric fields to be packed into one length-
      // delimited field. Support that form as well as repeated wire-0 fields.
      try {
        const packedKind = kind === "bool" ? "bool" : kind === "long" ? "bigint" : "varint";
        assignDecoded(out, name, decodePackedVarints(f.value, packedKind));
        continue;
      } catch {
        // A known nested/bytes field is handled by the ResultMessage nested pass.
      }
    }

    const decodeKind = kind === "bool" ? "bool" : kind === "int" ? "varint" : kind === "long" ? "bigint" : "string";
    assignDecoded(out, name, decodeScalarField(f, decodeKind));
  }
  if (type === "RoomEvent") {
    const userFields = fields.filter(f => f.fieldNo === 40 && f.wire === 2);
    if (userFields.length) out.users = userFields.map(f => decodeMessage("UserItem", f.value));
  }
  return out;
}

export function decode(type, buf) {
  const b = Buffer.from(buf);
  if (type === "ResultMessage") {
    const fields = decodeFields(b);
    const out = decodeMessage(type, b);
    const nested = {
      streamEvent: [8, "StreamEvent", false],
      chatMessage: [9, "ChatMessage", false],
      roomEvent: [10, "RoomEvent", false],
      users: [11, "UserItem", true],
      rooms: [12, "RoomItem", true],
      callInfo: [13, "CallInfo", false],
      roomAdmin: [14, "RoomAdmin", false],
      loginInfo: [15, "LoginInfo", false],
      sessions: [16, "SessionItem", true]
    };
    for (const [name, [no, child, repeated]] of Object.entries(nested)) {
      const matches = fields.filter(x => x.fieldNo === no && x.wire === 2);
      if (!matches.length) continue;
      out[name] = repeated
        ? matches.map(x => decodeMessage(child, x.value))
        : decodeMessage(child, matches[0].value);
    }

    // RoomAdmin contains repeated UserItem/RoomLog messages. The previous
    // decoder treated these as opaque strings, which meant the multi-room
    // supervisor could not reliably determine whether the PM requester was a
    // room owner after an invitation. Decode these nested lists explicitly.
    const admin = out.roomAdmin;
    if (admin && !Array.isArray(admin)) {
      const adminFields = decodeFields(fields.find(f => f.fieldNo === 14 && f.wire === 2)?.value || Buffer.alloc(0));
      const nestedAdmin = [
        ['occupants', 10, 'UserItem'],
        ['users', 11, 'UserItem'],
        ['logs', 12, 'RoomLog']
      ];
      for (const [name, no, child] of nestedAdmin) {
        const matches = adminFields.filter(x => x.fieldNo === no && x.wire === 2);
        if (matches.length) admin[name] = matches.map(x => decodeMessage(child, x.value));
      }
    }
    const roomEvent = out.roomEvent;
    if (roomEvent && !Array.isArray(roomEvent)) {
      const roomEventFields = decodeFields(fields.find(f => f.fieldNo === 10 && f.wire === 2)?.value || Buffer.alloc(0));
      const userMatches = roomEventFields.filter(x => x.fieldNo === 40 && x.wire === 2);
      if (userMatches.length) roomEvent.users = userMatches.map(x => decodeMessage('UserItem', x.value));
    }
    return out;
  }
  return decodeMessage(type, b);
}

export const protobufSchema = TYPE;
export { readVi, decodeFields };
