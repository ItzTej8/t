/* SQLite-only room/community state. User statistics and DJ lists are isolated
 * per room; this process never writes a JSON state file. */
import { getStateEntries, getStateValue, setStateValue, setStateEntries, getRoomPlayback, setRoomPlayback, clearRoomPlayback, deleteStatePrefix } from './room_database.js';
const ROOM=String(process.env.ROOM_WORKER_ROOM||process.env.DEFAULT_ROOM||'global').trim()||'global';
const NS='pro';
const key=u=>String(u||'User').trim().toLowerCase();
const clone=v=>v==null?v:structuredClone(v);
export function flushPersistence(){return true}
export function getProState(){
  const e=getStateEntries(ROOM,NS);
  return { queueLimit:Number(e.queueLimit)||100, djMode:e.djMode===true || e.djMode==='true', djUsers:Array.isArray(e.djUsers)?e.djUsers:(String(e.djUsers||'').split(',').map(x=>x.trim()).filter(Boolean)), userCommands:e.userCommands||{}, userTracks:e.userTracks||{}, topTracks:e.topTracks||{}, schedules:listSchedules(), transitionSeconds:Number(e.transitionSeconds)||0, playbackSnapshot:getPlaybackSnapshot() };
}
export function setQueueLimit(n){const v=Math.max(1,Math.min(1000,Math.floor(Number(n)||100)));setStateValue(ROOM,NS,'queueLimit',v);return v}
export function getQueueLimit(){return Number(getStateValue(ROOM,NS,'queueLimit',100))||100}
export function setDjState(enabled,users=[]){const out=[...new Set(users.map(String).filter(Boolean))];setStateValue(ROOM,NS,'djMode',!!enabled);setStateValue(ROOM,NS,'djUsers',out.join(','));return {enabled:!!enabled,users:out}}
export function setDjUsers(users){const out=[...new Set(users.map(String).filter(Boolean))];setStateValue(ROOM,NS,'djUsers',out.join(','));return out}
export function recordUserCommand(user){const u=key(user);const k=`userCommands.${u}`;setStateValue(ROOM,NS,k,(Number(getStateValue(ROOM,NS,k,0))||0)+1)}
export function recordUserTrack(user,track){
  const u=key(user);const uk=`userTracks.${u}`;setStateValue(ROOM,NS,uk,(Number(getStateValue(ROOM,NS,uk,0))||0)+1);
  const id=encodeURIComponent(String(track?.url||track?.title||'').slice(0,500));if(!id)return;
  const base=`topTracks.${id}`;
  setStateValue(ROOM,NS,`${base}.title`,track?.title||String(track?.url||''));
  setStateValue(ROOM,NS,`${base}.artist`,track?.artist||'YouTube');
  setStateValue(ROOM,NS,`${base}.plays`,(Number(getStateValue(ROOM,NS,`${base}.plays`,0))||0)+1);
}
export function topTracks(limit=10){return Object.values(getStateEntries(ROOM,NS).topTracks||{}).sort((a,b)=>(Number(b.plays)||0)-(Number(a.plays)||0)).slice(0,Math.max(1,Number(limit)||10))}
export function topUsers(limit=10){return Object.entries(getStateEntries(ROOM,NS).userTracks||{}).map(([user,plays])=>({user,plays:Number(plays)||0})).sort((a,b)=>b.plays-a.plays).slice(0,Math.max(1,Number(limit)||10))}
export function userStats(user){const u=key(user);return {user:u,commands:Number(getStateValue(ROOM,NS,`userCommands.${u}`,0))||0,tracks:Number(getStateValue(ROOM,NS,`userTracks.${u}`,0))||0}}
export function setTransitionSeconds(n){const v=Math.max(0,Math.min(30,Number(n)||0));setStateValue(ROOM,NS,'transitionSeconds',v);return v}
export function getTransitionSeconds(){return Number(getStateValue(ROOM,NS,'transitionSeconds',0))||0}
export function savePlaybackSnapshot(snapshot){setRoomPlayback(ROOM,snapshot)}
export function getPlaybackSnapshot(){return clone(getRoomPlayback(ROOM))}
export function clearPlaybackSnapshot(){clearRoomPlayback(ROOM)}
function scheduleEntries(){return getStateEntries(ROOM,NS).schedules||{}}
export function addSchedule(item){const id=String(item?.id||Date.now());const base=`schedules.${id}`;const entries={};const flatten=(obj,p='')=>{for(const [k,v] of Object.entries(obj||{})){const key=p?`${p}.${k}`:k;if(v&&typeof v==='object'&&!Array.isArray(v))flatten(v,key);else entries[key]=v}};flatten(item);for(const [k,v] of Object.entries(entries))setStateValue(ROOM,NS,`${base}.${k}`,v);return item}
export function listSchedules(){return Object.entries(scheduleEntries()).map(([id,v])=>({id,...v})).sort((a,b)=>Number(a.at||0)-Number(b.at||0))}
export function removeSchedule(id){const prefix=`schedules.${String(id)}`;const before=listSchedules().length;const {deleteStatePrefix}=Object.getPrototypeOf({});void deleteStatePrefix; // kept for API shape; actual delete below
  const rows=getStateEntries(ROOM,NS); delete rows.schedules?.[String(id)]; setStateEntries(ROOM,NS,{...rows}); return listSchedules().length<before}
export function updateSchedules(fn){const next=fn(clone(listSchedules()));setStateEntries(ROOM,NS,{...getStateEntries(ROOM,NS),schedules:Object.fromEntries(next.map(x=>[String(x.id),x]))});return clone(next)}
