import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { AudioStream, TrackKind, RoomEvent } from '@livekit/rtc-node';

const sleep = ms => new Promise(r => setTimeout(r, ms));
const clamp = (n,a,b) => Math.max(a, Math.min(b,n));

export { parseVoiceCommand } from "./voice_command_parser.js";

function pcmRms(frame) {
  const d = frame?.data;
  if (!d?.length) return 0;
  let sum = 0;
  const step = Math.max(1, Math.floor(d.length / 400));
  let n = 0;
  for (let i = 0; i < d.length; i += step) { const x = d[i] / 32768; sum += x*x; n++; }
  return Math.sqrt(sum / Math.max(1,n));
}

function wavHeader(dataBytes, sampleRate, channels) {
  const h = Buffer.alloc(44);
  h.write('RIFF',0); h.writeUInt32LE(36 + dataBytes,4); h.write('WAVE',8);
  h.write('fmt ',12); h.writeUInt32LE(16,16); h.writeUInt16LE(1,20); h.writeUInt16LE(channels,22);
  h.writeUInt32LE(sampleRate,24); h.writeUInt32LE(sampleRate * channels * 2,28);
  h.writeUInt16LE(channels * 2,32); h.writeUInt16LE(16,34); h.write('data',36); h.writeUInt32LE(dataBytes,40);
  return h;
}

export class VoiceCommandEngine {
  constructor({enabled=process.env.VOICE_COMMANDS_ENABLED === 'true', whisperBin=process.env.WHISPER_BIN || 'whisper', model=process.env.WHISPER_MODEL || '', language=process.env.VOICE_COMMAND_LANGUAGE || 'auto', onCommand=async()=>{}, onTranscript=()=>{}, log=console.log}={}) {
    this.enabled = Boolean(enabled);
    this.whisperBin = whisperBin;
    this.model = model;
    this.language = language;
    this.onCommand = onCommand;
    this.onTranscript = onTranscript;
    this.log = log;
    this.room = null;
    this.handlers = [];
    this.streams = new Set();
    this.running = false;
    this.lastCommandAt = 0;
  }
  status() { return { enabled:this.enabled, running:this.running, whisperBin:this.whisperBin, language:this.language, activeStreams:this.streams.size }; }
  async checkBinary() {
    if (!this.enabled) return false;
    return await new Promise(resolve => { const p=spawn(this.whisperBin,['--help'],{stdio:'ignore'}); let done=false; const finish=v=>{if(done)return;done=true;clearTimeout(timer);resolve(v)}; const timer=setTimeout(()=>{try{p.kill('SIGKILL')}catch{} finish(false)},5000); timer.unref?.(); p.on('error',()=>finish(false)); p.on('exit',code=>finish(code===0)); });
  }
  async attach(room) {
    if (!this.enabled || !room || this.room === room) return false;
    await this.detach(); this.room = room; this.running = true;
    const onSubscribed = (track, publication, participant) => {
      if (!track || track.kind !== TrackKind.KIND_AUDIO) return;
      if (participant?.identity === room.localParticipant?.identity) return;
      void this.consume(track, participant?.identity || 'unknown');
    };
    room.on?.(RoomEvent.TrackSubscribed, onSubscribed);
    this.handlers.push([room, RoomEvent.TrackSubscribed, onSubscribed]);
    // Existing remote publications may already be subscribed after reconnect.
    try {
      for (const participant of room.remoteParticipants?.values?.() || []) {
        for (const publication of participant.trackPublications?.values?.() || participant.tracks?.values?.() || []) {
          if (publication?.track && publication.kind === TrackKind.KIND_AUDIO) void this.consume(publication.track, participant.identity || 'unknown');
        }
      }
    } catch {}
    return true;
  }
  async consume(track, identity) {
    if (!this.running || this.streams.size >= 2) return;
    let audio;
    try { audio = new AudioStream(track, 16000, 1); } catch (e) { this.log(`[VoiceCmd] AudioStream failed: ${e.message}`); return; }
    this.streams.add(audio);
    try {
      let buffers=[]; let bytes=0; let speaking=false; let silentMs=0; let speechMs=0; let lastFlush=Date.now();
      for await (const frame of audio) {
        if (!this.running) break;
        const rms = pcmRms(frame);
        const frameMs = (frame.samplesPerChannel / frame.sampleRate) * 1000;
        if (rms > 0.018) { speaking=true; speechMs += frameMs; silentMs=0; }
        else if (speaking) silentMs += frameMs;
        if (speaking) { const b=Buffer.from(frame.data.buffer, frame.data.byteOffset, frame.data.byteLength); buffers.push(Buffer.from(b)); bytes += b.length; }
        if (speaking && silentMs >= 700 || (speaking && Date.now()-lastFlush >= 5000)) {
          if (speechMs >= 300) await this.transcribeAndDispatch(Buffer.concat(buffers, bytes), 16000, 1, identity);
          buffers=[]; bytes=0; speechMs=0; silentMs=0; speaking=false; lastFlush=Date.now();
        }
      }
    } catch (e) { if (this.running) this.log(`[VoiceCmd] stream error (${identity}): ${e.message}`); }
    finally { this.streams.delete(audio); try { await audio.cancel?.(); } catch {} }
  }
  async transcribeAndDispatch(pcm, sampleRate, channels, identity) {
    const tmp=path.join(os.tmpdir(),`talkinchat-voice-${process.pid}-${Date.now()}.wav`);
    try {
      fs.writeFileSync(tmp, Buffer.concat([wavHeader(pcm.length,sampleRate,channels),pcm]));
      const args=[tmp,'--output_format','txt','--output_dir',path.dirname(tmp),'--task','transcribe'];
      if (this.model) args.push('--model',this.model);
      if (this.language && this.language !== 'auto') args.push('--language',this.language);
      const text=await new Promise((resolve,reject)=>{let out='';let err='';let done=false;const p=spawn(this.whisperBin,args,{stdio:['ignore','pipe','pipe']});const finish=(fn,v)=>{if(done)return;done=true;clearTimeout(timer);fn(v)};const timeoutMs=Math.max(10000,Number(process.env.WHISPER_TIMEOUT_MS||60000));const timer=setTimeout(()=>{try{p.kill('SIGKILL')}catch{} finish(reject,new Error(`whisper timed out after ${timeoutMs}ms`))},timeoutMs);timer.unref?.();p.stdout.on('data',d=>out+=d);p.stderr.on('data',d=>err+=d);p.on('error',e=>finish(reject,e));p.on('exit',code=>code===0?finish(resolve,out):finish(reject,new Error(err||`whisper exited ${code}`)));});
      let transcript=String(text).trim();
      const txtFile=tmp.replace(/\.wav$/i,'.txt'); if(fs.existsSync(txtFile)){transcript=fs.readFileSync(txtFile,'utf8').trim();fs.rmSync(txtFile,{force:true});}
      if (!transcript) return;
      this.onTranscript(transcript, identity);
      const parsed=parseVoiceCommand(transcript);
      if (!parsed?.command || Date.now()-this.lastCommandAt < 1200) return;
      this.lastCommandAt=Date.now();
      await this.onCommand(parsed.command, identity, transcript);
    } catch (e) { this.log(`[VoiceCmd] transcription failed: ${e.message}`); }
    finally { fs.rmSync(tmp,{force:true}); }
  }
  async detach() { this.running=false; for(const [room,event,fn] of this.handlers){try{room.off?.(event,fn);}catch{}} this.handlers=[]; for(const s of this.streams){try{await s.cancel?.();}catch{}} this.streams.clear(); this.room=null; }
}
