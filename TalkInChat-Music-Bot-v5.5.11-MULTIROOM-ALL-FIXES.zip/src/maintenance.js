import fs from 'node:fs'; import os from 'node:os'; import {backupData,createBackupScheduler,dataDir} from './platform_core.js';
let stopBackup=null;
export function startMaintenance({log=console.log,time=process.env.BOT_BACKUP_TIME||'00:00'}={}){stopBackup=createBackupScheduler(time,()=>{try{const f=backupData('scheduled');log(`[Backup] Created ${f}`);}catch(e){log(`[Backup] ${e.message}`);}});}
export function stopMaintenance(){stopBackup?.();stopBackup=null;}
export function systemInfo(){return {platform:process.platform,arch:process.arch,node:process.version,uptime:os.uptime(),memory:process.memoryUsage(),dataDir};}
export function manualBackup(label='manual'){return backupData(label);}
