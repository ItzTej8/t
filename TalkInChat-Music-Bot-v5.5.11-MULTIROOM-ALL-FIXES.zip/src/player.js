import youtubedl from "youtube-dl-exec";
import { EventEmitter } from "node:events";
import fs from "node:fs";
import fsp from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { log } from "./config.js";
import { saveCustomPlaylist, getCustomPlaylist, deleteCustomPlaylist, listCustomPlaylists } from "./playlists.js";
import { discover as discoverSmartTracks } from "./smart_radio.js";

function durationSeconds(details) {
  const n = Number(details?.duration);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : 0;
}

const YTDLP_META_TIMEOUT_MS = Math.max(10000, Number(process.env.YTDLP_META_TIMEOUT_MS || 45000));

const AUDIO_QUALITY_FORMATS = Object.freeze({
  highest: "bestaudio/best",
  high: "bestaudio[abr>=192]/bestaudio/best",
  medium: "bestaudio[abr>=128]/bestaudio/best",
  low: "bestaudio[abr<=128]/bestaudio/best"
});

function normalizeAudioQuality(value) {
  const q = String(value || "highest").trim().toLowerCase();
  return Object.prototype.hasOwnProperty.call(AUDIO_QUALITY_FORMATS, q) ? q : "highest";
}


async function ytdlpJsonWithHardTimeout(target, options, timeoutMs = YTDLP_META_TIMEOUT_MS) {
  const proc = youtubedl.exec(target, options);
  let stdout = "", stderr = "", settled = false, timedOut = false;
  proc.stdout?.on("data", d => { if (stdout.length < 20_000_000) stdout += d.toString(); });
  proc.stderr?.on("data", d => { if (stderr.length < 1_000_000) stderr += d.toString(); });
  return await new Promise((resolve, reject) => {
    const finishTimeout = (message) => {
      if (settled) return;
      settled = true; timedOut = true; clearTimeout(timer);
      try { proc.kill("SIGKILL"); } catch {}
      const grace = setTimeout(() => reject(new Error(message)), 2000);
      grace.unref?.();
      proc.once("close", () => { clearTimeout(grace); reject(new Error(message)); });
    };
    const timer = setTimeout(() => finishTimeout(`yt-dlp metadata timed out after ${timeoutMs}ms`), timeoutMs);
    timer.unref?.();
    proc.on("error", err => { if (settled) return; settled=true; clearTimeout(timer); reject(err); });
    proc.on("close", code => {
      if (settled) return; settled=true; clearTimeout(timer);
      if (code !== 0) return reject(new Error(stderr.trim() || `yt-dlp exited with code ${code}`));
      try { resolve(JSON.parse(stdout)); } catch (e) { reject(new Error(`yt-dlp returned invalid JSON: ${e.message}`)); }
    });
    proc.catch?.(() => {});
  });
}


async function ytdlpDirectAudioUrl(target, format, timeoutMs = Math.max(20000, Number(process.env.YTDLP_STREAM_RESOLVE_TIMEOUT_MS || 30000))) {
  const proc = youtubedl.exec(target, {
    getUrl: true,
    noWarnings: true,
    preferFreeFormats: true,
    format,
    extractorArgs: "youtube:player_client=android,web",
    retries: 3,
    extractorRetries: 3,
    socketTimeout: 12,
  });
  let stdout = "", stderr = "", settled = false;
  return await new Promise((resolve, reject) => {
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(value);
    };
    const timer = setTimeout(() => {
      try { proc.kill("SIGKILL"); } catch {}
      finish(reject, new Error(`yt-dlp stream URL resolution timed out after ${timeoutMs}ms`));
    }, timeoutMs);
    timer.unref?.();
    proc.stdout?.on("data", d => { if (stdout.length < 2_000_000) stdout += d.toString(); });
    proc.stderr?.on("data", d => { if (stderr.length < 500_000) stderr += d.toString(); });
    proc.on("error", err => finish(reject, err));
    proc.on("close", code => {
      if (code !== 0) return finish(reject, new Error(stderr.trim() || `yt-dlp exited with code ${code}`));
      const urls = stdout.split(/\r?\n/).map(x => x.trim()).filter(x => /^https?:\/\//i.test(x));
      if (!urls.length) return finish(reject, new Error("yt-dlp returned no direct audio URL"));
      finish(resolve, urls[0]);
    });
    proc.catch?.(() => {});
  });
}

function formatDuration(seconds) {
  if (!Number.isFinite(seconds) || seconds <= 0) return "0:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}


function trackKey(track) {
  const url=String(track?.url || '').trim();
  const m=url.match(/(?:youtube\.com\/(?:watch\?(?:[^#]*&)?v=|shorts\/|embed\/)|youtu\.be\/)([A-Za-z0-9_-]{6,})/i);
  return m ? `yt:${m[1]}` : `url:${url}`;
}

export class YouTubePlayer extends EventEmitter {
  constructor() {
    super();
    this.queue = [];
    this.currentTrack = null;
    this.isPlaying = false;
    this.isPaused = false;
    this.activeProcess = null;
    this.stream = null;
    this._sourceSuspendedPlayIds = new Set();
    this.startedAt = 0;
    this.pausedAt = 0;
    this.pauseAccumulated = 0;
    this.seekOffset = 0;
    this.playId = 0;
    this.loopMode = "off"; // off | track | queue | playlist
    this.lastPlaylistTracks = [];
    this.shuffleEnabled = false;
    this.playHistory = [];
    this.recentHistory = []; // playback history, newest first
    this.previousTrack = null;
    this.volume = 1;
    this.playbackRate = 1;
    this.audioQuality = normalizeAudioQuality(process.env.CHATP_AUDIO_QUALITY || "highest");
    this.queueLimit = 100;
    this.autoplay = false;
    this.autoDjMode = "hybrid";
    this.radioEnabled = false;
    this.radioSeed = null;
    this.radioMode = "hybrid";
    this._autoDjFillInFlight = false;
    this._transition = Promise.resolve();
    this._sourceFailureAttempts = new Map();
    this._decodedProgress = new Map();
    this._progressWatchdogs = new Map();
    this._sourceRetryTimers = new Map();
    this._replacementFallbacks = new Map();
    this._audioCache = new Map();
    this._sourceDownloadProcesses = new Map();
    // One yt-dlp writer per cache key. This prevents Windows/NTFS rename
    // collisions when playback recovery and AutoDJ prefetch request the same
    // track at nearly the same time.
    this._audioCacheDownloads = new Map();
    this._earlyEofRetries = new Map();
    this._audioCacheLimit = Math.max(2, Math.min(8, Number(process.env.AUDIO_CACHE_FILES || 4)));
    this._cleanupAudioCache().catch(() => {});

    // EventEmitter throws when an `error` event has no listener. A YouTube/
    // yt-dlp failure is recoverable and must never terminate the whole bot.
    this.on("error", err => {
      log(`[YouTube] handled error: ${err?.message || err}`);
    });
  }

  setQueueLimit(value) { this.queueLimit = Math.max(1, Math.min(1000, Math.floor(Number(value) || 100))); if (this.queue.length > this.queueLimit) this.queue.length = this.queueLimit; return this.queueLimit; }

  addTrackObject(track, { front = false } = {}) {
    if (!track || !track.title) throw new Error("Invalid track");
    if (this.queue.length >= this.queueLimit) return false;
    if (front) this.queue.unshift(track); else this.queue.push(track);
    return true;
  }

  setPlaybackRate(value) {
    const n = Number(value);
    this.playbackRate = Number.isFinite(n) && n > 0 ? n : 1;
    return this.playbackRate;
  }

  setAudioQuality(value) {
    this.audioQuality = normalizeAudioQuality(value);
    return this.audioQuality;
  }

  getAudioQuality() { return this.audioQuality; }

  getAudioQualityFormat() { return AUDIO_QUALITY_FORMATS[this.audioQuality] || AUDIO_QUALITY_FORMATS.highest; }

  setAutoplay(value) {
    this.autoplay = Boolean(value);
    this.emit("autoplayChanged", this.autoplay);
    return this.autoplay;
  }
  toggleAutoplay() { return this.setAutoplay(!this.autoplay); }
  setAutoDjMode(value) { const v=String(value||"hybrid").toLowerCase(); const ok=["hybrid","artist","genre","mood","related","recommended"].includes(v); if(ok) this.autoDjMode=v; return this.autoDjMode; }
  setRadio(seed=null, mode=this.autoDjMode) { this.radioEnabled=true; this.radioSeed=seed ? {...seed} : (this.currentTrack ? {...this.currentTrack} : this.radioSeed); this.radioMode=this.setAutoDjMode(mode); return this.radioSeed; }
  stopRadio() { this.radioEnabled=false; this.radioSeed=null; return false; }

  async searchTop(query, count = 10) {
    const input = String(query).trim();
    if (!input) throw new Error("Search query cannot be empty");
    const target = `ytsearch${count}:${input}`;
    log(`[YouTube] Searching top ${count} results for: "${input}" ...`);
    const info = await ytdlpJsonWithHardTimeout(target, {
      dumpSingleJson: true,
      noWarnings: true,
      preferFreeFormats: true,
      format: this.getAudioQualityFormat(),
      extractorArgs: "youtube:player_client=android,web",
    }, YTDLP_META_TIMEOUT_MS);
    const entries = Array.isArray(info.entries) ? info.entries : [info];
    return entries.filter(e => e && e.title).map(details => {
      const seconds = durationSeconds(details);
      return {
        title: details.title,
        url: details.webpage_url || details.original_url || (details.id ? `https://www.youtube.com/watch?v=${details.id}` : ""),
        duration: formatDuration(seconds),
        durationSeconds: seconds,
        thumbnail: details.thumbnail || details.thumbnails?.[0]?.url || "",
        artist: details.uploader || details.channel || "YouTube",
        categories: Array.isArray(details.categories) ? details.categories : [],
        tags: Array.isArray(details.tags) ? details.tags : [],
        description: String(details.description || "").slice(0, 1200),
        id: details.id || ""
      };
    });
  }

  async resolvePlaylist(url, limit = 50) {
    const input = String(url).trim();
    if (!input) throw new Error("Playlist URL cannot be empty");
    log(`[YouTube] Resolving playlist: "${input}" (limit: ${limit}) ...`);
    const info = await ytdlpJsonWithHardTimeout(input, {
      dumpSingleJson: true,
      flatPlaylist: true,
      noWarnings: true,
      preferFreeFormats: true,
      extractorArgs: "youtube:player_client=android,web",
      playlistEnd: limit
    }, Math.max(YTDLP_META_TIMEOUT_MS, 60000));
    const entries = Array.isArray(info.entries) ? info.entries.slice(0, limit) : [];
    if (!entries.length) throw new Error("No playable tracks found in playlist.");
    return {
      title: info.title || "YouTube Playlist",
      author: info.uploader || info.channel || "YouTube",
      tracks: entries.map(details => {
        const seconds = durationSeconds(details);
        return {
          title: details.title,
          url: details.url || details.webpage_url || (details.id ? `https://www.youtube.com/watch?v=${details.id}` : ""),
          duration: formatDuration(seconds),
          durationSeconds: seconds,
          thumbnail: details.thumbnails?.[0]?.url || "",
          artist: details.uploader || details.channel || info.title || "YouTube",
          id: details.id || ""
        };
      })
    };
  }

  async enqueuePlaylist(url, requestedBy = "User", limit = 50) {
    const playlist = await this.resolvePlaylist(url, limit);
    this.lastPlaylistTracks = playlist.tracks.map(t => ({ ...t, requestedBy }));
    const available = Math.max(0, this.queueLimit - this.queue.length);
    const tracksToAdd = playlist.tracks.slice(0, available);
    const added = [];
    for (const item of tracksToAdd) {
      const track = { ...item, requestedBy };
      this.queue.push(track);
      added.push(track);
    }
    log(`[YouTube] Queued ${added.length} tracks from playlist: "${playlist.title}"`);
    this.emit("playlistQueued", { playlist, count: added.length, requestedBy });
    if (!this.isPlaying) await this.playNext();
    return { playlist, count: added.length, totalQueue: this.queue.length };
  }

  saveQueueAsPlaylist(name, savedBy = "User") {
    const allTracks = [this.currentTrack, ...this.queue].filter(Boolean);
    if (!allTracks.length) throw new Error("No tracks currently playing or in queue to save");
    const saved = saveCustomPlaylist(name, allTracks, savedBy);
    log(`[YouTube] Saved custom playlist "${saved.name}" with ${saved.trackCount} tracks (by ${savedBy})`);
    return saved;
  }

  async loadSavedPlaylist(name, requestedBy = "User", replace = false) {
    const playlist = getCustomPlaylist(name);
    if (!playlist) throw new Error(`Saved playlist "${name}" not found`);
    if (replace) {
      this.stop(true);
    }
    const added = [];
    for (const item of playlist.tracks) {
      const trackObj = { ...item, requestedBy };
      if (this.queue.length >= this.queueLimit) break;
      this.queue.push(trackObj);
      added.push(trackObj);
    }
    log(`[YouTube] Loaded ${added.length} tracks from saved playlist "${playlist.name}"`);
    this.emit("savedPlaylistLoaded", { playlist, count: added.length, requestedBy });
    if (!this.isPlaying) await this.playNext();
    return { playlist, count: added.length, totalQueue: this.queue.length };
  }

  getSavedPlaylists() {
    return listCustomPlaylists();
  }

  deleteSavedPlaylist(name) {
    return deleteCustomPlaylist(name);
  }

  async resolveTrack(query, requestedBy = "User") {
    const input = String(query).trim();
    if (!input) throw new Error("Search query cannot be empty");
    const target = /^https?:\/\//i.test(input) ? input : `ytsearch1:${input}`;
    log(`[YouTube] Resolving query: "${input}" ...`);
    const info = await ytdlpJsonWithHardTimeout(target, {
      dumpSingleJson: true,
      noWarnings: true,
      preferFreeFormats: true,
      format: this.getAudioQualityFormat(),
      extractorArgs: "youtube:player_client=android,web",
    }, YTDLP_META_TIMEOUT_MS);
    const details = Array.isArray(info.entries) ? info.entries[0] : info;
    if (!details?.title) throw new Error(`No YouTube results found for: "${input}"`);
    const seconds = durationSeconds(details);
    return {
      title: details.title,
      url: details.webpage_url || details.original_url || (details.id ? `https://www.youtube.com/watch?v=${details.id}` : input),
      duration: formatDuration(seconds),
      durationSeconds: seconds,
      thumbnail: details.thumbnail || details.thumbnails?.[0]?.url || "",
      artist: details.uploader || details.channel || "YouTube",
      categories: Array.isArray(details.categories) ? details.categories : [],
      tags: Array.isArray(details.tags) ? details.tags : [],
      description: String(details.description || "").slice(0, 1200),
      requestedBy,
      id: details.id || ""
    };
  }

  async replaceAndPlay(query, requestedBy = "User") {
    const track = await this.resolveTrack(query, requestedBy);
    const oldTrack = this.currentTrack ? { ...this.currentTrack } : null;
    const oldWasPlaying = Boolean(this.currentTrack && this.isPlaying);
    const oldOffset = oldWasPlaying ? this.getElapsedSeconds() : 0;
    const oldPaused = Boolean(this.isPaused);
    const oldQueue = [...this.queue];
    return this._serialize(async () => {
      this._cancelCurrent("replace");
      const replacementPlayId = this.playId + 1;
      if (oldTrack && oldWasPlaying) this._replacementFallbacks.set(replacementPlayId, { track: oldTrack, offset: oldOffset, paused: oldPaused, queue: oldQueue });
      this._sourceFailureAttempts.delete(track.url);
      this.currentTrack = track; this.isPlaying = true; this.isPaused = false;
      this.startedAt = Date.now(); this.pauseAccumulated = 0; this.seekOffset = 0;
      this.playId = replacementPlayId;
      this.recentHistory.unshift({ ...track, playedAt: Date.now() });
      if (this.recentHistory.length > 15) this.recentHistory.pop();
      log(`[YouTube] Now playing: "${track.title}"`);
      this.emit("trackStart", track);
      void this.prefetchNextTracks(2).catch(() => {});
      void this.startStream(track, replacementPlayId, 0).catch(err => log(`[YouTube] Background replacement start failed: ${err?.message || err}`));
      return { track, playId: this.playId, fallback: false, pending: true };

    });
  }
  async enqueue(query, requestedBy = "User") {
    const track = await this.resolveTrack(query, requestedBy);
    const wasPlaying = this.isPlaying;
    if (this.queue.length >= this.queueLimit) throw new Error(`Queue limit reached (${this.queueLimit}).`);
    this.queue.push(track);
    const queuePosition = this.queue.length;
    log(`[YouTube] Queued #${queuePosition}: "${track.title}" (Requested by: ${requestedBy})`);
    this.emit("queued", { track, queuePosition });
    let startedImmediately = false;
    if (!wasPlaying) {
      await this.playNext();
      startedImmediately = trackKey(this.currentTrack) === trackKey(track);
    }
    return { track, queuePosition, startedImmediately };
  }

  async addAndPlay(query, requestedBy = "User") { return this.enqueue(query, requestedBy); }

  async playTrackObject(track, reason = "manual", seekOffset = 0, { announce = true, recordHistory = true } = {}) {
    if (!track) return false;
    return this._serialize(async () => {
      this._cancelCurrent(reason);
      this._sourceFailureAttempts.delete(track.url);
      this.currentTrack = track;
      this.isPlaying = true;
      this.isPaused = false;
      this.startedAt = Date.now();
      this.pauseAccumulated = 0;
      this.seekOffset = seekOffset;
      this.playId += 1;
      const playId = this.playId;

      // Only genuine track selections enter recent history. Seeks, FX changes,
      // reconnect resumes and source retries must not create fake history entries.
      if (recordHistory) {
        this.recentHistory.unshift({ ...track, playedAt: Date.now() });
        if (this.recentHistory.length > 15) this.recentHistory.pop();
      }

      log(`[YouTube] Now playing: "${track.title}"${seekOffset > 0 ? ` (from ${formatDuration(seekOffset)})` : ""}`);
      if (announce) this.emit("trackStart", track);
      void this.prefetchNextTracks(2).catch(() => {});
      void this.startStream(track, playId, seekOffset)
        .catch(err => log(`[YouTube] Background playback start failed: ${err?.message || err}`));
      return true;
    });
  }

  async playNext() {
    return this._serialize(async () => {
      let refilledLoopQueue = false;
      if (this.currentTrack && this.isPlaying && this.loopMode === "track") {
        const same = this.currentTrack;
        this._cancelCurrent("loop-track");
        this.isPlaying = true;
        this.isPaused = false;
        this.startedAt = Date.now();
        this.pauseAccumulated = 0;
        this.seekOffset = 0;
        this.playId += 1;
        const playId = this.playId;
        log(`[YouTube] Repeating track: "${same.title}"`);
        this.emit("trackStart", same);
        void this.prefetchNextTracks(2).catch(() => {});
        void this.startStream(same, playId).catch(err => log(`[YouTube] Background loop start failed: ${err?.message || err}`));
        return true;
      }

      if (this.queue.length === 0 && this.loopMode === "playlist" && this.lastPlaylistTracks.length) {
        this.queue = this.lastPlaylistTracks
          .slice(0, this.queueLimit)
          .map(t => ({ ...t }));
        refilledLoopQueue = true;
      } else if (this.queue.length === 0 && this.loopMode === "queue" && this.playHistory.length > 0) {
        this.queue = [...this.playHistory, ...(this.currentTrack ? [{ ...this.currentTrack }] : [])].slice(0, this.queueLimit);
        this.playHistory = [];
        refilledLoopQueue = true;
      }

      // Smart AutoDJ: never search the complete title as the primary strategy.
      // That caused songs such as “Justin Bieber - Baby” to produce a queue of
      // unrelated videos whose only common word was “Baby”. Build a candidate
      // pool from artist, similar-artist, title-similarity and metadata/mood
      // searches, then rank it while suppressing recent/repeated tracks.
      if (this.queue.length === 0 && (this.autoplay || this.radioEnabled) && (this.currentTrack || this.radioSeed)) {
        // Never hold the playback transition mutex while yt-dlp/Smart Radio is
        // searching. A slow YouTube request used to make every command appear
        // stuck behind “last operations”. Discovery is now a background job;
        // once it fills the queue it invokes playNext() again.
        this._scheduleAutoDjFill(8);
      }

      if (this.queue.length === 0) {
        this._cancelCurrent("empty");
        if (this.currentTrack && this.loopMode === "queue" && !refilledLoopQueue) {
          this.playHistory.push(this.currentTrack);
        }
        this.currentTrack = null;
        this.isPlaying = false;
        this.isPaused = false;
        this.startedAt = 0;
        log("[YouTube] Queue is now empty.");
        this.emit("queueEmpty");
        return false;
      }

      if (!refilledLoopQueue && this.currentTrack && this.isPlaying && this.loopMode === "queue") {
        this.playHistory.push(this.currentTrack);
      }
      this._cancelCurrent("next");
      if (this.shuffleEnabled) this._shuffleInPlace();
      const next = this.queue.shift();
      this.currentTrack = next;
      this.isPlaying = true;
      this.isPaused = false;
      this.startedAt = Date.now();
      this.pauseAccumulated = 0;
      this.seekOffset = 0;
      this.playId += 1;
      const playId = this.playId;

      // Add to recent history
      this.recentHistory.unshift({ ...next, playedAt: Date.now() });
      if (this.recentHistory.length > 15) this.recentHistory.pop();

      log(`[YouTube] Now playing: "${next.title}"`);
      this.emit("trackStart", next);
      void this.prefetchNextTracks(2).catch(() => {});
      void this.startStream(next, playId).catch(err => log(`[YouTube] Background next-track start failed: ${err?.message || err}`));
      return true;
    });
  }

  _scheduleAutoDjFill(target = 8) {
    if (this._autoDjFillInFlight || (!this.autoplay && !this.radioEnabled)) return;
    const seed = this.currentTrack || this.radioSeed;
    if (!seed) return;
    this._autoDjFillInFlight = true;
    const mode = this.radioEnabled ? this.radioMode : this.autoDjMode;
    const recent = [this.currentTrack, this.radioSeed, ...this.queue, ...this.recentHistory.slice(0, 20)].filter(Boolean);
    const recentKeys = new Set(recent.map(trackKey));
    void discoverSmartTracks(seed, { count: 16, recent, mode })
      .then(results => {
        let added = 0;
        for (const candidate of results) {
          const key = trackKey(candidate);
          if (!candidate?.url || recentKeys.has(key)) continue;
          if (!this.addTrackObject({ ...candidate, requestedBy: this.radioEnabled ? 'Smart Radio' : 'AutoDJ' })) break;
          recentKeys.add(key);
          added++;
          this.emit('autoplayTrack', candidate);
          if (added >= Math.max(1, Math.min(16, target))) break;
        }
        if (added) {
          log(`[${this.radioEnabled ? 'Radio' : 'AutoDJ'}] Async refill: ${added} tracks | mode=${mode} | seed=${seed.title || seed.artist || 'current'}`);
          // If the track ended while discovery was running, start the newly
          // discovered item without requiring another user command.
          if (!this.isPlaying && this.queue.length) void this.playNext().catch(err => log(`[AutoDJ] async start failed: ${err.message}`));
        }
      })
      .catch(err => log(`[${this.radioEnabled ? 'Radio' : 'AutoDJ'}] Async discovery failed: ${err.message}`))
      .finally(() => { this._autoDjFillInFlight = false; });
  }

  getAudioCacheInfo() {
    const entries = [...this._audioCache.entries()].map(([key, value]) => ({ key, path: value.path, usedAt: value.usedAt }));
    return { count: entries.length, limit: this._audioCacheLimit, entries };
  }

  async clearAudioCache() {
    const dir = path.join(os.tmpdir(), 'talkinchat-audio-cache');
    let removed = 0;
    for (const { path: file } of this._audioCache.values()) {
      try { await fsp.unlink(file); removed++; } catch {}
    }
    this._audioCache.clear();
    try {
      const files = await fsp.readdir(dir);
      for (const name of files) {
        if (!name.endsWith('.part')) { try { await fsp.unlink(path.join(dir, name)); removed++; } catch {} }
      }
    } catch {}
    return removed;
  }

  async prefetchNextTracks(count = 2) {
    const tracks = this.queue.slice(0, Math.max(0, Math.min(4, Number(count) || 2)));
    for (const track of tracks) {
      const key = trackKey(track);
      if (!key || this._audioCache.has(key)) continue;
      try {
        // Prefetching must not be tied to the current playId. The queued song
        // remains useful even if the current track is replaced while download
        // is in progress.
        await this._downloadAudioCache(track, null, { allowStale: true });
      } catch (err) {
        log(`[YouTube] Prefetch failed for "${track.title}": ${err.message}`);
      }
    }
  }

  async smartDiscover(count = 12, mode = "hybrid", seed = this.currentTrack) {
    if (!seed) return [];
    return discoverSmartTracks(seed, { count, recent: [this.currentTrack, ...this.recentHistory].filter(Boolean), mode });
  }

  async refillSmartQueue(target = 6, mode = null, seed = null) {
    const wanted = Math.max(1, Math.min(16, Number(target) || 6));
    if (this.queue.length >= wanted || this._autoDjFillInFlight) return 0;
    const activeSeed = seed || this.currentTrack || (this.radioEnabled ? this.radioSeed : null);
    if (!activeSeed) return 0;
    this._autoDjFillInFlight = true;
    try {
      const discoveryMode = mode || (this.radioEnabled ? this.radioMode : this.autoDjMode);
      const recent = [this.currentTrack, this.radioSeed, ...this.queue, ...this.recentHistory.slice(0, 20)].filter(Boolean);
      const recentKeys = new Set(recent.map(trackKey));
      const rows = await discoverSmartTracks(activeSeed, { count: 16, recent, mode: discoveryMode });
      let added = 0;
      for (const candidate of rows) {
        const key = trackKey(candidate);
        if (!candidate?.url || recentKeys.has(key)) continue;
        if (!this.addTrackObject({ ...candidate, requestedBy: this.radioEnabled ? 'Smart Radio' : 'AutoDJ' })) break;
        recentKeys.add(key);
        added++;
        this.emit('autoplayTrack', candidate);
        if (this.queue.length >= wanted) break;
      }
      if (added) log(`[${this.radioEnabled ? 'Radio' : 'AutoDJ'}] Pre-filled ${added} track(s) | mode=${discoveryMode} | seed=${activeSeed.title || activeSeed.artist || 'current'}`);
      return added;
    } catch (err) {
      log(`[${this.radioEnabled ? 'Radio' : 'AutoDJ'}] Background refill failed: ${err.message}`);
      return 0;
    } finally {
      this._autoDjFillInFlight = false;
    }
  }

  startDecodedWatchdog(playId) {
    if (playId !== this.playId) return;
    const watchdog = this._progressWatchdogs.get(playId);
    if (watchdog) {
      this._decodedProgress.set(playId, Date.now());
      watchdog();
    }
  }

  confirmPlayback(playId) { this._replacementFallbacks.delete(playId); }

  markDecodedProgress(playId) {
    if (playId !== this.playId) return;
    this._decodedProgress.set(playId, Date.now());
    this._progressWatchdogs.get(playId)?.();
  }

  invalidateAudioCache(track = this.currentTrack) {
    const key = trackKey(track);
    if (!key) return false;
    const entry = this._audioCache.get(key);
    this._audioCache.delete(key);
    if (entry?.path) void fsp.unlink(entry.path).catch(() => {});
    return Boolean(entry);
  }

  async _cleanupAudioCache() {
    const dir = path.join(os.tmpdir(), "talkinchat-audio-cache");
    try {
      const files = await fsp.readdir(dir);
      const cutoff = Date.now() - 24 * 60 * 60 * 1000;
      for (const file of files) {
        const full = path.join(dir, file);
        try { if (fs.statSync(full).mtimeMs < cutoff) await fsp.unlink(full); } catch {}
      }
    } catch {}
  }

  async _downloadAudioCache(track, playId, { allowStale = false } = {}) {
    const mode = String(process.env.AUDIO_CACHE_MODE || "always").toLowerCase();
    if (mode === "off" || mode === "false" || mode === "0") return null;
    const key = trackKey(track);
    if (!key) return null;

    const existing = this._audioCache.get(key);
    if (existing && fs.existsSync(existing.path)) {
      existing.usedAt = Date.now();
      return existing.path;
    }

    // Critical Windows fix: playback recovery and AutoDJ prefetch can ask for
    // the same track at the same time. Never let two yt-dlp processes write to
    // the same final filename; yt-dlp's final rename otherwise fails with
    // WinError 32 because the other process owns the destination/temp file.
    const inFlight = this._audioCacheDownloads.get(key);
    if (inFlight) {
      const cached = await inFlight;
      if (!allowStale && playId !== this.playId) throw new Error("Playback operation superseded by a newer track");
      return cached;
    }

    const downloadPromise = (async () => {
      const cacheDir = path.join(os.tmpdir(), "talkinchat-audio-cache");
      await fsp.mkdir(cacheDir, { recursive: true });
      const safe = key.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 80);
      const stableId = String(track.id || key).replace(/[^a-zA-Z0-9_-]/g, "_");
      const base = path.join(cacheDir, `${safe}-${stableId}`);
      const output = `${base}.%(ext)s`;

      // If another process completed this cache between our first check and
      // acquiring the lock, reuse it instead of starting another downloader.
      try {
        const filesNow = await fsp.readdir(cacheDir);
        const ready = filesNow.filter(f => f.startsWith(path.basename(base) + ".") && !f.endsWith(".part"));
        if (ready.length) {
          const cached = path.join(cacheDir, ready.sort((a,b) => fs.statSync(path.join(cacheDir,b)).mtimeMs - fs.statSync(path.join(cacheDir,a)).mtimeMs)[0]);
          this._audioCache.set(key, { path: cached, usedAt: Date.now() });
          return cached;
        }
      } catch {}

      const proc = youtubedl.exec(track.url, {
        noPlaylist: true, noWarnings: true, preferFreeFormats: true,
        format: this.getAudioQualityFormat(), output,
        extractorArgs: "youtube:player_client=android,web",
        retries: 4, fragmentRetries: 10, extractorRetries: 3, socketTimeout: 20,
        concurrentFragments: 4
      });
      let stderr = "";
      const processKey = `cache:${key}`;
      this._sourceDownloadProcesses.set(processKey, proc);
      proc.stderr?.on("data", d => { if (stderr.length < 500_000) stderr += d.toString(); });
      try {
        await new Promise((resolve, reject) => {
          proc.on("error", reject);
          proc.on("close", code => code === 0 ? resolve() : reject(new Error(stderr.trim() || `yt-dlp download exited with code ${code}`)));
          proc.catch?.(() => {});
        });

        const files = await fsp.readdir(cacheDir);
        const matches = files.filter(f => f.startsWith(path.basename(base) + ".") && !f.endsWith(".part"));
        if (!matches.length) throw new Error("yt-dlp completed but no cached audio file was produced");
        const cached = path.join(cacheDir, matches.sort((a,b) => fs.statSync(path.join(cacheDir,b)).mtimeMs - fs.statSync(path.join(cacheDir,a)).mtimeMs)[0]);
        this._audioCache.set(key, { path: cached, usedAt: Date.now() });
        log(`[YouTube] Cached high-quality audio locally: ${path.basename(cached)}`);
        return cached;
      } finally {
        if (this._sourceDownloadProcesses.get(processKey) === proc) this._sourceDownloadProcesses.delete(processKey);
      }
    })();

    this._audioCacheDownloads.set(key, downloadPromise);
    try {
      const cached = await downloadPromise;
      if (!allowStale && playId !== this.playId) throw new Error("Playback operation superseded by a newer track");

      while (this._audioCache.size > this._audioCacheLimit) {
        let oldestKey = null, oldest = Infinity;
        for (const [k,v] of this._audioCache) {
          if (k !== key && k !== trackKey(this.currentTrack) && !this._audioCacheDownloads.has(k) && v.usedAt < oldest) {
            oldest = v.usedAt; oldestKey = k;
          }
        }
        if (!oldestKey) break;
        const old = this._audioCache.get(oldestKey);
        this._audioCache.delete(oldestKey);
        try { await fsp.unlink(old.path); } catch {}
      }
      return cached;
    } finally {
      if (this._audioCacheDownloads.get(key) === downloadPromise) this._audioCacheDownloads.delete(key);
    }
  }

  async startStream(track, playId, seekOffset = 0, options = {}) {
    try {
      // Reuse the already-resolved direct source for live setting changes.
      // This avoids another yt-dlp resolution round-trip when .speed/.pitch/.fx
      // is changed and makes the replacement pipeline start from the current
      // position instead of appearing to restart the song.
      const suppliedDirectUrl = String(options.directUrl || '').trim();
      let source = (options.reuseDirectUrl !== false && suppliedDirectUrl) ? suppliedDirectUrl : null;
      if (!source) {
        try {
          source = await this._downloadAudioCache(track, playId);
        } catch (cacheErr) {
          log(`[YouTube] Local audio cache failed for "${track.title}": ${cacheErr.message}; falling back to direct streaming.`);
          source = await ytdlpDirectAudioUrl(track.url, this.getAudioQualityFormat());
        }
      }
      if (playId !== this.playId || !this.isPlaying) return false;
      // Start the wall clock when the media source is actually ready.
      // seekOffset is already included by getElapsedSeconds(), so subtracting
      // it from startedAt here would count the resume offset twice. That made
      // recovery jump 3:43 -> 7:26 -> 14:52 -> 29:44 on every retry.
      this.startedAt = Date.now();
      this.stream = source;
      this._decodedProgress.delete(playId);
      this._progressWatchdogs.get(playId)?.();
      const cached = Boolean(source && !/^https?:\/\//i.test(source));
      this.emit("streamReady", { stream: source, directUrl: cached ? "" : source, track, playId, seekOffset, direct: !cached, cached, fastStart: Boolean(options.fastStart) });
      return true;
    } catch (err) {
      if (playId !== this.playId) return false;
      log(`[YouTube] Direct audio URL failed for "${track.title}": ${err.message}`);
      this.emit("streamError", { playId, track, code: null, attempts: 1, error: err });
      this.isPlaying = false;
      queueMicrotask(() => { void this.playNext().catch(e => log(`[YouTube] Next-track recovery failed: ${e?.message || e}`)); });
      return false;
    }
  }

  async restartCurrent(reason = "restart", seekOffset = this.getElapsedSeconds(), options = {}) {
    if (!this.currentTrack || !this.isPlaying) return false;
    const track = { ...this.currentTrack };
    const offset = Math.max(0, Number(seekOffset) || 0);
    // Keep the current resolved media URL so a setting change does not wait for
    // yt-dlp to resolve the same YouTube URL again.
    const directUrl = options.reuseDirectUrl === false ? '' : String(this.stream || '').trim();
    return this._serialize(async () => {
      this._cancelCurrent(reason);
      this.currentTrack = track;
      this.isPlaying = true;
      this.isPaused = false;
      this.startedAt = Date.now();
      this.pauseAccumulated = 0;
      this.seekOffset = offset;
      this.playId += 1;
      const playId = this.playId;
      log(`[YouTube] Restarting current track: "${track.title}"${offset > 0 ? ` at ${formatDuration(offset)}` : ""}`);
      this.emit("trackRestart", { track, reason, offset });
      if (options.announce !== false) this.emit("trackStart", track);
      void this.startStream(track, playId, offset, { directUrl, reuseDirectUrl: options.reuseDirectUrl !== false, fastStart: true })
        .catch(err => log(`[YouTube] Background restart failed: ${err?.message || err}`));
      return true;
    });
  }

  async seek(targetSeconds) {
    if (!this.currentTrack || !this.isPlaying) return false;
    const total = Number(this.currentTrack.durationSeconds || 0);
    const sec = Math.max(0, Math.min(total > 0 ? total - 2 : 7200, Number(targetSeconds) || 0));
    log(`[YouTube] Seeking to ${formatDuration(sec)} in "${this.currentTrack.title}" ...`);
    await this.playTrackObject(this.currentTrack, "seek", sec, { announce: false, recordHistory: false });
    return sec;
  }

  async forward(seconds = 15) {
    const cur = this.getElapsedSeconds();
    return this.seek(cur + Number(seconds));
  }

  async rewind(seconds = 15) {
    const cur = this.getElapsedSeconds();
    return this.seek(Math.max(0, cur - Number(seconds)));
  }

  async previous() {
    if (!this.currentTrack) return false;
    // Find the newest history item that is different from the current track.
    const currentKey = trackKey(this.currentTrack);
    const previous = this.recentHistory.find(t => t?.url && trackKey(t) !== currentKey);
    if (!previous) return false;

    // Preserve the current track at the front of the queue so Previous does not
    // silently destroy the user's queue.
    const current = { ...this.currentTrack };
    if (!this.queue.some(t => trackKey(t) === trackKey(current))) {
      if (this.queue.length >= this.queueLimit) return false;
      this.queue.unshift(current);
    }
    await this.playTrackObject({ ...previous }, "previous");
    return previous;
  }

  async replay(historyIndex = 1) {
    const idx = Math.max(1, Number(historyIndex) || 1) - 1;
    if (idx < 0 || idx >= this.recentHistory.length) return false;
    const item = this.recentHistory[idx];
    await this.playTrackObject({ ...item }, "replay");
    return item;
  }

  skip() {
    if (!this.currentTrack && !this.isPlaying) return false;
    const skipped = this.currentTrack;
    this._cancelCurrent("skip");
    this.emit("trackSkipped", skipped);
    void this.playNext();
    return true;
  }

  pause() {
    if (!this.isPlaying || this.isPaused) return false;
    this.isPaused = true;
    this.pausedAt = Date.now();
    this.emit("paused", this.currentTrack);
    return true;
  }

  resume() {
    if (!this.isPlaying || !this.isPaused) return false;
    this.pauseAccumulated += Date.now() - this.pausedAt;
    this.pausedAt = 0;
    this.isPaused = false;
    this.emit("resumed", this.currentTrack);
    return true;
  }

  stop(clearQueue = true) {
    this._cancelCurrent("stop");
    if (clearQueue) { this.queue = []; this.lastPlaylistTracks = []; }
    this.playHistory = [];
    this.currentTrack = null;
    this.isPlaying = false;
    this.isPaused = false;
    this.startedAt = 0;
    this.seekOffset = 0;
    this.emit("stopped");
  }

  setLoop(value) {
    const v = String(value).toLowerCase().trim();
    if (["track", "song", "one", "current"].includes(v)) this.loopMode = "track";
    else if (["queue", "all"].includes(v)) this.loopMode = "queue";
    else if (["playlist", "pl"].includes(v)) this.loopMode = "playlist";
    else if (["off", "none", "disable"].includes(v)) this.loopMode = "off";
    else throw new Error("Invalid loop mode");
    this.emit("loopChanged", this.loopMode);
    return this.loopMode;
  }

  setShuffle(value) { this.shuffleEnabled = Boolean(value); if (this.shuffleEnabled) this._shuffleInPlace(); this.emit("shuffleChanged", this.shuffleEnabled); return this.shuffleEnabled; }
  toggleShuffle() { return this.setShuffle(!this.shuffleEnabled); }

  clearQueue() {
    const n = this.queue.length;
    this.queue = [];
    this.lastPlaylistTracks = [];
    this.playHistory = [];
    if (this.loopMode === "playlist" || this.loopMode === "queue") this.loopMode = "off";
    return n;
  }
  playQueueIndex(index) {
    const i = Number(index) - 1;
    if (!Number.isInteger(i) || i < 0 || i >= this.queue.length) return false;
    const [track] = this.queue.splice(i, 1);
    return this.playTrackObject(track, "queue-select").then(() => track).catch(err => {
      if (this.queue.length < this.queueLimit && !this.queue.some(t => trackKey(t) === trackKey(track))) this.queue.splice(Math.min(i, this.queue.length), 0, track);
      throw err;
    });
  }
  removeQueue(index) {
    const i = Number(index) - 1;
    if (!Number.isInteger(i) || i < 0 || i >= this.queue.length) return null;
    return this.queue.splice(i, 1)[0];
  }
  moveQueue(from, to) {
    const a = Number(from) - 1, requested = Number(to);
    if (!Number.isInteger(a) || !Number.isInteger(requested) || a < 0 || a >= this.queue.length || requested < 1 || requested > this.queue.length + 1) return false;
    const [item] = this.queue.splice(a, 1);
    const b = Math.min(this.queue.length, requested - 1);
    this.queue.splice(b, 0, item);
    return true;
  }

  smartShuffle() {
    const recent = new Set(this.recentHistory.slice(0, 8).map(t => t?.url).filter(Boolean));
    const recentArtists = new Set(this.recentHistory.slice(0, 5).map(t => String(t?.artist||'').toLowerCase()).filter(Boolean));
    this.queue.sort((a,b) => {
      const sa = (recent.has(a.url)?100:0) + (recentArtists.has(String(a.artist||'').toLowerCase())?25:0) + Math.random()*10;
      const sb = (recent.has(b.url)?100:0) + (recentArtists.has(String(b.artist||'').toLowerCase())?25:0) + Math.random()*10;
      return sa-sb;
    });
    this.emit('smartShuffled', this.queue);
    return this.queue;
  }

  _shuffleInPlace() {
    for (let i = this.queue.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [this.queue[i], this.queue[j]] = [this.queue[j], this.queue[i]];
    }
  }

  suspendSourceForVoiceLoss() {
    const playId = this.playId;
    const retry = this._sourceRetryTimers.get(playId);
    if (retry) { clearTimeout(retry); this._sourceRetryTimers.delete(playId); }
    this._sourceSuspendedPlayIds.add(playId);
    const p = this.activeProcess;
    this.activeProcess = null;
    this.stream = null;
    try { p?.stdout?.destroy(); } catch {}
    try { p?.kill("SIGKILL"); } catch {}
    const watchdog = this._progressWatchdogs.get(playId);
    if (watchdog) this._progressWatchdogs.delete(playId);
    this._decodedProgress.delete(playId);
  }

  _cancelCurrent(reason = "cancel") {
    const oldPlayId = this.playId;
    this.playId += 1;
    const retry = this._sourceRetryTimers.get(oldPlayId);
    if (retry) { clearTimeout(retry); this._sourceRetryTimers.delete(oldPlayId); }
    const download = this._sourceDownloadProcesses.get(oldPlayId);
    if (download) { try { download.kill("SIGKILL"); } catch {} this._sourceDownloadProcesses.delete(oldPlayId); }
    if (this.activeProcess) {
      try { this.activeProcess.stdout?.destroy(); } catch {}
      try { this.activeProcess.kill("SIGKILL"); } catch {}
      this.activeProcess = null;
    }
    this.stream = null;
    if (reason !== "next" && reason !== "loop-track") log(`[YouTube] Current playback cancelled (${reason}).`);
  }

  _serialize(fn) {
    const run = this._transition.then(fn, fn);
    this._transition = run.catch(() => {});
    return run;
  }

  clearHistory() {
    const n = this.recentHistory.length;
    this.recentHistory = [];
    this.playHistory = [];
    return n;
  }

  getQueue() { return [...this.queue]; }
  getQueueDurationSeconds() {
    return this.queue.reduce((sum, t) => sum + Number(t?.durationSeconds || 0), 0);
  }
  getNowPlaying() { return this.currentTrack; }
  getTrackKey(track = this.currentTrack) { return trackKey(track); }
  getRecentHistory() { return [...this.recentHistory]; }

  getElapsedSeconds() {
    if (!this.currentTrack || !this.startedAt) return 0;
    const paused = this.isPaused && this.pausedAt ? Date.now() - this.pausedAt : 0;
    const wallSeconds = (Date.now() - this.startedAt - this.pauseAccumulated - paused) / 1000;
    return Math.max(0, this.seekOffset + wallSeconds * this.playbackRate);
  }

  getRemainingSeconds() {
    const total = Number(this.currentTrack?.durationSeconds || 0);
    return total ? Math.max(0, total - this.getElapsedSeconds()) : 0;
  }

  getProgressBar(barLength = 10) {
    const total = Number(this.currentTrack?.durationSeconds || 0);
    const elapsed = this.getElapsedSeconds();
    if (!total || total <= 0) return `${formatDuration(elapsed)} / Live`;
    const percent = Math.min(1, Math.max(0, elapsed / total));
    const filled = Math.round(barLength * percent);
    const empty = barLength - filled;
    const bar = "━".repeat(Math.max(0, filled - 1)) + "🔘" + "━".repeat(empty);
    return `${bar} ${formatDuration(elapsed)}/${formatDuration(total)} (${Math.round(percent * 100)}%)`;
  }

  getQueueEtaSeconds(position = 1) {
    const n = Math.max(1, Number(position) || 1);
    let total = this.isPlaying ? this.getRemainingSeconds() : 0;
    for (let i = 0; i < Math.min(n - 1, this.queue.length); i++) total += Number(this.queue[i]?.durationSeconds || 0);
    return total;
  }
}
