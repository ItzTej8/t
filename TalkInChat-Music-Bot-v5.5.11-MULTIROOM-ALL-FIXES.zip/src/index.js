#!/usr/bin/env node
import "node:process";
import { installPrettyConsole, banner, setDebugEnabled as setLoggerDebugEnabled } from "./logger.js";

installPrettyConsole();
import { config, log, debug } from "./config.js";
import { login, register, clearSession } from "./auth.js";
import { ChatPSocket } from "./ws.js";
import { ChatPClient } from "./client.js";
import { attachDefaultHandlers } from "./handlers.js";
import { printCatalog } from "./catalog.js";
import { VoiceManager, YouTubePlayer } from "./media.js";
import { startInteractiveConsole } from "./console.js";
import { fetchLyrics } from "./lyrics.js";
import { addFavorite, removeFavorite, getFavorites, clearFavorites } from "./favorites.js";
import { addTrackToCustomPlaylist } from "./playlists.js";
import { increment as incrementStat, setStat, getStats, formatUptime, flushPersistence as flushStats } from "./bot_stats.js";
import { loadSettings, saveSettings, setActiveRoom, getActiveRoom, getRoomSettingsList, ensureLegacySettingsFile } from "./bot_settings.js";
import { initRoomDatabase, getRoomPlayback, setRoomPlayback, clearRoomPlayback, getRoomQueue, setRoomQueue, persistRoomDatabase, getRoomDatabaseFile, getRoomMeta, setRoomMeta, addRoomMaster, removeRoomMaster, listRoomMasters, isRoomMaster, getRoomMaster } from "./room_database.js";
import { getQueueLimit, setQueueLimit, recordUserCommand, recordUserTrack, topTracks, topUsers, userStats, setTransitionSeconds, getTransitionSeconds, addSchedule, removeSchedule, listSchedules, updateSchedules, getProState, savePlaybackSnapshot, getPlaybackSnapshot, clearPlaybackSnapshot, setDjState, setDjUsers, flushPersistence as flushPro } from "./pro_features.js";
import { getCustomPlaylistByIndex, updateCustomPlaylistByIndex } from "./playlists.js";
import { saveAudioProfile, getAudioProfile, listAudioProfiles, saveSongSettings, getSongSettings, setUserProfile, getUserProfile, getRadioPresets, saveRadioPreset, removeRadioPreset, antiSpamCheck, getVoteConfig, setVoteConfig, flushPersistence as flushAdvanced } from "./advanced_features.js";
import { AtomicStore, hooks, SessionGuard } from "./platform_core.js";
import { loadPlugins } from "./plugin_system.js";
import { VoiceCommandEngine } from "./voice_commands.js";
import { recordPlay as recordCommunityPlay, recordCommand as recordCommunityCommand, reward as rewardPoints, leaderboard, profile as communityProfile, achievements } from "./gamification.js";
import { startMaintenance, stopMaintenance, manualBackup, systemInfo } from "./maintenance.js";
import { t, languages } from "./i18n.js";
import { COMMAND_CATALOG } from "./command_catalog.js";

process.on("unhandledRejection", reason => {
  const msg = reason?.message || String(reason);
  if (reason?.signalCode === "SIGKILL" || reason?.killed || /SIGKILL|EPIPE/i.test(msg)) return;
  debug("[Process UnhandledRejection]", msg);
});

function botNames(authInfo = {}) {
  return new Set([
    config.username,
    authInfo?.username,
    authInfo?.userId,
    authInfo?.loginInfo?.username
  ].map(value => String(value || '').trim().toLowerCase()).filter(Boolean));
}

function serverUrl(port) {
  const validPorts = ["5333", "5335"];
  const finalPort = validPorts.includes(String(port)) ? String(port) : (config.serverPort || "5335");
  return `wss://chatp.net:${finalPort}/server`;
}

function buildSessionHeaders(auth) {
  const sessionId = auth.sessionId || auth.id;
  const bRaw = `${sessionId}@${config.deviceId}@${config.deviceModel}@android@${config.language}@${auth.photoVersion || "0"}@${auth.rosterVersion || "0"}`;
  return {
    "b": Buffer.from(bRaw).toString("base64"),
    "User-Agent": "ChatP-Android/5.8.3"
  };
}

export async function connectAuthenticated(options = {}) {
  let auth;
  try {
    auth = await login(options);
  } catch (err) {
    if (!options.forceLogin) {
      clearSession();
      auth = await login({ ...options, forceLogin: true });
    } else {
      throw err;
    }
  }

  const url = serverUrl(auth.server);
  const headers = buildSessionHeaders(auth);
  log(`[Main] Connecting to ChatP WebSocket: ${url} ...`);

  const socket = new ChatPSocket({
    url,
    headers,
    auth,
    enablePing: auth.enablePing !== false
  });

  attachDefaultHandlers(socket);
  socket.connect();

  await new Promise((resolve, reject) => {
    let settled = false;
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      socket.off("open", onOpen);
      fn(value);
    };
    const timer = setTimeout(() => {
      if (socket.connected) finish(resolve);
      else {
        try { socket.close(1000, "initial connection timeout"); } catch {}
        finish(reject, new Error("WebSocket connection timeout after 20s"));
      }
    }, 20000);
    if (socket.connected) {
      finish(resolve);
      return;
    }

    function onOpen() {
      log("[Main] WebSocket connection established.");
      finish(resolve);
    }

    socket.on("open", onOpen);
  });

  const client = new ChatPClient(socket);
  return { auth, socket, client };
}

async function startBot(defaultRoom = config.defaultRoom) {
  log("\n======================================================");
  log("   TalkInChat Music Bot Initializing     ");
  log("======================================================");
  log(`[Main] Authenticating user: ${config.username || "(not set)"} ...`);

  const { client, socket, auth } = await connectAuthenticated();
  await initRoomDatabase();
  const workerRoom = String(process.env.ROOM_WORKER_ROOM || defaultRoom || "").trim();
  const requireOwnerForPlayback = process.env.BOT_REQUIRE_OWNER !== "false";
  // When the bot is authoritative OWNER in a room, automatically bootstrap
  // its publisher. Set AUTO_PUBLISH_ON_OWNER=false only if a deployment wants
  // manual .stream/.play startup. Losing OWNER always stops publishing.
  const autoPublishOnOwner = process.env.AUTO_PUBLISH_ON_OWNER !== "false";
  const masterOnly = process.env.BOT_ROOM_MASTER_ONLY !== "false";
  let botOwnsRoom = false;
  let botRole = "";
  const setBotRole = (role, room = workerRoom) => {
    botRole = String(role || "").trim().toLowerCase();
    botOwnsRoom = botRole === "owner";
    if (room) { try { setRoomMeta(room, { botRole }); } catch {} }
    return botOwnsRoom;
  };
  const getBotOwnerState = () => botOwnsRoom && (!workerRoom || String(client.currentRoom || workerRoom).trim() === workerRoom);
  const bootstrapMaster = String(process.env.BOT_MASTER_USERNAME || '').trim();
  if (workerRoom && bootstrapMaster && !listRoomMasters(workerRoom).length) {
    addRoomMaster(workerRoom, { username: bootstrapMaster, userId: String(process.env.BOT_MASTER_USER_ID || '') }, { username: bootstrapMaster, userId: String(process.env.BOT_MASTER_USER_ID || '') });
  }
  await initRoomDatabase();
  ensureLegacySettingsFile();
  setActiveRoom(defaultRoom || "");
  const voiceManager = new VoiceManager();
  let handleRoomCommand = null;
  const voiceCommandEngine = new VoiceCommandEngine({
    enabled: process.env.VOICE_COMMANDS_ENABLED === "true",
    whisperBin: process.env.WHISPER_BIN || "whisper",
    model: process.env.WHISPER_MODEL || "",
    language: process.env.VOICE_COMMAND_LANGUAGE || "auto",
    log,
    onTranscript: (text, identity) => log(`[VoiceCmd] ${identity}: ${text}`),
    onCommand: async (command, identity, transcript) => {
      if (!handleRoomCommand) return;
      const room = client.currentRoom || defaultRoom;
      if (!room) return;
      await handleRoomCommand({ text: `.${command}`, room, username: identity, userId: identity, voiceCommand: true, transcript });
    }
  });
  const youtubePlayer = new YouTubePlayer();
  const sessionGuard = new SessionGuard();
  const runtimeStore = new AtomicStore("runtime", { language: "en", roomProfiles: {}, session: null, debug: false });
  // Runtime debug state may be persisted by .debug; CHATP_DEBUG=true in .env always enables it.
  config.debug = Boolean(config.debug || runtimeStore.data.debug);
  setLoggerDebugEnabled(config.debug);
  sessionGuard.start({ room: defaultRoom });
  await loadPlugins(log);
  startMaintenance({ log });
  const syncPlaybackRate = () => {
    let rate = voiceManager.filters.speed;
    if (voiceManager.filters.nightcore) rate *= (60000 / 48000);
    // vaporwave uses asetrate=0.82 followed by resampling back to 48 kHz, so
    // the audio itself runs at 82% of wall-clock speed. Keep progress/seek/ETA
    // aligned with the actual filtered audio.
    if (voiceManager.filters.preset === "vaporwave") rate *= 0.82;
    return youtubePlayer.setPlaybackRate(rate);
  };

  const applyFilterChange = async (reason, change) => {
    const active = Boolean(youtubePlayer.currentTrack && youtubePlayer.isPlaying);
    const offset = active ? youtubePlayer.getElapsedSeconds() : 0;
    const wasPaused = active && youtubePlayer.isPaused;
    const result = change();
    syncPlaybackRate();
    if (active) {
      await youtubePlayer.restartCurrent(reason, offset, { announce: false });
      if (wasPaused) youtubePlayer.pause();
    }
    return result;
  };
  let pendingAudio = null;
  let recoveryResume = null;
  let startupRestorePlayId = 0;
  let startupRestoreInFlight = false;
  let recoveryAttempt = 0;
  let recoveryResetDone = false;
  let lastJoinRequestAt = 0;
  let selfJoinStreamSeenAt = 0;

  // Keep player state and the native LiveKit pump synchronized. These listeners
  // make pause/resume immediate and ensure a replacement cannot leave an old
  // PCM producer running behind the new track.
  youtubePlayer.on("paused", () => voiceManager.setPlaybackPaused(true));
  youtubePlayer.on("resumed", () => voiceManager.setPlaybackPaused(false));
  youtubePlayer.on("trackStart", () => voiceManager.setPlaybackPaused(false));
  youtubePlayer.on("stopped", () => { voiceManager.setPlaybackPaused(false); });
  syncPlaybackRate();

  voiceManager.on("connected", async () => {
    const connectedRoom = voiceManager.currentRoomName || client.currentRoom || defaultRoom;
    startVoiceHeartbeat(connectedRoom);
    if (!alwaysOn && !youtubePlayer.isPlaying && youtubePlayer.queue.length === 0) { try { resetIdleWatcher(); } catch {} }
    if (process.env.VOICE_COMMANDS_ENABLED === "true") {
      try { await voiceCommandEngine.attach(voiceManager.room); } catch (err) { log(`[VoiceCmd] attach failed: ${err.message}`); }
    }

    // Persistent playback recovery after a full process restart. The previous
    // implementation loaded the snapshot into recoveryResume and then called
    // restartCurrent(), which requires currentTrack to already exist. That made
    // a fresh process silently fail to resume. Restore the saved track directly
    // through playTrackObject(), preserving its queue and exact position.
    if (!pendingAudio && !recoveryResume && !youtubePlayer.currentTrack && !startupRestoreInFlight && autoResume) {
      const snap = getRoomPlayback(connectedRoom) || getPlaybackSnapshot();
      if (snap?.track?.url && (!snap.room || snap.room === connectedRoom)) {
        startupRestoreInFlight = true;
        const savedTrack = { ...snap.track };
        const savedQueue = (Array.isArray(snap.queue) ? snap.queue : [])
          .slice(0, youtubePlayer.queueLimit)
          .map(t => ({ ...t }));
        const total = Number(savedTrack.durationSeconds || 0);
        const savedOffset = Math.max(0, Number(snap.offset) || 0);
        const safeOffset = Math.max(0, total > 5 ? Math.min(savedOffset, total - 2) : savedOffset);
        youtubePlayer.queue = savedQueue;
        log(`[Voice] Restoring last session: "${savedTrack.title}" at ${safeOffset.toFixed(1)}s (${savedQueue.length} queued).`);
        void youtubePlayer.playTrackObject(savedTrack, "startup-resume", safeOffset, { announce: false, recordHistory: false })
          .then(ok => {
            if (!ok) throw new Error("player refused startup restore");
            startupRestorePlayId = youtubePlayer.playId;
            log(`[Voice] ✓ Last session restored: "${savedTrack.title}".`);
          })
          .catch(err => {
            startupRestoreInFlight = false;
            startupRestorePlayId = 0;
            log(`[Voice] Last-session restore failed: ${err?.message || err}`);
          });
      }
    }

    if (pendingAudio) {
      const pending = pendingAudio;
      pendingAudio = null;
      if (pending.playId !== youtubePlayer.playId) { try { pending.stream?.destroy?.(); } catch {} }
      else {
        youtubePlayer.startDecodedWatchdog?.(pending.playId);
        try { await voiceManager.publishAudioStream(pending.stream, pending.playId, { seekOffset: Number(pending.seekOffset) || 0, fastStart: Boolean(pending.fastStart) }); }
        catch (err) { incrementStat("voiceFailures"); log(`[Voice] Pending playback error: ${err.message}`); }
      }
      return;
    }

    // Network recovery: rebuild the media source from the same YouTube track
    // and resume near the exact position where LiveKit was lost. Queue/settings
    // remain in YouTubePlayer/VoiceManager and are therefore preserved.
    if (recoveryResume?.track?.url) {
      const saved = recoveryResume;
      recoveryResume = null;
      const total = Number(saved.track.durationSeconds || 0);
      const safeOffset = Math.max(0, total > 5 ? Math.min(saved.offset, total - 2) : saved.offset);
      log(`[Voice] Restoring last track after reconnect: "${saved.track.title}" at ${safeOffset.toFixed(1)}s`);
      try {
        await youtubePlayer.restartCurrent("voice-reconnect", safeOffset, { announce: false });
      } catch (err) {
        log(`[Voice] Resume after reconnect failed: ${err.message}`);
      }
    }
  });

  youtubePlayer.on("trackStart", track => { try { recordCommunityPlay(track?.requestedBy || "User"); } catch {} });
  youtubePlayer.on("streamError", ({ track, code, attempts, error } = {}) => {
    log(`[YouTube Recovery] Source failure${track?.title ? ` for "${track.title}"` : ""} code=${code ?? "unknown"} attempt=${attempts ?? 1}: ${error?.message || error || "unknown error"}`);
  });

  youtubePlayer.on("streamReady", async ({ stream, track, playId, seekOffset = 0, fastStart = false }) => {
    try {
      if (!voiceManager.isConnected) {
        if (pendingAudio?.stream && pendingAudio.playId !== playId) {
          try { pendingAudio.stream.destroy?.(); } catch {}
        }
        pendingAudio = { stream, track, playId, seekOffset: Number(seekOffset) || 0, fastStart: Boolean(fastStart) };
        const room = client.currentRoom || defaultRoom;
        log(`[Voice] Music requested while disconnected; saving stream and joining voice lobby.`);
        if (room) requestVoiceJoin(room);
        return;
      }
      pendingAudio = null;
      youtubePlayer.startDecodedWatchdog?.(playId);
      await voiceManager.publishAudioStream(stream, playId, { seekOffset: Number(seekOffset) || 0, fastStart: Boolean(fastStart) });
    } catch (err) {
      incrementStat("voiceFailures");
      log(`[Main] Playback stream error: ${err.message}`);
      youtubePlayer.emit("playbackError", { track, error: err });
    }
  });

  voiceManager.on("disconnected", (reason) => {
    clearStreamDirectoryTimers();
    youtubePlayer.suspendSourceForVoiceLoss?.();
    void voiceCommandEngine.detach();
    stopVoiceHeartbeat();
    if (!manualVoiceStop && autoResume && youtubePlayer.currentTrack && youtubePlayer.isPlaying) {
      const offset = youtubePlayer.getElapsedSeconds();
      recoveryResume = { track: { ...youtubePlayer.currentTrack }, offset };
      // Freeze player time while LiveKit is unavailable so reconnect resumes
      // from the saved point rather than advancing through the track silently.
      youtubePlayer.pause();
      log(`[Voice] Saved recovery position ${offset.toFixed(1)}s for "${youtubePlayer.currentTrack.title}".`);
    }
    if (!manualVoiceStop) { incrementStat("voiceRecoveries"); scheduleVoiceRecovery(voiceManager.currentRoomName || client.currentRoom || defaultRoom, reason || 'livekit disconnected'); }
  });
  voiceManager.on("reconnecting", () => {
    log('[Voice] LiveKit is reconnecting...');
  });
  voiceManager.on("reconnected", () => {
    log('[Voice] LiveKit reconnected; keeping current music/settings.');
  });

  voiceManager.on("audioProgress", ({ playId } = {}) => {
    mediaRetryCount = 0;
    mediaRetryPlayId = playId || youtubePlayer.playId;
    youtubePlayer.confirmPlayback?.(playId);
    youtubePlayer.markDecodedProgress?.(playId);
    // Only delete the persisted startup snapshot after the restored playId has
    // produced real PCM. If FFmpeg/LiveKit fails before audio starts, the next
    // bot launch can still recover the same session.
    if (startupRestorePlayId && Number(playId) === Number(startupRestorePlayId)) {
      clearPlaybackSnapshot();
      startupRestorePlayId = 0;
      startupRestoreInFlight = false;
      log(`[Voice] ✓ Startup playback confirmed; session snapshot cleared.`);
    }
  });

  const earlyEofRetries = new Map();
  voiceManager.on("streamFinished", ({ playId, elapsedSeconds = 0 } = {}) => {
    if (playId && playId !== youtubePlayer.playId) return;
    const track = youtubePlayer.currentTrack;
    if (!track) return void youtubePlayer.playNext();
    const total = Number(track.durationSeconds || 0);
    const elapsed = Number(elapsedSeconds || youtubePlayer.getElapsedSeconds?.() || 0);
    // FFmpeg can occasionally reach EOF cleanly after a truncated/corrupt
    // cached file. Treat that as a media failure instead of immediately
    // advancing to the next song. A small tolerance covers YouTube duration
    // metadata rounding and normal encoder padding.
    const tolerance = Math.max(8, Math.min(25, total * 0.04));
    if (total >= 45 && elapsed < total - tolerance) {
      const attempts = (earlyEofRetries.get(playId) || 0) + 1;
      if (attempts <= 2) {
        earlyEofRetries.set(playId, attempts);
        log(`[Voice] Early EOF detected for "${track.title}" at ${elapsed.toFixed(1)}s/${total.toFixed(1)}s; retrying media source (${attempts}/2) instead of skipping.`);
        youtubePlayer.invalidateAudioCache?.(track);
        const resumeAt = Math.max(0, elapsed - 1.0);
        void youtubePlayer.restartCurrent("early-eof", resumeAt, { announce: false, reuseDirectUrl: false })
          .catch(err => log(`[Voice] Early EOF recovery failed: ${err?.message || err}`));
        return;
      }
      earlyEofRetries.delete(playId);
    }
    earlyEofRetries.delete(playId);
    void youtubePlayer.playNext();
  });

  let mediaRetryPlayId = 0;
  let mediaRetryCount = 0;
  voiceManager.on("playbackError", ({ playId, error } = {}) => {
    if (playId && playId !== youtubePlayer.playId) return;
    if (manualVoiceStop || !youtubePlayer.currentTrack || !youtubePlayer.isPlaying) return;
    if (playId !== mediaRetryPlayId) { mediaRetryPlayId = playId || youtubePlayer.playId; mediaRetryCount = 0; }
    const offset = youtubePlayer.getElapsedSeconds();
    // Prefer restarting only the media source. Tearing down LiveKit for an
    // FFmpeg/YouTube hiccup creates an avoidable audible gap and can trigger
    // the old invite/recovery loop. Re-resolve the direct YouTube URL while
    // keeping the healthy publisher alive.
    if (mediaRetryCount < 3 && voiceManager.isConnected && voiceManager.publishing) {
      mediaRetryCount += 1;
      log(`[Recovery] Media pipeline failed (${mediaRetryCount}/3): ${error?.message || error}. Re-resolving source at ${offset.toFixed(1)}s without disconnecting LiveKit.`);
      setTimeout(() => {
        if (manualVoiceStop || !youtubePlayer.currentTrack || !youtubePlayer.isPlaying) return;
        void youtubePlayer.restartCurrent("media-source-retry", offset, { announce: false, reuseDirectUrl: false })
          .catch(err => log(`[Recovery] Media source retry failed: ${err?.message || err}`));
      }, Math.min(1200, 350 * mediaRetryCount)).unref?.();
      return;
    }
    const room = client.currentRoom || defaultRoom;
    if (!room || !autoResume) return;
    mediaRetryCount = 0;
    recoveryResume = { track: { ...youtubePlayer.currentTrack }, offset };
    log(`[Recovery] Media pipeline remained unhealthy after 3 source retries. Restarting voice from ${offset.toFixed(1)}s.`);
    youtubePlayer.pause();
    void voiceManager.disconnect().catch(()=>{});
    scheduleVoiceRecovery(room, 'FFmpeg/media pipeline failure');
  });

  let lastStreamCredentialKey = "";
  let lastStreamCredentialAt = 0;
  // Invitation sessionId stays constant for a room stream session while the
  // temporary invitation token changes. Deduplicate by token, not sessionId;
  // otherwise a failed first publish causes every later you_invited event in
  // the same session to be discarded forever.
  const acceptedInviteTokens = new Set();
  let lastAcceptedInviteSession = "";
  let publishFallbackSent = false;
  let streamJoinInProgress = false;
  let autoUpgradeStreamingAttempted = false;
  let lastOwnJoinStreamSession = "";
  let lastOwnJoinStreamLogAt = 0;
  let streamRetryTimer = null;
  let voiceRoomGeneration = 0;
  let wsRecoveryGeneration = 0;
  let startupVoiceTimer = null;
  let wsRecoveryTimer = null;
  let lastInviteAt = 0;
  let selfInviteInFlight = false;
  let selfInviteGeneration = 0;
  let selfInviteTimer = null;
  const SELF_INVITE_COOLDOWN_MS = 5000;
  const SELF_INVITE_HARD_TIMEOUT_MS = 7000;
  const SELF_INVITE_FALLBACK_WAIT_MS = 9000;
  let voiceHeartbeat = null;
  let voiceRecoveryTimer = null;
  let voiceRecoveryRunning = false;
  let voiceRecoveryGeneration = 0;
  let activeRecoveryRoom = "";
  let streamDirectoryTimer = null;
  const streamDirectoryTimers = new Set();
  let streamDirectoryGeneration = 0;
  let streamVisibilityRefreshInFlight = false;
  let lastStreamVisibilityRefreshAt = 0;
  let lastKnownStreaming = false;
  // One controlled Voice/Active directory promotion attempt per room session.
  // Some ChatP deployments only refresh the APK Active cache after the Android-
  // style room_join(intValue=1). Never repeat it during automatic recovery:
  // repeating it is what can create the historical invite/revoke loop.
  let directorySyncTimer = null;
  let lastVoiceRoom = null;
  let manualVoiceStop = false;
  let voiceRecoveryWanted = false;
  const VOICE_RECOVERY_DELAY_MS = 1000;
  const VOICE_RECOVERY_BACKOFF_MS = [5000, 5000, 5000, 5000, 5000, 5000];
  const LIVEKIT_STATIC_CONNECT_DELAY_MS = 0;
  const VOICE_INVITE_TIMEOUT_MS = 15000;
  const STREAM_DIRECTORY_REFRESH_MS = 10000;
  let visibilityDiagnosticTimer = null;
  // The Android client sends room_stream/publish only after RoomActivity has
  // successfully joined the text room. A bot can receive the room advertisement
  // before its room_join acknowledgement, so gate the first publisher request
  // on an actual you_joined/you_rejoined event.
  let textRoomJoinedAt = 0;
  let pendingPublisherRoom = "";
  let pendingPublisherTimer = null;

  const refreshVoiceDirectory = (room) => {
    const targetRoom = String(room || client.currentRoom || defaultRoom || '').trim();
    if (!targetRoom || !socket.connected) return;
    // IMPORTANT: the Android Voice/Active screen does NOT build its list from
    // public_rooms/trending_rooms. The APK caches RoomEvent.streamingEnabled
    // and exposes that cache as the Active/Voice directory. A check request can
    // verify the server state, but it cannot manufacture the RoomEvent.
    try { client.streamCheck(targetRoom); }
    catch (err) { debug('[Voice Directory] stream-state check failed:', err.message); }
  };

  const clearStreamDirectoryTimers = () => {
    streamDirectoryGeneration += 1;
    if (directorySyncTimer) { clearTimeout(directorySyncTimer); directorySyncTimer = null; }
    if (visibilityDiagnosticTimer) { clearTimeout(visibilityDiagnosticTimer); visibilityDiagnosticTimer = null; }
    for (const timer of streamDirectoryTimers) clearTimeout(timer);
    streamDirectoryTimers.clear();
  };

  const scheduleStreamDirectoryRefreshes = (room) => {
    clearStreamDirectoryTimers();
    const generation = streamDirectoryGeneration;
    const targetRoom = String(room || '').trim();
    for (const delay of [5000, 15000, 30000, 60000]) {
      const timer = setTimeout(() => {
        streamDirectoryTimers.delete(timer);
        if (generation !== streamDirectoryGeneration) return;
        if (manualVoiceStop || sleepTriggered || !voiceManager.isConnected || String(client.currentRoom || defaultRoom || "").trim() !== targetRoom) return;
        void refreshVoiceDirectory(targetRoom);
      }, delay);
      streamDirectoryTimers.add(timer);
    }
  };

  const refreshStreamVisibility = async (room, reason = 'publisher-start') => {
    const targetRoom = String(room || client.currentRoom || defaultRoom || '').trim();
    if (!targetRoom || !socket.connected || manualVoiceStop) return false;
    const now = Date.now();
    if (streamVisibilityRefreshInFlight) return false;
    if (now - lastStreamVisibilityRefreshAt < 5000) return false;
    streamVisibilityRefreshInFlight = true;
    lastStreamVisibilityRefreshAt = now;
    try {
      // IMPORTANT: the supplied APK does NOT perform a text-room rejoin as a
      // general-purpose way to make Voice/Active visible. A room_join(intValue=1)
      // tears down the current ChatP room membership on this server and, for the
      // bot, was the direct cause of the invite/revoke/DC loop. The APK's normal
      // stream path is: room_join(0) -> invite -> publish -> publish_stream ->
      // LiveKit. Voice/Active state is then delivered by the server's RoomEvent.
      // Never rejoin the text room while a publisher is healthy.
      log(`[Voice Directory] Checking server Voice/Active state for "${targetRoom}" (${reason})...`);
      client.streamCheck(targetRoom);
      return true;
    } catch (err) {
      log(`[Voice Directory] Server visibility check failed: ${err.message}`);
      return false;
    } finally {
      streamVisibilityRefreshInFlight = false;
    }
  };

  const stopVoiceRecovery = () => {
    voiceRecoveryGeneration += 1;
    activeRecoveryRoom = "";
    voiceRecoveryRunning = false;
    if (voiceRecoveryTimer) clearTimeout(voiceRecoveryTimer);
    voiceRecoveryTimer = null;
  };

  const resetVoiceJoinState = () => {
    streamJoinInProgress = false;
    selfInviteGeneration += 1;
    selfInviteInFlight = false;
    if (selfInviteTimer) { clearTimeout(selfInviteTimer); selfInviteTimer = null; }
    acceptedInviteTokens.clear();
    lastAcceptedInviteSession = "";
    publishFallbackSent = false;
    autoUpgradeStreamingAttempted = false;
    lastStreamCredentialKey = "";
    lastStreamCredentialAt = 0;
    if (streamRetryTimer) clearTimeout(streamRetryTimer);
    streamRetryTimer = null;
  };

  const resetServerStreamForRecovery = async (room) => {
    const targetRoom = String(room || lastVoiceRoom || client.currentRoom || defaultRoom || '').trim();
    if (!targetRoom || manualVoiceStop) return;
    // v5.3.5: recovery must never send unpublish/stop_stream automatically.
    // Those operations are destructive and were producing the visible
    // "has been revoked from stream by aryan" event before every retry.
    // A recovery cycle only resets local single-flight state and lets the APK
    // compatible room_stream/publish request obtain fresh credentials.
    log(`[Voice Recovery] Preserving server publisher registration for "${targetRoom}"; local state reset only.`);
    await new Promise(resolve => setTimeout(resolve, 50));
    resetVoiceJoinState();
    recoveryResetDone = true;
  };

  const scheduleVoiceRecovery = (room, reason = 'network') => {
    const targetRoom = String(room || lastVoiceRoom || client.currentRoom || defaultRoom || '').trim();
    if (!targetRoom || manualVoiceStop || !config.reconnect) return;
    lastVoiceRoom = targetRoom;
    if (voiceManager.isConnected) return;
    if (voiceRecoveryRunning && activeRecoveryRoom && activeRecoveryRoom !== targetRoom) stopVoiceRecovery();
    if (voiceRecoveryTimer) return;
    if (!voiceRecoveryRunning) {
      activeRecoveryRoom = targetRoom;
      voiceRecoveryGeneration += 1;
      voiceRecoveryRunning = true;
      recoveryAttempt = 0;
      recoveryResetDone = false;
      log(`[Voice] Recovery state machine started: room="${targetRoom}" reason=${reason}.`);
    }
    const generation = voiceRecoveryGeneration;
    const tick = async () => {
      voiceRecoveryTimer = null;
      if (generation !== voiceRecoveryGeneration || targetRoom !== activeRecoveryRoom) return;
      if (manualVoiceStop || voiceManager.isConnected || !socket.connected) {
        if (!socket.connected && !manualVoiceStop) log('[Voice] Recovery paused until WebSocket reconnects.');
        if (voiceManager.isConnected || manualVoiceStop) voiceRecoveryRunning = false;
        return;
      }
      recoveryAttempt += 1;
      const delay = VOICE_RECOVERY_BACKOFF_MS[Math.min(recoveryAttempt - 1, VOICE_RECOVERY_BACKOFF_MS.length - 1)];
      log(`[Voice] Recovery attempt ${recoveryAttempt}: waiting server state, then requesting one direct publisher operation.`);
      try {
        await voiceManager.waitForCleanup();
        // A publish_stream may already be in the native LiveKit handshake.
        // Never release the server stream or issue another invitation while
        // that connection is pending; let the current attempt finish first.
        if (voiceManager.isConnecting) {
          debug(`[Voice Recovery] LiveKit handshake is still pending for "${targetRoom}"; skipping this recovery invite.`);
        } else {
        // First retry is non-destructive. Only if the server still has not
        // accepted a new publisher by the second retry do we release a stale
        // publisher registration. This prevents revoke/invite storms.
        if (recoveryAttempt >= 2 && !recoveryResetDone) await resetServerStreamForRecovery(targetRoom);
        requestVoiceJoin(targetRoom, true);
        }
      } catch (err) {
        debug('[Voice Recovery] attempt failed:', err.message);
      }
      if (generation === voiceRecoveryGeneration && !voiceManager.isConnected && !manualVoiceStop && socket.connected) {
        voiceRecoveryTimer = setTimeout(tick, delay);
      } else {
        voiceRecoveryRunning = false;
      }
    };
    if (!voiceRecoveryTimer) voiceRecoveryTimer = setTimeout(tick, 250);
  };

  let heartbeatGeneration = 0;
  const startVoiceHeartbeat = (room) => {
    if (voiceHeartbeat) clearInterval(voiceHeartbeat);
    if (streamDirectoryTimer) clearInterval(streamDirectoryTimer);
    const generation = ++heartbeatGeneration;
    if (!room) return;
    voiceHeartbeat = setInterval(() => {
      if (generation !== heartbeatGeneration || String(client.currentRoom || defaultRoom || "").trim() !== String(room).trim() || !voiceManager.isConnected) {
        stopVoiceHeartbeat();
        return;
      }
      try { client.streamCheck(room); } catch (err) { debug("[Voice Heartbeat Error]", err.message); }
    }, 10000);
    // Keep the room's server-side streaming advertisement refreshed. This is
    // intentionally separate from the LiveKit media heartbeat.
    streamDirectoryTimer = setInterval(() => {
      if (generation === heartbeatGeneration && String(client.currentRoom || defaultRoom || "").trim() === String(room).trim() && voiceManager.isConnected) refreshVoiceDirectory(room);
    }, STREAM_DIRECTORY_REFRESH_MS);
    refreshVoiceDirectory(room);
  };

  const stopVoiceHeartbeat = () => {
    heartbeatGeneration += 1;
    if (voiceHeartbeat) { clearInterval(voiceHeartbeat); voiceHeartbeat = null; }
    if (streamDirectoryTimer) { clearInterval(streamDirectoryTimer); streamDirectoryTimer = null; }
  };

  // Media watchdog: a connected LiveKit room with no PCM frames is a dead
  // publisher even when the transport itself still reports connected.
  let watchdogTimer = null;
  const startVoiceWatchdog = () => {
    if (watchdogTimer) clearInterval(watchdogTimer);
    watchdogTimer = setInterval(() => {
      if (!voiceManager.isConnected || !voiceManager.publishing || !youtubePlayer.isPlaying || youtubePlayer.isPaused) return;
      const h = voiceManager.getHealth();
      const now = Date.now();
      const pipelineStartedAt = Number(h.pipelineStartedAt || 0);
      const lastFrameAt = Number(h.lastFrameAt || 0);
      // Never use a timestamp from a previous playback session. A fresh PCM
      // pipeline gets a new start marker; allow a full startup grace period
      // before declaring it stalled. Once frames begin, use the latest frame.
      if (!pipelineStartedAt) return;
      // Give a new pipeline time to fill its jitter buffer. If FFmpeg is still
      // alive, a short absence of captured frames is not enough evidence that
      // the publisher is dead. Recover only after a sustained 60s stall.
      const startupAge = now - pipelineStartedAt;
      const frameAge = lastFrameAt > pipelineStartedAt ? now - lastFrameAt : startupAge;
      const ffmpegAlive = Boolean(h.ffmpeg);
      const threshold = ffmpegAlive ? 15000 : 10000;
      if (startupAge < 10000) return;
      if (frameAge > threshold) {
        const room = client.currentRoom || defaultRoom;
        if (!room || String(h.room || voiceManager.currentRoomName || '').trim() !== String(room).trim()) return;
        log(`[Watchdog] Media pipeline stalled (${Math.round(frameAge/1000)}s without PCM; ffmpeg=${ffmpegAlive?'alive':'dead'}); starting controlled voice recovery.`);
        if (room && !manualVoiceStop) {
          const offset = youtubePlayer.getElapsedSeconds();
          recoveryResume = { track: { ...youtubePlayer.currentTrack }, offset };
          youtubePlayer.pause();
          void voiceManager.disconnect().catch(()=>{});
          scheduleVoiceRecovery(room, 'media watchdog: stale PCM');
        }
      }
    }, 5000);
  };
  startVoiceWatchdog();
  process.once('exit',()=>{ if(watchdogTimer) clearInterval(watchdogTimer); });

  async function handleStreamEvent(event) {
    if (!event) return;
    const type = String(event.type || "");
    const activeRoom = String(client.currentRoom || defaultRoom || "").trim();
    const eventRoomRaw = String(event.room || "").trim();
    if (eventRoomRaw && activeRoom && eventRoomRaw !== activeRoom) {
      debug(`[Voice] Ignoring ${type} event for non-active room "${eventRoomRaw}" (active="${activeRoom}").`);
      return;
    }
    const effectiveRoom = eventRoomRaw || activeRoom;

    // The Android client also receives the authoritative streaming flag on
    // normal room-state events. Consume it when present; this is the only safe
    // way for the bot to know that ChatP has advertised the room as active.
    if ((type === "you_joined" || type === "you_rejoined") && effectiveRoom === activeRoom) {
      const streaming = event.isStreaming === true || Number(event.isStreaming) === 1 || String(event.streamingEnabled || "").toLowerCase() === "true";
      if (streaming) {
        lastVoiceRoom = effectiveRoom;
        lastKnownStreaming = true;
        debug(`[Voice Directory] Room-state event confirms streaming for "${effectiveRoom}".`);
      }
    }

    // APK-compatible invitation acceptance:
    // The server first sends `you_invited` with the invitation/publish token.
    // That token MUST be supplied as `to` in the subsequent room_stream/publish
    // request. Do not send an empty publish request before accepting the invite.
    if (type === "you_invited") {
      const invitationToken = String(event.token || "").trim();
      const invitationSession = String(event.sessionId || "").trim();
      // sessionId is the stream session identifier, NOT a unique invitation
      // identifier. The server legitimately reuses it while issuing a fresh
      // temporary token after a failed/expired publish attempt.
      if (invitationToken && acceptedInviteTokens.has(invitationToken)) {
        debug(`[Voice] Duplicate invitation token ignored (session=${invitationSession || "?"}).`);
        return;
      }
      if (!effectiveRoom || !invitationToken) {
        log(`[Voice] you_invited received without a usable token (room=${effectiveRoom || "?"}).`);
        return;
      }

      log(`[Voice] Owner invitation received: room="${effectiveRoom}" session=${invitationSession || "?"}. Accepting with publish token.`);
      streamJoinInProgress = true;
      acceptedInviteTokens.add(invitationToken);
      // Keep memory bounded if a server keeps issuing temporary tokens.
      if (acceptedInviteTokens.size > 64) {
        const oldest = acceptedInviteTokens.values().next().value;
        if (oldest) acceptedInviteTokens.delete(oldest);
      }
      lastAcceptedInviteSession = invitationSession;
      publishFallbackSent = false;
      try {
        client.streamPublish(effectiveRoom, invitationToken);
      } catch (err) {
        log(`[Voice] Failed to accept self invitation: ${err.message}`);
        return;
      }

      // Some ChatP server builds accept the invitation through the pending
      // stream session but do not require the temporary token in `to`. The
      // APK-compatible token form is always attempted first. If no
      // publish_stream arrives quickly, fall back ONCE to the server-compatible
      // empty-`to` publish request before asking for another invitation. This is
      // still the same room_stream/publish protocol and never performs the
      // unsafe room_join(intValue=1) refresh.
      if (streamRetryTimer) clearTimeout(streamRetryTimer);
      streamRetryTimer = setTimeout(() => {
        streamRetryTimer = null;
        if (voiceManager.isConnected || !streamJoinInProgress || manualVoiceStop || client.currentRoom !== effectiveRoom) return;
        if (!publishFallbackSent) {
          publishFallbackSent = true;
          log(`[Voice] No publish_stream after invitation token; retrying pending publisher acceptance for "${effectiveRoom}" without the temporary token.`);
          try { client.streamPublish(effectiveRoom, ""); } catch (err) { debug(`[Voice] Empty-token publish fallback failed: ${err.message}`); }
          streamRetryTimer = setTimeout(() => {
            streamRetryTimer = null;
            if (!voiceManager.isConnected && streamJoinInProgress && !manualVoiceStop && client.currentRoom === effectiveRoom) {
              // Do not issue another self-invite from inside an invitation
              // callback. The invitation lock is still authoritative; recovery
              // owns the next attempt after the hard timeout.
              selfInviteInFlight = false;
              streamJoinInProgress = false;
              log(`[Voice] Publisher acceptance produced no publish_stream for "${effectiveRoom}"; handing recovery back to the single-flight controller.`);
              scheduleVoiceRecovery(effectiveRoom, 'publisher acceptance timeout');
            }
          }, 5000);
          streamRetryTimer.unref?.();
        }
      }, 2500);
      streamRetryTimer.unref?.();
      return;
    }

    // IMPORTANT: `join_stream` is NOT a publisher credential event.
    // ChatP can send join_stream with canPublish=false; the separate
    // publish_stream event contains the actual publisher token. Treating
    // join_stream as publisher credentials creates a LiveKit connection that
    // can never publish and leads to "track publication timed out".
    if (type === "join_stream" && event.token && event.url) {
      // This is subscriber/audience credentials, not publisher credentials.
      // If the event belongs to our own stale session, do not immediately send
      // another invite. That was the source of the repeated self-invite loop.
      const from = String(event.from || '').trim().toLowerCase();
      const own = String(config.username || auth.username || '').trim().toLowerCase();
      if (from && own && from === own) {
        selfJoinStreamSeenAt = Date.now();
        // ChatP may broadcast the same subscriber-side join_stream repeatedly
        // for the lifetime of a stream session. It is NOT a publisher request
        // and must never trigger another self-invite. Keep the first diagnostic
        // useful, then silently deduplicate repeats so the console stays clean.
        const session = String(event.sessionId || "").trim();
        const now = Date.now();
        const duplicate = session && session === lastOwnJoinStreamSession && now - lastOwnJoinStreamLogAt < 60000;
        if (!duplicate) {
          lastOwnJoinStreamSession = session;
          lastOwnJoinStreamLogAt = now;
          log(`[Voice] Ignoring subscriber join_stream for our active/stale session; publisher credentials are handled only by publish_stream.`);
        } else {
          debug(`[Voice] Duplicate own join_stream suppressed (session=${session || "?"}).`);
        }
      } else {
        debug(`[Voice] join_stream received for subscriber/session; publisher credentials are still required.`);
      }
      return;
    }

    // IMPORTANT: only publish_stream is a publisher credential event.
    if (type === "publish_stream" && event.token && event.url) {
      const token = String(event.token);
      const url = String(event.url);
      const streamKey = `${url}:${token}`;
      const now = Date.now();

      if (voiceManager.isConnected && lastStreamCredentialKey === streamKey) return;
      if (!voiceManager.isConnected && streamKey === lastStreamCredentialKey && now - lastStreamCredentialAt < 1000) return;

      lastStreamCredentialKey = streamKey;
      lastStreamCredentialAt = now;
      selfInviteInFlight = false;
      if (selfInviteTimer) { clearTimeout(selfInviteTimer); selfInviteTimer = null; }
      streamJoinInProgress = false;
      publishFallbackSent = false;
      voiceRecoveryWanted = !manualVoiceStop;
      if (streamRetryTimer) {
        clearTimeout(streamRetryTimer);
        streamRetryTimer = null;
      }

      log(`[Voice] ${type}: LiveKit credentials received for "${effectiveRoom}". Connecting immediately...`);
      try {
        // Do not add an artificial pre-connect delay. The APK connects as soon
        // as publish_stream arrives; LiveKit itself has a bounded 15s handshake timeout.
        if (LIVEKIT_STATIC_CONNECT_DELAY_MS > 0) {
          await new Promise(resolve => setTimeout(resolve, LIVEKIT_STATIC_CONNECT_DELAY_MS));
        }
        if (manualVoiceStop || !socket.connected) return;
        log(`[Voice] Connecting to LiveKit immediately: room="${effectiveRoom}".`);
        const success = await voiceManager.connectToRoom(url, token, effectiveRoom, {
          connectTimeoutMs: 15000,
          retryDelayMs: 5000,
          maxAttempts: 3
        });
        if (success) {
          lastVoiceRoom = effectiveRoom;
          // Preserve the latest authoritative ChatP directory state across the
          // LiveKit connection. In particular, some ChatP deployments send
          // RoomEvent.isStreaming=1 in you_joined and do not emit a second
          // stream_enabled event after publish_stream. Resetting this flag here
          // incorrectly turned a known STREAMING room into UNKNOWN and produced
          // a false Voice/Active warning. Only explicit server state events
          // (stream_enabled/stream_exists/stop_stream/revoked) may change it.
          const knownDirectoryStateBeforePublish = lastKnownStreaming;
          voiceRecoveryWanted = false;
          log(`[Voice] Publisher connected and audio track published for "${effectiveRoom}".`);
          if (knownDirectoryStateBeforePublish) {
            log(`[Voice Directory] Preserving server STREAMING state for "${effectiveRoom}" across publisher connection.`);
          }
          startVoiceHeartbeat(effectiveRoom);
          // Match the APK's safe sequence: after publish, only query the server
          // stream state. Do NOT rejoin the text room; that creates a user_left /
          // user_joined cycle and can revoke the active publisher on this server.
          await refreshStreamVisibility(effectiveRoom, 'publisher-start');
          refreshVoiceDirectory(effectiveRoom);
          log(`[Voice Directory] Publisher is live; waiting for the server's official Voice/Active advertisement for "${effectiveRoom}".`);
          scheduleStreamDirectoryRefreshes(effectiveRoom);
          // Voice/Active visibility is authoritative server state. Do not
          // perform a room_join(intValue=1) refresh here; that can revoke the
          // active publisher on some deployments. Continue querying the stream
          // state instead.
          if (visibilityDiagnosticTimer) clearTimeout(visibilityDiagnosticTimer);
          const visibilityGeneration = streamDirectoryGeneration;
          visibilityDiagnosticTimer = setTimeout(() => {
            visibilityDiagnosticTimer = null;
            if (visibilityGeneration !== streamDirectoryGeneration) return;
            if (voiceManager.isConnected && !lastKnownStreaming && client.currentRoom === effectiveRoom) {
              log(`[Voice Directory] WARNING: LiveKit publisher is healthy, but this session has no authoritative ChatP stream_enabled/isStreaming=1 advertisement for "${effectiveRoom}". Voice/Active visibility is server-controlled; no unsafe room rejoin will be attempted.`);
            }
          }, 15000);
          visibilityDiagnosticTimer.unref?.();
          stopVoiceRecovery();
          recoveryAttempt = 0;
          recoveryResetDone = false;
          selfJoinStreamSeenAt = 0;
        } else {
          lastKnownStreaming = false;
          voiceRecoveryWanted = !manualVoiceStop;
          log(`[Voice] Publisher connection failed for "${effectiveRoom}"; recovery remains active.`);
          scheduleVoiceRecovery(effectiveRoom, 'livekit publish failure');
        }
      } catch (err) {
        voiceRecoveryWanted = !manualVoiceStop;
        log(`[Voice Connect Error] ${err?.message || err}`);
        scheduleVoiceRecovery(effectiveRoom, 'livekit connect exception');
      }
      return;
    }

    if (type === "stream_exists") {
      const activeRoom = String(client.currentRoom || defaultRoom || "").trim();
      if (activeRoom && effectiveRoom === activeRoom) {
        const exists = event.isStreaming === true || Number(event.isStreaming) === 1 || Number(event.intValue) === 1 || String(event.value || "").toLowerCase() === "1" || String(event.value || "").toLowerCase() === "true";
        if (exists) {
          lastVoiceRoom = effectiveRoom;
          lastKnownStreaming = true;
          log(`[Voice Directory] SERVER CONFIRMED active stream for "${effectiveRoom}" via stream_exists.`);
        } else {
          debug(`[Voice Directory] stream_exists response for "${effectiveRoom}" did not contain an active flag.`);
        }
      }
      return;
    }

    if (type === "stream_enabled") {
      const activeRoom = String(client.currentRoom || defaultRoom || "").trim();
      if (!activeRoom || effectiveRoom !== activeRoom) { debug(`[Voice Directory] Ignoring stream_enabled for stale/other room "${effectiveRoom}".`); return; }
      lastVoiceRoom = effectiveRoom;
      lastKnownStreaming = true;
      log(`[Voice Directory] SERVER CONFIRMED "${effectiveRoom}" streaming-enabled / Voice-Active.`);
      refreshVoiceDirectory(effectiveRoom);
      return;
    }

    if (type === "stop_stream" || type === "stop_streaming_service" || type === "revoked") {
      if (effectiveRoom === (client.currentRoom || defaultRoom)) {
        // The APK-compatible intValue=1 room refresh can generate a transient
        // administrative revoke event while the LiveKit publisher remains live.
        // Never tear down a healthy publisher because of that stale notification.
        if (type === "revoked" && voiceManager.isConnected) {
          log(`[Voice] Ignoring server revoke notice for "${effectiveRoom}" while LiveKit publisher remains healthy; no invite/rejoin will be issued.`);
          return;
        }
        log(`[Voice] Server stopped/revoked stream for "${effectiveRoom}".`);
        lastKnownStreaming = false;
        // A server stop/revoke immediately after a failed publish is part of
        // ChatP's stream reset flow. Do not kill recovery unless the user
        // explicitly requested .leave/.stop.
        if (voiceRecoveryWanted && !manualVoiceStop) {
          log(`[Voice] Stream reset received for "${effectiveRoom}"; keeping unlimited recovery alive.`);
          streamJoinInProgress = true;
          acceptedInviteTokens.clear();
          lastAcceptedInviteSession = "";
          publishFallbackSent = false;
          if (streamRetryTimer) clearTimeout(streamRetryTimer);
          streamRetryTimer = null;
          scheduleVoiceRecovery(effectiveRoom, 'server stream reset');
          return;
        }
        streamJoinInProgress = false;
        voiceRecoveryWanted = false;
        stopVoiceRecovery();
        acceptedInviteTokens.clear();
        lastAcceptedInviteSession = "";
        publishFallbackSent = false;
        if (streamRetryTimer) clearTimeout(streamRetryTimer);
        streamRetryTimer = null;
        stopVoiceHeartbeat();
        if (voiceManager.isConnected) await voiceManager.disconnect();
      }
    }
  }

  socket.onEvent("streamEvent", handleStreamEvent);
  // Some ChatP builds deliver stream lifecycle messages as top-level ResultMessage
  // events instead of nesting them under streamEvent. Consume both forms.
  for (const streamType of ["stream_enabled", "stream_exists", "publish_stream", "stop_stream", "stop_streaming_service", "revoked"]) {
    socket.onEvent(streamType, payload => {
      const event = { ...(payload || {}), type: streamType };
      void handleStreamEvent(event);
    });
  }
  // APK source confirms that the global Voice/Active UI is refreshed by the
  // ChatP application event `active_rooms_update`. It is distinct from the
  // local RoomEvent.isStreaming flag. Keep a listener so a bot can observe the
  // same server-side directory invalidation instead of assuming LiveKit publish
  // alone makes the room visible.
  socket.onEvent("active_rooms_update", payload => {
    debug(`[Voice Directory] APK active_rooms_update received`, payload || {});
    const active=String(client.currentRoom||defaultRoom||'').trim();
    if(active && voiceManager.isConnected) { try { client.streamCheck(active); } catch {} }
  });
  // Room-list responses contain RoomItem.isStreaming. Track the authoritative
  // directory bit too; this is the same bit used by the app's Voice/Active list.
  socket.onEvent("result", payload => {
    try {
      const active = String(client.currentRoom || defaultRoom || "").trim();
      if (!active || !Array.isArray(payload?.rooms)) return;
      const row = payload.rooms.find(r => String(r?.name || "").trim() === active);
      if (!row) return;
      if (row.isStreaming === true || Number(row.isStreaming) === 1) {
        lastVoiceRoom = active;
        lastKnownStreaming = true;
        debug(`[Voice Directory] Room list confirms Voice/Active visibility for "${active}".`);
      }
    } catch {}
  });

  function requestVoiceJoin(room, forceInvite = false) {
    const targetRoom = String(room || client.currentRoom || defaultRoom || '').trim();
    if (!targetRoom) return false;
    if (requireOwnerForPlayback && !getBotOwnerState()) { debug(`[Voice] Publisher blocked: bot is not OWNER in "${targetRoom}".`); return false; }
    if (voiceManager.isConnected || voiceManager.isConnecting) return false;
    if (sleepTriggered || manualVoiceStop) return false;

    const now = Date.now();
    // A single publisher invitation owns the complete server handshake. The
    // ChatP server can emit several join_stream notifications for that same
    // session; none of them justify another self-invite. In particular, force
    // recovery must NOT bypass this lock.
    if (selfInviteInFlight) {
      debug(`[Voice] Publisher invitation already in flight for "${targetRoom}"; suppressing duplicate request.`);
      return false;
    }
    if (streamJoinInProgress && now - lastJoinRequestAt < VOICE_INVITE_TIMEOUT_MS) {
      debug(`[Voice] Join already in progress for "${targetRoom}"; duplicate request suppressed.`);
      return false;
    }
    if (!forceInvite && now - lastInviteAt < SELF_INVITE_COOLDOWN_MS) return false;

    manualVoiceStop = false;
    voiceRecoveryWanted = true;
    lastVoiceRoom = targetRoom;
    streamJoinInProgress = true;
    selfInviteInFlight = true;
    const inviteGeneration = ++selfInviteGeneration;
    lastJoinRequestAt = now;
    lastInviteAt = now;

    // Do not race room_join. This is especially important on startup where the
    // server can advertise a streaming room before it acknowledges our own join.
    if (client.currentRoom === targetRoom) {
      // Already inside the target text room. The Android publisher path does
      // not re-join the text room before publishing, and rejoining here can
      // generate user_left/you_joined plus a stream reset on some servers.
    } else if (socket.connected) {
      pendingPublisherRoom = targetRoom;
      if (pendingPublisherTimer) clearTimeout(pendingPublisherTimer);
      try { client.roomJoin(targetRoom); } catch (err) { debug(`[Voice] room_join before publisher failed: ${err.message}`); }
      pendingPublisherTimer = setTimeout(() => {
        pendingPublisherTimer = null;
        if (pendingPublisherRoom === targetRoom && !manualVoiceStop && socket.connected && !voiceManager.isConnected) {
          log(`[Voice] No room_join acknowledgement yet; continuing publisher handshake for "${targetRoom}" after startup grace period.`);
          pendingPublisherRoom = "";
          requestVoiceJoin(targetRoom, true);
        }
      }, 1500);
      pendingPublisherTimer.unref?.();
      // Keep the single-flight lock while waiting; the recursive call is
      // suppressed by streamJoinInProgress, so release only after the grace.
      selfInviteInFlight = false;
      streamJoinInProgress = false;
      return true;
    }
    pendingPublisherRoom = "";
    if (pendingPublisherTimer) { clearTimeout(pendingPublisherTimer); pendingPublisherTimer = null; }
    log(`[Voice] Starting APK-compatible publisher flow for "${targetRoom}".`);
    try { client.streamCheck(targetRoom); } catch (err) { debug("[Voice] streamCheck failed:", err.message); }

    // IMPORTANT: the supplied Android APK does NOT self-invite itself when the
    // current user starts the room stream. RoomActivity.z() sends the direct
    // publisher operation:
    //   action=room_stream, type=publish, to=<stream password>, room=<room>
    // and then waits for the server's publish_stream credentials. The previous
    // Node implementation incorrectly used room_stream/invite(to=self), which
    // puts the bot through the subscriber/invitation path and produces repeated
    // join_stream events. That path can leave LiveKit healthy while ChatP never
    // promotes the room to the Voice/Active directory.
    const streamPassword = String(process.env.STREAM_PASSWORD || '').trim();
    log(`[Voice] Sending direct APK publisher request: room_stream/publish room="${targetRoom}".`);
    try { client.streamPublish(targetRoom, streamPassword); }
    catch (err) {
      selfInviteInFlight = false;
      streamJoinInProgress = false;
      log(`[Voice] Direct publisher request failed: ${err.message}`);
      return false;
    }

    // Some ChatP deployments require the owner to bootstrap a publisher
    // session through the same self-invitation handshake used by the APK.
    // Direct publish is attempted first; if no publish_stream arrives, do ONE
    // self-invite. Never revoke/stop the server stream during this fallback.
    if (selfInviteTimer) clearTimeout(selfInviteTimer);
    selfInviteTimer = setTimeout(() => {
      selfInviteTimer = null;
      if (inviteGeneration !== selfInviteGeneration || !selfInviteInFlight) return;
      if (voiceManager.isConnected || voiceManager.isConnecting) return;
      if (manualVoiceStop || client.currentRoom !== targetRoom) {
        selfInviteInFlight = false;
        streamJoinInProgress = false;
        return;
      }

      if (process.env.AUTO_UPGRADE_STREAMING === 'true' && !autoUpgradeStreamingAttempted && socket.connected && client.currentRoom === targetRoom) {
        autoUpgradeStreamingAttempted = true;
        const duration = String(process.env.STREAM_UPGRADE_DURATION || '30');
        if (['1','7','30'].includes(duration)) {
          log(`[Voice] Direct publisher returned no credentials; AUTO_UPGRADE_STREAMING is enabled. Requesting ChatP upgrade_streaming(${duration}) once.`);
          try { client.upgradeStreaming(targetRoom, duration); } catch (err) { debug(`[Voice] upgrade_streaming failed: ${err.message}`); }
          setTimeout(() => {
            if (socket.connected && !manualVoiceStop && !voiceManager.isConnected && client.currentRoom === targetRoom) {
              streamJoinInProgress = true;
              selfInviteInFlight = true;
              lastJoinRequestAt = Date.now();
              try { client.streamPublish(targetRoom, String(process.env.STREAM_PASSWORD || '').trim()); } catch (err) { debug(`[Voice] publish after upgrade failed: ${err.message}`); }
            }
          }, 1200).unref?.();
          return;
        }
      }
      // Practical compatibility fallback: the APK/server combination can
      // bootstrap the owner's publisher by inviting the same account and then
      // returning you_invited/publish_stream. Do it only once per generation.
      if (!publishFallbackSent && socket.connected) {
        publishFallbackSent = true;
        const ownUsername = String(config.username || auth.username || '').trim();
        if (ownUsername) {
          log(`[Voice] Direct publish produced no credentials; bootstrapping one owner invitation for "${targetRoom}".`);
          try {
            client.streamInvite(targetRoom, ownUsername);
            if (selfInviteTimer) clearTimeout(selfInviteTimer);
            selfInviteTimer = setTimeout(() => {
              selfInviteTimer = null;
              if (inviteGeneration !== selfInviteGeneration || !selfInviteInFlight) return;
              if (voiceManager.isConnected || voiceManager.isConnecting || manualVoiceStop || client.currentRoom !== targetRoom) return;
              selfInviteInFlight = false;
              streamJoinInProgress = false;
              log(`[Voice] Owner invitation produced no publisher credentials for "${targetRoom}"; starting controlled recovery.`);
              scheduleVoiceRecovery(targetRoom, 'owner invitation timeout');
            }, SELF_INVITE_FALLBACK_WAIT_MS);
            selfInviteTimer.unref?.();
            return;
          } catch (err) {
            log(`[Voice] Owner invitation fallback failed: ${err.message}`);
          }
        }
      }

      selfInviteInFlight = false;
      streamJoinInProgress = false;
      log(`[Voice] Direct publisher request timed out for "${targetRoom}"; starting controlled recovery.`);
      scheduleVoiceRecovery(targetRoom, 'direct publisher timeout');
    }, SELF_INVITE_HARD_TIMEOUT_MS);
    selfInviteTimer.unref?.();
    return true;
  }

  // Active state for search, voteskip, DJ mode, welcome, sleep timer, and rate limiting
  const pendingSearches = new Map();
  const voteSkips = new Set();
  let voteSkipPlayId = 0;
  const savedProState = getProState();
  let djModeEnabled = savedProState.djMode === true;
  const djUsers = new Set((savedProState.djUsers || []).map(String).map(v => v.toLowerCase()).filter(Boolean));
  // Restore all user-facing runtime settings before the first voice connection.
  // A reconnect must never recreate these values from hard-coded defaults.
  // Persistent defaults: welcome, 24/7 and auto-resume are ON for a fresh build.
  let welcomeEnabled = loadSettings().welcomeEnabled !== false;
  // Persistent defaults: 24/7 and auto-resume are ON for a fresh build.
  // User changes via .247/.autoresume are saved and restored on restart.
  const savedSettings = loadSettings();
  let alwaysOn = savedSettings.alwaysOn !== false;
  let autoResume = savedSettings.autoResume !== false;
  const savedPlayer = savedSettings.player || {};
  youtubePlayer.setQueueLimit(savedPlayer.queueLimit || getQueueLimit());
  youtubePlayer.setAudioQuality(savedPlayer.audioQuality || "highest");
  youtubePlayer.setAutoplay(Boolean(savedPlayer.autoplay));
  youtubePlayer.setAutoDjMode(savedSettings.radio?.seedMode || "hybrid");
  if (savedSettings.radio?.enabled && savedSettings.radio?.seed?.url) youtubePlayer.setRadio(savedSettings.radio.seed, savedSettings.radio.seedMode || "hybrid");
  try { youtubePlayer.setLoop(savedPlayer.loopMode || "off"); } catch {}
  youtubePlayer.setShuffle(Boolean(savedPlayer.shuffleEnabled));
  const savedVoice = savedSettings.voice || {};
  if (Number.isFinite(Number(savedVoice.volume))) voiceManager.setVolume(Number(savedVoice.volume));
  if (savedVoice.filters) voiceManager.setFilters(savedVoice.filters);
  const savedAutomation = savedSettings.automation || {};
  const savedRadio = savedSettings.radio || {};
  const userCooldowns = new Map();
  let sleepTimer = null;
  let sleepTriggered = false;
  const wakeFromSleep = () => {
    const wasSleeping = sleepTriggered || Boolean(sleepTimer);
    if (sleepTimer) { clearTimeout(sleepTimer); sleepTimer = null; }
    if (!wasSleeping) return false;
    sleepTriggered = false;
    manualVoiceStop = false;
    voiceRecoveryWanted = true;
    return true;
  };
  let idleTimer = null;
  youtubePlayer.setQueueLimit(getQueueLimit());
  let persistenceTimer = null;
  const persistRuntimeState = (reason = "state-change", roomOverride = null) => {
    const room = String(roomOverride || getActiveRoom() || client.currentRoom || defaultRoom || "").trim();
    if (!room) return;
    try {
      saveSettings({
        alwaysOn, autoResume, welcomeEnabled,
        defaultRoom: room,
        player: {
          autoplay: Boolean(youtubePlayer.autoplay), audioQuality: youtubePlayer.getAudioQuality(),
          loopMode: youtubePlayer.loopMode, shuffleEnabled: Boolean(youtubePlayer.shuffleEnabled),
          queueLimit: youtubePlayer.queueLimit
        },
        voice: { volume: Number(voiceManager.volume ?? 1), filters: voiceManager.getFilters() },
        automation: { ...savedAutomation, autoDj: Boolean(youtubePlayer.autoplay) },
        radio: { ...savedRadio, enabled: Boolean(youtubePlayer.radioEnabled), seedMode: youtubePlayer.radioMode || youtubePlayer.autoDjMode, seed: youtubePlayer.radioSeed ? { ...youtubePlayer.radioSeed } : savedRadio.seed || null }
      }, room);
      setRoomQueue(room, youtubePlayer.getQueue());
      if (youtubePlayer.currentTrack) {
        setRoomPlayback(room, { room, track: { ...youtubePlayer.currentTrack }, queue: youtubePlayer.getQueue(), offset: youtubePlayer.getElapsedSeconds(), savedAt: Date.now() });
      } else if (!youtubePlayer.isPlaying && youtubePlayer.queue.length === 0) {
        clearRoomPlayback(room);
      }
      debug(`[Persistence] saved room state (${room}; ${reason})`);
    } catch (err) { debug(`[Persistence] room save failed: ${err?.message || err}`); }
  };

  const restoreRoomRuntime = (room) => {
    const target = String(room || "").trim();
    if (!target) return;
    setActiveRoom(target);
    const settings = loadSettings(target);
    const player = settings.player || {};
    const voice = settings.voice || {};
    const radio = settings.radio || {};
    youtubePlayer.stop();
    youtubePlayer.queue = getRoomQueue(target).slice(0, Math.max(1, Number(player.queueLimit || 100)));
    youtubePlayer.setQueueLimit(player.queueLimit || getQueueLimit());
    youtubePlayer.setAudioQuality(player.audioQuality || "highest");
    youtubePlayer.setAutoplay(Boolean(player.autoplay));
    youtubePlayer.setAutoDjMode(radio.seedMode || "hybrid");
    if (radio.enabled && radio.seed?.url) youtubePlayer.setRadio(radio.seed, radio.seedMode || "hybrid");
    else youtubePlayer.stopRadio();
    try { youtubePlayer.setLoop(player.loopMode || "off"); } catch {}
    youtubePlayer.setShuffle(Boolean(player.shuffleEnabled));
    if (Number.isFinite(Number(voice.volume))) voiceManager.setVolume(Number(voice.volume));
    if (voice.filters) voiceManager.setFilters(voice.filters);
    const snapshot = getRoomPlayback(target);
    if (snapshot?.track?.url) {
      const queue = Array.isArray(snapshot.queue) ? snapshot.queue : youtubePlayer.queue;
      youtubePlayer.queue = queue.slice(0, youtubePlayer.queueLimit).map(t => ({ ...t }));
    }
    log(`[RoomDB] Loaded room profile: ${target} | queue=${youtubePlayer.queue.length} | AutoDJ=${youtubePlayer.autoplay ? "ON" : "OFF"}`);
    return settings;
  };

  const scheduleRuntimePersist = (reason) => {
    if (persistenceTimer) clearTimeout(persistenceTimer);
    persistenceTimer = setTimeout(() => { persistenceTimer = null; persistRuntimeState(reason); }, 150);
    persistenceTimer.unref?.();
  };
  youtubePlayer.on("autoplayChanged", () => scheduleRuntimePersist("autoplay"));
  youtubePlayer.on("loopChanged", () => scheduleRuntimePersist("loop"));
  youtubePlayer.on("shuffleChanged", () => scheduleRuntimePersist("shuffle"));
  youtubePlayer.on("filtersChanged", () => scheduleRuntimePersist("filters"));
  voiceManager.on("volumeChanged", () => scheduleRuntimePersist("volume"));
  const scheduleTimers = new Map();
  const snapshotTimer = setInterval(() => {
    try {
      if (youtubePlayer.currentTrack) {
        const room = client.currentRoom || defaultRoom || "";
        const snapshot = { room, track: youtubePlayer.currentTrack, queue: youtubePlayer.getQueue(), offset: youtubePlayer.getElapsedSeconds(), savedAt: Date.now() };
        savePlaybackSnapshot(snapshot);
        if (room) setRoomPlayback(room, snapshot);
        if (room) setRoomQueue(room, youtubePlayer.getQueue());
      }
    } catch (err) { debug("[Snapshot] save failed:", err?.message || err); }
  }, 10000);
  process.once("exit", () => clearInterval(snapshotTimer));
  process.once('exit',()=>{ try{stopMaintenance();}catch{} });

  function resetIdleWatcher() {
    if (idleTimer) clearTimeout(idleTimer);
    // If stopped or empty for 5 minutes, leave voice to preserve bandwidth
    idleTimer = setTimeout(async () => {
      if (!alwaysOn && voiceManager.isConnected && !youtubePlayer.isPlaying && youtubePlayer.queue.length === 0) {
        log("[Idle] No music playing for 5 mins; leaving voice lobby to save bandwidth.");
        await voiceManager.disconnect();
      }
    }, 300000);
  }

  function isDjOrAdmin(user) {
    if (isRoomController(user)) {
      if (!djModeEnabled) return true;
      const name = String(user?.username || "").toLowerCase();
      const uid = String(user?.userId || "");
      const role = String(user?.role || "").toLowerCase();
      const ownName = String(config.username || auth.username || "").toLowerCase();
      const ownUid = String(auth.userId || socket.auth?.userId || "");
      if (role === "owner" || role === "admin") return true;
      if (name === ownName || (uid && ownUid && uid === ownUid)) return true;
      if (djUsers.has(name) || djUsers.has(uid)) return true;
      // A room master is a controller even when DJ mode is enabled.
      return isRoomMaster(String(user?.room || client.currentRoom || workerRoom || defaultRoom || ""), name, uid);
    }
    return false;
  }

  function isRoomController(user) {
    const room = String(user?.room || client.currentRoom || workerRoom || defaultRoom || "").trim();
    const name = String(user?.username || user?.from || "").trim();
    const uid = String(user?.userId || "").trim();
    const role = String(user?.role || "").trim().toLowerCase();
    if (role === "owner" || role === "admin") return true;
    if (!masterOnly) return true;
    return isRoomMaster(room, name, uid);
  }

  function requireBotOwner(room, reply = true) {
    if (!requireOwnerForPlayback || getBotOwnerState()) return true;
    if (reply) void roomReply(room, "⛔ I cannot stream or play music in this room until my account has the OWNER role. Ask the room owner to promote the bot to Owner.");
    return false;
  }

  function findBotInUsers(users, authInfo = auth) {
    if (!Array.isArray(users)) return null;
    const names = botNames(authInfo);
    const ownId = String(authInfo?.userId || '').trim();
    return users.find(u => {
      const name = String(u?.username || '').trim().toLowerCase();
      const uid = String(u?.userId || '').trim();
      return (name && names.has(name)) || (ownId && uid && uid === ownId);
    }) || null;
  }

  let ownerVoiceAction = Promise.resolve();
  async function applyAuthoritativeBotRole(room, role, source = 'unknown', notify = false) {
    const eventRoom = String(room || client.currentRoom || defaultRoom || '').trim();
    if (!eventRoom) return false;
    const nextRole = String(role || '').trim().toLowerCase();
    const previousRole = String(botRole || '').trim().toLowerCase();
    const wasOwner = getBotOwnerState();
    const roleChanged = previousRole !== nextRole;
    if (roleChanged) setBotRole(nextRole, eventRoom);
    // occupants_list is polled as a safety net. Do not spam the log or rerun
    // the owner bootstrap every poll when the authoritative role is unchanged.
    if (roleChanged || source === 'you_joined.users') {
      log(`[Security] Authoritative bot role for "${eventRoom}" = "${nextRole || 'unknown'}" (${source}); owner=${nextRole === 'owner'}.`);
    }

    if (requireOwnerForPlayback && nextRole !== 'owner') {
      // Save the exact position before a forced demotion stop so OWNER
      // promotion/restart can resume the room instead of losing the track.
      try {
        if (youtubePlayer.currentTrack?.url) {
          const snapshot = { room: eventRoom, track: { ...youtubePlayer.currentTrack }, queue: youtubePlayer.getQueue(), offset: youtubePlayer.getElapsedSeconds(), savedAt: Date.now(), reason: `owner-lost:${source}` };
          savePlaybackSnapshot(snapshot);
          setRoomPlayback(eventRoom, snapshot);
          setRoomQueue(eventRoom, youtubePlayer.getQueue());
          flushPro();
        }
      } catch (err) { debug(`[Security] Demotion snapshot failed: ${err?.message || err}`); }
      manualVoiceStop = false;
      voiceRecoveryWanted = false;
      try { youtubePlayer.stop(); } catch (err) { debug(`[Security] Player stop failed: ${err?.message || err}`); }
      try {
        if (voiceManager.isConnected || voiceManager.isConnecting) await voiceManager.disconnect();
      } catch (err) { debug(`[Security] Voice disconnect after demotion failed: ${err?.message || err}`); }
      resetVoiceJoinState();
      clearStreamDirectoryTimers();
      lastKnownStreaming = false;
      if (wasOwner || notify) void roomReply(eventRoom, `⛔ Bot is not OWNER in this room (role: ${nextRole || 'unknown'}). Streaming and playback are stopped until the bot is promoted to OWNER.`);
      return false;
    }

    if (nextRole === 'owner') {
      voiceRecoveryWanted = true;
      if (autoPublishOnOwner && !manualVoiceStop && !voiceManager.isConnected && !voiceManager.isConnecting && socket.connected && client.currentRoom === eventRoom && (!wasOwner || roleChanged)) {
        // Serialize owner-triggered publisher starts. Room role events and
        // occupants replies can arrive together and must not send two publish
        // handshakes.
        ownerVoiceAction = ownerVoiceAction.then(async () => {
          await new Promise(resolve => setTimeout(resolve, 350));
          if (!socket.connected || manualVoiceStop || client.currentRoom !== eventRoom || !getBotOwnerState() || voiceManager.isConnected || voiceManager.isConnecting) return;
          log(`[Security] Bot is OWNER in "${eventRoom}"; automatically starting publisher.`);
          requestVoiceJoin(eventRoom, true);
        }).catch(err => debug(`[Security] Owner voice bootstrap failed: ${err?.message || err}`));
      }
      return true;
    }
    return false;
  }

  function inspectAuthoritativeOccupants(room, users, source = 'occupants') {
    const bot = findBotInUsers(users);
    if (!bot) return false;
    const role = String(bot.role || '').trim().toLowerCase();
    if (!role) return false;
    void applyAuthoritativeBotRole(room, role, source, true);
    return true;
  }

  function isDjAdminOnly(user) {
    const name = String(user?.username || '').toLowerCase();
    const uid = String(user?.userId || '');
    const role = String(user?.role || '').toLowerCase();
    const ownName = String(config.username || auth.username || '').toLowerCase();
    const ownUid = String(auth.userId || socket.auth?.userId || '');
    return role === 'owner' || role === 'admin' ||
      (name && name === ownName) || (uid && ownUid && uid === ownUid);
  }

  function requirePlaybackControl(user, message = '🔒 DJ Mode active.') {
    if (isDjOrAdmin(user)) return true;
    void roomReply(user?.room, message);
    return false;
  }

  function searchKey(room, user) {
    return `${String(room || '')}\u0000${String(user?.userId || user?.username || 'anonymous').toLowerCase()}`;
  }

  function participantCount(payload) {
    const candidates = [payload?.usersCount, payload?.memberCount, payload?.roomUsersCount, payload?.room?.usersCount];
    for (const value of candidates) {
      const n = Number(value);
      if (Number.isFinite(n) && n >= 1) return Math.floor(n);
    }
    if (Array.isArray(payload?.users)) return Math.max(1, payload.users.length);
    // Conservative fallback: known voters plus the bot. This avoids requiring
    // an impossible fixed room size when the protocol does not include roster
    // information in the command event.
    return Math.max(1, voteSkips.size + 1);
  }

  function checkRateLimit(userId) {
    if (!userId) return true;
    const now = Date.now();
    const last = userCooldowns.get(userId) || 0;
    if (now - last < 1200) return false;
    userCooldowns.set(userId, now);
    return true;
  }

  async function runScheduled(item) {
    try {
      if (!item?.query || !item.room) return;
      const track = await youtubePlayer.resolveTrack(item.query, "Scheduler");
      if (youtubePlayer.queue.length >= getQueueLimit()) throw new Error(`Queue limit reached (${getQueueLimit()})`);
      if (!youtubePlayer.addTrackObject(track)) throw new Error(`Queue limit reached (${getQueueLimit()})`);
      if (!youtubePlayer.isPlaying) await youtubePlayer.playNext();
    } catch (err) { log(`[Scheduler] ${err?.message || err}`); }
    removeSchedule(item.id); scheduleTimers.delete(item.id);
  }
  function armSchedule(item) {
    if (!item?.id) return;
    if (scheduleTimers.has(item.id)) clearTimeout(scheduleTimers.get(item.id));
    const delay = Math.max(0, Number(item.at) - Date.now());
    if (delay <= 0) { void runScheduled(item); return; }
    const timer = setTimeout(() => void runScheduled(item), delay);
    scheduleTimers.set(item.id, timer);
  }
  for (const item of listSchedules()) armSchedule(item);

  // ChatP/Android exposes room chat as RoomMessage/room_message at the event
  // layer, while the protobuf packet is nested in ResultMessage.roomEvent.
  // Keep a dedicated listener so room commands work even when the server/client
  // wrapper does not emit the generic roomEvent alias.
  socket.onEvent("roomMessage", event => {
    if (!event) return;
    void handleRoomCommandEvent(event).catch(err => log(`[Room Message] ${err?.message || err}`));
  });

  // occupants_list is the authoritative source for the bot's current room
  // role. The supplied APK displays the role from the room participant list,
  // and some servers report `you_joined.role=member` even when that same user
  // is already OWNER. Always reconcile from the actual roster.
  socket.onEvent("result", payload => {
    try {
      // APK fact: `room_admin/occupants_list` is not guaranteed to come back
      // as ResultMessage.roomAdmin. The APK ResultMessage also has a top-level
      // repeated `users` field (field 11), and some ChatP builds put the roster
      // there. Always inspect BOTH representations.
      const fallbackRoom = String(client.currentRoom || defaultRoom || '').trim();
      const admin = payload?.roomAdmin;
      if (admin && !Array.isArray(admin)) {
        const room = String(admin.room || fallbackRoom).trim();
        const users = [
          ...(Array.isArray(admin.occupants) ? admin.occupants : []),
          ...(Array.isArray(admin.users) ? admin.users : [])
        ];
        if (room && users.length) inspectAuthoritativeOccupants(room, users, 'roomAdmin.occupants/users');
      }

      if (Array.isArray(payload?.users) && payload.users.length) {
        const room = fallbackRoom;
        if (room) inspectAuthoritativeOccupants(room, payload.users, 'ResultMessage.users(field=11)');
      }
    } catch (err) { debug(`[Security] roster role reconciliation failed: ${err?.message || err}`); }
  });

  socket.onEvent("roomEvent", async event => {
    if (!event) return;
    const type = event.type || "";
    if (String(type).toLowerCase() === "text" && event.body != null) {
      // Normalized roomMessage listener handles actual room chat commands.
      // Continue here only for non-chat room state/events.
      await handleRoomCommandEvent(event);
      return;
    }
    const eventRoom = String(event.room || client.currentRoom || defaultRoom || '').trim();
    if ((type === "you_joined" || type === "you_rejoined") && eventRoom) {
      if (eventRoom === String(client.currentRoom || defaultRoom || '').trim()) {
        // `you_joined.role` is not authoritative on every ChatP deployment.
        // Prefer the nested participant list when present, then immediately
        // request the server's occupants_list. This fixes the exact case where
        // the UI shows the bot as OWNER but the join event says `member`.
        const nestedBot = findBotInUsers(event.users);
        if (nestedBot?.role) {
          void applyAuthoritativeBotRole(eventRoom, nestedBot.role, 'you_joined.users', true);
        } else {
          setBotRole(event.role || "", eventRoom);
        }
        try { client.occupants(eventRoom); } catch (err) { debug(`[Security] occupants query after join failed: ${err?.message || err}`); }

        textRoomJoinedAt = Date.now();
        if (pendingPublisherRoom === eventRoom && pendingPublisherTimer) {
          clearTimeout(pendingPublisherTimer);
          pendingPublisherTimer = null;
          pendingPublisherRoom = "";
          // The publisher request is intentionally sent on the next turn so the
          // server can finish installing the room membership state first.
          if ((!requireOwnerForPlayback || getBotOwnerState()) && !manualVoiceStop && !voiceManager.isConnected && !voiceManager.isConnecting) {
            setTimeout(() => {
              if ((!requireOwnerForPlayback || getBotOwnerState()) && !manualVoiceStop && socket.connected && client.currentRoom === eventRoom && !voiceManager.isConnected && !voiceManager.isConnecting) {
                requestVoiceJoin(eventRoom, true);
              }
            }, 100).unref?.();
          }
        }
      }
      const streaming = Number(event.isStreaming) === 1 || event.isStreaming === true || String(event.isStreaming).toLowerCase() === 'true';
      if (streaming) {
        lastKnownStreaming = true;
        log(`[Voice Directory] Server advertised "${eventRoom}" as STREAMING (isStreaming=1).`);
      } else {
        // Do not clear a known active publisher from a stale/non-streaming
        // membership event; a subsequent stream event may be in flight.
        debug(`[Voice Directory] Room join event for "${eventRoom}" has isStreaming=${String(event.isStreaming ?? 0)}.`);
      }
    }
    if (type === "your_role_changed" || type === "role_changed") {
      const botNamesSet = botNames(auth);
      const targetName = String(event.tUsername || event.to || event.username || event.from || '').trim().toLowerCase();
      const targetId = String(event.toId || event.userId || event.to_id || '').trim();
      const isBotTarget = type === "your_role_changed" || botNamesSet.has(targetName) || (targetId && targetId === String(auth.userId || '').trim());
      if (isBotTarget) {
        const role = String(event.newRole || event.role || '').trim().toLowerCase();
        log(`[Main] Bot role event in "${eventRoom}": ${event.oldRole || '?'} -> ${role || 'unknown'} (target=${event.tUsername || event.username || targetName || '?'})`);
        await applyAuthoritativeBotRole(eventRoom, role, `${type}`, true);
        // Ask for the complete roster as a second authoritative check. This
        // catches servers that emit a role_changed packet before the database
        // membership update becomes visible.
        try { client.occupants(eventRoom); } catch (err) { debug(`[Security] occupants query after role change failed: ${err?.message || err}`); }
      }
    } else if (type === "user_joined" && welcomeEnabled) {
      if (!isOwnRoomEvent(event)) {
        const u = event.from || event.username || "Friend";
        const r = event.room || client.currentRoom;
        if (r) {
          void roomReply(r, `👋 Welcome @${u} to ${r}! Type .help for commands.`);
        }
      }
    }
    await handleRoomCommandEvent(event);
  });

  // Fallback role reconciliation. Room events are primary, but a few ChatP
  // deployments do not broadcast role_changed to every websocket. Polling the
  // participant roster every 12s is cheap and guarantees a demotion cannot leave
  // a publisher running indefinitely.
  const ownerStatePoller = setInterval(() => {
    const room = String(client.currentRoom || workerRoom || defaultRoom || '').trim();
    if (!room || !socket.connected) return;
    try { client.occupants(room); } catch (err) { debug(`[Security] periodic occupants query failed: ${err?.message || err}`); }
  }, 12000);
  ownerStatePoller.unref?.();
  process.once('exit', () => clearInterval(ownerStatePoller));

  // Room commands are independent asynchronous jobs. The old global Promise
  // chain serialized every command behind long-running operations such as
  // yt-dlp downloads, Smart Radio discovery, cache creation, and LiveKit
  // recovery. That made the bot appear frozen with messages like "waiting for
  // last operations" even though Node's event loop itself was healthy. Keep
  // command delivery concurrent; playback state mutations are single-flight
  // inside YouTubePlayer and voice recovery has its own guards.
  const enqueueRoomCommand = (event) => {
    void handleRoomCommand(event).catch(err => log(`[Room Command] ${err.message}`));
  };

  function isOwnRoomEvent(event) {
    const uid = String(event.userId || "");
    const from = String(event.from || event.username || "").trim().toLowerCase();
    const ownUid = String(auth.userId || socket.auth?.userId || "");
    const ownName = String(config.username || auth.username || "").trim().toLowerCase();
    return (uid && ownUid && uid === ownUid) || (from && ownName && from === ownName);
  }

  const commandDedup = new Map();
  const COMMAND_DEDUP_MS = 3500;

  async function handleRoomCommandEvent(event) {
    if (!event) return;
    // APK/server builds have surfaced room text with `type=text`,
    // `type=room_message`, and occasionally an empty type with a populated
    // body. The body is authoritative for command delivery.
    const eventType = String(event.type || "").trim().toLowerCase();
    if (!(["text", "room_message", "message"].includes(eventType) || event.body != null)) return;
    if (isOwnRoomEvent(event)) return;
    const room = String(event.room || client.currentRoom || "").trim();
    const text = String(event.body || "").trim();
    if (!room || !/^\s*\./.test(text)) return;
    const username = String(event.from || event.username || "User").trim();
    const userId = String(event.userId || "").trim();
    // ChatP can surface the same room command through more than one event path.
    // Deduplicate identical command deliveries so `.help` (and every other
    // command) produces exactly one response.
    // Prefer semantic delivery identity over server packet ids. Some ChatP
    // builds assign a fresh id/uid when the same room message is surfaced
    // through multiple event paths, which otherwise causes duplicate bot replies.
    const fingerprint = `${room}|${userId || username.toLowerCase()}|${text.toLowerCase()}`;
    const now = Date.now();
    const seenAt = commandDedup.get(fingerprint);
    if (seenAt && now - seenAt < COMMAND_DEDUP_MS) return;
    commandDedup.set(fingerprint, now);
    if (commandDedup.size > 500) {
      for (const [key, ts] of commandDedup) {
        if (now - ts >= COMMAND_DEDUP_MS) commandDedup.delete(key);
      }
    }
    const normalized = text.trim();
    recordUserCommand(username);
    enqueueRoomCommand({ room, text: normalized, username, userId, role: event.role || "" });
  }

  // ChatP room messages have a practical size limit. Never silently truncate
  // a command menu, title, URL, or search result: split long replies into
  // separate room messages instead.
  async function roomReplyLong(room, linesOrText, maxLen = 340) {
    const rawLines = Array.isArray(linesOrText)
      ? linesOrText.map(String)
      : String(linesOrText || "").split("\n");
    const chunks = [];
    let current = "";

    const pushCurrent = () => {
      if (current) {
        chunks.push(current);
        current = "";
      }
    };

    for (const rawLine of rawLines) {
      const line = String(rawLine);
      if (!line) {
        if (current) current += "\n";
        continue;
      }

      // Preserve every character. If one line is larger than the room limit,
      // split that line itself rather than replacing it with "...".
      let remaining = line;
      while (remaining.length > maxLen) {
        if (current) pushCurrent();
        chunks.push(remaining.slice(0, maxLen));
        remaining = remaining.slice(maxLen);
      }

      const candidate = current ? `${current}\n${remaining}` : remaining;
      if (candidate.length > maxLen) {
        pushCurrent();
        current = remaining;
      } else {
        current = candidate;
      }
    }
    pushCurrent();

    for (const chunk of chunks) {
      await roomReply(room, chunk, { chunked: true });
      // Tiny delay prevents multiple help/search packets from being merged or
      // rate-limited by the room server/client.
      await new Promise(resolve => setTimeout(resolve, 120));
    }
  }

  const replyDedup = new Map();
  const REPLY_DEDUP_MS = 1600;

  async function roomReply(room, text, options = {}) {
    try {
      const clean = String(text || "").trim();
      if (!clean) return;
      if (!options.chunked && clean.length > 340) {
        return roomReplyLong(room, clean, 340);
      }
      // Prevent duplicate server/event paths from posting the exact same room
      // reply repeatedly. This is intentionally short so two deliberate
      // identical commands remain possible after the debounce window.
      if (!options.chunked) {
        const key = `${room}|${clean}`;
        const now = Date.now();
        const last = replyDedup.get(key);
        if (last && now - last < REPLY_DEDUP_MS) return;
        replyDedup.set(key, now);
        if (replyDedup.size > 1000) {
          for (const [k, ts] of replyDedup) if (now - ts >= REPLY_DEDUP_MS) replyDedup.delete(k);
        }
      }
      client.sendRoomText(room, clean);
      log(`[Room Reply] ${room}: ${clean.replace(/\n/g, " | ")}`);
    } catch (err) {
      log(`[Room Reply Error] ${err.message}`);
    }
  }

  youtubePlayer.on("trackStart", track => {
    incrementStat("tracksPlayed");
    setStat("lastTrack", track?.title || "");
    setStat("lastRoom", client.currentRoom || defaultRoom || "");
    try { resetIdleWatcher(); } catch (err) { debug("[Idle Watcher] reset failed:", err?.message || err); }
    const room = client.currentRoom || defaultRoom;
    if (!room || !track) return;
    voteSkips.clear();
    voteSkipPlayId = youtubePlayer.playId;
    recordUserTrack(track?.requestedBy || "User", track);
    const qCount = youtubePlayer.queue.length;
    const loop = (youtubePlayer.loopMode || "off").toUpperCase();
    const auto = youtubePlayer.autoplay ? "ON" : "OFF";
    const filter = voiceManager.getFilterSummary();
    const lines = [
      "🎵 NOW PLAYING",
      `🎶 ${track.title}`,
      `⏱️ ${track.duration || "Unknown"} | 👤 ${track.requestedBy || "User"}`,
      `📋 Queue: ${qCount} | 🔁 Loop: ${loop} | 📻 Auto: ${auto}`,
      ...(filter !== "None (Clean)" ? [`🎛️ FX: ${filter}`] : [])
    ];
    void roomReply(room, lines.join("\n"));
    // Keep AutoDJ/Radio ahead of the currently playing song. Discovery runs in
    // the background so the first track is never blocked by yt-dlp searches.
    if (youtubePlayer.autoplay || youtubePlayer.radioEnabled) {
      void youtubePlayer.refillSmartQueue?.(4);
    }
    scheduleRuntimePersist?.("track-start");
  });

  youtubePlayer.on("queueEmpty", () => {
    // A naturally completed session must not be resurrected on the next bot
    // launch. Keep snapshots for interrupted/manual shutdown sessions only.
    try { clearPlaybackSnapshot(); } catch {}
    try { clearRoomPlayback(client.currentRoom || defaultRoom || ""); } catch {}
    try { resetIdleWatcher(); } catch (err) { debug("[Idle Watcher] reset failed:", err?.message || err); }
    const room = client.currentRoom || defaultRoom;
    if (!room) return;
    void roomReply(room, "⏹️ Music playback finished. The queue is now empty.");
  });

  function formatEta(seconds) {
    const s = Math.max(0, Math.ceil(Number(seconds) || 0));
    if (s < 60) return `${s}s`;
    const m = Math.floor(s / 60), r = s % 60;
    return r ? `${m}m ${r}s` : `${m}m`;
  }

  function parseTimeSeconds(str) {
    const s = String(str || "").trim();
    if (/^\d+$/.test(s)) return Number(s);
    const parts = s.split(":").map(Number);
    if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) return parts[0] * 60 + parts[1];
    if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) return parts[0] * 3600 + parts[1] * 60 + parts[2];
    return null;
  }

  // Queue pagination: keep queue listings to one compact room message per page.
  // Page state is tracked per room so .qnext/.qprev work naturally without
  // flooding the room with one message per track.
  const queuePageByRoom = new Map();
  const QUEUE_PAGE_SIZE = 5;

  function renderQueuePage(room, requestedPage = 1) {
    const q = youtubePlayer.getQueue();
    const totalPages = Math.max(1, Math.ceil(q.length / QUEUE_PAGE_SIZE));
    let page = Number(requestedPage);
    if (!Number.isInteger(page)) page = 1;
    page = Math.max(1, Math.min(totalPages, page));
    queuePageByRoom.set(room, page);

    const current = youtubePlayer.getNowPlaying();
    const start = (page - 1) * QUEUE_PAGE_SIZE;
    const items = q.slice(start, start + QUEUE_PAGE_SIZE);
    const lines = [
      `🎶 MUSIC QUEUE • PAGE ${page}/${totalPages}`,
      current ? `▶️ NOW: ${current.title} (${current.duration || "Unknown"})` : "▶️ NOW: Nothing playing"
    ];
    if (!q.length) {
      lines.push("📋 Queue: Empty");
    } else {
      for (let i = 0; i < items.length; i++) {
        const n = start + i + 1;
        const t = items[i];
        const eta = youtubePlayer.getQueueEtaSeconds(n);
        lines.push(`${n}. ${t.title} (${t.duration || "Unknown"}) • ETA ${formatEta(eta)}`);
      }
      lines.push(`📋 ${q.length} waiting • ${totalPages} pages • ${QUEUE_PAGE_SIZE} tracks/page`);
      lines.push("➡️ .queue <page> | .qnext | .qprev | .play #N | .like #N | .qsave #N <playlist>");
    }
    return lines.join("\n");
  }

  function queuePage(room, direction = 0) {
    const current = queuePageByRoom.get(room) || 1;
    return Math.max(1, current + direction);
  }

  // Saved playlists are selected by their displayed number. Names are kept
  // internally for storage/backward compatibility, but room commands use
  // stable numeric positions so users do not need to type long names.
  function resolvePlaylistNumber(value) {
    const raw = String(value || "").trim();
    if (!/^#?\d+$/.test(raw)) return null;
    const number = Number(raw.replace(/^#/, ""));
    if (!Number.isInteger(number) || number < 1) return null;
    const list = youtubePlayer.getSavedPlaylists();
    return { number, list, playlist: list[number - 1] || null };
  }

  function playlistNumberUsage(list) {
    if (!list.length) return "📋 No saved custom playlists yet. Use .savequeue <name> first.";
    return `Available playlist numbers: 1-${list.length}. Use .loadqueue <number>.`;
  }

  function commandHelp(category = "") {
    const raw = String(category || "").trim();
    const tokens = raw.split(/\s+/).filter(Boolean);
    const requested = (tokens.shift() || "").toLowerCase();
    const requestedPage = Math.max(1, Number(tokens.shift()) || 1);

    const aliases = new Map([
      ["1", "playback"], ["play", "playback"], ["p", "playback"], ["playback", "playback"],
      ["2", "queue"], ["q", "queue"], ["queue", "queue"],
      ["3", "audio / fx"], ["fx", "audio / fx"], ["effects", "audio / fx"], ["filters", "audio / fx"], ["audio", "audio / fx"], ["audio-fx", "audio / fx"], ["audio-&-fx", "audio / fx"],
      ["4", "voice & stream"], ["voice", "voice & stream"], ["stream", "voice & stream"],
      ["5", "radio & automation"], ["radio", "radio & automation"], ["automation", "radio & automation"],
      ["6", "community"], ["community", "community"],
      ["7", "profiles & system"], ["system", "profiles & system"], ["settings", "profiles & system"], ["profiles", "profiles & system"],
      ["8", "host / account"], ["host", "host / account"], ["account", "host / account"],
      ["pl", "playlists & favorites"], ["playlist", "playlists & favorites"], ["favorites", "playlists & favorites"],
      ["9", "smart radio & power tools"], ["smart", "smart radio & power tools"], ["smart-radio", "smart radio & power tools"], ["power", "smart radio & power tools"]
    ]);

    const sections = COMMAND_CATALOG.map(section => ({
      ...section,
      commands: [...section.commands]
    }));

    if (!requested) {
      const total = sections.reduce((n, s) => n + s.commands.length, 0);
      return [
        "🎵 TALKINCHAT MUSIC BOT • COMPLETE HELP",
        `📚 ${total} commands • Choose a submenu:`,
        ...sections.map((s, i) => `${i + 1}. ${s.icon} .help ${s.group.toLowerCase().replace(/\s*&\s*/g, " & ").replace(/\s+/g, "-")} — ${s.commands.length} commands`),
        "",
        "📖 Examples: .help playback | .help queue | .help fx 2 | .help voice | .help radio",
        "🔎 .help all  = compact index of every command",
        "ℹ️ Command aliases are included in each submenu."
      ];
    }

    if (requested === "all" || requested === "*" || requested === "everything") {
      const compact = ["📚 COMPLETE COMMAND INDEX"];
      for (const section of sections) {
        compact.push(``, `${section.icon} ${section.group.toUpperCase()} (${section.commands.length})`);
        compact.push(...section.commands.map(c => `.${c}`));
      }
      return compact;
    }

    const target = aliases.get(requested) || requested.replace(/-/g, " ");
    const section = sections.find(s => s.group.toLowerCase() === target);
    if (!section) {
      return [
        `❓ Unknown help submenu: ${requested}`,
        `📖 Available: ${sections.map((s, i) => `${i + 1}=${s.group}`).join(" • ")}`,
        "Try .help, .help fx, .help voice, or .help all."
      ];
    }

    // Keep room messages comfortably sized. Every command in the catalog is
    // represented; large sections are split into numbered pages.
    const pageSize = 12;
    const totalPages = Math.max(1, Math.ceil(section.commands.length / pageSize));
    const page = Math.min(requestedPage, totalPages);
    const slice = section.commands.slice((page - 1) * pageSize, page * pageSize);
    const lines = [
      `${section.icon} ${section.group.toUpperCase()} • PAGE ${page}/${totalPages}`,
      ...slice.map((command, i) => `${(page - 1) * pageSize + i + 1}. .${command}`),
      "",
      page < totalPages ? `➡️ Next: .help ${requested} ${page + 1}` : "✅ End of submenu",
      page > 1 ? `⬅️ Previous: .help ${requested} ${page - 1}` : "",
      `📚 Total in ${section.group}: ${section.commands.length}`
    ].filter(Boolean);
    return lines;
  }

  async function dispatchRoomCommand(userPayload) {
    const { room, text, username, userId } = userPayload;
    if (!checkRateLimit(userId)) return;
    recordCommunityCommand(username || userId || "User");
    void hooks.run("command", { room, text, username, userId, command: text });

    const parts = text.replace(/^\s*\./, "").trim().split(/\s+/);
    const cmd = (parts.shift() || "").toLowerCase();
    incrementStat("commands");
    const arg = parts.join(" ").trim();
    // Incoming room commands are replied to using their event room; do not
    // silently change the bot's actual joined/voice room here.

    // One authoritative DJ gate for state-changing playback controls. Individual
    // commands may still have stricter checks, but no command can accidentally
    // bypass DJ mode because a new handler forgot to add one.
    const publicCommands = new Set([
      'help','commands','queue','q','qnext','queuenext','qprev','queueprev','queueinfo','nowplaying','np','progress','pos','history','lyrics','lyric','rooms','roomsettings','roomstate','masters','master','stats','stat','status','health','ping','uptime','version','about','whoami','profile','users','members','owners','admins','voteskip','vote','qcount','queuecount','playlistinfo','favorites','favs','list','catalog','cache','source','latency','roominfo','controllers','version','about'
    ]);
    const playbackCommands = new Set([
      'join','publish','stream','leave','play','playqueue','queueplay','playlist','pl','pause','resume','stop','skip','next','s','loop','repeat','shuffle','volume','vol','speed','tempo','bassboost','bb','treble','nightcore','nc','8d','karaoke','vocal','reverb','echo','stereo','wide','fx','filter','preset','voicefx','voicepreset','autoplay','autodj','autodjmode','smartdj','radio','radioon','radiooff','stopradio','radioartist','radiogenre','radiomood','radiorelated','queuefill','sleep','seek','forward','ff','rewind','rw','previous','prev','back','replay','pick','crossfade','transition','247','qplay','qp','random','randomplay','playfavs','playnext','clear','clearqueue','qclear','move','remove','unqueue','loadqueue','loadplaylist','lq','savequeue','saveplaylist','sq','qsave','queueplaylist','playlistadd','playlistremove','playlistmove','playlistrename','persist','saveall','savesettings','volup','voldown','mute','unmute','fxreset','cleanfx','replaylast','speedup','speeddown','pitchup','pitchdown','bassup','bassdown','trebleup','trebledown','8don','8doff','8dspeed','wideon','wideoff','monoon','monooff','echoon','echooff','reverbon','reverboff','compressor','limiter','normalize','nightmode','lofi','tremolo','chorus','flanger','vibrato','crystalizer','crystallizer','haas','deesser','de-esser','basscut','dj'
    ]);
    if (masterOnly && !publicCommands.has(cmd) && !isRoomController(userPayload)) {
      return roomReply(room, '🔒 Only the room bot masters or room owner/admin can control this bot. Use .masters to see who is authorized.');
    }
    if (playbackCommands.has(cmd) && requireOwnerForPlayback && !requireBotOwner(room, false)) {
      // Do not consume the anti-spam strike for an authorization failure.
      // Previously a few failed `.play` attempts could create a 20–60s
      // cooldown even after the bot was promoted to OWNER.
      return roomReply(room, '⛔ Bot playback/streaming is disabled because the bot is not OWNER in this room. Ask the room owner to promote the bot to Owner.');
    }
    // Anti-spam is scoped to room + user and is checked only after permission
    // gates. A failed OWNER/master check must never punish a valid retry.
    const spam = antiSpamCheck(`${room}|${username || userId}`);
    if (!spam.ok) return roomReply(room, `🛡️ Anti-spam cooldown active. Try again in ${Math.ceil(spam.remaining/1000)}s.`);

    switch (cmd) {
      case "say": {
        if (!arg) return roomReply(room, "Usage: .say <message>");
        if (!isRoomController(userPayload)) return roomReply(room, "🔒 Only room masters or owner/admin can use .say.");
        client.sendRoomText(room, arg);
        return;
      }
      case "width": {
        const value = parts[0];
        if (value == null) return roomReply(room, `Usage: .width <0-150>\nCurrent: ${voiceManager.filters.stereoWidth}`);
        const n = Math.max(0, Math.min(150, Number(value)));
        if (!Number.isFinite(n)) return roomReply(room, "❌ Width must be a number from 0 to 150.");
        await applyFilterChange("width", () => voiceManager.setStereoWidth(n));
        return roomReply(room, `↔️ Stereo width ${n}%`);
      }
      case "rooms": {
        const profiles = getRoomSettingsList();
        if (!profiles.length) return roomReply(room, `🏠 ROOM DATABASE
Current room: ${room}
No other room profiles have been created yet.`);
        const lines = profiles.map((p, i) => `${i + 1}. ${p.room} • queue ${p.queueLength} • ${p.playback?.title ? `saved: ${p.playback.title}` : "no saved track"}`);
        return roomReplyLong(room, [`🏠 ROOM DATABASE • ${profiles.length} PROFILE(S)`, `Current: ${getActiveRoom() || room}`, ...lines, "", "Each room has its own settings, queue, AutoDJ/Radio, FX, volume and resume state."]);
      }
      case "roomsettings":
      case "roomstate": {
        const target = String(parts[0] || room).trim();
        const st = loadSettings(target);
        const profile = getRoomSettingsList().find(p => p.room === target);
        return roomReplyLong(room, [
          `🏠 ROOM SETTINGS • ${target}`,
          JSON.stringify({ settings: st, queueLength: profile?.queueLength || 0, playback: profile?.playback || null, database: getRoomDatabaseFile() }, null, 2).slice(0, 6500)
        ]);
      }
      case "help":
      case "commands": {
        // Main help is intentionally a single compact room message.
        // Detailed sections remain available as one-message help pages.
        const helpLines = commandHelp(arg);
        const helpText = Array.isArray(helpLines) ? helpLines.join("\n") : String(helpLines || "");
        return roomReply(room, helpText);
      }

      case "join":
      case "publish":
      case "stream": {
        manualVoiceStop = false;
        if (voiceManager.isConnected && voiceManager.currentRoomName === room) return roomReply(room, "🔊 Music lobby is already connected. Send .play <song> to start.");
        await roomReply(room, "🔊 Starting music lobby... loading this room's saved profile and using the direct publisher flow.");
        try {
          await joinRoomAndVoice(room);
        } catch (err) {
          streamJoinInProgress = false;
          return roomReply(room, `❌ Voice join failed: ${err.message}`);
        }
        return;
      }

      case "leave":
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode is active: Only DJs/Admins can disconnect the bot.");
        manualVoiceStop = true;
        sleepTriggered = false;
        voiceRecoveryWanted = false;
        clearStreamDirectoryTimers();
        stopVoiceRecovery();
        stopVoiceHeartbeat();
        resetVoiceJoinState();
        // Tell the TalkInChat server first, then tear down only this LiveKit
        // room. The native LiveKit runtime must remain alive for the next join.
        persistRuntimeState("manual-leave", room);
        try { client.streamUnpublish(room, config.username || auth.username); } catch {}
        await voiceManager.disconnect();
        youtubePlayer.stop();
        lastKnownStreaming = false;
        return roomReply(room, "🔇 Left the music lobby. The bot remains in the text room. You can use .join again.");

      case "play":
      case "p": {
        if (!arg) return roomReply(room, "Usage: .play <YouTube URL or search query>");
        wakeFromSleep();
        const requestedBy = username || "User";
        await roomReply(room, `🔎 Searching YouTube for: ${arg}`);
        // Start the voice handshake immediately instead of waiting for yt-dlp
        // to finish resolving the audio URL. This removes the startup race in
        // which a slow YouTube lookup leaves the bot disconnected and the media
        // pipeline has nowhere to publish its first frames.
        if (!voiceManager.isConnected && !voiceManager.isConnecting) {
          try { requestVoiceJoin(room); } catch (err) { debug(`[Voice] Pre-play join request failed: ${err.message}`); }
        }
        await youtubePlayer.replaceAndPlay(arg, requestedBy);
        return;
      }

      case "qplay":
      case "qp": {
        if (!arg) return roomReply(room, "Usage: .qplay <YouTube URL or search query>");
        wakeFromSleep();
        const requestedBy = username || "User";
        const wasPlaying = youtubePlayer.isPlaying;
        const { track, queuePosition, startedImmediately } = await youtubePlayer.enqueue(arg, requestedBy);
        if (startedImmediately || (!wasPlaying && youtubePlayer.currentTrack?.url === track.url)) {
          return roomReply(room, `▶️ NOW PLAYING\n🎵 ${track.title}\n⏱️ ${track.duration} | 👤 ${requestedBy}\n📋 Queue: ${youtubePlayer.queue.length}`);
        }
        const eta = youtubePlayer.getQueueEtaSeconds(queuePosition);
        return roomReply(room, `➕ QUEUED #${queuePosition}\n🎵 ${track.title}\n⏱️ ${track.duration} | 👤 ${requestedBy}\n⏳ ETA: ${formatEta(eta)}`);
      }

      case "playlist":
      case "pl": {
        if (!arg) return roomReply(room, "Usage: .playlist <YouTube playlist URL>");
        wakeFromSleep();
        const requestedBy = username || "User";
        await roomReply(room, `📜 Loading playlist: "${arg}" ...`);
        try {
          const { playlist, count, totalQueue } = await youtubePlayer.enqueuePlaylist(arg, requestedBy, 50);
          return roomReply(room, `✅ Added ${count} songs from "${playlist.title}"!\n📋 Total queue: ${totalQueue} tracks.`);
        } catch (err) {
          return roomReply(room, `❌ Failed to load playlist: ${err.message}`);
        }
      }

      case "seek": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can seek audio.");
        const sec = parseTimeSeconds(arg);
        if (sec === null) return roomReply(room, "Usage: .seek <seconds or mm:ss>");
        const pos = await youtubePlayer.seek(sec);
        if (pos === false) return roomReply(room, "❌ Nothing currently playing to seek.");
        return roomReply(room, `⏩ Seeked to ${youtubePlayer.getProgressBar(8)}`);
      }

      case "forward":
      case "ff": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can seek audio.");
        const sec = Number(parts[0]) || 15;
        const pos = await youtubePlayer.forward(sec);
        if (pos === false) return roomReply(room, "❌ Nothing currently playing.");
        return roomReply(room, `⏩ Forwarded +${sec}s: ${youtubePlayer.getProgressBar(8)}`);
      }

      case "rewind":
      case "rw": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can seek audio.");
        const sec = Number(parts[0]) || 15;
        const pos = await youtubePlayer.rewind(sec);
        if (pos === false) return roomReply(room, "❌ Nothing currently playing.");
        return roomReply(room, `⏪ Rewound -${sec}s: ${youtubePlayer.getProgressBar(8)}`);
      }

      case "history": {
        const hist = youtubePlayer.getRecentHistory();
        if (!hist.length) return roomReply(room, "📜 Playback history is empty.");
        const lines = ["📜 RECENTLY PLAYED SONGS:"];
        hist.slice(0, 10).forEach((t, i) => lines.push(`${i + 1}. ${t.title} (${t.duration})`));
        lines.push("👉 .replay <#> to replay | .previous to return to the previous track");
        return roomReplyLong(room, lines);
      }

      case "replay": {
        const idx = Number(parts[0]) || 1;
        const track = await youtubePlayer.replay(idx);
        if (!track) return roomReply(room, `❌ No song at history position #${idx}.`);
        return roomReply(room, `🔄 Replaying #${idx}: "${track.title}"`);
      }

      case "clearhistory":
      case "historyclear": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode active. Only DJs/Admins can clear history.");
        const n = youtubePlayer.clearHistory();
        return roomReply(room, `🧹 Cleared ${n} history entries.`);
      }

      case "progress":
      case "pos": {
        const t = youtubePlayer.currentTrack;
        if (!t) return roomReply(room, "🎵 Nothing is currently playing.");
        return roomReply(room, `📍 ${t.title}\n${youtubePlayer.getProgressBar(16)}\n⏳ Remaining: ${formatEta(youtubePlayer.getRemainingSeconds())}`);
      }

      case "random":
      case "randomplay": {
        const q = youtubePlayer.getQueue();
        if (!q.length) return roomReply(room, "🎲 Queue is empty. Add songs with .qplay first.");
        const index = Math.floor(Math.random() * q.length);
        const [track] = youtubePlayer.queue.splice(index, 1);
        await youtubePlayer.playTrackObject(track, "random");
        return roomReply(room, `🎲 RANDOM PLAY\n🎵 ${track.title}\n⏱️ ${track.duration || "Unknown"}`);
      }

      case "like":
      case "fav": {
        const uid = userId || username;
        // `.like #3` / `.fav #3` can save a track directly from the queue.
        if (parts[0] && /^#?\d+$/.test(parts[0])) {
          const n = Number(parts[0].replace(/^#/, ""));
          const queued = youtubePlayer.getQueue()[n - 1];
          if (!queued) return roomReply(room, `❌ Queue track #${n} not found. Use .queue to see the queue.`);
          const res = addFavorite(uid, queued);
          return roomReply(room, res.added ? `❤️ Saved queue #${n}: "${queued.title}" to your likes. (${res.count} total)` : `❤️ Queue #${n} is already in your likes. (${res.count} total)`);
        }
        const current = youtubePlayer.currentTrack;
        if (!current) return roomReply(room, "❌ Nothing is playing to like. Use .like #<queue_number> for a queued track.");
        const res = addFavorite(uid, current);
        return roomReply(room, res.added ? `❤️ Saved "${current.title}" to your favorites! (${res.count} total)` : `❤️ Already in your favorites list! (${res.count} total)`);
      }

      case "likeq":
      case "favq": {
        const n = Number(String(parts[0] || "").replace(/^#/, ""));
        const queued = Number.isInteger(n) && n > 0 ? youtubePlayer.getQueue()[n - 1] : null;
        if (!queued) return roomReply(room, "Usage: .likeq <queue_number>  (example: .likeq 3)");
        const uid = userId || username;
        const res = addFavorite(uid, queued);
        return roomReply(room, res.added ? `❤️ Saved queue #${n}: "${queued.title}" to your likes. (${res.count} total)` : `❤️ Queue #${n} is already in your likes. (${res.count} total)`);
      }

      case "qsave":
      case "queueplaylist":
      case "playlistadd": {
        const n = Number(String(parts[0] || "").replace(/^#/, ""));
        const playlistName = parts.slice(1).join(" ").trim();
        const queued = Number.isInteger(n) && n > 0 ? youtubePlayer.getQueue()[n - 1] : null;
        if (!queued || !playlistName) return roomReply(room, "Usage: .qsave <queue_number> <playlist_name>  (example: .qsave 3 workout)");
        try {
          const res = addTrackToCustomPlaylist(playlistName, queued, username || "User");
          const action = res.added ? "➕ Added" : "ℹ️ Already in";
          return roomReply(room, `${action} queue #${n}: "${queued.title}" → playlist "${res.playlist.name}" (${res.count} tracks)`);
        } catch (err) {
          return roomReply(room, `❌ Playlist error: ${err.message}`);
        }
      }

      case "unfav":
      case "unlike": {
        const uid = userId || username;
        if (!arg) return roomReply(room, "Usage: .unfav <song index or name>");
        const ok = removeFavorite(uid, arg);
        return roomReply(room, ok ? `💔 Removed from your favorites.` : `❌ Favorite not found.`);
      }

      case "myfavs":
      case "favorites": {
        const uid = userId || username;
        const favs = getFavorites(uid);
        if (!favs.length) return roomReply(room, "❤️ You don't have any liked songs yet. Type .like to add current song!");
        const lines = [`❤️ YOUR LIKED SONGS (${favs.length}):`];
        favs.slice(0, 5).forEach((t, i) => lines.push(`${i + 1}. ${t.title} (${t.duration})`));
        if (favs.length > 5) lines.push(`... and ${favs.length - 5} more`);
        lines.push("👉 Type .playfavs to queue all your favorites!");
        return roomReply(room, lines.join("\n"));
      }

      case "playfavs": {
        const uid = userId || username;
        const favs = getFavorites(uid);
        if (!favs.length) return roomReply(room, "❤️ You don't have any liked songs yet. Use .like while a song is playing.");
        wakeFromSleep();
        let added = 0;
        for (const t of favs) {
          if (!youtubePlayer.addTrackObject({ ...t, requestedBy: username || "User" })) break;
          added++;
        }
        if (!youtubePlayer.isPlaying && added) await youtubePlayer.playNext();
        return roomReply(room, `▶️ Queued ${added} of ${favs.length} liked tracks${added < favs.length ? ` (queue limit ${youtubePlayer.queueLimit} reached)` : ""}.`);
      }

      case "quality": {
        const quality = String(arg || "").toLowerCase().trim();
        if (!quality) {
          return roomReply(room, `🎧 Source quality: ${youtubePlayer.getAudioQuality().toUpperCase()} | ${youtubePlayer.getAudioQualityFormat()}`);
        }
        if (!new Set(["highest", "high", "medium", "low"]).has(quality)) {
          return roomReply(room, "Usage: .quality <highest|high|medium|low> | highest = maximum available YouTube audio");
        }
        const previous = youtubePlayer.getAudioQuality();
        if (quality !== previous) {
          try {
            await applyFilterChange("audio-quality", () => youtubePlayer.setAudioQuality(quality));
          } catch (err) {
            youtubePlayer.setAudioQuality(previous);
            return roomReply(room, `❌ Quality change failed: ${err.message}`);
          }
        }
        return roomReply(room, `🎧 Source quality: ${youtubePlayer.getAudioQuality().toUpperCase()} | ${youtubePlayer.getAudioQualityFormat()}${youtubePlayer.currentTrack ? " | 🔄 Applied now" : ""}`);
      }

      case "preset":
      case "eq": {
        if (!arg) return roomReply(room, "Usage: .preset <pop|rock|electronic|vocal|bass|classical|treble|vaporwave|soft|club|headphones|cinema|clear>");
        const presetInput = String(arg).toLowerCase().trim();
        const allowedPresets = new Set(["pop","rock","electronic","edm","dance","vocal","bass","classical","treble","vaporwave","soft","club","headphones","cinema","clear","flat","off"]);
        if (!allowedPresets.has(presetInput)) return roomReply(room, "❌ Invalid preset. Available: pop, rock, electronic, vocal, bass, classical, treble, vaporwave, soft, clear");
        const res = await applyFilterChange("preset", () => voiceManager.setPreset(arg));
        return roomReply(room, `🎛️ Equalizer preset set to: ${res.toUpperCase()}${youtubePlayer.currentTrack ? " | 🔄 Applied now" : ""}`);
      }

      case "voicefx":
      case "voicepreset": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const available = "normal, man, lady, kidboy, kidgirl, oldman, oldwoman, deep, helium, demon, robot, radio, megaphone, underwater, alien, ghost, cave, space, walkie, vintage, megaphone2, child, giant, telephone, underwaterdeep, glitch, cyber, vinyl, cavewide, radiofx, distorted, dream, darkhall";
        if (!arg) return roomReply(room, `🎙️ Voice FX: ${voiceManager.filters.voiceFx} | Available: ${available}`);
        const requested = String(arg).toLowerCase().trim();
        const aliases = new Set(["normal","clean","off","none","man","male","lady","woman","femalevoice","kidboy","boy","littleboy","kidgirl","girl","littlegirl","oldman","grandpa","elderlyman","oldwoman","grandma","elderlywoman","deep","bass","helium","chipmunk","high","female","demon","monster","dark","robot","robotic","radio","telephone","phone","megaphone","underwater","water","alien","ghost","phantom","haunted","cave","cavern","space","cosmic","walkie","walkietalkie","vintage","oldradio","megaphone2","child","kid","giant","giantvoice","underwaterdeep","glitch","cyber","cyborg","vinyl","record","distorted","distortion","dream","dreamy","darkhall","hall","cavewide","radiofx"]);
        if (!aliases.has(requested)) return roomReply(room, `Usage: .voicefx <${available}>`);
        const res = await applyFilterChange("voice-fx", () => voiceManager.setVoiceFx(requested));
        return roomReply(room, `🎙️ Voice FX: ${res.toUpperCase()}${youtubePlayer.currentTrack ? " | 🔄 Applied at current position" : ""}`);
      }

      case "savequeue":
      case "saveplaylist":
      case "sq": {
        if (!arg) return roomReply(room, "Usage: .savequeue <playlist_name>");
        try {
          const saved = youtubePlayer.saveQueueAsPlaylist(arg, username || "User");
          const list = youtubePlayer.getSavedPlaylists();
          const number = list.findIndex(p => p.name === saved.name) + 1;
          return roomReply(room, `💾 Saved playlist "${saved.name}" (${saved.trackCount} tracks)! Playlist #${number}. Play with: .loadqueue ${number}`);
        } catch (err) {
          return roomReply(room, `❌ Failed to save queue: ${err.message}`);
        }
      }

      case "loadqueue":
      case "loadplaylist":
      case "lq": {
        wakeFromSleep();
        const ref = resolvePlaylistNumber(parts[0]);
        const list = ref?.list || youtubePlayer.getSavedPlaylists();
        if (!parts[0]) return roomReply(room, `Usage: .loadqueue <playlist_number>\n${playlistNumberUsage(list)}`);
        if (!ref?.playlist) return roomReply(room, `❌ Playlist #${parts[0]} not found. ${playlistNumberUsage(list)}`);
        try {
          const { playlist, count, totalQueue } = await youtubePlayer.loadSavedPlaylist(ref.playlist.name, username || "User");
          return roomReply(room, `▶️ Loaded playlist #${ref.number} "${playlist.name}" (${count} tracks)! Queue: ${totalQueue} songs.`);
        } catch (err) {
          return roomReply(room, `❌ Load playlist error: ${err.message}`);
        }
      }

      case "savedplaylists":
      case "playlists": {
        const list = youtubePlayer.getSavedPlaylists();
        if (!list.length) return roomReply(room, "📋 No saved custom playlists yet. Use .savequeue <name> to create one!");
        const lines = ["💾 SAVED CUSTOM PLAYLISTS:"];
        list.forEach((p, i) => lines.push(`${i + 1}. "${p.name}" (${p.trackCount} tracks)`));
        lines.push("👉 .loadqueue <number> = play playlist");
        lines.push("👉 .viewplaylist <number> = view tracks");
        lines.push("👉 .deleteplaylist <number> = delete playlist (DJ/Admin)");
        return roomReplyLong(room, lines);
      }

      case "viewplaylist": {
        const ref = resolvePlaylistNumber(parts[0]);
        const list = ref?.list || youtubePlayer.getSavedPlaylists();
        if (!parts[0]) return roomReply(room, `Usage: .viewplaylist <playlist_number>\n${playlistNumberUsage(list)}`);
        if (!ref?.playlist) return roomReply(room, `❌ Playlist #${parts[0]} not found. ${playlistNumberUsage(list)}`);
        const pl = ref.playlist;
        const lines = [`📂 PLAYLIST #${ref.number}: "${pl.name}" (${pl.trackCount} tracks):`];
        pl.tracks.slice(0, 15).forEach((t, i) => lines.push(`${i + 1}. ${t.title} (${t.duration || "?"})`));
        if (pl.tracks.length > 15) lines.push(`... and ${pl.tracks.length - 15} more tracks`);
        lines.push(`👉 .loadqueue ${ref.number} to play this playlist`);
        return roomReplyLong(room, lines);
      }

      case "deleteplaylist": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs/Admins can delete playlists.");
        const ref = resolvePlaylistNumber(parts[0]);
        const list = ref?.list || youtubePlayer.getSavedPlaylists();
        if (!parts[0]) return roomReply(room, `Usage: .deleteplaylist <playlist_number>\n${playlistNumberUsage(list)}`);
        if (!ref?.playlist) return roomReply(room, `❌ Playlist #${parts[0]} not found. ${playlistNumberUsage(list)}`);
        const name = ref.playlist.name;
        const ok = youtubePlayer.deleteSavedPlaylist(name);
        return roomReply(room, ok ? `🗑️ Deleted playlist #${ref.number} "${name}".` : `❌ Playlist #${ref.number} could not be deleted.`);
      }

      case "search":
      case "find": {
        if (!arg) return roomReply(room, "Usage: .search <song title>");
        await roomReply(room, `🔎 Searching top 10 for: "${arg}" ...`);
        try {
          const results = await youtubePlayer.searchTop(arg, 10);
          if (!results.length) return roomReply(room, "❌ No results found on YouTube.");
          pendingSearches.set(searchKey(room, userPayload), { results, expiresAt: Date.now() + 60000, username, userId });
          const lines = ["🔍 SEARCH RESULTS (Reply .pick <number>):"];
          results.forEach((r, i) => {
            const title = String(r.title || "Unknown");
            lines.push(`${i + 1}. ${title} (${r.duration || "?"})`);
          });
          return roomReplyLong(room, lines);
        } catch (err) {
          return roomReply(room, `❌ Search error: ${err.message}`);
        }
      }

      case "pick": {
        const choice = parseInt(parts[0] || "1", 10);
        const pending = pendingSearches.get(searchKey(room, userPayload));
        if (!pending || Date.now() > pending.expiresAt) {
          return roomReply(room, "❌ No active search. Run .search <query> first.");
        }
        if (isNaN(choice) || choice < 1 || choice > pending.results.length) {
          return roomReply(room, `Usage: .pick 1-${pending.results.length}`);
        }
        const selected = pending.results[choice - 1];
        pendingSearches.delete(searchKey(room, userPayload));
        selected.requestedBy = username || "User";
        await roomReply(room, `👉 Picked #${choice}: "${selected.title}"`);
        wakeFromSleep();
        if (!youtubePlayer.isPlaying) {
          await youtubePlayer.playTrackObject(selected, "search-pick");
        } else if (youtubePlayer.addTrackObject(selected)) {
          await roomReply(room, `➕ Added to queue #${youtubePlayer.queue.length}: "${selected.title}"`);
        } else {
          return roomReply(room, `❌ Queue limit reached (${youtubePlayer.queueLimit}).`);
        }
        return;
      }

      case "lyrics":
      case "ly": {
        const query = arg || youtubePlayer.currentTrack?.title;
        if (!query) return roomReply(room, "Usage: .lyrics <song title> or play a song first.");
        const artist = arg ? "" : youtubePlayer.currentTrack?.artist || "";
        const dur = arg ? 0 : youtubePlayer.currentTrack?.durationSeconds || 0;
        await roomReply(room, `🎤 Fetching lyrics for: "${query}" ...`);
        try {
          const result = await fetchLyrics(query, artist, dur);
          if (!result || !result.lyrics) {
            return roomReply(room, `❌ No lyrics found for "${query}".`);
          }
          const snippet = result.lyrics.length > 250 ? result.lyrics.slice(0, 240) + "\n... (more)" : result.lyrics;
          return roomReply(room, `📜 ${result.title} - ${result.artist}\n${snippet}`);
        } catch (err) {
          return roomReply(room, `❌ Lyrics error: ${err.message}`);
        }
      }

      case "bassboost":
      case "bb": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const level = parts[0] || "med";
        const res = await applyFilterChange("bassboost", () => voiceManager.setBassBoost(level));
        return roomReply(room, `🔊 Bass Boost: ${String(res).toUpperCase()}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }

      case "nightcore":
      case "nc": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? parts[0].toLowerCase() === "on" || parts[0] === "1" : !voiceManager.filters.nightcore;
        const res = await applyFilterChange("nightcore", () => voiceManager.setNightcore(toggle));
        return roomReply(room, `⚡ Nightcore: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }

      case "8d": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? parts[0].toLowerCase() === "on" || parts[0] === "1" : !voiceManager.filters.eightD;
        const res = await applyFilterChange("8d", () => voiceManager.setEightD(toggle));
        return roomReply(room, `🎧 8D Audio: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied immediately" : ""}`);
      }

      case "speed":
      case "tempo": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        if (!parts[0]) return roomReply(room, `⏩ Speed: ${voiceManager.filters.speed}x | Usage: .speed 0.5-2.0`);
        const rawSpeed = String(parts[0]).toLowerCase();
        const mult = rawSpeed === "normal" || rawSpeed === "reset" ? 1 : parseFloat(rawSpeed);
        if (isNaN(mult) || mult < 0.5 || mult > 2.0) return roomReply(room, "Usage: .speed 0.5 - 2.0");
        const res = await applyFilterChange("speed", () => voiceManager.setSpeed(mult));
        return roomReply(room, `⏩ Playback speed: ${res}x${youtubePlayer.currentTrack ? " | applied immediately" : ""}`);
      }

      case "8dspeed": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        if (!parts[0]) return roomReply(room, `🎧 8D speed: ${voiceManager.filters.eightDSpeed}Hz | Usage: .8dspeed 0.03-2.00`);
        const hz = Number(parts[0]);
        if (!Number.isFinite(hz) || hz < 0.03 || hz > 2.00) return roomReply(room, "Usage: .8dspeed 0.03 - 2.00");
        const res = voiceManager.setEightDSpeed(hz);
        return roomReply(room, `🎧 8D rotation speed: ${res}Hz (applied immediately)`);
      }

      case "treble": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const n = Number(parts[0]);
        if (!Number.isFinite(n) || n < -12 || n > 12) return roomReply(room, "Usage: .treble -12 to 12");
        const res = await applyFilterChange("treble", () => voiceManager.setTreble(n));
        return roomReply(room, `🎚️ Treble: ${res > 0 ? "+" : ""}${res}dB | applied at current position`);
      }

      case "pitch": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const n = Number(parts[0]);
        if (!Number.isFinite(n) || n < -12 || n > 12) return roomReply(room, "Usage: .pitch -12 to 12");
        const res = await applyFilterChange("pitch", () => voiceManager.setPitch(n));
        return roomReply(room, `🎼 Pitch: ${res > 0 ? "+" : ""}${res} semitones | applied at current position`);
      }

      case "limiter": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.limiter;
        const res = await applyFilterChange("limiter", () => voiceManager.setLimiter(toggle));
        return roomReply(room, `🛡️ Limiter: ${res ? "ON" : "OFF"} | applied at current position`);
      }

      case "normalize": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.normalize;
        const res = await applyFilterChange("normalize", () => voiceManager.setNormalize(toggle));
        return roomReply(room, `📏 Normalize: ${res ? "ON" : "OFF"} | applied at current position`);
      }

      case "nightmode": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.nightMode;
        const res = await applyFilterChange("nightmode", () => voiceManager.setNightMode(toggle));
        return roomReply(room, `🌙 Night mode: ${res ? "ON" : "OFF"} | applied at current position`);
      }

      case "fadein": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.fadeIn;
        const res = await applyFilterChange("fadein", () => voiceManager.setFadeIn(toggle));
        return roomReply(room, `🌅 Fade-in: ${res ? "ON" : "OFF"} | applied at current position`);
      }

      case "karaoke": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? parts[0].toLowerCase() === "on" || parts[0] === "1" : !voiceManager.filters.karaoke;
        const res = await applyFilterChange("karaoke", () => voiceManager.setKaraoke(toggle));
        return roomReply(room, `🎤 Karaoke Vocal Cut: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | 🔄 Applied now" : ""}`);
      }

      case "echo": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.echo;
        const res = await applyFilterChange("echo", () => voiceManager.setEcho(toggle));
        return roomReply(room, `🔊 Echo: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }

      case "phaser": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.phaser;
        const res = await applyFilterChange("phaser", () => voiceManager.setPhaser(toggle));
        return roomReply(room, `🌊 Phaser: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }

      case "lofi": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.lofi;
        const res = await applyFilterChange("lofi", () => voiceManager.setLofi(toggle));
        return roomReply(room, `📻 Lo-Fi: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }

      case "surround": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.surround;
        const res = await applyFilterChange("surround", () => voiceManager.setSurround(toggle));
        return roomReply(room, `🔈 Surround: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }

      case "fx":
      case "effects":
      case "filters":
        return roomReply(room, `🎛️ Active Audio FX: ${voiceManager.getFilterSummary()}`);

      case "reverb": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.reverb;
        const res = await applyFilterChange("reverb", () => voiceManager.setReverb(toggle));
        return roomReply(room, `🏛️ Reverb: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }

      case "wide":
      case "stereo": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.wide;
        const res = await applyFilterChange("wide", () => voiceManager.setWide(toggle));
        return roomReply(room, `↔️ Stereo Wide: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }

      case "compressor":
      case "comp": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.compressor;
        const res = await applyFilterChange("compressor", () => voiceManager.setCompressor(toggle));
        return roomReply(room, `🎚️ Compressor: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }

      case "tremolo": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.tremolo;
        const res = await applyFilterChange("tremolo", () => voiceManager.setTremolo(toggle));
        return roomReply(room, `〰️ Tremolo: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }

      case "mono": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.mono;
        const res = await applyFilterChange("mono", () => voiceManager.setMono(toggle));
        return roomReply(room, `🎧 Mono: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }

      case "hifi": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const wasPlaying = Boolean(youtubePlayer.currentTrack && youtubePlayer.isPlaying);
        const offset = wasPlaying ? youtubePlayer.getElapsedSeconds() : 0;
        const wasPaused = wasPlaying && youtubePlayer.isPaused;
        voiceManager.clearFilters();
        youtubePlayer.setAudioQuality("highest");
        syncPlaybackRate();
        if (wasPlaying) {
          await youtubePlayer.restartCurrent("hifi", offset, { announce: false });
          if (wasPaused) youtubePlayer.pause();
        }
        return roomReply(room, "🎧 Hi-Fi mode: MAX available source quality + clean DSP path enabled.");
      }

      case "chorus": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.chorus;
        const res = await applyFilterChange("chorus", () => voiceManager.setChorus(toggle));
        return roomReply(room, `🎶 Chorus: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }
      case "flanger": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.flanger;
        const res = await applyFilterChange("flanger", () => voiceManager.setFlanger(toggle));
        return roomReply(room, `🌊 Flanger: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }
      case "vibrato": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.vibrato;
        const res = await applyFilterChange("vibrato", () => voiceManager.setVibrato(toggle));
        return roomReply(room, `〰️ Vibrato: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }
      case "crystalizer":
      case "crystallizer": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.crystalizer;
        const res = await applyFilterChange("crystalizer", () => voiceManager.setCrystalizer(toggle));
        return roomReply(room, `✨ Crystalizer: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }
      case "haas": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.haas;
        const res = await applyFilterChange("haas", () => voiceManager.setHaas(toggle));
        return roomReply(room, `🎧 Haas Stereo: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }
      case "deesser":
      case "de-esser": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.deesser;
        const res = await applyFilterChange("deesser", () => voiceManager.setDeesser(toggle));
        return roomReply(room, `🎙️ De-Esser: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }
      case "basscut": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change audio effects.");
        const toggle = parts[0] ? /^(on|1|true)$/i.test(parts[0]) : !voiceManager.filters.bassCut;
        const res = await applyFilterChange("basscut", () => voiceManager.setBassCut(toggle));
        return roomReply(room, `🎚️ Bass Cut: ${res ? "ON" : "OFF"}${youtubePlayer.currentTrack ? " | applied now" : ""}`);
      }

      case "resetfilters":
      case "cleanfilters":
        await applyFilterChange("reset-filters", () => voiceManager.clearFilters());
        return roomReply(room, "🎛️ All audio filters and presets reset to clean.");

      case "voteskip": {
        if (!youtubePlayer.isPlaying || !youtubePlayer.currentTrack) return roomReply(room, "❌ Nothing currently playing to skip.");
        if (voteSkipPlayId !== youtubePlayer.playId) {
          voteSkips.clear();
          voteSkipPlayId = youtubePlayer.playId;
        }
        voteSkips.add(userId || username);
        const count = voteSkips.size;
        const voteCfg = getVoteConfig();
        const participants = participantCount(userPayload);
        const NEEDED = Math.min(participants, Math.max(voteCfg.minVotes, Math.ceil(participants * voteCfg.percent / 100)));
        if (!voteCfg.enabled) return roomReply(room, "🗳️ Vote system is disabled.");
        if (count >= NEEDED) {
          voteSkips.clear();
          youtubePlayer.skip();
          return roomReply(room, `⏭️ Vote skip passed (${count}/${NEEDED})! Skipping song.`);
        }
        return roomReply(room, `🗳️ Vote skip: ${count}/${NEEDED} votes. Type .voteskip to vote.`);
      }

      case "autoplay": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode active.");
        const toggle = parts[0] ? parts[0].toLowerCase() === "on" || parts[0] === "1" : !youtubePlayer.autoplay;
        const res = youtubePlayer.setAutoplay(toggle);
        if (res && youtubePlayer.currentTrack) void youtubePlayer.refillSmartQueue?.(4);
        persistRuntimeState("autoplay-command");
        return roomReply(room, `📻 AutoDJ: ${res ? "ON (related smart playback)" : "OFF"}`);
      }

      case "radio": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode active.");
        if (!parts.length) { const ps=getRadioPresets(); return roomReply(room,`📻 Radio presets: ${Object.keys(ps).join(', ')}\nUse .radio <artist/song/genre/mood/query>`); }
        const q=parts.join(' '), presets=getRadioPresets(), query=presets[q.toLowerCase()]||q;
        try {
          const seed=await youtubePlayer.resolveTrack(query, username||'Radio');
          youtubePlayer.setRadio(seed, youtubePlayer.autoDjMode || 'hybrid');
          if (!youtubePlayer.currentTrack) await youtubePlayer.playTrackObject(seed,'radio-seed');
          const results=await youtubePlayer.smartDiscover(16,youtubePlayer.radioMode,seed);
          let added=0; const seen=new Set([youtubePlayer.currentTrack?.url,...youtubePlayer.queue.map(t=>t?.url),...youtubePlayer.recentHistory.slice(0,20).map(t=>t?.url)].filter(Boolean));
          for(const t of results){if(!t.url||seen.has(t.url))continue;if(!youtubePlayer.addTrackObject({...t,requestedBy:username||'Radio'}))break;seen.add(t.url);added++;if(added>=8)break;}
          youtubePlayer.setAutoplay(true); persistRuntimeState('radio-start');
          if(!youtubePlayer.isPlaying) await youtubePlayer.playNext();
          return roomReply(room,`📻 Smart Radio ON\nSeed: ${seed.title} — ${seed.artist||'YouTube'}\nMode: ${youtubePlayer.radioMode}\nQueued: ${added}\nRadio will keep exploring artist, related artists, genre, mood and relevant recommendations.`);
        } catch(e){ return roomReply(room,`❌ Radio failed: ${e.message}`); }
      }

      case "radiooff": case "stopradio": {
        youtubePlayer.stopRadio(); persistRuntimeState('radio-stop');
        return roomReply(room,'📻 Smart Radio OFF.');
      }

      case "shuffle": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can shuffle queue.");
        const toggle = parts[0] ? parts[0].toLowerCase() === "on" || parts[0] === "1" : !youtubePlayer.shuffleEnabled;
        const res = youtubePlayer.setShuffle(toggle);
        return roomReply(room, `🔀 Shuffle: ${res ? "ON" : "OFF"}`);
      }

      case "master":
      case "masters": {
        const sub = (parts[0] || "list").toLowerCase();
        const targetName = parts.slice(1).join(" ").trim().replace(/^@/, "");
        const actorIsOwner = String(userPayload?.role || "").toLowerCase() === "owner";
        const actorIsMaster = isRoomMaster(room, userPayload?.username, userPayload?.userId);
        if (sub === "list" || sub === "show") {
          const masters = listRoomMasters(room);
          if (!masters.length) return roomReply(room, "👑 No bot masters configured for this room yet. The room owner who invited the bot becomes the first master.");
          return roomReplyLong(room, [`👑 BOT MASTERS • ${room}`, ...masters.map((m,i) => `${i+1}. @${m.username}${m.user_id ? ` (${m.user_id})` : ""}`)]);
        }
        if (!["add","remove","del","delete"].includes(sub)) return roomReply(room, "Usage: .master add <username> | .master remove <username> | .masters");
        if (!actorIsOwner && !actorIsMaster) return roomReply(room, "🔒 Only a room owner or existing bot master can manage bot masters.");
        if (!targetName) return roomReply(room, `Usage: .master ${sub === "add" ? "add" : "remove"} <username>`);
        if (sub === "add") {
          addRoomMaster(room, { username: targetName }, { username: userPayload?.username, userId: userPayload?.userId });
          return roomReply(room, `👑 @${targetName} is now a bot master for ${room}. They can control music in this room.`);
        }
        removeRoomMaster(room, targetName);
        return roomReply(room, `🧹 Removed @${targetName} from bot masters in ${room}.`);
      }

      case "dj": {
        const sub = (parts[0] || "").toLowerCase();
        const target = parts.slice(1).join(" ").trim().toLowerCase();
        if (sub === "on" || sub === "off" || sub === "add" || sub === "remove") {
          if (!isDjAdminOnly(userPayload)) return roomReply(room, "🔒 DJ configuration is restricted to the room owner/admin or bot owner.");
        }
        if (sub === "on") {
          djModeEnabled = true;
          setDjState(true, [...djUsers]);
          return roomReply(room, "🔒 DJ Mode enabled. Playback controls restricted to DJs/Admins.");
        }
        if (sub === "off") {
          djModeEnabled = false;
          setDjState(false, [...djUsers]);
          return roomReply(room, "🔓 DJ Mode disabled. Everyone can control music.");
        }
        if (sub === "add" && target) {
          djUsers.add(target);
          setDjUsers([...djUsers]);
          return roomReply(room, `🎧 Added @${target} as DJ.`);
        }
        if (sub === "remove" && target) {
          djUsers.delete(target);
          setDjUsers([...djUsers]);
          return roomReply(room, `🎧 Removed @${target} from DJs.`);
        }
        return roomReply(room, `🎧 DJ Mode: ${djModeEnabled ? "ON" : "OFF"}. DJs: ${djUsers.size ? Array.from(djUsers).join(", ") : "None"}`);
      }

      case "sleep": {
        if (!arg || arg === "off") {
          if (sleepTimer) { clearTimeout(sleepTimer); sleepTimer = null; }
          sleepTriggered = false;
          if (!sleepTimer) { manualVoiceStop = false; voiceRecoveryWanted = true; }
          return roomReply(room, "🌙 Sleep timer turned off.");
        }
        const mins = Number(parts[0]);
        if (isNaN(mins) || mins <= 0) return roomReply(room, "Usage: .sleep <minutes> or .sleep off");
        if (sleepTimer) clearTimeout(sleepTimer);
        sleepTriggered = false;
        sleepTimer = setTimeout(async () => {
          sleepTimer = null;
          sleepTriggered = true;
          manualVoiceStop = true;
          voiceRecoveryWanted = false;
          stopVoiceRecovery();
          stopVoiceHeartbeat();
          resetVoiceJoinState();
          log("[Sleep Timer] Firing sleep timer. Stopping playback and disconnecting...");
          youtubePlayer.stop();
          await voiceManager.disconnect();
          roomReply(room, "🌙 Sleep timer reached. Goodnight! Voice recovery is paused until you start music/join again.");
        }, mins * 60000);
        return roomReply(room, `🌙 Sleep timer set for ${mins} minutes.`);
      }

      case "247":
      case "alwayson":
      case "24/7": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change 24/7 mode.");
        const raw = String(parts[0] || "").toLowerCase();
        if (!["on", "off", "1", "0", "true", "false"].includes(raw)) {
          return roomReply(room, `♾️ 24/7 mode: ${alwaysOn ? "ON" : "OFF"}. Usage: .247 on|off`);
        }
        alwaysOn = raw === "on" || raw === "1" || raw === "true";
        saveSettings({ alwaysOn, autoResume });
        if (alwaysOn) {
          manualVoiceStop = false;
          voiceRecoveryWanted = true;
          resetIdleWatcher();
          if (!voiceManager.isConnected) requestVoiceJoin(room, true);
        }
        return roomReply(room, `♾️ 24/7 mode: ${alwaysOn ? "ON — bot will keep the voice session alive and recover automatically" : "OFF"}.`);
      }

      case "autoresume": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change auto-resume.");
        const raw = String(parts[0] || "").toLowerCase();
        if (!["on", "off", "1", "0", "true", "false"].includes(raw)) {
          return roomReply(room, `♻️ Auto-resume: ${autoResume ? "ON" : "OFF"}. Usage: .autoresume on|off`);
        }
        autoResume = raw === "on" || raw === "1" || raw === "true";
        saveSettings({ alwaysOn, autoResume });
        return roomReply(room, `♻️ Auto-resume after network voice loss: ${autoResume ? "ON" : "OFF"}.`);
      }

      case "recent": {
        const items = youtubePlayer.getRecentHistory().slice(0, Math.max(1, Math.min(15, Number(parts[0]) || 10)));
        if (!items.length) return roomReply(room, "📜 No recently played tracks.");
        return roomReplyLong(room, ["📜 RECENTLY PLAYED", ...items.map((t,i)=>`${i+1}. ${t.title} — ${t.artist || "YouTube"}`)]);
      }

      case "toptracks": {
        const items = topTracks(Number(parts[0]) || 10);
        if (!items.length) return roomReply(room, "🏆 No track statistics yet.");
        return roomReplyLong(room, ["🏆 TOP TRACKS", ...items.map((t,i)=>`${i+1}. ${t.title} — ${t.plays} plays`)]);
      }

      case "topusers": {
        const items = topUsers(Number(parts[0]) || 10);
        if (!items.length) return roomReply(room, "🏆 No user statistics yet.");
        return roomReply(room, ["🏆 TOP LISTENERS", ...items.map((t,i)=>`${i+1}. @${t.user} — ${t.plays} tracks`)].join("\n"));
      }

      case "userstats": {
        const who = parts.join(" ").trim() || userPayload.username || "User";
        const st = userStats(who);
        return roomReply(room, `👤 @${st.user} — commands: ${st.commands} | tracks requested: ${st.tracks}`);
      }

      case "qfind": {
        const q = parts.join(" ").toLowerCase().trim();
        if (!q) return roomReply(room, "Usage: .qfind <text>");
        const found = youtubePlayer.getQueue().map((t,i)=>({t,i})).filter(x=>String(x.t.title||"").toLowerCase().includes(q));
        if (!found.length) return roomReply(room, "🔎 No matching queue tracks.");
        return roomReplyLong(room, ["🔎 QUEUE SEARCH", ...found.slice(0,20).map(x=>`#${x.i+1}. ${x.t.title}`)]);
      }

      case "playlistremove": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs/Admins can edit playlists.");
        const pn = Number(String(parts[0] || "").replace(/^#/, "")); const tn = Number(String(parts[1] || "").replace(/^#/, ""));
        if (!pn || !tn) return roomReply(room, "Usage: .playlistremove <playlist_number> <track_number>");
        const result = updateCustomPlaylistByIndex(pn, pl => { if (tn < 1 || tn > pl.tracks.length) return null; pl.tracks.splice(tn-1,1); return pl; });
        return roomReply(room, result ? `🗑️ Removed track #${tn} from playlist #${pn} "${result.name}".` : "❌ Playlist or track number not found.");
      }

      case "playlistmove": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs/Admins can edit playlists.");
        const pn = Number(String(parts[0] || "").replace(/^#/, "")); const from = Number(String(parts[1] || "").replace(/^#/, "")); const to = Number(String(parts[2] || "").replace(/^#/, ""));
        if (!pn || !from || !to) return roomReply(room, "Usage: .playlistmove <playlist_number> <from_track> <to_track>");
        const result = updateCustomPlaylistByIndex(pn, pl => { if (from<1||to<1||from>pl.tracks.length||to>pl.tracks.length) return null; const [x]=pl.tracks.splice(from-1,1); pl.tracks.splice(to-1,0,x); return pl; });
        return roomReply(room, result ? `↔️ Moved track #${from} → #${to} in playlist #${pn}.` : "❌ Invalid playlist/track number.");
      }

      case "playlistrename": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs/Admins can edit playlists.");
        const pn = Number(String(parts[0] || "").replace(/^#/, "")); const name = parts.slice(1).join(" ").trim();
        if (!pn || !name) return roomReply(room, "Usage: .playlistrename <playlist_number> <new_name>");
        const result = updateCustomPlaylistByIndex(pn, pl => ({ ...pl, name }));
        return roomReply(room, result ? `✏️ Playlist #${pn} renamed to "${result.name}".` : "❌ Playlist not found.");
      }

      case "playnext": {
        const query = parts.join(" ").trim();
        if (!query) return roomReply(room, "Usage: .playnext <song>");
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can use playnext.");
        if (youtubePlayer.queue.length >= getQueueLimit()) return roomReply(room, `❌ Queue limit reached (${getQueueLimit()}).`);
        const track = await youtubePlayer.resolveTrack(query, userPayload.username || "User");
        if (!youtubePlayer.addTrackObject(track, { front: true })) return roomReply(room, `❌ Queue limit reached (${getQueueLimit()}).`);
        return roomReply(room, `⏭️ NEXT UP: ${track.title}`);
      }

      case "queue-limit":
      case "queuelimit": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change the queue limit.");
        const n = parts[0];
        if (!n) return roomReply(room, `📏 Queue limit: ${getQueueLimit()}`);
        const v = setQueueLimit(n); youtubePlayer.setQueueLimit(v);
        return roomReply(room, `📏 Queue limit set to ${v}.`);
      }

      case "crossfade":
      case "transition": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can change transitions.");
        if (!parts[0]) return roomReply(room, `🎚️ Transition fade: ${getTransitionSeconds()}s. Use .crossfade <0-30>`);
        const v = setTransitionSeconds(parts[0]);
        return roomReply(room, `🎚️ Transition fade set to ${v}s. Note: this build uses safe fade transitions; true overlapping crossfade is disabled to avoid duplicate LiveKit publishers.`);
      }

      case "voicehealth": {
        const pro = getProState();
        const h = voiceManager.getHealth();
        return roomReply(room, ["🎙️ VOICE HEALTH", `Room: ${room}`, `WebSocket: ${socket.connected ? "🟢 Connected" : "🔴 Disconnected"}`, `LiveKit: ${voiceManager.isConnected ? "🟢 Connected" : "🔴 Disconnected"}`, `Publisher: ${voiceManager.publishing ? "🟢 Active" : "🔴 Inactive"}`, `Audio source: ${voiceManager.audioSource ? "🟢 Ready" : "🔴 Missing"}`, `PCM frames: ${h.framesSent}`, `Last frame: ${h.lastFrameAt ? Math.round((Date.now()-h.lastFrameAt)/1000)+"s ago" : "never"}`, `Capture errors: ${h.captureErrors}`, `24/7: ${alwaysOn ? "ON" : "OFF"}`, `Auto-resume: ${autoResume ? "ON" : "OFF"}`, `Recovery: ${voiceRecoveryRunning ? "🟢 Running" : "⚪ Idle"}`, `Queue limit: ${pro.queueLimit}`].join("\n"));
      }

      case "doctor": {
        const { execFileSync } = await import("node:child_process");
        let ff = "❌ Missing";
        try { execFileSync(process.platform === "win32" ? "where.exe" : "which", ["ffmpeg"], { stdio: "ignore" }); ff = "🟢 Found"; } catch {}
        return roomReply(room, ["🩺 BOT DOCTOR", `OS: ${process.platform}/${process.arch}`, `Node: ${process.version}`, `FFmpeg: ${ff}`, `WebSocket: ${socket.connected ? "🟢" : "🔴"}`, `LiveKit: ${voiceManager.isConnected ? "🟢" : "🔴"}`, `Publisher: ${voiceManager.publishing ? "🟢" : "🔴"}`, `Queue: ${youtubePlayer.queue.length}/${getQueueLimit()}`].join("\n"));
      }

      case "schedules": {
        const list = listSchedules();
        if (!list.length) return roomReply(room, "⏰ No scheduled playback tasks.");
        return roomReply(room, ["⏰ SCHEDULES", ...list.map((x,i)=>`${i+1}. ${x.whenLabel || x.when} → ${x.query} (id ${x.id})`)].join("\n"));
      }

      case "schedule": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can schedule playback.");
        const raw = parts.join(" ").trim();
        const m = raw.match(/^(\d+)\s+(.+)$/);
        if (!m) return roomReply(room, "Usage: .schedule <minutes_from_now> <song/query>");
        const minutes = Number(m[1]); const query = m[2].trim();
        if (minutes < 1 || minutes > 10080) return roomReply(room, "⏰ Minutes must be 1-10080.");
        const item = { id: `${Date.now()}-${Math.random().toString(36).slice(2,8)}`, at: Date.now()+minutes*60000, whenLabel: `in ${minutes}m`, query, room };
        addSchedule(item); armSchedule(item);
        return roomReply(room, `⏰ Scheduled in ${minutes}m: ${query}`);
      }

      case "unschedule": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can remove schedules.");
        const item = listSchedules()[Number(parts[0])-1];
        if (!item) return roomReply(room, "Usage: .unschedule <schedule_number>");
        if (scheduleTimers.has(item.id)) { clearTimeout(scheduleTimers.get(item.id)); scheduleTimers.delete(item.id); }
        removeSchedule(item.id); return roomReply(room, `🗑️ Schedule removed: ${item.query}`);
      }

      case "stats":
      case "botstats": {
        const st = getStats();
        return roomReply(room, [
          "📊 TALKINCHAT MUSIC BOT STATS",
          `⏱️ Process uptime: ${formatUptime()}`,
          `🎵 Tracks played: ${st.tracksPlayed}`,
          `⌨️ Commands: ${st.commands}`,
          `🔄 WebSocket reconnects: ${st.reconnects}`,
          `♻️ Voice recoveries: ${st.voiceRecoveries}`,
          `🎙️ Voice failures: ${st.voiceFailures}`,
          `♾️ 24/7: ${alwaysOn ? "ON" : "OFF"} | ♻️ Auto-resume: ${autoResume ? "ON" : "OFF"}`,
          `🎶 Last track: ${st.lastTrack || "None"}`
        ].join("\n"));
      }

      case "welcome": {
        const toggle = parts[0] ? parts[0].toLowerCase() === "on" || parts[0] === "1" : !welcomeEnabled;
        welcomeEnabled = toggle;
        persistRuntimeState("welcome");
        return roomReply(room, `👋 Welcome greetings: ${welcomeEnabled ? "ON" : "OFF"}`);
      }

      case "queue":
      case "q": {
        const sub = String(parts[0] || "").toLowerCase();
        if (sub === "next" || sub === ">") {
          return roomReply(room, renderQueuePage(room, queuePage(room, 1)));
        }
        if (sub === "prev" || sub === "previous" || sub === "<") {
          return roomReply(room, renderQueuePage(room, queuePage(room, -1)));
        }
        const page = sub ? Number(sub) : (queuePageByRoom.get(room) || 1);
        return roomReply(room, renderQueuePage(room, page));
      }

      case "qnext":
      case "queuenext":
        return roomReply(room, renderQueuePage(room, queuePage(room, 1)));

      case "qprev":
      case "queueprev":
        return roomReply(room, renderQueuePage(room, queuePage(room, -1)));

      case "qpage": {
        const page = Number(parts[0] || 1);
        if (!Number.isInteger(page) || page < 1) return roomReply(room, "Usage: .qpage <page>");
        return roomReply(room, renderQueuePage(room, page));
      }

      case "clear":
      case "clearqueue":
      case "qclear":
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can clear queue.");
        const count = youtubePlayer.clearQueue();
        return roomReply(room, `🗑️ Cleared ${count} songs from the queue.`);

      case "move": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can move songs.");
        const from = Number(parts[0]);
        const to = Number(parts[1]);
        if (!youtubePlayer.moveQueue(from, to)) return roomReply(room, "Usage: .move <from_pos> <to_pos>");
        return roomReply(room, `↔️ Moved song from #${from} to #${to}.`);
      }

      case "remove":
      case "unqueue": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode: Only DJs can remove songs.");
        const n = Number(parts[0]);
        const removed = youtubePlayer.removeQueue(n);
        if (!removed) return roomReply(room, "Usage: .remove <queue_number>");
        return roomReply(room, `🗑️ Removed #${n}: "${removed.title}"`);
      }

      case "previous":
      case "prev":
      case "back": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode active. Only DJs/Admins can use previous.");
        const previous = await youtubePlayer.previous();
        if (!previous) return roomReply(room, "⏮️ No previous song is available yet.");
        return roomReply(room, `⏮️ PREVIOUS TRACK\n🎵 ${previous.title}\n⏱️ ${previous.duration || "Unknown"}\n📋 Queue: ${youtubePlayer.queue.length}`);
      }

      case "skip":
      case "next":
      case "s":
        if (!isDjOrAdmin(userPayload)) {
          return roomReply(room, "🔒 DJ Mode active. Use .voteskip to vote skip.");
        }
        if (!youtubePlayer.skip()) return roomReply(room, "⏭️ Nothing currently playing.");
        return roomReply(room, "⏭️ Skipped to next track.");

      case "pause":
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode active.");
        return roomReply(room, youtubePlayer.pause() ? "⏸️ Playback paused." : "⏸️ Nothing playing / already paused.");

      case "resume":
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode active.");
        return roomReply(room, youtubePlayer.resume() ? "▶️ Playback resumed." : "▶️ Nothing is paused.");

      case "stop":
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode active.");
        youtubePlayer.stop();
        if (sleepTimer) { clearTimeout(sleepTimer); sleepTimer = null; }
        sleepTriggered = false;
        manualVoiceStop = false;
        return roomReply(room, "⏹️ Playback stopped and queue cleared.");

      case "loop":
      case "repeat": {
        const mode = (parts[0] || "").toLowerCase();
        if (!mode) return roomReply(room, `🔁 Loop: ${youtubePlayer.loopMode}. Use .loop off|track|queue|playlist`);
        try {
          const selected = youtubePlayer.setLoop(mode);
          return roomReply(room, `🔁 Loop mode: ${selected.toUpperCase()}.`);
        } catch (err) {
          return roomReply(room, `Usage: .loop off | track | queue | playlist`);
        }
      }

      case "nowplaying":
      case "np": {
        const t = youtubePlayer.getNowPlaying();
        if (!t) return roomReply(room, "🎵 Nothing is currently playing.");
        const bar = youtubePlayer.getProgressBar(10);
        return roomReply(room, `🎵 NOW PLAYING\n${t.title}\n${bar}\n👤 ${t.requestedBy || "User"} | 🔊 ${Math.round(voiceManager.volume * 100)}% | 🔁 ${youtubePlayer.loopMode}\n🎛️ ${voiceManager.getFilterSummary()}\n📋 Queue: ${youtubePlayer.queue.length}`);
      }

      case "volume":
      case "vol": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode active.");
        if (!parts[0]) return roomReply(room, `🔊 Volume: ${Math.round(voiceManager.volume * 100)}% | Usage: .volume 0-100 | .volume +10/-10`);
        const rawVolume = String(parts[0]).trim().toLowerCase();
        let n;
        if (/^[+-]\d+(?:\.\d+)?$/.test(rawVolume)) n = Math.round(voiceManager.volume * 100) + Number(rawVolume);
        else if (/^max$/.test(rawVolume)) n = 100;
        else if (/^min$|^mute$/.test(rawVolume)) n = 0;
        else n = Number(rawVolume);
        if (!Number.isFinite(n) || n < 0 || n > 100) return roomReply(room, "Usage: .volume 0-100 | .volume +10/-10 | .volume max|min");
        voiceManager.setVolume(n / 100);
        return roomReply(room, `🔊 Volume: ${Math.round(n)}% (applied immediately)`);
      }

      case "mute": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode active.");
        voiceManager.mute();
        return roomReply(room, "🔇 Muted immediately. Use .unmute to restore the previous volume.");
      }

      case "unmute": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode active.");
        voiceManager.unmute();
        return roomReply(room, `🔊 Unmuted: ${Math.round(voiceManager.volume * 100)}% (applied immediately).`);
      }

      case "eta": {
        const n = Number(parts[0]) || 1;
        const q = youtubePlayer.getQueue();
        if (!q.length) return roomReply(room, "⏳ Queue is empty.");
        if (!Number.isInteger(n) || n < 1 || n > q.length) return roomReply(room, `Usage: .eta <queue_number> (1-${q.length})`);
        return roomReply(room, `⏳ Queue #${n} ETA: ${formatEta(youtubePlayer.getQueueEtaSeconds(n))} • 🎵 ${q[n - 1].title}`);
      }

      case "streamstatus":
      case "voicestatus": {
        return roomReply(room, `📡 VOICE STATUS\nRoom: ${room}\nLiveKit: ${voiceManager.isConnected ? "🟢 Connected" : "🔴 Disconnected"}\nPublishing: ${voiceManager.publishing ? "🟢 Yes" : "🔴 No"}\nServer streaming flag: ${lastKnownStreaming ? "🟢 ON" : "⚪ Unknown/Off"}\nRecovery: ${voiceRecoveryRunning ? "♻️ Active (5s retry)" : "⏹️ Idle"}`);
      }

      case "streamrefresh":
      case "refreshvoice": {
        const refreshed = await refreshStreamVisibility(room, 'manual .streamrefresh');
        refreshVoiceDirectory(room);
        return roomReply(room, refreshed
          ? "🔄 Voice/Active server state synchronized. The app will show the room when ChatP broadcasts the updated streaming state."
          : "⏳ Voice/Active synchronization is already in progress; server stream state was checked.");
      }

      case "streamupgrade":
      case "upgrade-streaming": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode active.");
        const duration = String(parts[0] || process.env.STREAM_UPGRADE_DURATION || "30");
        if (!['1','7','30'].includes(duration)) return roomReply(room, "Usage: .streamupgrade <1|7|30>");
        try {
          client.upgradeStreaming(room, duration);
          return roomReply(room, `📡 Streaming service upgrade requested for ${duration} day(s). Waiting for ChatP stream_enabled...`);
        } catch (err) {
          return roomReply(room, `❌ Streaming upgrade failed: ${err.message}`);
        }
      }

      case "rejoinvoice":
      case "rejoin": {
        sleepTriggered = false;
        manualVoiceStop = false;
        clearStreamDirectoryTimers();
        voiceRecoveryWanted = true;
        stopVoiceRecovery();
        resetVoiceJoinState();
        if (voiceManager.isConnected) await voiceManager.disconnect();
        requestVoiceJoin(room, true);
        return roomReply(room, "♻️ Voice reconnect started. It retries with a fixed 5-second recovery interval until connected.");
      }

      case "profile": {
        const sub=String(parts.shift()||'').toLowerCase(); const name=parts.join(' ').trim();
        if(sub==='save' && name){ const x=saveAudioProfile(name,voiceManager.getFilters(),username || userId || "global"); return roomReply(room,`🎛️ Audio profile saved: ${x.name}`); }
        if(sub==='load' && name){ const x=getAudioProfile(name,username || userId || "global"); if(!x) return roomReply(room,'❌ Audio profile not found.'); await applyFilterChange("profile-load", () => voiceManager.setFilters(x.filters)); return roomReply(room,`🎛️ Audio profile loaded: ${x.name}${youtubePlayer.currentTrack ? ' | applied now' : ''}`); }
        if(sub==='list') return roomReply(room,`🎛️ Profiles: ${listAudioProfiles(username || userId || "global").map((x,i)=>`${i+1}. ${x.name}`).join(' | ')||'None'}`);
        return roomReply(room,'Usage: .profile save <name> | .profile load <name> | .profile list');
      }
      case "songfx": {
        const sub=String(parts.shift()||'').toLowerCase(); const name=parts.join(' ').trim(); const t=youtubePlayer.currentTrack;
        if(!t) return roomReply(room,'❌ Nothing is playing.');
        if(sub==='save') { saveSongSettings(t,voiceManager.getFilters()); return roomReply(room,'💾 Current FX saved for this song.'); }
        if(sub==='load') { const x=getSongSettings(t); if(!x) return roomReply(room,'ℹ️ No saved FX for this song.'); await applyFilterChange("songfx-load", () => voiceManager.setFilters(x)); return roomReply(room,'🎛️ Saved song FX loaded and applied now.'); }
        return roomReply(room,'Usage: .songfx save | .songfx load');
      }
      case "radiopreset": {
        const sub=String(parts.shift()||'').toLowerCase(); const name=String(parts.shift()||'').trim(); const query=parts.join(' ').trim();
        if(sub==='save'&&name&&query){ saveRadioPreset(name,query); return roomReply(room,`📻 Radio preset saved: ${name}`); }
        if(sub==='delete'&&name){ return roomReply(room,removeRadioPreset(name)?`🗑️ Radio preset deleted: ${name}`:'❌ Preset not found.'); }
        return roomReply(room,'Usage: .radiopreset save <name> <query> | .radiopreset delete <name>');
      }
      case "voteconfig": {
        const sub=String(parts.shift()||'').toLowerCase(); if(sub==='show'||!sub){ const v=getVoteConfig(); return roomReply(room,`🗳️ Vote: ${v.enabled?'ON':'OFF'} • ${v.percent}% • min ${v.minVotes} • ${Math.round(v.durationMs/1000)}s`); }
        if(!isDjOrAdmin(userPayload)) return roomReply(room,'🔒 DJ Mode active.');
        const v=getVoteConfig(); if(sub==='on'||sub==='off') v.enabled=sub==='on'; else if(sub==='percent') v.percent=Math.max(1,Math.min(100,Number(parts[0])||50)); else if(sub==='min') v.minVotes=Math.max(1,Math.floor(Number(parts[0])||2)); else if(sub==='time') v.durationMs=Math.max(5000,Math.min(120000,(Number(parts[0])||30)*1000)); else return roomReply(room,'Usage: .voteconfig on|off|percent N|min N|time seconds');
        setVoteConfig(v); return roomReply(room,'🗳️ Vote configuration updated.');
      }
      case "userprofile": {
        const sub=String(parts.shift()||'').toLowerCase(); const val=parts.join(' ').trim(); const who=username||'User';
        if(sub==='set'&&val){ setUserProfile(who,{label:val}); return roomReply(room,`👤 Profile updated for ${who}.`); }
        const x=getUserProfile(who); return roomReply(room,`👤 ${who} profile: ${x.label||'No custom profile'} • tracks ${userStats(who).tracks}`);
      }
      case "netdiag": {
        const dns = await import('node:dns/promises');
        const targets=['chatp.net','media.chatp.net']; const out=[];
        for(const host of targets){ const t=Date.now(); try { const r=await dns.lookup(host); out.push(`🟢 ${host} → ${r.address} (${Date.now()-t}ms)`); } catch(e){ out.push(`🔴 ${host} → ${e.message}`); } }
        return roomReply(room,['🌐 NETWORK DIAGNOSTICS',...out,`WebSocket: ${socket.connected?'🟢 connected':'🔴 disconnected'}`,`LiveKit: ${voiceManager.isConnected?'🟢 connected':'🔴 disconnected'}`].join('\n'));
      }
      case "selftest": {
        const h=voiceManager.getHealth(); const checks=[['WebSocket',socket.connected],['Queue',Array.isArray(youtubePlayer.queue)],['Voice publisher',!voiceManager.isConnected||h.publishing],['Audio source',!voiceManager.isConnected||h.source]];
        return roomReply(room,['🧪 SELF TEST',...checks.map(([n,v])=>`${v?'🟢':'🔴'} ${n}`),`Result: ${checks.every(x=>x[1])?'PASS':'CHECK REQUIRED'}`].join('\n'));
      }
      case "recommend":
      case "recommendations":
      case "related": {
        if (!youtubePlayer.currentTrack) return roomReply(room, "❌ Nothing is playing. Start a song first.");
        const mode = cmd === "related" ? "hybrid" : "hybrid";
        try { const rows = await youtubePlayer.smartDiscover(Math.max(5, Math.min(15, Number(parts[0]) || 10)), mode); return roomReplyLong(room, ["🧠 SMART RECOMMENDATIONS", ...rows.map((x,i)=>`${i+1}. ${x.title} — ${x.artist || "YouTube"}`), "", "Use .radio to queue these automatically."]); } catch (e) { return roomReply(room, `❌ Recommendation failed: ${e.message}`); }
      }
      case "autodjmode":
      case "smartdj": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode active.");
        const mode = String(parts[0] || "hybrid").toLowerCase();
        const valid = ["hybrid","artist","genre","mood","related","recommended"];
        if (!valid.includes(mode)) return roomReply(room, `Usage: .autodjmode <${valid.join("|")}>`);
        youtubePlayer.setAutoDjMode(mode);
        saveSettings({ radio: { ...loadSettings().radio, seedMode: mode }, automation: { ...loadSettings().automation, autoDj: true } });
        return roomReply(room, `🤖 AutoDJ discovery mode saved: ${mode}.`);
      }
      case "radioartist":
      case "radiogenre":
      case "radiomood":
      case "radiorelated": {
        if (!isDjOrAdmin(userPayload)) return roomReply(room, "🔒 DJ Mode active.");
        if (!parts.length && !youtubePlayer.currentTrack) return roomReply(room, `Usage: .${cmd} <artist/genre/mood/query>`);
        const seed = parts.length ? await youtubePlayer.resolveTrack(parts.join(" "), username || "User") : youtubePlayer.currentTrack;
        if (!seed) return roomReply(room,"❌ Nothing to use as a radio seed.");
        if (!youtubePlayer.currentTrack) await youtubePlayer.playTrackObject(seed, "radio-seed", 0, { announce:false });
        try { const mode = cmd === "radioartist" ? "artist" : "hybrid"; const rows=await youtubePlayer.smartDiscover(12, mode, seed); let added=0; const seen=new Set([youtubePlayer.currentTrack?.url,...youtubePlayer.queue.map(x=>x?.url)]); for(const x of rows){if(!x.url||seen.has(x.url))continue;if(!youtubePlayer.addTrackObject({...x,requestedBy:"Smart Radio"}))break;seen.add(x.url);added++;} youtubePlayer.setAutoplay(true); persistRuntimeState(cmd); return roomReply(room,`📻 ${cmd}: queued ${added} smart tracks.`); } catch(e){return roomReply(room,`❌ ${cmd} failed: ${e.message}`);}
      }
      case "queuefill": {
        if (!youtubePlayer.currentTrack) return roomReply(room,"❌ Nothing is playing.");
        const n=Math.max(1,Math.min(20,Number(parts[0])||5)); const rows=await youtubePlayer.smartDiscover(n+5,"hybrid"); let added=0; const seen=new Set([youtubePlayer.currentTrack?.url,...youtubePlayer.queue.map(x=>x?.url),...youtubePlayer.recentHistory.map(x=>x?.url)]); for(const x of rows){if(!x.url||seen.has(x.url))continue;if(!youtubePlayer.addTrackObject({...x,requestedBy:"Queue Fill"}))break;seen.add(x.url);added++;if(added>=n)break;} return roomReply(room,`🧠 Queue Fill: added ${added} smart tracks.`);
      }
      case "persist": case "saveall": case "savesettings": { persistRuntimeState("manual"); flushPro(); flushAdvanced(); flushStats(); return roomReply(room,"💾 All runtime settings, playback state and feature state flushed to disk."); }
      case "settingsdump": case "state": { const st=loadSettings(); return roomReplyLong(room,["💾 PERSISTED SETTINGS",JSON.stringify(st,null,2).slice(0,6500)]); }
      case "volup": { voiceManager.setVolume(Math.min(1,voiceManager.volume+0.05)); return roomReply(room,`🔊 Volume ${Math.round(voiceManager.volume*100)}%`); }
      case "voldown": { voiceManager.setVolume(Math.max(0,voiceManager.volume-0.05)); return roomReply(room,`🔉 Volume ${Math.round(voiceManager.volume*100)}%`); }
      case "mute": { voiceManager.mute(); return roomReply(room,"🔇 Muted."); }
      case "unmute": { voiceManager.unmute(); return roomReply(room,`🔊 Unmuted at ${Math.round(voiceManager.volume*100)}%.`); }
      case "fxreset": case "cleanfX": case "cleanfx": { await applyFilterChange("fx-reset",()=>voiceManager.clearFilters()); return roomReply(room,"🎛️ All audio FX reset."); }
      case "now": case "np": { const t=youtubePlayer.currentTrack; return roomReply(room,t?`🎵 ${t.title} — ${t.artist||"YouTube"} | ${t.duration||"?"}`:"🎵 Nothing playing."); }
      case "eta": { return roomReply(room,`⏳ ${formatEta(youtubePlayer.getRemainingSeconds?.()||0)} remaining.`); }
      case "qtime": { return roomReply(room,`⏱️ Queue duration: ${formatEta(youtubePlayer.getQueueDurationSeconds())}`); }
      case "qcount": { return roomReply(room,`📋 Queue: ${youtubePlayer.queue.length}/${youtubePlayer.queueLimit}`); }
      case "clearhistory": { const n=youtubePlayer.clearHistory(); return roomReply(room,`🧹 Cleared ${n} history entries.`); }
      case "replaylast": { const x=await youtubePlayer.replay(1); return roomReply(room,x?`🔁 Replaying: ${x.title}`:"❌ No history."); }
      case "speedup": { const x=voiceManager.setSpeed(Math.min(2,voiceManager.filters.speed+0.05)); await applyFilterChange("speedup",()=>x); return roomReply(room,`⏩ Speed ${x.toFixed(2)}x`); }
      case "speeddown": { const x=voiceManager.setSpeed(Math.max(.5,voiceManager.filters.speed-0.05)); await applyFilterChange("speeddown",()=>x); return roomReply(room,`⏪ Speed ${x.toFixed(2)}x`); }
      case "pitchup": { const x=voiceManager.setPitch(Math.min(12,voiceManager.filters.pitch+1)); await applyFilterChange("pitchup",()=>x); return roomReply(room,`🎚️ Pitch +${x}st`); }
      case "pitchdown": { const x=voiceManager.setPitch(Math.max(-12,voiceManager.filters.pitch-1)); await applyFilterChange("pitchdown",()=>x); return roomReply(room,`🎚️ Pitch ${x}st`); }
      case "bassup": { const x=voiceManager.setBassBoost("high"); await applyFilterChange("bassup",()=>x); return roomReply(room,"🔊 Bass Boost HIGH"); }
      case "bassdown": { const x=voiceManager.setBassBoost("low"); await applyFilterChange("bassdown",()=>x); return roomReply(room,"🔉 Bass Boost LOW"); }
      case "trebleup": { const x=voiceManager.setTreble(Math.min(12,voiceManager.filters.treble+2)); await applyFilterChange("trebleup",()=>x); return roomReply(room,`🎚️ Treble ${x>0?"+":""}${x}dB`); }
      case "trebledown": { const x=voiceManager.setTreble(Math.max(-12,voiceManager.filters.treble-2)); await applyFilterChange("trebledown",()=>x); return roomReply(room,`🎚️ Treble ${x>0?"+":""}${x}dB`); }
      case "8don": { await applyFilterChange("8d-on",()=>voiceManager.setEightD(true)); return roomReply(room,"🌀 8D ON"); }
      case "8doff": { await applyFilterChange("8d-off",()=>voiceManager.setEightD(false)); return roomReply(room,"🌀 8D OFF"); }
      case "8dspeed": { const x=voiceManager.setEightDSpeed(parts[0]||.11); await applyFilterChange("8d-speed",()=>x); return roomReply(room,`🌀 8D speed ${x}`); }
      case "wideon": { await applyFilterChange("wide-on",()=>voiceManager.setWide(true)); return roomReply(room,"↔️ Wide stereo ON"); }
      case "wideoff": { await applyFilterChange("wide-off",()=>voiceManager.setWide(false)); return roomReply(room,"↔️ Wide stereo OFF"); }
      case "monoon": { await applyFilterChange("mono-on",()=>voiceManager.setMono(true)); return roomReply(room,"🔘 Mono ON"); }
      case "monooff": { await applyFilterChange("mono-off",()=>voiceManager.setMono(false)); return roomReply(room,"🔘 Mono OFF"); }
      case "echoon": { await applyFilterChange("echo-on",()=>voiceManager.setEcho(true)); return roomReply(room,"🏛️ Echo ON"); }
      case "echooff": { await applyFilterChange("echo-off",()=>voiceManager.setEcho(false)); return roomReply(room,"🏛️ Echo OFF"); }
      case "reverbon": { await applyFilterChange("reverb-on",()=>voiceManager.setReverb(true)); return roomReply(room,"🌌 Reverb ON"); }
      case "reverboff": { await applyFilterChange("reverb-off",()=>voiceManager.setReverb(false)); return roomReply(room,"🌌 Reverb OFF"); }
      case "compressor": { const on=String(parts[0]||"on")!=="off"; await applyFilterChange("compressor",()=>voiceManager.setCompressor(on)); return roomReply(room,`🗜️ Compressor ${on?"ON":"OFF"}`); }
      case "limiter": { const on=String(parts[0]||"on")!=="off"; await applyFilterChange("limiter",()=>voiceManager.setLimiter(on)); return roomReply(room,`🧱 Limiter ${on?"ON":"OFF"}`); }
      case "normalize": { const on=String(parts[0]||"on")!=="off"; await applyFilterChange("normalize",()=>voiceManager.setNormalize(on)); return roomReply(room,`📏 Normalize ${on?"ON":"OFF"}`); }
      case "nightmode": { const on=String(parts[0]||"on")!=="off"; await applyFilterChange("nightmode",()=>voiceManager.setNightMode(on)); return roomReply(room,`🌙 Night Mode ${on?"ON":"OFF"}`); }
      case "karaoke": { const on=String(parts[0]||"on")!=="off"; await applyFilterChange("karaoke",()=>voiceManager.setKaraoke(on)); return roomReply(room,`🎤 Karaoke ${on?"ON":"OFF"}`); }
      case "lofi": { const on=String(parts[0]||"on")!=="off"; await applyFilterChange("lofi",()=>voiceManager.setLofi(on)); return roomReply(room,`📼 Lo-Fi ${on?"ON":"OFF"}`); }
      case "tremolo": { const on=String(parts[0]||"on")!=="off"; await applyFilterChange("tremolo",()=>voiceManager.setTremolo(on)); return roomReply(room,`〰️ Tremolo ${on?"ON":"OFF"}`); }
      case "chorus": { const on=String(parts[0]||"on")!=="off"; await applyFilterChange("chorus",()=>voiceManager.setChorus(on)); return roomReply(room,`🎚️ Chorus ${on?"ON":"OFF"}`); }
      case "flanger": { const on=String(parts[0]||"on")!=="off"; await applyFilterChange("flanger",()=>voiceManager.setFlanger(on)); return roomReply(room,`🎛️ Flanger ${on?"ON":"OFF"}`); }
      case "vibrato": { const on=String(parts[0]||"on")!=="off"; await applyFilterChange("vibrato",()=>voiceManager.setVibrato(on)); return roomReply(room,`🎶 Vibrato ${on?"ON":"OFF"}`); }
      case "crystalizer": case "crystallizer": { const on=String(parts[0]||"on")!=="off"; await applyFilterChange("crystalizer",()=>voiceManager.setCrystalizer(on)); return roomReply(room,`💎 Crystalizer ${on?"ON":"OFF"}`); }
      case "haas": { const on=String(parts[0]||"on")!=="off"; await applyFilterChange("haas",()=>voiceManager.setHaas(on)); return roomReply(room,`🎧 Haas ${on?"ON":"OFF"}`); }
      case "deesser": case "de-esser": { const on=String(parts[0]||"on")!=="off"; await applyFilterChange("deesser",()=>voiceManager.setDeesser(on)); return roomReply(room,`🎙️ De-esser ${on?"ON":"OFF"}`); }
      case "basscut": { const on=String(parts[0]||"on")!=="off"; await applyFilterChange("basscut",()=>voiceManager.setBassCut(on)); return roomReply(room,`✂️ Bass Cut ${on?"ON":"OFF"}`); }

      case "autodj": {
        const v = String(parts[0] || '').toLowerCase();
        const on = ["on","enable","enabled","1","true"].includes(v) ? true : ["off","disable","disabled","0","false"].includes(v) ? false : youtubePlayer.autoplay;
        youtubePlayer.setAutoplay(on);
        if (on && youtubePlayer.currentTrack) void youtubePlayer.refillSmartQueue?.(4);
        persistRuntimeState("autodj");
        return roomReply(room, `🤖 Auto-DJ: ${on ? "ON — related artist/music discovery" : "OFF"}.`);
      }

      case "smartshuffle": {
        youtubePlayer.smartShuffle();
        return roomReply(room, `🧠 Smart Shuffle applied to ${youtubePlayer.queue.length} queued track(s).`);
      }

      case "queueinfo": {
        return roomReply(room, `📋 QUEUE INFO\nTracks: ${youtubePlayer.queue.length}/${getQueueLimit()}\nDuration: ${formatEta(youtubePlayer.getQueueDurationSeconds())}\nCurrent: ${youtubePlayer.currentTrack?.title || "Nothing"}`);
      }

      case "uptime": {
        const sec = Math.floor((Date.now() - process.uptime() * 1000) / 1000);
        return roomReply(room, `⏱️ Uptime: ${formatEta(Math.floor(process.uptime()))}\nVoice: ${voiceManager.isConnected ? "🟢 connected" : "🔴 disconnected"}`);
      }

      case "cache": {
        const info = youtubePlayer.getAudioCacheInfo?.() || { count: 0, limit: 0, entries: [] };
        if (!parts[0] || parts[0].toLowerCase() === 'list' || parts[0].toLowerCase() === 'info') {
          const current = youtubePlayer.currentTrack ? youtubePlayer.getTrackKey?.(youtubePlayer.currentTrack) : 'none';
          return roomReplyLong(room, [`💾 AUDIO CACHE`, `Entries: ${info.count}/${info.limit}`, `Current: ${current}`, ...info.entries.slice(0,8).map((x,i)=>`${i+1}. ${x.key}`), `Use .cache clear (DJ/Admin) to remove cached files.`]);
        }
        if (parts[0].toLowerCase() === 'clear') {
          if (!isDjOrAdmin(userPayload)) return roomReply(room, '🔒 DJ/Admin only.');
          const n = await youtubePlayer.clearAudioCache?.();
          return roomReply(room, `🧹 Removed ${Number(n)||0} cached audio file(s).`);
        }
        return roomReply(room, 'Usage: .cache | .cache clear');
      }

      case "source":
      case "sourceinfo": {
        const t = youtubePlayer.currentTrack;
        if (!t) return roomReply(room, '🎵 Nothing is currently playing.');
        const info = youtubePlayer.getAudioCacheInfo?.() || { entries: [] };
        const cached = info.entries.some(x => x.key === youtubePlayer.getTrackKey?.(t));
        return roomReply(room, [`🎚️ SOURCE INFO`, `🎵 ${t.title}`, `Artist: ${t.artist || 'YouTube'}`, `Quality: ${youtubePlayer.getAudioQuality?.() || 'highest'}`, `Format selector: ${youtubePlayer.getAudioQualityFormat?.() || 'unknown'}`, `Source: ${cached ? '💾 local cached audio' : '🌐 direct YouTube audio'}`, `LiveKit: ${voiceManager.publishing ? '🟢 publishing' : '🔴 not publishing'}`].join('\n'));
      }

      case "latency": {
        const h = voiceManager.getHealth?.() || {};
        const frameAge = h.lastFrameAt ? Math.max(0, Math.round((Date.now() - Number(h.lastFrameAt))/1000)) : null;
        return roomReply(room, [`📶 BOT LATENCY / HEALTH`, `WebSocket: ${socket.connected ? '🟢 connected' : '🔴 disconnected'}`, `LiveKit: ${voiceManager.isConnected ? '🟢 connected' : '🔴 disconnected'}`, `Publisher: ${voiceManager.publishing ? '🟢 active' : '🔴 inactive'}`, `PCM: ${frameAge === null ? 'waiting' : `${frameAge}s since last frame`}`, `Capture errors: ${h.captureErrors || 0}`, `Queue: ${youtubePlayer.queue.length}/${youtubePlayer.queueLimit}`].join('\n'));
      }

      case "roominfo": {
        return roomReply(room, [`🏠 ROOM INFO`, `Room: ${room}`, `Bot role: ${botRole || 'unknown'}`, `Bot owner access: ${requireBotOwner ? (requireBotOwner(room, false) ? '🟢 allowed' : '🔴 blocked') : 'unknown'}`, `Masters: ${(listRoomMasters(room)||[]).map(x => '@'+x.username).join(', ') || 'none'}`, `DJ mode: ${djModeEnabled ? 'ON' : 'OFF'}`, `AutoDJ: ${youtubePlayer.autoplay ? 'ON' : 'OFF'}`, `Radio: ${youtubePlayer.radioEnabled ? 'ON' : 'OFF'}`].join('\n'));
      }

      case "controllers":
      case "controller": {
        const masters = listRoomMasters(room) || [];
        return roomReplyLong(room, [`🎛️ ROOM CONTROLLERS — ${room}`, `Bot masters: ${masters.map(x => '@'+x.username).join(', ') || 'none'}`, `DJ users: ${djUsers.size ? [...djUsers].map(x=>'@'+x).join(', ') : 'none'}`, `Room owner/admin controls are always accepted.`]);
      }

      case "version":
      case "about": {
        return roomReply(room, '🎵 TalkInChat Music Bot v5.5.8 • Multi-room • SQLite • async command engine • Smart AutoDJ/Radio • LiveKit Hi-Fi audio');
      }

      case "features": {
        return roomReply(room,['🚀 FEATURE STATUS','Audio Engine: profiles • per-song FX • speed • pitch • bass/treble • 8D','Radio: Smart Radio • Smart Shuffle • Auto-DJ • presets • scheduled playback • queue info','Voice: APK Voice/Active sync • instant LiveKit • publisher-only credentials • watchdog • stale-session cleanup • session IDs • single-flight invite guard • fixed 5s recovery','Reliability: resume snapshots • crash recovery • recovery journal • circuit-safe single-flight invites','Community: user profiles • points • achievements • leaderboards • favorites • stats • DJ controls','Automation: scheduled radio • midnight backups • queue persistence • room profiles • plugin hooks','Tools: diagnostics • self-test • structured recovery logs • multilingual commands • voice commands','Cross-platform: Windows • Debian • Termux • Node.js 18+'].join('\n'));
      }
      case "leaderboard": {
        const rows=leaderboard(10); return roomReplyLong(room,["🏆 LEADERBOARD",...rows.map((x,i)=>`${i+1}. ${x.user} — ${x.points} pts • ${x.plays} plays • ${x.badges.length} badges`)]);
      }
      case "points": { const x=communityProfile(username||userId||"User"); return roomReply(room,`💰 ${username||"User"}: ${x.points} points • ${x.plays} plays • badges: ${x.badges.join(", ")||"none"}`); }
      case "achievements": { const a=achievements(username||userId||"User"); return roomReply(room,`🏅 Achievements: ${a.join(", ")||"none yet"}`); }
      case "reward": { if(!isDjOrAdmin(userPayload)) return roomReply(room,"🔒 DJ/Admin only."); const n=Math.max(1,Math.min(1000,Number(parts[0])||10)); rewardPoints(parts[1]||username,n); return roomReply(room,`🎁 Awarded ${n} points.`); }
      case "recovery": { return roomReply(room, `♻️ RECOVERY ${voiceRecoveryRunning ? "RUNNING" : "IDLE"}\nAttempts: ${recoveryAttempt}\nMode: single fixed-5s recovery state machine`); }
      case "backup": { if(!isDjOrAdmin(userPayload)) return roomReply(room,"🔒 DJ/Admin only."); const f=manualBackup("command"); return roomReply(room,`💾 Backup created: ${f.split(/[\\/]/).pop()}`); }
      case "system": return roomReplyLong(room,["🛠️ SYSTEM",JSON.stringify(systemInfo(),null,2)]);
      case "lang": { const l=(parts[0]||'').toLowerCase(); if(!languages().includes(l)) return roomReply(room,`🌐 Languages: ${languages().join(', ')}`); runtimeStore.patch({language:l}); return roomReply(room,`🌐 Language set to ${l}.`); }
      case "debug": { if(!isDjOrAdmin(userPayload)) return roomReply(room,"🔒 DJ/Admin only."); const enabled = (parts[0]||'on')!=='off'; runtimeStore.patch({debug:enabled}); config.debug = enabled; setLoggerDebugEnabled(enabled); return roomReply(room,`🐞 Debug ${enabled?'ON':'OFF'}.`); }
      case "hook": { if(!isDjOrAdmin(userPayload)) return roomReply(room,"🔒 DJ/Admin only."); await hooks.run(parts[0]||'manual',{room,userPayload}); return roomReply(room,"🪝 Hook dispatched."); }
      case "session": return roomReply(room,`🔐 Session: ${sessionGuard.current?.id||'none'} • generation ${sessionGuard.generation}`);
      case "status":
        return roomReply(room, `📡 Room: ${room} | Voice: ${voiceManager.isConnected ? "🟢 Connected" : "🔴 Disconnected"}\nNow: ${youtubePlayer.currentTrack?.title || "None"}\nQueue: ${youtubePlayer.queue.length} | FX: ${voiceManager.getFilterSummary()}`);

      default:
        return roomReply(room, `Unknown command: .${cmd}. Send .help for commands.`);
    }
  }

  handleRoomCommand = async function(payload) {
    const raw = payload.text.slice(1).trim();
    const m = raw.match(/^(?:play|playqueue|queueplay)\s+#?(\d+)$/i);
    if (m) {
      if (masterOnly && !isRoomController(payload)) return roomReply(payload.room, "🔒 Only the room bot masters or room owner/admin can control playback.");
      if (requireOwnerForPlayback && !requireBotOwner(payload.room, false)) return roomReply(payload.room, "⛔ Bot playback is disabled because the bot is not OWNER in this room.");
      const n = Number(m[1]);
      if (!Number.isInteger(n) || n < 1 || n > youtubePlayer.queue.length) return roomReply(payload.room, `❌ Queue item #${n} does not exist.`);
      const track = await youtubePlayer.playQueueIndex(n);
      if (!track) return roomReply(payload.room, `❌ Queue item #${n} does not exist.`);
      await roomReply(payload.room, `🎵 NOW PLAYING QUEUE #${n}\n${track.title}\n⏱️ ${track.duration} | 👤 ${payload.username || "User"}`);
      return;
    }
    return dispatchRoomCommand(payload);
  };

  let hadConnectedOnce = false;
  socket.on("connected", () => {
    const wsGeneration = ++wsRecoveryGeneration;
    if (wsRecoveryTimer) { clearTimeout(wsRecoveryTimer); wsRecoveryTimer = null; }
    if (hadConnectedOnce) incrementStat("reconnects");
    hadConnectedOnce = true;
    if (!client.currentRoom) return;
    const reconnectRoom = client.currentRoom;
    log(`[Main] WebSocket connected/reconnected. Restoring text room "${reconnectRoom}"...`);

    // Every WebSocket session gets a fresh publisher invitation. Never reuse
    // a token/session from the dead socket.
    clearStreamDirectoryTimers();
    resetVoiceJoinState();
    lastOwnJoinStreamSession = "";
    lastOwnJoinStreamLogAt = 0;
    recoveryAttempt = 0;
    recoveryResetDone = false;
    selfJoinStreamSeenAt = 0;
    lastOwnJoinStreamSession = "";
    lastOwnJoinStreamLogAt = 0;
    voiceRecoveryWanted = !manualVoiceStop;
    lastVoiceRoom = reconnectRoom;
    try { client.roomJoin(reconnectRoom); } catch (err) {
      log(`[Main] Text-room rejoin request failed: ${err.message}`);
    }

    // Wait for the server to process room_join, then request the publisher
    // invitation. We also retry below if the first request gets no response.
    if (!manualVoiceStop && (alwaysOn || voiceRecoveryWanted)) {
      wsRecoveryTimer = setTimeout(() => {
        wsRecoveryTimer = null;
        if (wsGeneration !== wsRecoveryGeneration) return;
        if (socket.connected && !manualVoiceStop && !voiceManager.isConnected && client.currentRoom === reconnectRoom) {
          log(`[Voice] WebSocket recovery: resetting stale stream session and requesting fresh credentials for "${reconnectRoom}".`);
          void resetServerStreamForRecovery(reconnectRoom).then(() => {
            if (wsGeneration !== wsRecoveryGeneration) return;
            if (socket.connected && !manualVoiceStop && !voiceManager.isConnected && client.currentRoom === reconnectRoom) {
              requestVoiceJoin(reconnectRoom, true);
            }
          }).catch(err => debug("[Voice] WebSocket recovery reset failed:", err.message));
        }
      }, 2500);
      wsRecoveryTimer.unref?.();
    }
  });

  // Fresh process startup: join the configured text room and automatically
  // start the 24/7 voice publisher. This makes .247 effectively ON by default.
  if (defaultRoom) {
    const room = defaultRoom.trim();
    restoreRoomRuntime(room);
    client.currentRoom = room;
    lastVoiceRoom = room;
    voiceRecoveryWanted = !manualVoiceStop;
    log(`[Main] Auto-joining configured room: ${room} ...`);
    client.roomJoin(room);
    if (alwaysOn && (!requireOwnerForPlayback || getBotOwnerState())) {
      startupVoiceTimer = setTimeout(() => {
        startupVoiceTimer = null;
        if (socket.connected && client.currentRoom === room && !manualVoiceStop && !voiceManager.isConnected) {
          log(`[Voice] 24/7 startup: automatically starting stream in "${room}".`);
          requestVoiceJoin(room, true);
        }
      }, 2500);
      startupVoiceTimer.unref?.();
    }
  }

  const joinRoomAndVoice = async (roomName, password = "") => {
    const room = String(roomName || "").trim();
    if (!room) throw new Error("Room name is required");
    if (!isRoomController({ room, username: config.username, userId: auth.userId, role: "owner" })) throw new Error("Only an authorized bot master/room owner can start the bot in this room.");
    if (!requireBotOwner(room, false)) throw new Error("The bot must have OWNER role in this room before it can stream.");
    const generation = ++voiceRoomGeneration;
    if (startupVoiceTimer) { clearTimeout(startupVoiceTimer); startupVoiceTimer = null; }
    const previousRoom = String(client.currentRoom || getActiveRoom() || "").trim();
    if (previousRoom && previousRoom !== room) persistRuntimeState("room-switch", previousRoom);
    restoreRoomRuntime(room);
    manualVoiceStop = false;
    sleepTriggered = false;
    voiceRecoveryWanted = true;
    lastVoiceRoom = room;
    clearStreamDirectoryTimers();
    stopVoiceRecovery();
    resetVoiceJoinState();
    if (voiceManager.isConnected && voiceManager.currentRoomName !== room) await voiceManager.disconnect();
    client.currentRoom = room;
    client.roomJoin(room, password);
    log(`[Main] Joining room: ${room} ...`);
    await new Promise(resolve => setTimeout(resolve, 2500));
    if (generation !== voiceRoomGeneration || client.currentRoom !== room || manualVoiceStop) return false;
    requestVoiceJoin(room, true);
    return true;
  };

  const leaveRoomAndVoice = async ({ leaveTextRoom = true } = {}) => {
    const room = String(client.currentRoom || "").trim();
    if (!room) return false;
    ++voiceRoomGeneration;
    if (startupVoiceTimer) { clearTimeout(startupVoiceTimer); startupVoiceTimer = null; }
    persistRuntimeState("room-leave", room);
    manualVoiceStop = true;
    sleepTriggered = false;
    voiceRecoveryWanted = false;
    clearStreamDirectoryTimers();
    stopVoiceRecovery();
    stopVoiceHeartbeat();
    resetVoiceJoinState();
    try { client.streamUnpublish(room, config.username || auth.username); } catch {}
    await voiceManager.disconnect();
    youtubePlayer.stop();
    lastKnownStreaming = false;
    if (leaveTextRoom) { try { client.roomLeave(room); } catch {} client.currentRoom = null; }
    return true;
  };

  let shuttingDown = false;
  const gracefulShutdown = async (signal = "shutdown") => {
    if (shuttingDown) return;
    shuttingDown = true;
    persistRuntimeState(`shutdown:${signal}`);
    void persistRoomDatabase();
    log(`[Main] Graceful shutdown requested (${signal}).`);
    manualVoiceStop = true; voiceRecoveryWanted = false;
    stopVoiceRecovery(); stopVoiceHeartbeat(); clearStreamDirectoryTimers();
    if (watchdogTimer) { clearInterval(watchdogTimer); watchdogTimer = null; }
    ++wsRecoveryGeneration;
    if (wsRecoveryTimer) { clearTimeout(wsRecoveryTimer); wsRecoveryTimer = null; }
    if (startupVoiceTimer) { clearTimeout(startupVoiceTimer); startupVoiceTimer = null; }
    if (sleepTimer) clearTimeout(sleepTimer); if (idleTimer) clearTimeout(idleTimer);
    for (const timer of scheduleTimers.values()) clearTimeout(timer); scheduleTimers.clear();
    clearInterval(snapshotTimer);
    // Persist the exact last position BEFORE stopping the player. This snapshot
    // intentionally survives a clean shutdown so the next process can resume
    // automatically after joining the configured room.
    try {
      if (youtubePlayer.currentTrack?.url) {
        savePlaybackSnapshot({
          room: client.currentRoom || defaultRoom || "",
          track: { ...youtubePlayer.currentTrack },
          queue: youtubePlayer.getQueue(),
          offset: youtubePlayer.getElapsedSeconds(),
          savedAt: Date.now(),
          reason: `shutdown:${signal}`
        });
        flushPro();
        log(`[Main] Saved playback session at ${youtubePlayer.getElapsedSeconds().toFixed(1)}s.`);
      }
    } catch (err) { log(`[Main] Could not save playback session: ${err?.message || err}`); }
    try { persistRuntimeState(`shutdown:${signal}`); } catch {}
    try { youtubePlayer.stop(); } catch {}
    try { await voiceCommandEngine.detach(); } catch {}
    try { await voiceManager.shutdown(); } catch (err) { debug("[Main] LiveKit shutdown failed:", err.message); }
    try { flushStats(); } catch {}
    try { flushPro(); } catch {}
    try { flushAdvanced(); } catch {}
    try { socket.close(1000, `process ${signal}`); } catch {}
    try { stopMaintenance(); } catch {}
  };
  for (const sig of ["SIGINT", "SIGTERM"]) process.once(sig, () => {
    void gracefulShutdown(sig).finally(() => process.exit(0));
  });

  const stopPlaybackSession = async () => {
    if (sleepTimer) { clearTimeout(sleepTimer); sleepTimer = null; }
    sleepTriggered = false;
    manualVoiceStop = false;
    voiceRecoveryWanted = true;
    try { youtubePlayer.stop(); } catch {}
    lastKnownStreaming = Boolean(voiceManager.isConnected);
  };

  const getUiState = () => {
    const health = voiceManager.getHealth?.() || {};
    const track = youtubePlayer.getNowPlaying?.() || null;
    return {
      connected: Boolean(socket.connected),
      room: client.currentRoom || defaultRoom || '',
      voice: Boolean(voiceManager.isConnected),
      publishing: Boolean(voiceManager.publishing),
      nowPlaying: track ? { ...track } : null,
      elapsed: Number(youtubePlayer.getElapsedSeconds?.() || 0),
      queue: youtubePlayer.getQueue?.() || [],
      queueLimit: youtubePlayer.queueLimit || getQueueLimit(),
      youtubePlaying: Boolean(youtubePlayer.isPlaying),
      paused: Boolean(youtubePlayer.isPaused),
      quality: youtubePlayer.getAudioQuality?.() || 'highest',
      qualityFormat: youtubePlayer.getAudioQualityFormat?.() || '',
      loop: youtubePlayer.loopMode || 'off',
      autoplay: Boolean(youtubePlayer.autoplay),
      volume: Number(youtubePlayer.volume ?? 1),
      speed: Number(youtubePlayer.playbackRate ?? 1),
      filters: voiceManager.getFilterSummary?.() || '',
      health,
      recovery: { running: Boolean(voiceRecoveryRunning), attempt: Number(recoveryAttempt || 0) },
      session: { id: lastAcceptedInviteSession || '' },
      djMode: Boolean(djModeEnabled),
      djCount: djUsers.size,
      alwaysOn: Boolean(alwaysOn),
      autoResume: Boolean(autoResume)
    };
  };

  startInteractiveConsole({
    client,
    socket,
    voiceManager,
    youtubePlayer,
    config,
    connectAuthenticated,
    sendRoomCommand: payload => dispatchRoomCommand(payload),
    joinRoom: joinRoomAndVoice,
    leaveRoom: leaveRoomAndVoice,
    applyFilterChange,
    stopPlaybackSession,
    getState: getUiState
  });
}

async function main() {
  banner("TalkInChat Music Bot v5.5.8");
  const [cmd, ...args] = process.argv.slice(2);

  if (cmd === "features") {
    printCatalog();
    return;
  }

  if (cmd === "register") {
    console.log(await register());
    return;
  }

  if (!cmd || cmd === "bot" || cmd === "start") {
    const targetRoom = args[0] || config.defaultRoom;
    await startBot(targetRoom);
    return;
  }

  if (cmd === "login") {
    const { auth, socket } = await connectAuthenticated({ forceLogin: true });
    console.log("\n[AUTH RESULT SUCCESS]");
    console.log(`User ID: ${auth.userId}`);
    console.log(`Session ID: ${auth.sessionId}`);
    console.log(`Server Port: ${auth.server}`);
    socket.close();
    return;
  }

  const { client, socket } = await connectAuthenticated();
  const room = args[0];

  try {
    switch (cmd) {
      case "create":
        client.roomCreate(room, args[1] === "true");
        break;
      case "join":
        client.roomJoin(room, args[1] || "");
        break;
      case "leave":
        client.roomLeave(room);
        break;
      case "rooms":
        ({
          public: () => client.publicRooms(),
          trending: () => client.trendingRooms(),
          favourites: () => client.favouriteRooms()
        }[args[1] || "public"] || (() => client.publicRooms()))();
        break;
      case "search":
        client.searchRooms(room);
        break;
      case "occupants":
        client.occupants(room);
        break;
      case "admins":
        client.admins(room);
        break;
      case "members":
        client.members(room);
        break;
      case "owners":
        client.owners(room);
        break;
      case "outcasts":
        client.outcasts(room);
        break;
      case "settings":
        client.roomSettings(room);
        break;
      case "logs":
        client.roomLogs(room);
        break;
      case "stream-check":
        client.streamCheck(room);
        break;
      case "stream-sync":
        // Safe directory synchronization: query authoritative stream state only.
        // Never use room_join(intValue=1) while the publisher is healthy.
        client.streamCheck(room);
        log(`[Voice Directory] Manual safe Voice/Active sync requested for "${room}".`);
        break;
      case "stream-publish":
        client.streamPublish(room, args[1] || "");
        break;
      case "stream-invite":
        client.streamInvite(room, args[1]);
        break;
      case "profile":
        client.myProfile();
        break;
      case "profile-user":
        client.otherProfile(room);
        break;
      case "requests":
        client.friendRequests();
        break;
      case "blocked":
        client.blockedList();
        break;
      case "sessions":
        client.sessions();
        break;
      case "store":
        client.storeData();
        break;
      case "gifts":
        client.gifts(args[1] || "new_gifts");
        break;
      case "ping":
        client.ping();
        break;
      default:
        throw new Error(`Unknown command: ${cmd}`);
    }

    await new Promise(resolve => setTimeout(resolve, 3000));
  } finally {
    socket.close();
  }
}

import { fileURLToPath } from "node:url";

const isDirectRun = process.argv[1] && (
  fileURLToPath(import.meta.url) === process.argv[1] ||
  process.argv[1].endsWith("index.js")
);

if (isDirectRun) {
  main().catch(err => {
    console.error("FATAL:", err.stack || err.message);
    process.exitCode = 1;
  });
}
