#!/usr/bin/env node
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { connectAuthenticated } from '../src/index.js';
import { initRoomDatabase, listRoomProfiles, setRoomMeta, addRoomMaster, getRoomMeta } from '../src/room_database.js';
import { config, log, debug } from '../src/config.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const WORKER = path.join(ROOT, 'src', 'index.js');
const workers = new Map();
const pendingInvites = new Map();
const pendingOwnerPollers = new Map();
let activeJoinRoom = "";

function botNames(auth) {
  return new Set([String(config.username || ''), String(auth?.username || ''), String(auth?.userId || '')].map(v => v.trim().toLowerCase()).filter(Boolean));
}

function spawnRoomWorker(room) {
  const name = String(room || '').trim();
  if (!name || workers.has(name)) return workers.get(name)?.child || null;
  const child = spawn(process.execPath, [WORKER, 'start', name], {
    cwd: ROOT,
    env: { ...process.env, ROOM_WORKER: '1', ROOM_WORKER_ROOM: name, DEFAULT_ROOM: name, BOT_ROOM_MASTER_ONLY: 'true', BOT_REQUIRE_OWNER: 'true' },
    stdio: ['ignore', 'inherit', 'inherit']
  });
  const info = { child, startedAt: Date.now(), restarts: 0 };
  workers.set(name, info);
  log(`[MultiRoom] Started worker for "${name}" (pid=${child.pid}).`);
  child.on('exit', (code, signal) => {
    workers.delete(name);
    log(`[MultiRoom] Worker "${name}" exited code=${code ?? '-'} signal=${signal || '-'}.`);
    const meta = getRoomMeta(name);
    if (meta?.enabled !== 0 && process.env.MULTIROOM_AUTO_RESTART !== 'false') {
      setTimeout(() => spawnRoomWorker(name), 5000).unref?.();
    }
  });
  child.on('error', err => log(`[MultiRoom] Worker "${name}" error: ${err.message}`));
  return child;
}

function stopRoomWorker(room) {
  const info = workers.get(String(room || '').trim());
  if (!info) return false;
  try { info.child.kill('SIGTERM'); } catch {}
  workers.delete(String(room || '').trim());
  return true;
}

function sendPm(client, username, body) {
  try { client.sendText(String(username), String(body)); } catch (err) { log(`[MultiRoom] PM failed to @${username}: ${err.message}`); }
}

function stopOwnerPoll(room) {
  const key = String(room || '').trim();
  const timer = pendingOwnerPollers.get(key);
  if (timer) clearInterval(timer);
  pendingOwnerPollers.delete(key);
}

function startOwnerPoll(client, room, pending) {
  const key = String(room || '').trim();
  if (!key || pendingOwnerPollers.has(key)) return;
  const check = () => {
    const current = pendingInvites.get(key);
    if (!current || current.ownerVerified || current.joined === false) { stopOwnerPoll(key); return; }
    try { client.occupants(key); } catch (err) { debug(`[MultiRoom] owner poll failed for ${key}: ${err.message}`); }
  };
  const timer = setInterval(check, 5000);
  timer.unref?.();
  pendingOwnerPollers.set(key, timer);
  check();
}

function parseInvite(body) {
  const text = String(body || '').trim();
  // ChatP room names are not limited to [A-Za-z0-9_]. The APK passes the
  // room name as a single string, and real rooms may contain punctuation such
  // as `!`, `-`, `.` and `#`. Treat the first non-whitespace token as the room
  // and make the password genuinely optional.
  const m = text.match(/^\.(?:(?:invite|addbot|add-bot|join)\s+(\S+)(?:\s+(.+))?|bot\s+(?:invite|join)\s+(\S+)(?:\s+(.+))?)$/i);
  if (!m) return null;
  let room = String(m[1] || m[3] || '').trim();
  let password = String(m[2] || m[4] || '').trim();
  // Optional explicit password syntax avoids ambiguity for future room-name
  // forms and makes the open-room case obvious: `.invite room` has no password.
  const pw = password.match(/^--password(?:=|\s+)(.*)$/i);
  if (pw) password = pw[1].trim();
  return room ? { room, password } : null;
}

function eventRole(event) {
  return String(event?.role || event?.newRole || '').trim().toLowerCase();
}

function handlePrivateMessage(client, message, names) {
  if (!message || String(message.type || '').toLowerCase() !== 'text') return;
  const to = String(message.to || '').trim().toLowerCase();
  const from = String(message.from || '').trim();
  if (!from || !to || !names.has(to)) return;
  const invite = parseInvite(message.body);
  if (!invite) {
    sendPm(client, from, '🤖 Multi-room bot commands: .invite <room> [password] or .join <room> [password]\nThe bot can join the room after the request. Music/streaming remains disabled until the bot account has OWNER role.');
    return;
  }
  const room = invite.room;
  if (workers.has(room)) {
    sendPm(client, from, `✅ The bot is already connected to ${room}. Use .masters in that room.`);
    return;
  }
  const existing = pendingInvites.get(room);
  if (existing) {
    sendPm(client, from, `⏳ I am already processing an invitation for ${room}.`);
    return;
  }
  pendingInvites.set(room, {
    inviter: from,
    inviterUserId: String(message.userId || '').trim(),
    password: invite.password,
    at: Date.now(),
    joined: false,
    ownerVerified: false
  });
  log(`[MultiRoom] Invitation request from @${from} for room "${room}".`);
  sendPm(client, from, `⏳ Joining ${room}...`);
  try {
    activeJoinRoom = room;
    // Empty password is the APK-compatible representation of an open room.
    // Do not invent or require a password when the room is public.
    client.roomJoin(room, invite.password || "");
  }
  catch (err) {
    pendingInvites.delete(room);
    sendPm(client, from, `❌ Could not join ${room}: ${err.message}`);
  }
}

function handoffSupervisorToWorker(client, room) {
  const name = String(room || '').trim();
  if (!name) return;
  const child = spawnRoomWorker(name);
  // The worker has its own authenticated WebSocket and room state. Keep the
  // supervisor in the room only during the short handoff window so the same
  // account is not unnecessarily present twice. If the worker exits before the
  // handoff completes, leave the supervisor connected so the room can still be
  // recovered/observed.
  setTimeout(() => {
    const info = workers.get(name);
    if (!info || info.child !== child || info.child.exitCode !== null) return;
    try { client.roomLeave(name); } catch {}
  }, 3500).unref?.();
}

async function finalizeAuthorizedRoom(client, room, pending, ownerNames = []) {
  const normalizedOwners = new Set(ownerNames.map(v => String(v || '').trim().toLowerCase()).filter(Boolean));
  const inviter = String(pending.inviter || '').trim();
  if (normalizedOwners.has(inviter.toLowerCase())) {
    addRoomMaster(room, { username: inviter, userId: pending.inviterUserId }, { username: inviter, userId: pending.inviterUserId });
    sendPm(client, inviter, `✅ Bot joined ${room} with OWNER role. You are now the first bot master for this room.\nUse .master add <username> to add another master.`);
  } else {
    sendPm(client, inviter, `✅ Bot is OWNER in ${room}.\nThe PM requester was not detected as a room owner, so no master was granted automatically. A room owner can use .master add <username> in the room.`);
  }
  setRoomMeta(room, { inviterUsername: pending.inviter, inviterUserId: pending.inviterUserId, botRole: 'owner', enabled: true });
  pendingInvites.delete(room);
  stopOwnerPoll(room);
  spawnRoomWorker(room);
  handoffSupervisorToWorker(client, room);
}

function requestOwnerCheck(client, room, pending) {
  pending.ownerCheckAt = Date.now();
  pending.ownerCheckRequested = true;
  try { client.occupants(room); }
  catch (err) {
    log(`[MultiRoom] Could not query occupants for ${room}: ${err.message}`);
    // Never infer OWNER from a failed roster query. Keep the invitation pending
    // and let the poll retry. This prevents the stale `you_joined.role=member`
    // value from becoming the persisted room role.
    sendPm(client, pending.inviter, `⏳ I joined ${room}, but I could not verify the bot's room role yet. I will retry automatically.`);
    startOwnerPoll(client, room, pending);
  }
}

async function main() {
  log('======================================================');
  log('   TalkInChat Music Bot — Multi-Room Supervisor');
  log('======================================================');
  await initRoomDatabase();
  const { client, socket, auth } = await connectAuthenticated();
  const names = botNames(auth);
  // Make the bot explicitly available for private invitations. These are
  // normal ChatP profile settings and are intentionally enabled by the
  // multi-room supervisor so the PM invitation feature works on a fresh
  // account without manual APK setup.
  try { client.setAllowPM(true); } catch (err) { debug(`[MultiRoom] allow_pm update failed: ${err.message}`); }
  try { client.setAllowInvites(true); } catch (err) { debug(`[MultiRoom] allow_invites update failed: ${err.message}`); }

  // Resume every enabled room already authorized in SQLite. No JSON state is
  // used for room membership, masters, queues, playback or settings.
  for (const profile of listRoomProfiles()) {
    if (profile.enabled && (profile.masterCount > 0 || String(profile.botRole || "").toLowerCase() === "owner")) spawnRoomWorker(profile.room);
  }

  // ProtocolHandlers emits the canonical `chatMessage` event plus the APK
  // compatible `chat_message` alias. Register both so old/new server wrappers
  // cannot silently break PM command handling. A small fingerprint prevents a
  // duplicate reply if both aliases are emitted for the same packet.
  const privateMessageSeen = new Map();
  const handlePrivate = message => {
    const fingerprint = [message?.id, message?.from, message?.to, message?.body].map(v => String(v ?? '')).join('|');
    const now = Date.now();
    if (fingerprint && privateMessageSeen.has(fingerprint) && now - privateMessageSeen.get(fingerprint) < 3000) return;
    if (fingerprint) privateMessageSeen.set(fingerprint, now);
    if (privateMessageSeen.size > 500) {
      for (const [key, ts] of privateMessageSeen) if (now - ts >= 3000) privateMessageSeen.delete(key);
    }
    log(`[MultiRoom] Private message received from @${message?.from || '?'} to @${message?.to || '?'}: ${String(message?.body || '').slice(0, 160)}`);
    handlePrivateMessage(client, message, names);
  };
  socket.onEvent('chatMessage', handlePrivate);
  socket.onEvent('chat_message', handlePrivate);

  socket.onEvent('roomEvent', event => {
    if (!event) return;
    const room = String(event.room || event.toRoom || '').trim();
    const pending = pendingInvites.get(room);
    const type = String(event.type || '').toLowerCase();
    if (!pending) return;

    if (type === 'you_joined' || type === 'you_rejoined') {
      const role = eventRole(event);
      pending.joined = true;
      if (activeJoinRoom === room) activeJoinRoom = "";
      pending.botRole = role;
      setRoomMeta(room, { inviterUsername: pending.inviter, inviterUserId: pending.inviterUserId, botRole: role, enabled: true });

      if (role === 'owner') {
        pending.ownerVerified = true;
        // Verify the PM requester against the room's actual occupant roles
        // before granting the first master slot.
        requestOwnerCheck(client, room, pending);
      } else {
        // IMPORTANT: `you_joined.role` is not authoritative on every ChatP
        // deployment. Do not tell the inviter that the bot is a member yet.
        // Query the actual roster first; the Android client displays the role
        // from the participant list, and that list can already say OWNER.
        sendPm(client, pending.inviter, `✅ Bot joined ${room}. Verifying the bot's actual room role...`);
        startOwnerPoll(client, room, pending);
        requestOwnerCheck(client, room, pending);
      }
      return;
    }

    if (type === 'your_role_changed' || type === 'role_changed' || event.newRole || event.tUsername) {
      const botNameSet = botNames(auth);
      const target = String(event.to || event.username || event.tUsername || '').trim().toLowerCase();
      const targetId = String(event.toId || event.userId || '').trim();
      const isBotTarget = botNameSet.has(target) || (targetId && targetId === String(auth.userId || '').trim()) || type === 'your_role_changed';
      if (!isBotTarget) return;
      const role = String(event.newRole || event.role || '').trim().toLowerCase();
      pending.botRole = role;
      setRoomMeta(room, { botRole: role, enabled: true });
      if (role === 'owner') {
        pending.ownerVerified = true;
        requestOwnerCheck(client, room, pending);
      } else {
        sendPm(client, pending.inviter, `ℹ️ Bot role in ${room} changed to "${event.role || role || 'unknown'}". OWNER role is required before streaming.`);
      }
      return;
    }

    if (/unauthorized|wrong_password|needs_password|membership_required|full|captcha/i.test(type)) {
      sendPm(client, pending.inviter, `❌ I could not join ${room} (${event.type}). If the room is restricted, make sure the bot account is allowed to join and send the invitation again.`);
      pendingInvites.delete(room);
      stopOwnerPoll(room);
    }
  });

  socket.onEvent('result', result => {
    // Room join failures are delivered by ChatP as ResultMessage.type/handler
    // events on some server builds and as nested RoomEvent packets on others.
    // Handle both forms so an open room never gets stuck waiting for an event.
    const resultType = String(result?.type || '').trim().toLowerCase();
    if (activeJoinRoom && pendingInvites.has(activeJoinRoom)) {
      const pendingJoin = pendingInvites.get(activeJoinRoom);
      if (/^room_(?:unauthorized|wrong_password|needs_password|needs_captcha|membership_required|full)$/.test(resultType)) {
        sendPm(client, pendingJoin.inviter, `❌ I could not join ${activeJoinRoom} (${resultType}).`);
        pendingInvites.delete(activeJoinRoom);
        stopOwnerPoll(activeJoinRoom);
        activeJoinRoom = '';
      }
    }

    const admin = result?.roomAdmin;
    const adminRoom = String(admin?.room || '').trim();
    const topUsers = Array.isArray(result?.users) ? result.users : [];
    const room = adminRoom || (activeJoinRoom && pendingInvites.has(activeJoinRoom) ? activeJoinRoom : '');
    const pending = pendingInvites.get(room);
    if (!pending) return;
    const users = [
      ...(Array.isArray(admin?.occupants) ? admin.occupants : []),
      ...(Array.isArray(admin?.users) ? admin.users : []),
      ...topUsers
    ];
    if (!users.length) return;
    const owners = users.filter(u => String(u?.role || '').trim().toLowerCase() === 'owner').map(u => u?.username);
    if (!owners.length) return;
    const botNameSet = botNames(auth);
    const botOwner = users.some(u => {
      const name = String(u?.username || '').trim().toLowerCase();
      const uid = String(u?.userId || '').trim();
      return (botNameSet.has(name) || (uid && uid === String(auth.userId || '').trim())) && String(u?.role || '').trim().toLowerCase() === 'owner';
    });
    if (botOwner) {
      pending.ownerVerified = true;
      void finalizeAuthorizedRoom(client, room, pending, owners);
    }
  });

  socket.onEvent('room_unauthorized', event => debug('[MultiRoom] room_unauthorized', event));
  socket.onEvent('room_wrong_password', event => debug('[MultiRoom] room_wrong_password', event));

  const shutdown = signal => {
    log(`[MultiRoom] Shutdown ${signal}; stopping ${workers.size} room workers.`);
    for (const [room, info] of workers) { try { info.child.kill('SIGTERM'); } catch {} }
    try { socket.close(1000, 'supervisor shutdown'); } catch {}
    setTimeout(() => process.exit(0), 1000).unref?.();
  };
  process.once('SIGINT', () => shutdown('SIGINT'));
  process.once('SIGTERM', () => shutdown('SIGTERM'));
  process.once('uncaughtException', err => log(`[MultiRoom] uncaughtException: ${err.stack || err.message}`));
  process.once('unhandledRejection', err => log(`[MultiRoom] unhandledRejection: ${err?.stack || err}`));
}

main().catch(err => { console.error('[MultiRoom] FATAL:', err.stack || err.message); process.exit(1); });
