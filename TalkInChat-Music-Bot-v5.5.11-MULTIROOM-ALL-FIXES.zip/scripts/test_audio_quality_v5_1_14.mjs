import assert from "node:assert/strict";
import { YouTubePlayer } from "../src/player.js";

const p = new YouTubePlayer();
assert.equal(p.getAudioQuality(), "highest");
assert.equal(p.getAudioQualityFormat(), "bestaudio/best");
assert.equal(p.setAudioQuality("high"), "high");
assert.match(p.getAudioQualityFormat(), /abr>=192/);
assert.equal(p.setAudioQuality("medium"), "medium");
assert.match(p.getAudioQualityFormat(), /abr>=128/);
assert.equal(p.setAudioQuality("low"), "low");
assert.match(p.getAudioQualityFormat(), /abr<=128/);
assert.equal(p.setAudioQuality("invalid"), "highest");
assert.equal(p.getAudioQualityFormat(), "bestaudio/best");
console.log("audio quality v5.2.0 checks: PASS");
