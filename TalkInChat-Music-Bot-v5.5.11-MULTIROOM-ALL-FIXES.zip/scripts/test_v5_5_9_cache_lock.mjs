import fs from 'node:fs';
import path from 'node:path';
const src = fs.readFileSync(path.join(process.cwd(), 'src/player.js'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'package.json'), 'utf8'));
const checks = [
  ['version', pkg.version === '5.5.11'],
  ['cache in-flight map', src.includes('this._audioCacheDownloads = new Map()')],
  ['same-key dedupe', src.includes('const inFlight = this._audioCacheDownloads.get(key)')],
  ['cache lock registration', src.includes('this._audioCacheDownloads.set(key, downloadPromise)')],
  ['cache lock cleanup', src.includes('this._audioCacheDownloads.get(key) === downloadPromise')],
  ['cache eviction protects in-flight downloads', src.includes('!this._audioCacheDownloads.has(k)')],
  ['stable cache output key', src.includes('const stableId = String(track.id || key)')],
  ['cache process is keyed independently from playId', src.includes('const processKey = `cache:${key}`')]
];
for (const [name, ok] of checks) console.log(`${ok ? 'PASS' : 'FAIL'}: ${name}`);
if (checks.some(([,ok]) => !ok)) process.exit(1);
