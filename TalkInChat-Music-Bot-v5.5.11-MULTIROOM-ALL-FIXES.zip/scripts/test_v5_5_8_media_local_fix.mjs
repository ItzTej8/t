import assert from 'node:assert/strict';
import fs from 'node:fs';

const voice = fs.readFileSync(new URL('../src/voice.js', import.meta.url), 'utf8');
const player = fs.readFileSync(new URL('../src/player.js', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

assert.equal(pkg.version, '5.5.11');
assert.ok(voice.includes('const isHttpInput = Boolean(inputSource &&'));
assert.ok(voice.includes('const inputSource = typeof audioStream === \"string\" ? audioStream : null;'));
assert.match(voice, /if \(isHttpInput\) \{[\s\S]*?"-reconnect", "1"/);
assert.match(voice, /if \(isHttpInput\) \{[\s\S]*?"-rw_timeout", "8000000"/);
const localBlock = voice.slice(voice.indexOf('const ffmpegArgs = ['), voice.indexOf('if (isHttpInput)', voice.indexOf('const ffmpegArgs = [')));
assert.doesNotMatch(localBlock, /"-reconnect", "1"/);
assert.doesNotMatch(localBlock, /"-rw_timeout", "8000000"/);
assert.match(player, /this\.startedAt = Date\.now\(\);[\s\S]*?this\.stream = source;/);
assert.match(player, /seekOffset is already included by getElapsedSeconds\(\)/);
console.log('PASS: v5.5.8 local-cache FFmpeg options and resume-clock fix');
