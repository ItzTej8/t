import assert from 'node:assert/strict';
import fs from 'node:fs';
const player=fs.readFileSync(new URL('../src/player.js',import.meta.url),'utf8');
const voice=fs.readFileSync(new URL('../src/voice.js',import.meta.url),'utf8');
const index=fs.readFileSync(new URL('../src/index.js',import.meta.url),'utf8');
const catalog=fs.readFileSync(new URL('../src/command_catalog.js',import.meta.url),'utf8');
assert.doesNotMatch(player,/noPart:\s*false/);
assert.match(player,/allowStale = false/);
assert.match(player,/_scheduleAutoDjFill/);
assert.match(player,/prefetchNextTracks/);
assert.match(player,/getAudioCacheInfo/);
assert.match(voice,/if \(!inputSource && !isReadableSource\)/);
assert.doesNotMatch(voice,/if \(!inputUrl && !isReadableSource\)/);
for (const c of ['cache','source','latency','roominfo','controllers','version','about']) { assert.match(index,new RegExp(`case "${c}"`)); assert.match(catalog,new RegExp(c)); }
console.log('PASS: v5.5.7 media/async/diagnostic command fixes');
assert.match(fs.readFileSync(new URL('../src/console.js',import.meta.url),'utf8'),/stdin\.setRawMode/);
assert.match(index,/listRoomMasters\(room\)/);
assert.doesNotMatch(index,/botRoleByRoom\.get\(room\)/);
console.log('PASS: v5.5.7 TUI fallback and room-info references');
