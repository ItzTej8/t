import assert from 'node:assert/strict';
import fs from 'node:fs';
const player = fs.readFileSync('src/player.js','utf8');
const index = fs.readFileSync('src/index.js','utf8');
assert.match(player, /options\.reuseDirectUrl !== false/);
assert.match(player, /options\.reuseDirectUrl === false \? '' : String\(this\.stream \|\| ''\)\.trim\(\)/);
assert.match(index, /restartCurrent\("media-source-retry", offset, \{ announce: false, reuseDirectUrl: false \}\)/);
assert.match(index, /hz < 0\.03 \|\| hz > 2\.00/);
console.log('media source retry + 8D speed validation test: PASS');
