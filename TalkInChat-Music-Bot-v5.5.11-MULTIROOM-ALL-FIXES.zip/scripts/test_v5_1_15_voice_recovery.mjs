import assert from 'node:assert/strict';
import fs from 'node:fs';

const index = fs.readFileSync('src/index.js', 'utf8');
const client = fs.readFileSync('src/client.js', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));

assert.equal(pkg.version, '5.2.16');
assert.match(index, /const acceptedInviteTokens = new Set\(\)/);
assert.doesNotMatch(index, /const acceptedInviteSessions = new Set\(\)/);
assert.match(index, /acceptedInviteTokens\.has\(invitationToken\)/);
assert.match(index, /client\.streamPublish\(effectiveRoom, invitationToken\)/);
assert.match(index, /client\.streamPublish\(effectiveRoom, ""\)/);
assert.match(index, /No publish_stream after invitation token/);
assert.match(index, /Requesting ONE self-invite/);
assert.match(index, /voiceManager\.isConnecting/);
assert.match(index, /LiveKit handshake is still pending/);
assert.match(index, /VOICE_INVITE_TIMEOUT_MS = 15000/);
const voice = fs.readFileSync('src/voice.js', 'utf8');
assert.match(voice, /STATIC_LIVEKIT_CONNECT_TIMEOUT_MS = 15000/);
assert.match(voice, /get isConnecting\(\) \{ return Boolean\(this\._connectPromise\); \}/);
assert.match(index, /client\.streamStop\(targetRoom\)/);
assert.doesNotMatch(index, /client\.roomRejoin\(/);
assert.match(index, /type === "you_joined" \|\| type === "you_rejoined"/);
assert.doesNotMatch(index, /if \(\(type === "you_joined" \|\| type === "you_rejoined" \|\| type === "user_joined"\) && eventRoom\)/);
assert.match(index, /event\.isStreaming === true \|\| Number\(event\.isStreaming\) === 1/);
assert.doesNotMatch(index, /applyFilterChange\("audio-quality", \(\) => youtubePlayer\.restartCurrent/);
assert.doesNotMatch(index, /changeFilter\("audio-quality", \(\) => youtubePlayer\.restartCurrent/);
assert.match(client, /type:"publish",to:password,room/);

console.log('v5.2.0 voice invitation/recovery regression checks: PASS');
