import assert from 'node:assert/strict';
import fs from 'node:fs';
const index=fs.readFileSync('src/index.js','utf8');
const client=fs.readFileSync('src/client.js','utf8');
assert.match(index,/client\.streamPublish\(targetRoom, streamPassword\)/);
assert.match(index,/AUTO_UPGRADE_STREAMING/);
assert.match(index,/streamInvite\(targetRoom, ownUsername\)/);
assert.match(client,/type:"publish"/);
console.log('v5.3.7 publisher-flow checks: PASS');
