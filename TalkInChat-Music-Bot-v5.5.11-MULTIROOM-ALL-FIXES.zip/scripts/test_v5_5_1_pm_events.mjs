import assert from 'node:assert/strict';
import { ProtocolHandlers } from '../src/handlers.js';
import { encode } from '../src/proto.js';

const handlers = new ProtocolHandlers();
let camel = null;
let snake = null;
handlers.on('chatMessage', value => { camel = value; });
handlers.on('chat_message', value => { snake = value; });

const chat = encode('ChatMessage', {
  type: 'text',
  id: 'pm-1',
  from: 'Emptiness',
  to: 'bot',
  body: '.invite india',
  uid: 'u-1'
});
const packet = encode('ResultMessage', { chatMessage: chat });
handlers.handle(packet, true);

assert.equal(camel?.from, 'Emptiness');
assert.equal(camel?.to, 'bot');
assert.equal(camel?.body, '.invite india');
assert.deepEqual(snake, camel);
console.log('PASS: v5.5.1 private chat_message event alias');
