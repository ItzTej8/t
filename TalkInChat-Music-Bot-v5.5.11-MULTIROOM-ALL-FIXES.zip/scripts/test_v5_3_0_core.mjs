import fs from 'node:fs';
import assert from 'node:assert/strict';
import { loadSettings, saveSettings } from '../src/bot_settings.js';

const before = loadSettings();
const marker = { ...before, welcomeEnabled: true, player: { ...before.player, autoplay: true, audioQuality: 'highest' }, voice: { ...before.voice, volume: 0.73 }, radio: { ...before.radio, seedMode: 'genre' } };
saveSettings(marker);
const after = loadSettings();
assert.equal(after.welcomeEnabled, true);
assert.equal(after.player.autoplay, true);
assert.equal(after.player.audioQuality, 'highest');
assert.equal(after.voice.volume, 0.73);
assert.equal(after.radio.seedMode, 'genre');
console.log('v5.3.0 persistence core: PASS');
