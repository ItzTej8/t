import fs from 'node:fs';
import assert from 'node:assert/strict';
const src = fs.readFileSync(new URL('../src/index.js', import.meta.url), 'utf8');
for (const needle of [
  'const autoPublishOnOwner = process.env.AUTO_PUBLISH_ON_OWNER !== "false"',
  'function findBotInUsers(users, authInfo = auth)',
  "inspectAuthoritativeOccupants(room, users, 'roomAdmin.occupants/users')",
  'type === "your_role_changed" || type === "role_changed"',
  'event.newRole || event.role',
  'client.occupants(eventRoom)',
  'automatically starting publisher',
  'Bot is not OWNER in this room',
  'savePlaybackSnapshot(snapshot)',
  'antiSpamCheck(`${room}|${username || userId}`)'
]) assert.ok(src.includes(needle), `missing: ${needle}`);
console.log('PASS v5.5.5 authoritative OWNER role reconciliation + demotion + scoped anti-spam checks');
