import { manualBackup } from '../src/maintenance.js';
console.log(`[Backup] ${manualBackup('cli')}`);
