import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { encode, decode } from "../src/proto.js";
import { ProtocolHandlers } from "../src/handlers.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
assert.equal(pkg.version, "5.5.11");

// APK-compatible room text is ResultMessage.roomEvent, not ChatMessage.
const roomEventWire = encode("RoomEvent", { type: "text", room: "hello_!", from: "emptiness", userId: "u1", body: ".play kiss me more" });
const wire = encode("ResultMessage", { roomEvent: roomEventWire });
const handlers = new ProtocolHandlers();
let roomMessage = null;
handlers.on("roomMessage", event => { roomMessage = event; });
handlers.handle(wire, true);
assert.equal(roomMessage?.type, "text");
assert.equal(roomMessage?.room, "hello_!");
assert.equal(roomMessage?.body, ".play kiss me more");

// The command handler accepts the alternate server event type as well.
assert.match(fs.readFileSync(path.join(root, "src", "index.js"), "utf8"), /room_message.*message/);

// Round-trip confirms the normalized room event is still decoded correctly.
const decoded = decode("ResultMessage", wire);
assert.equal(decoded.roomEvent.room, "hello_!");
assert.equal(decoded.roomEvent.body, ".play kiss me more");

const src = fs.readFileSync(path.join(root, "scripts", "multiroom-supervisor.mjs"), "utf8");
assert.match(src, /startOwnerPoll/);
assert.match(src, /botOwner/);
assert.match(src, /client\.occupants\(key\)/);

const settings = fs.readFileSync(path.join(root, "src", "bot_settings.js"), "utf8");
assert.doesNotMatch(settings, /atomicWriteJson|\.bot-settings\.json/);

console.log("PASS: v5.5.5 room messages + owner polling + SQLite-only settings");
