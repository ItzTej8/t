import assert from 'node:assert/strict';
import fs from 'node:fs';

const supervisor = fs.readFileSync(new URL('./multiroom-supervisor.mjs', import.meta.url), 'utf8');
const proto = fs.readFileSync(new URL('../src/proto.js', import.meta.url), 'utf8');
const platform = fs.readFileSync(new URL('./platform-start.mjs', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const env = fs.readFileSync(new URL('../.env.example', import.meta.url), 'utf8');

assert.equal(pkg.version, '5.5.11');
assert.equal(pkg.engines.node, '>=22.0.0 <27');
assert.match(supervisor, /\(\\S\+\)/); // first room token accepts punctuation
assert.match(supervisor, /invite|addbot|add-bot|join/);
assert.match(supervisor, /invite\.password \|\| ""/);
assert.match(supervisor, /handoffSupervisorToWorker/);
assert.match(proto, /isStreaming: 30/);
assert.match(proto, /newRole: 31/);
assert.match(proto, /tUsername: 33/);
assert.match(proto, /userMatches = roomEventFields\.filter/);
assert.match(platform, /setup_22\.x/);
assert.match(platform, /requires Node\.js 22/);
assert.match(env, /ROOM_DATABASE_PATH=data\/talkinchat-room\.db/);
assert.doesNotMatch(env, /ROOM_DATABASE_PATH=data\/talkinchat-room-db\.json/);
console.log('PASS: v5.5.5 multi-room invitation/password/protocol/startup hardening');
