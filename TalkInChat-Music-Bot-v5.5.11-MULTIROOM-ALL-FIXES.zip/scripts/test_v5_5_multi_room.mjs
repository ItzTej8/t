import fs from 'node:fs';
import assert from 'node:assert/strict';

const root = new URL('..', import.meta.url).pathname;
const db = fs.readFileSync(new URL('../src/room_database.js', import.meta.url), 'utf8');
const index = fs.readFileSync(new URL('../src/index.js', import.meta.url), 'utf8');
const supervisor = fs.readFileSync(new URL('./multiroom-supervisor.mjs', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

assert.equal(pkg.version, '5.5.11');
assert.equal(pkg.dependencies['better-sqlite3'], '13.0.3');
assert.match(db, /CREATE TABLE IF NOT EXISTS rooms/);
assert.match(db, /CREATE TABLE IF NOT EXISTS room_masters/);
assert.match(db, /CREATE TABLE IF NOT EXISTS room_queue/);
assert.match(db, /CREATE TABLE IF NOT EXISTS room_playback/);
assert.match(db, /journal_mode = WAL/);
assert.match(index, /BOT_REQUIRE_OWNER/);
assert.match(index, /room bot masters|room owner/);
assert.match(index, /botRole === "owner"/);
assert.match(index, /master add/);
assert.match(supervisor, /\.invite|\.addbot|\.add-bot/);
assert.match(supervisor, /spawn\(process\.execPath/);
assert.match(supervisor, /ROOM_WORKER_ROOM/);
assert.match(supervisor, /addRoomMaster/);
console.log('PASS: v5.5 multi-room/master/SQLite static checks');
