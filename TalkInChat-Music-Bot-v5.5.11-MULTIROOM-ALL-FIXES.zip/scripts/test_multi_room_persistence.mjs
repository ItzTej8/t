import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

const temp = await fs.mkdtemp(path.join(os.tmpdir(), 'talkinchat-roomdb-test-'));
process.env.ROOM_DATABASE_PATH = path.join(temp, 'rooms.json');

const db = await import('../src/room_database.js');
const settings = await import('../src/bot_settings.js');

await db.initRoomDatabase();
settings.setActiveRoom('Room-A');
const a = settings.loadSettings('Room-A');
a.player.autoplay = true;
a.voice.volume = 0.42;
settings.saveSettings(a, 'Room-A');
db.setRoomQueue('Room-A', [{ title: 'A song', url: 'https://youtu.be/aaaaaaaa' }]);
db.setRoomPlayback('Room-A', { room: 'Room-A', track: { title: 'A song', url: 'https://youtu.be/aaaaaaaa' }, queue: [], offset: 12 });

settings.setActiveRoom('Room-B');
const b = settings.loadSettings('Room-B');
assert.equal(b.player.autoplay, false);
assert.equal(b.voice.volume, 1);
settings.saveSettings({ player: { autoplay: false }, voice: { volume: 0.88 } }, 'Room-B');
db.setRoomQueue('Room-B', [{ title: 'B song', url: 'https://youtu.be/bbbbbbbb' }]);

assert.equal(settings.loadSettings('Room-A').player.autoplay, true);
assert.equal(settings.loadSettings('Room-A').voice.volume, 0.42);
assert.equal(db.getRoomQueue('Room-A').length, 1);
assert.equal(db.getRoomQueue('Room-B').length, 1);
assert.equal(db.getRoomPlayback('Room-A').offset, 12);
assert.equal(db.listRoomProfiles().length, 2);
await db.persistRoomDatabase();
await fs.access(process.env.ROOM_DATABASE_PATH);
await fs.rm(temp, { recursive: true, force: true });
console.log('PASS multi-room settings/queue/playback persistence');
