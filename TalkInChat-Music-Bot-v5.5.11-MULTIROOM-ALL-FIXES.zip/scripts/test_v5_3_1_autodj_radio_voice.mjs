import assert from 'node:assert/strict';
import fs from 'node:fs';
const p=fs.readFileSync('src/player.js','utf8');
const r=fs.readFileSync('src/smart_radio.js','utf8');
const i=fs.readFileSync('src/index.js','utf8');
assert.match(p,/radioEnabled/); assert.match(p,/setRadio\(/); assert.match(p,/!this\._autoDjFillInFlight/);
assert.match(r,/songs like/); assert.match(r,/artists similar to/); assert.match(r,/artistNorm/); assert.match(r,/sameArtist/);
assert.match(i,/active_rooms_update/); assert.match(i,/threshold = ffmpegAlive \? 15000 : 10000/); assert.match(i,/radio-start/);
console.log('v5.3.1 smart AutoDJ/radio/Voice-directory checks: PASS');
