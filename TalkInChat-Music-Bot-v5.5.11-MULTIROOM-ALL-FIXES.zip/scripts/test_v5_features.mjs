import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { parseVoiceCommand } from '../src/voice_command_parser.js';
import { RecoveryCoordinator } from '../src/voice_recovery.js';
import { AtomicStore, SessionGuard, backupData } from '../src/platform_core.js';
import { allOperationNames } from '../src/operations.js';

assert.equal(parseVoiceCommand('Hey bot pause').command, 'pause');
assert.equal(parseVoiceCommand('volume 75').command, 'volume 75');
assert.equal(parseVoiceCommand('play blinding lights').command, 'play blinding lights');
assert.equal(parseVoiceCommand('search summer mix').command, 'play summer mix');
assert.equal(parseVoiceCommand('8d on').command, '8d on');
assert.equal(parseVoiceCommand('what is playing').command, 'nowplaying');
assert.equal(parseVoiceCommand('unknown magic').unsupported, true);

let attempts=0;
const r=new RecoveryCoordinator({enabled:()=>true,isHealthy:()=>false,onAttempt:async()=>{attempts++;},log:()=>{}});
r.start('test'); assert.equal(r.status().running,true); assert.equal(r.status().unlimitedAfterAttempt,6); r.stop('test'); assert.equal(r.status().running,false);

const sg=new SessionGuard(); const a=sg.start({room:'x'}); assert.equal(sg.isCurrent(a.id),true); sg.invalidate(); assert.equal(sg.isCurrent(a.id),false);
const st=new AtomicStore('v5-test',{x:1}); st.patch({x:2,y:'ok'}); assert.equal(st.data.x,2); assert.equal(st.data.y,'ok');
const backup=backupData('v5-test'); assert.ok(fs.existsSync(backup));
assert.ok(allOperationNames().includes('streamPublish'));

const src=fs.readFileSync(path.resolve(process.cwd(),'package.json'),'utf8');
assert.equal(JSON.parse(src).version,'5.2.16');
console.log('v5 feature tests: PASS');
