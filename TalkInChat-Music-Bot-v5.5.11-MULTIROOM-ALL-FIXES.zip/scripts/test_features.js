import { VoiceManager } from "../src/voice.js";
import { YouTubePlayer } from "../src/player.js";
import { fetchLyrics } from "../src/lyrics.js";
import { addFavorite, getFavorites, removeFavorite, clearFavorites } from "../src/favorites.js";

async function testAllFeatures() {
  console.log("=== Testing VoiceManager Filters & Presets ===");
  const vm = new VoiceManager();
  console.log("Initial filters:", vm.getFilterSummary());

  vm.setPreset("pop");
  console.log("Preset pop:", vm.getFilterSummary());
  console.log("Filter string (pop):", vm.buildAudioFilterString());

  vm.setPreset("vaporwave");
  console.log("Preset vaporwave:", vm.getFilterSummary());
  console.log("Filter string (vaporwave):", vm.buildAudioFilterString());

  vm.setBassBoost("high");
  vm.setNightcore(true);
  vm.setEightD(true);
  vm.setSpeed(1.25);
  vm.setKaraoke(true);
  console.log("Combined filters + preset:", vm.getFilterSummary());

  vm.clearFilters();
  console.log("After clearFilters:", vm.getFilterSummary());

  console.log("\n=== Testing YouTubePlayer Autoplay, History, Progress Bar & Methods ===");
  const player = new YouTubePlayer();
  player.setAutoplay(true);
  console.log("Autoplay enabled:", player.autoplay);

  player.currentTrack = { title: "Test Song", duration: "3:00", durationSeconds: 180, requestedBy: "Tester" };
  player.startedAt = Date.now() - 60000; // 60s elapsed
  console.log("Elapsed seconds:", Math.round(player.getElapsedSeconds()));
  console.log("Progress bar:", player.getProgressBar(10));

  // History
  player.recentHistory.unshift({ title: "Recent 1", duration: "2:30" });
  player.recentHistory.unshift({ title: "Recent 2", duration: "3:15" });
  console.log("Recent history count:", player.getRecentHistory().length);

  console.log("\n=== Testing Personal Favorites Persistence ===");
  const testTrack = { title: "Favorite Song 1", url: "https://youtube.com/watch?v=fav1", duration: "3:45", durationSeconds: 225, artist: "Fav Artist" };
  const favAddRes = addFavorite("user123", testTrack);
  console.log("Added favorite:", favAddRes);
  const userFavs = getFavorites("user123");
  console.log("User favorites count:", userFavs.length);
  const remRes = removeFavorite("user123", 1);
  console.log("Removed favorite:", remRes);
  clearFavorites("user123");

  console.log("\n=== Testing Lyrics Fetcher ===");
  try {
    const res = await fetchLyrics("Kiss Me", "Sixpence None The Richer", 210);
    if (res && res.lyrics) {
      console.log("Lyrics fetched successfully:", res.title, "by", res.artist);
      console.log("Preview:", res.lyrics.slice(0, 80).replace(/\n/g, " "), "...");
    } else {
      console.log("Lyrics fetch completed (no result for query).");
    }
  } catch (err) {
    console.log("Lyrics fetch error (network/offline):", err.message);
  }

  console.log("\n=== Testing Custom Playlist Persistence ===");
  player.queue = [
    { title: "Song 1", url: "https://youtube.com/watch?v=111", duration: 180, requestedBy: "Tester" },
    { title: "Song 2", url: "https://youtube.com/watch?v=222", duration: 200, requestedBy: "Tester" }
  ];
  player.currentTrack = { title: "Song 0 (Playing)", url: "https://youtube.com/watch?v=000", duration: 150, requestedBy: "Tester" };

  const saveRes = player.saveQueueAsPlaylist("my_favs", "Tester");
  console.log(`Saved playlist response: name="${saveRes.name}" trackCount=${saveRes.trackCount}`);

  const listRes = player.getSavedPlaylists();
  console.log("Saved playlists in storage:", listRes.map(p => `${p.name} (${p.trackCount} tracks)`).join(", "));

  // Clear queue and load it back
  player.queue = [];
  player.currentTrack = null;
  const loadRes = await player.loadSavedPlaylist("my_favs", "Tester");
  console.log(`Loaded playlist response: "${loadRes.playlist.name}" count=${loadRes.count} (Queue size now: ${player.queue.length})`);

  // Delete test playlist
  const delRes = player.deleteSavedPlaylist("my_favs");
  console.log("Delete playlist response: deleted=", delRes);

  console.log("\n✅ ALL ADVANCED FEATURES TEST PASSED!");
  process.exit(0);
}

testAllFeatures().catch(err => {
  console.error("Test failed:", err);
  process.exit(1);
});
