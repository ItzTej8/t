import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const file = path.resolve(process.cwd(), '.playlists.json');
const backup = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : null;
try {
  fs.writeFileSync(file, JSON.stringify({
    spotify_2026: { name:'spotify_2026', trackCount:2, tracks:[{title:'A'},{title:'B'}] },
    workout: { name:'workout', trackCount:1, tracks:[{title:'C'}] }
  }));
  const { listCustomPlaylists, getCustomPlaylist, deleteCustomPlaylist } = await import('../src/playlists.js');
  const list = listCustomPlaylists();
  assert.equal(list[0].name, 'spotify_2026');
  assert.equal(list[1].name, 'workout');
  assert.equal(getCustomPlaylist('spotify_2026').name, 'spotify_2026');
  // Command layer maps #1 -> list[0], #2 -> list[1].
  assert.equal(list[0].name, 'spotify_2026');
  assert.equal(list[1].name, 'workout');
  assert.equal(deleteCustomPlaylist('workout'), true);
  console.log('playlist number regression tests: PASS');
} finally {
  if (backup === null) fs.rmSync(file, { force: true });
  else fs.writeFileSync(file, backup);
}
