import fs from 'node:fs';
import assert from 'node:assert/strict';

const index = fs.readFileSync(new URL('../src/index.js', import.meta.url), 'utf8');
assert.match(index, /const QUEUE_PAGE_SIZE = 5/);
assert.match(index, /\.help playback \| \.help queue \| \.help fx 2 \| \.help voice \| \.help radio/);
assert.match(index, /COMMAND_DEDUP_MS = 3500/);
assert.doesNotMatch(index, /\.9d/);
console.log('UI/command regression checks passed.');
