#!/usr/bin/env node
import { execFileSync, spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { findFfmpeg } from '../src/ffmpeg.js';

function run(cmd, args, options = {}) {
  console.log(`[Setup] ${cmd} ${args.join(' ')}`);
  const r = spawnSync(cmd, args, { stdio: 'inherit', shell: false, ...options });
  return r.status === 0;
}
function has(cmd) {
  try { execFileSync(process.platform === 'win32' ? 'where.exe' : 'which', [cmd], { stdio: 'ignore' }); return true; }
  catch { return false; }
}
const REQUIRED_PACKAGES = [
  'ws', '@livekit/rtc-node', 'youtube-dl-exec', 'ink', 'react',
  'is-ci', 'is-upper-case', 'is-in-ci', 'better-sqlite3'
];
const PINNED_INSTALL = [
  '@livekit/rtc-node@0.13.35',
  'ws@8.21.0',
  'youtube-dl-exec@3.1.15',
  'ink@4.4.1',
  'react@18.2.0',
  'is-ci@3.0.1',
  'is-upper-case@3.0.0',
  'is-in-ci@2.0.0',
  'better-sqlite3@13.0.3'
];

function packageExists(name) {
  return existsSync(new URL(`../node_modules/${name}/package.json`, import.meta.url));
}

function needNodeDeps() {
  return REQUIRED_PACKAGES.some(name => !packageExists(name));
}

function needTuiDeps() {
  return ['ink', 'react', 'is-ci', 'is-upper-case', 'is-in-ci'].some(name => !packageExists(name));
}

if (needNodeDeps()) {
  const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  const nodeMajor = Number(process.versions.node.split('.')[0]);
  if (!Number.isFinite(nodeMajor) || nodeMajor < 22) {
    console.error(`[Setup] Node.js ${process.versions.node} is too old for better-sqlite3@13.0.3. Node.js 22+ is required.`);
    process.exit(1);
  }

  console.log('[Setup] Node dependencies are missing. Installing...');
  console.log(`[Setup] Node: ${process.version} | npm: checking... | OS: ${process.platform}/${process.arch}`);
  console.log('[Setup] Registry: https://registry.npmjs.org/');

  const lockfile = existsSync(new URL('../package-lock.json', import.meta.url));
  // Use npm install here rather than npm ci when bootstrapping. This project
  // deliberately declares Ink's small runtime helpers (is-ci, is-upper-case
  // and is-in-ci) directly so partially-installed/mixed node_modules trees
  // can be repaired and the lockfile can be reconciled automatically.
  const installArgs = [
    'install',
    '--include=optional',
    '--no-audit',
    '--no-fund',
    '--prefer-online',
    '--fetch-retries=5',
    '--fetch-retry-factor=2',
    '--fetch-retry-mintimeout=2000',
    '--fetch-retry-maxtimeout=30000'
  ];

  // Install the known-good dependency set instead of allowing a fresh major
  // release of LiveKit RTC to change the native ABI/API underneath the bot.
  // v0.13.35 is the last pre-1.0 release and was published immediately before
  // 1.0.0; it also has the platform-specific native packages this project uses.
  const installCmdArgs = ['install', ...PINNED_INSTALL, ...installArgs.slice(1)];
  const installed = run(npm, installCmdArgs, {
    env: { ...process.env, npm_config_registry: 'https://registry.npmjs.org/' }
  });

  if (!installed) {
    console.error('');
    console.error('[Setup] npm dependency installation failed.');
    console.error('[Setup] A detailed npm log should be visible above.');
    console.error('[Setup] Run this exact command manually if you need the raw npm diagnostic:');
    console.error(`        ${npm} install ${PINNED_INSTALL.join(' ')} --include=optional --no-audit --no-fund --verbose`);
    if (process.platform === 'win32') {
      console.error('[Setup] Also verify:');
      console.error('        node -v');
      console.error('        npm -v');
      console.error('        npm cache verify');
      console.error('        npm config get registry');
    }
    process.exit(1);
  }
}

if (needTuiDeps()) {
  const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  console.log('[Setup] Repairing TUI runtime dependencies (Ink/React + required helpers)...');
  const installed = run(npm, [
    'install',
    'ink@4.4.1', 'react@18.2.0', 'is-ci@3.0.1', 'is-upper-case@3.0.0', 'is-in-ci@2.0.0',
    '--no-audit', '--no-fund', '--prefer-online',
    '--fetch-retries=5', '--fetch-retry-factor=2',
    '--fetch-retry-mintimeout=2000', '--fetch-retry-maxtimeout=30000'
  ], { env: { ...process.env, npm_config_registry: 'https://registry.npmjs.org/' } });
  if (!installed || needTuiDeps()) {
    console.error('[Setup] Could not repair the TUI runtime dependencies.');
    console.error('[Setup] Run: npm install ink@4.4.1 react@18.2.0 is-ci@3.0.1 is-upper-case@3.0.0 is-in-ci@2.0.0');
    process.exit(1);
  }
}

if (findFfmpeg()) {
  console.log(`[Setup] FFmpeg: ${findFfmpeg()}`);
  process.exit(0);
}

console.log(`[Setup] FFmpeg not found; attempting automatic installation for ${process.platform}/${process.arch}...`);
let ok = false;
const isTermux = process.platform === 'android' || !!process.env.TERMUX_VERSION || !!process.env.PREFIX?.includes('/com.termux/');
if (isTermux) {
  if (has('pkg')) {
    run('pkg', ['update', '-y']);
    ok = run('pkg', ['install', '-y', 'ffmpeg']);
  }
} else if (process.platform === 'win32') {
  if (has('winget')) ok = run('winget', ['install', '--id', 'Gyan.FFmpeg', '-e', '--source', 'winget', '--accept-package-agreements', '--accept-source-agreements']);
  if (!ok && has('choco')) ok = run('choco', ['install', 'ffmpeg', '-y']);
} else if (process.platform === 'darwin') {
  if (has('brew')) ok = run('brew', ['install', 'ffmpeg']);
} else if (has('apt-get')) {
  const sudo = process.getuid?.() === 0 ? null : (has('sudo') ? 'sudo' : false);
  if (sudo !== false) {
    ok = sudo ? run('sudo', ['apt-get', 'update']) : run('apt-get', ['update']);
    if (ok) ok = sudo ? run('sudo', ['apt-get', 'install', '-y', 'ffmpeg']) : run('apt-get', ['install', '-y', 'ffmpeg']);
  }
} else if (has('dnf')) {
  ok = run('sudo', ['dnf', 'install', '-y', 'ffmpeg']);
} else if (has('pacman')) {
  ok = run('sudo', ['pacman', '-Sy', '--noconfirm', 'ffmpeg']);
}

let resolved = findFfmpeg();
if (!resolved && process.platform === 'win32') {
  // winget may install successfully but the current Node process keeps the old
  // PATH. Search common WinGet package locations before failing.
  try {
    const ps = `Get-ChildItem -Path "$env:LOCALAPPDATA\\Microsoft\\WinGet\\Packages" -Filter ffmpeg.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName`;
    const out = execFileSync('powershell.exe', ['-NoProfile','-NonInteractive','-Command', ps], {encoding:'utf8',stdio:['ignore','pipe','ignore']}).trim();
    if (out) process.env.FFMPEG_PATH = out;
    resolved = findFfmpeg();
  } catch {}
}
if (!resolved) {
  console.error('[Setup] Could not install/find FFmpeg automatically.');
  if (isTermux) console.error('[Setup] Termux: pkg update -y && pkg install -y ffmpeg');
  else if (process.platform === 'win32') console.error('[Setup] Windows: winget install --id Gyan.FFmpeg -e');
  else if (process.platform === 'darwin') console.error('[Setup] macOS: brew install ffmpeg');
  else console.error('[Setup] Linux/Debian: sudo apt-get update && sudo apt-get install -y ffmpeg');
  process.exit(1);
}
console.log(`[Setup] FFmpeg ready: ${resolved}`);
