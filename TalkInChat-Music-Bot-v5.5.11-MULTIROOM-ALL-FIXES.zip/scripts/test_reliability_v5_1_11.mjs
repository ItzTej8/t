import assert from 'node:assert/strict';
import fs from 'node:fs';

const player = fs.readFileSync('src/player.js', 'utf8');
const voice = fs.readFileSync('src/voice.js', 'utf8');
const index = fs.readFileSync('src/index.js', 'utf8');
const proto = fs.readFileSync('src/proto.js', 'utf8');
const ws = fs.readFileSync('src/ws.js', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));

assert.equal(pkg.version, '5.2.16');
assert.ok(player.includes('this.on("error", err =>'), 'player must have a safe default error listener');
assert.ok(voice.includes('this.on("error", err =>'), 'voice manager must have a safe default error listener');
assert.ok(player.includes('emit("streamError"'), 'yt-dlp source failures must be surfaced');
assert.ok(index.includes('mediaRetryCount < 3'), 'media pipeline failures must retry the source before voice recovery');
assert.ok(index.includes('Media pipeline remained unhealthy after 3 source retries'), 'permanent media failure must escalate to voice recovery');
assert.ok(player.includes('const available = Math.max(0, this.queueLimit - this.queue.length)'), 'playlist enqueue must respect queue limit');
assert.ok(index.includes('preset === "vaporwave"'), 'vaporwave must affect playback timing');
assert.ok(index.includes('const applyFilterChange = async'), 'filter changes must preserve playback position');
assert.ok(index.includes('sleepTriggered'), 'sleep timer must suppress automatic voice recovery');
assert.ok(index.includes('if (sleepTimer) { clearTimeout(sleepTimer); sleepTimer = null; }'), 'waking playback must cancel an existing sleep timer');
assert.ok(index.includes('scheduleStreamDirectoryRefreshes'), 'directory refresh timers must be tracked');
assert.ok(index.includes('streamDirectoryGeneration'), 'directory refresh timers must be generation guarded');
assert.ok(voice.includes('nextFrameAt'), 'audio frames must be paced in realtime');
assert.ok(voice.includes('await this._closeResource(track)'), 'native track cleanup must be awaited');
assert.ok(voice.includes('await this._closeResource(source)'), 'native source cleanup must be awaited');
assert.ok(proto.includes('FIELD_KINDS'), 'protobuf field types must be message-specific');
assert.ok(proto.includes('RoomEvent: { animation: "int"'), 'RoomEvent string/bool fields must not use global-name typing');
assert.ok(proto.includes('decodePackedVarints'), 'packed repeated scalar protobuf fields must be supported');
assert.ok(ws.includes('CHATP_WS_TLS_INSECURE === "true" ? false : true'), 'TLS verification must be enabled by default');
assert.ok(!index.match(/restartCurrent\([^\n]*getElapsedSeconds\(\)/), 'effect changes must snapshot position before changing playback rate');
assert.ok(!player.includes('this.playId += 1;\n      this.playId += 1;'), 'duplicate playId increments must be absent');
assert.ok(!player.includes('this.recentHistory.unshift({ ...next, playedAt: Date.now() });\n      this.recentHistory.unshift'), 'duplicate history insertion must be absent');

assert.ok(player.includes('YTDLP_META_TIMEOUT_MS'), 'metadata yt-dlp operations must have bounded timeouts');
assert.ok(player.includes('ytdlpJsonWithHardTimeout'), 'metadata yt-dlp must use a hard Node-side process timeout');
assert.ok(voice.includes('jitterSeconds') && index.includes('markDecodedProgress'), 'streaming watchdog must use decoded audio progress');
assert.ok(player.includes('addTrackObject'), 'all programmatic queue additions must have a central limit guard');
assert.ok(player.includes('recordHistory = true'), 'playback history must be explicitly controlled');
assert.ok(player.includes('recordHistory: false'), 'seek/restart paths must not pollute history');
assert.ok(voice.includes('PCM audio pump stopped before FFmpeg completed'), 'PCM pump failure must surface as playbackError');
assert.ok(!voice.includes('stopPlayback({ silent = true } = {}) { this.playbackGeneration++; this._killCurrentFfmpeg(); this._paused = false; this._publishDone = Promise.resolve();'), 'stopPlayback must not discard the active publish promise');
assert.ok(voice.includes('performance.now()'), 'PCM pacing must use a monotonic high-resolution clock');
assert.ok(index.includes('await voiceManager.waitForCleanup()'), 'voice recovery must wait for native cleanup');
assert.ok(index.includes('const activeRoom = String(client.currentRoom || defaultRoom || "").trim()'), 'stream events must be bound to the active room');
assert.ok(!index.includes(`client.currentRoom = room;\n\n    switch (cmd)`), 'incoming command events must not silently change joined room');
assert.ok(!index.includes('startDashboard') && !fs.existsSync('src/dashboard.js'), 'web dashboard must be completely removed');
assert.ok(!index.includes(`recordUserCommand(username || userId || "User");\n    recordCommunityCommand`), 'command statistics must not be double-counted');
assert.ok(index.includes('recordCommunityPlay(track?.requestedBy || "User")'), 'community play stats must use the track requester');
assert.ok(ws.includes('this.connectionGeneration'), 'WebSocket must use connection generations');
assert.ok(ws.includes('superseded'), 'stale WebSocket connections must be superseded');
assert.ok(index.includes('socket.close(1000, "initial connection timeout")'), 'initial WebSocket timeout must close the socket');
assert.ok(player.includes('setQueueLimit(value)'), 'player queue limit setter must exist');
assert.ok(player.includes('if (this.queue.length > this.queueLimit) this.queue.length = this.queueLimit'), 'lowering queue limit must trim the queue');
assert.ok(player.includes('if (this.queue.length >= this.queueLimit) return false'), 'central queue insertion must reject overflow');

assert.ok(index.includes('voiceRecoveryGeneration'), 'voice recovery must reject stale generation callbacks');
assert.ok(index.includes('SIGINT') && index.includes('SIGTERM'), 'graceful shutdown signal handlers must exist');

assert.ok(voice.includes('this._connectionGeneration'), 'LiveKit attempts must have a connection generation');
assert.ok(voice.includes('LiveKit connection", () =>'), 'LiveKit connect timeout must actively cancel the Room');
assert.ok(voice.includes('room.disconnect();'), 'LiveKit timeout cleanup must disconnect the timed-out Room');
assert.ok(player.includes('startDecodedWatchdog'), 'pending/connected audio must arm the decoded-audio watchdog before silence');
assert.ok(player.includes('clearQueue()') && player.includes('this.playHistory = []'), 'clearQueue must clear queue-loop history');
assert.ok(index.includes('applyFilterChange("8d"'), '8D changes must restart the active stream immediately');
assert.ok(player.includes('requested > this.queue.length'), 'moveQueue must validate destination bounds');
assert.ok(player.includes('const b = Math.min(this.queue.length, requested - 1)'), 'moveQueue must support moving to the end');

console.log('v5.2.0 reliability regression checks: PASS');
