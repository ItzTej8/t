import assert from 'node:assert/strict';
import { decode } from '../src/proto.js';

// UserItem { username=aryan, role=owner } encoded as:
// field 1 username + field 6 role.
const user = Buffer.from([0x0a, 0x05, ...Buffer.from('aryan'), 0x32, 0x05, ...Buffer.from('owner')]);

// ResultMessage.users = repeated UserItem, field 11.
const result = Buffer.concat([Buffer.from([0x5a, user.length]), user]);
const decodedResult = decode('ResultMessage', result);
assert.ok(Array.isArray(decodedResult.users));
assert.equal(decodedResult.users[0].username, 'aryan');
assert.equal(decodedResult.users[0].role, 'owner');

// RoomEvent.users = repeated UserItem, field 40.
const roomEvent = Buffer.concat([Buffer.from([0xc2, 0x02, user.length]), user]);
const decodedEvent = decode('RoomEvent', roomEvent);
assert.ok(Array.isArray(decodedEvent.users));
assert.equal(decodedEvent.users[0].username, 'aryan');
assert.equal(decodedEvent.users[0].role, 'owner');

console.log('PASS: v5.5.5 owner roster protobuf decoding');
