#!/usr/bin/env node
import process from 'node:process';
import { findFfmpeg } from '../src/ffmpeg.js';
console.log('TalkInChat Music Bot doctor');
console.log(`Platform : ${process.platform} ${process.arch}`);
console.log(`Node     : ${process.version}`);
console.log(`FFmpeg   : ${findFfmpeg() || 'NOT FOUND'}`);
try { await import('@livekit/rtc-node'); console.log('LiveKit  : OK'); } catch (e) { console.log(`LiveKit  : ERROR - ${e.message}`); }
try { await import('youtube-dl-exec'); console.log('yt-dlp   : OK'); } catch (e) { console.log(`yt-dlp   : ERROR - ${e.message}`); }
