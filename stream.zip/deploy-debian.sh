#!/usr/bin/env bash
# ============================================================
#  Bigg Boss 24/7 Live Stream — Debian VPS Deploy Script
#  Supports: Debian 11 (Bullseye), Debian 12 (Bookworm), Ubuntu 22/24
#
#  Usage:
#    chmod +x deploy-debian.sh
#    sudo ./deploy-debian.sh
#
#  What this does:
#    1. Installs system dependencies (ffmpeg, bun, canvas libs, etc.)
#    2. Creates a dedicated 'biggboss' system user
#    3. Copies project to /opt/bigg-boss-live
#    4. Installs npm dependencies with bun
#    5. Installs & enables a systemd service (auto-start + auto-restart)
#    6. Opens health/MJPEG ports in ufw firewall (if active)
# ============================================================

set -euo pipefail

# ── Colours ──────────────────────────────────────────────────
RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'; CYN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${CYN}[INFO]${NC}  $*"; }
ok()    { echo -e "${GRN}[OK]${NC}    $*"; }
warn()  { echo -e "${YLW}[WARN]${NC}  $*"; }
err()   { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }

# ── Must be root ─────────────────────────────────────────────
[[ $EUID -ne 0 ]] && err "Run as root: sudo ./deploy-debian.sh"

APP_DIR="/opt/bigg-boss-live"
SERVICE_NAME="bigg-boss-live"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
APP_USER="biggboss"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo -e "${CYN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${CYN}║   Bigg Boss 24/7 Live — Debian VPS Deploy Script     ║${NC}"
echo -e "${CYN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""

# ── Step 1: System packages ───────────────────────────────────
info "Updating apt and installing system dependencies..."
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
    ffmpeg \
    curl \
    unzip \
    ca-certificates \
    build-essential \
    python3 \
    libcairo2-dev \
    libpango1.0-dev \
    libjpeg-dev \
    libgif-dev \
    librsvg2-dev \
    libpixman-1-dev \
    pkg-config \
    fontconfig \
    fonts-dejavu-core \
    fonts-liberation \
    fonts-noto-color-emoji \
    logrotate
ok "System packages installed."

# ── Step 2: Install Bun ──────────────────────────────────────
if ! command -v bun &>/dev/null; then
    info "Installing Bun runtime..."
    curl -fsSL https://bun.sh/install | bash
    # Make bun available system-wide
    BUN_BIN="$HOME/.bun/bin/bun"
    if [[ -f "$BUN_BIN" ]]; then
        ln -sf "$BUN_BIN" /usr/local/bin/bun
        ok "Bun installed at /usr/local/bin/bun"
    else
        err "Bun install failed — check https://bun.sh"
    fi
else
    ok "Bun already installed: $(bun --version)"
fi

# Ensure /usr/local/bin/bun exists (user may have it in ~/.bun)
if [[ ! -f /usr/local/bin/bun ]]; then
    for candidate in /root/.bun/bin/bun /home/*/.bun/bin/bun; do
        [[ -f "$candidate" ]] && ln -sf "$candidate" /usr/local/bin/bun && break
    done
fi
[[ -f /usr/local/bin/bun ]] || err "/usr/local/bin/bun not found. Install bun manually."

# ── Step 3: Create dedicated system user ──────────────────────
if ! id "$APP_USER" &>/dev/null; then
    info "Creating system user '$APP_USER'..."
    useradd --system --no-create-home --shell /usr/sbin/nologin "$APP_USER"
    ok "User '$APP_USER' created."
else
    ok "User '$APP_USER' already exists."
fi

# ── Step 4: Copy project files ────────────────────────────────
info "Installing project to $APP_DIR ..."
mkdir -p "$APP_DIR"/{data,logs,assets/contestants}

# Sync project files (exclude dev/windows artifacts)
rsync -a --delete \
    --exclude='.git' \
    --exclude='node_modules' \
    --exclude='bun.lock' \
    --exclude='*.bat' \
    --exclude='*.ps1' \
    --exclude='autostart.bat' \
    --exclude='data/*.sqlite*' \
    --exclude='data/*.json' \
    --exclude='logs/' \
    --exclude='scratch/' \
    "$SCRIPT_DIR/" "$APP_DIR/"

ok "Project files copied to $APP_DIR."

# ── Step 5: .env file ────────────────────────────────────────
if [[ ! -f "$APP_DIR/.env" ]]; then
    if [[ -f "$SCRIPT_DIR/.env" ]]; then
        cp "$SCRIPT_DIR/.env" "$APP_DIR/.env"
        warn ".env copied from source. Edit $APP_DIR/.env with your stream key!"
    else
        warn ".env not found — creating template. You MUST edit $APP_DIR/.env!"
        cat > "$APP_DIR/.env" <<'ENVEOF'
YOUTUBE_RTMP_URL=rtmp://a.rtmp.youtube.com/live2
YOUTUBE_STREAM_KEY=YOUR_STREAM_KEY_HERE
YOUTUBE_VIDEO_ID=YOUR_VIDEO_ID_HERE
YOUTUBE_CHANNEL_ID=YOUR_CHANNEL_ID_HERE
ADMIN_CHANNEL_IDS=
STREAM_RESOLUTION=720x1280
RENDER_RESOLUTION=720x1280
FPS=30
RENDER_FPS=30
JPEG_QUALITY=72
BITRATE=2500k
VIDEO_CODEC=libx264
PRESET=veryfast
ENCODER_THREADS=4
GOP_SECONDS=2
VOTE_COMMAND=!vote
PUBLIC_THEME_COMMANDS=true
PUBLIC_MUSIC_COMMANDS=true
PUBLIC_SCREEN_COMMANDS=true
SCREEN_INTERVAL_MS=20000
SCREEN_TRANSITION_MS=650
BACKGROUND_IMAGE=assets/bb20_bg.jpg
HEALTH_PORT=8787
FRAME_SERVER_PORT=8788
STATE_FILE=data/state.json
DB_FILE=data/votes.sqlite
IMAGE_CACHE_DIR=data/contestant-images
MEMORY_WARN_MB=800
MEMORY_EXIT_MB=2048
ENVEOF
    fi
fi
# Protect .env (contains stream key)
chmod 600 "$APP_DIR/.env"

# ── Step 6: Install Node dependencies ────────────────────────
info "Installing npm dependencies with bun..."
cd "$APP_DIR"
bun install --frozen-lockfile 2>/dev/null || bun install
ok "Dependencies installed."

# ── Step 7: Set permissions ───────────────────────────────────
chown -R "$APP_USER:$APP_USER" "$APP_DIR"
chmod -R 755 "$APP_DIR"
chmod 600 "$APP_DIR/.env"
ok "Permissions set."

# ── Step 8: Install systemd service ──────────────────────────
info "Installing systemd service..."
sed \
    -e "s|User=biggboss|User=$APP_USER|g" \
    -e "s|Group=biggboss|Group=$APP_USER|g" \
    -e "s|WorkingDirectory=/opt/bigg-boss-live|WorkingDirectory=$APP_DIR|g" \
    -e "s|EnvironmentFile=/opt/bigg-boss-live/.env|EnvironmentFile=$APP_DIR/.env|g" \
    -e "s|ReadWritePaths=/opt/bigg-boss-live/data /opt/bigg-boss-live/logs|ReadWritePaths=$APP_DIR/data $APP_DIR/logs|g" \
    -e "s|ExecStart=/usr/local/bin/bun|ExecStart=$(which bun)|g" \
    "$APP_DIR/systemd-bigg-boss.service" > "$SERVICE_FILE"

chmod 644 "$SERVICE_FILE"
systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
ok "Systemd service installed and enabled (auto-start on boot)."

# ── Step 9: Set up log rotation ───────────────────────────────
cat > "/etc/logrotate.d/$SERVICE_NAME" <<LOGEOF
/opt/bigg-boss-live/logs/*.log {
    daily
    rotate 7
    compress
    missingok
    notifempty
    copytruncate
    su $APP_USER $APP_USER
}
LOGEOF
ok "Log rotation configured."

# ── Step 10: Firewall (ufw) ───────────────────────────────────
if command -v ufw &>/dev/null && ufw status | grep -q "Status: active"; then
    info "Configuring UFW firewall..."
    ufw allow ssh
    # Health & frame server ports are local-only (127.0.0.1) by design — no public port needed
    ok "Firewall: SSH allowed. Health/frame ports stay on 127.0.0.1 (local only)."
fi

# ── Step 11: Start the service ────────────────────────────────
info "Starting bigg-boss-live service..."
systemctl start "$SERVICE_NAME"
sleep 3

STATUS=$(systemctl is-active "$SERVICE_NAME" 2>/dev/null || echo "unknown")
if [[ "$STATUS" == "active" ]]; then
    ok "Service is RUNNING!"
else
    warn "Service status: $STATUS — check logs: journalctl -u $SERVICE_NAME -n 50 --no-pager"
fi

# ── Summary ───────────────────────────────────────────────────
echo ""
echo -e "${GRN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${GRN}║              DEPLOYMENT COMPLETE!                    ║${NC}"
echo -e "${GRN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${CYN}App directory:${NC}   $APP_DIR"
echo -e "  ${CYN}Service:${NC}         $SERVICE_NAME"
echo -e "  ${CYN}Config:${NC}          $APP_DIR/.env"
echo -e "  ${CYN}Service file:${NC}    $SERVICE_FILE"
echo ""
echo -e "${YLW}Useful commands:${NC}"
echo -e "  ${GRN}systemctl status $SERVICE_NAME${NC}          — check if running"
echo -e "  ${GRN}journalctl -u $SERVICE_NAME -f${NC}         — live logs"
echo -e "  ${GRN}journalctl -u $SERVICE_NAME -n 100${NC}     — last 100 log lines"
echo -e "  ${GRN}systemctl restart $SERVICE_NAME${NC}        — restart stream"
echo -e "  ${GRN}systemctl stop $SERVICE_NAME${NC}           — stop stream"
echo -e "  ${GRN}systemctl disable $SERVICE_NAME${NC}        — disable auto-start"
echo -e "  ${GRN}nano $APP_DIR/.env${NC}               — edit config"
echo ""
echo -e "${YLW}⚠  If .env was newly created, edit it now:${NC}"
echo -e "  ${GRN}nano $APP_DIR/.env${NC}"
echo -e "  ${GRN}systemctl restart $SERVICE_NAME${NC}"
echo ""
