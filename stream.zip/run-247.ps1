# Bigg Boss 24x7 Continuous YouTube Live Stream Runner
# Automatically restarts if stream exits, and keeps Windows awake while streaming.

$Host.UI.RawUI.WindowTitle = "Bigg Boss 24x7 YouTube Live Stream"
Set-Location -Path $PSScriptRoot

# Prevent Windows from entering sleep mode while running
try {
    Add-Type -Namespace Win32 -Name SystemState -MemberDefinition @"
    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public static extern uint SetThreadExecutionState(uint esFlags);
"@
    # ES_CONTINUOUS (0x80000000) | ES_SYSTEM_REQUIRED (0x00000001) | ES_AWAYMODE_REQUIRED (0x00000040)
    [Win32.SystemState]::SetThreadExecutionState([uint32]0x80000041) | Out-Null
    Write-Host "[System] Sleep prevention activated. PC will stay awake while streaming." -ForegroundColor Green
} catch {
    Write-Host "[System] Note: Could not set execution state ($($_.Exception.Message))." -ForegroundColor Yellow
}

$RestartCount = 0

Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host "   Bigg Boss 24x7 Continuous YouTube Live Stream Runner" -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan

# Auto-kill previous stream instance if still running
if (Test-Path "data\bigg-boss.pid") {
    $OldPid = (Get-Content "data\bigg-boss.pid" -ErrorAction SilentlyContinue | Out-String).Trim()
    if ($OldPid -and ($OldPid -as [int])) {
        Write-Host "[Auto-Clean] Stopping previous stream instance (PID $OldPid)..." -ForegroundColor Yellow
        taskkill /F /PID $OldPid /T 2>$null | Out-Null
        Start-Sleep -Milliseconds 800
    }
}

while ($true) {
    $RestartCount++
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "`n[$Timestamp] Launching stream (Run #$RestartCount)...`n" -ForegroundColor Cyan

    & bun run src/index.mjs
    $ExitCode = $LASTEXITCODE

    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "`n=======================================================" -ForegroundColor Yellow
    Write-Host "[$Timestamp] Stream exited with code $ExitCode." -ForegroundColor Yellow
    Write-Host "Restarting in 3 seconds... (Press Ctrl+C to stop)" -ForegroundColor Yellow
    Write-Host "=======================================================" -ForegroundColor Yellow

    Start-Sleep -Seconds 3
}
