@echo off
title Bigg Boss 24x7 YouTube Live Stream
cd /d "%~dp0"

echo =======================================================
echo   Bigg Boss 24x7 Continuous YouTube Live Stream Runner
echo =======================================================
echo.

set RESTART_COUNT=0

if exist data\bigg-boss.pid (
    for /f %%p in (data\bigg-boss.pid) do (
        echo [Auto-Clean] Stopping previous stream instance (PID %%p)...
        taskkill /F /PID %%p /T >nul 2>&1
    )
    timeout /t 1 /nobreak >nul
)

:loop
set /a RESTART_COUNT+=1
echo [%DATE% %TIME%] Starting stream instance (Run #%RESTART_COUNT%)...
echo.

bun run src/index.mjs

set EXIT_CODE=%ERRORLEVEL%
echo.
echo =======================================================
echo [%DATE% %TIME%] Stream process exited with code %EXIT_CODE%.
echo Restarting automatically in 3 seconds... (Press Ctrl+C to cancel)
echo =======================================================
echo.

timeout /t 3 /nobreak >nul
goto loop
