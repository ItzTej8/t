#!/usr/bin/env bash
# ============================================================
#  update.sh — Pull latest code and restart the stream service
#
#  Run from the VPS as root or with sudo:
#    sudo ./update.sh
# ============================================================
set -euo pipefail

APP_DIR="/opt/bigg-boss-live"
SERVICE_NAME="bigg-boss-live"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'; CYN='\033[0;36m'; NC='\033[0m'
info() { echo -e "${CYN}[INFO]${NC}  $*"; }
ok()   { echo -e "${GRN}[OK]${NC}    $*"; }

[[ $EUID -ne 0 ]] && { echo -e "${RED}Run as root: sudo ./update.sh${NC}"; exit 1; }

info "Stopping service..."
systemctl stop "$SERVICE_NAME" || true

info "Syncing updated project files..."
rsync -a --delete \
    --exclude='.git' \
    --exclude='node_modules' \
    --exclude='bun.lock' \
    --exclude='*.bat' \
    --exclude='*.ps1' \
    --exclude='.env' \
    --exclude='data/' \
    --exclude='logs/' \
    --exclude='scratch/' \
    "$SCRIPT_DIR/" "$APP_DIR/"

info "Reinstalling dependencies..."
cd "$APP_DIR"
bun install --frozen-lockfile 2>/dev/null || bun install

info "Fixing permissions..."
chown -R biggboss:biggboss "$APP_DIR"

info "Reloading systemd and starting service..."
systemctl daemon-reload
systemctl start "$SERVICE_NAME"
sleep 2

STATUS=$(systemctl is-active "$SERVICE_NAME" 2>/dev/null || echo "unknown")
ok "Service status: $STATUS"
echo ""
echo -e "  Live logs: ${GRN}journalctl -u $SERVICE_NAME -f${NC}"
