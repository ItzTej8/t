// Bigg Boss Season 20 — confirmed contestant catalog (17 entrants).
// Source checked against Pinkvilla's 17-person confirmed list, updated 07.09.2026.
export const contestants = [
  { no: 1,  name: "MC Mary Kom",           displayName: "Mary Kom",       imageUrl: "https://bigboss20.in/images/mc-mary-kom-avatar.jpg" },
  { no: 2,  name: "Amrapali Dubey",        displayName: "Amrapali",       imageUrl: "https://bigboss20.in/images/aamrapali-dubey-avatar.jpg" },
  { no: 3,  name: "Uditi Singh",           displayName: "Uditi Singh",    imageUrl: "https://bigboss20.in/images/uditi-singh-avatar.jpg" },
  { no: 4,  name: "Arishfa Khan",          displayName: "Arishfa Khan",   imageUrl: "https://bigboss20.in/images/arishfa-khan-avatar.jpg" },
  { no: 5,  name: "Aman Gandhi",           displayName: "Aman Gandhi",    imageUrl: "https://bigboss20.in/images/aman-gandhi-avatar.jpg" },
  { no: 6,  name: "Qazi Ahmad Tauqeer",    displayName: "Qazi Touqeer",   imageUrl: "https://bigboss20.in/images/qazi-ahmad-tauqeer-avatar.jpg" },
  { no: 7,  name: "Harsh Machare",         displayName: "Yung DSA",       imageUrl: "https://bigboss20.in/images/harsh-machare-yung-dsa-avatar.jpg" },
  { no: 8,  name: "Kushal Tanwar",         displayName: "Gullu",           imageUrl: "https://bigboss20.in/images/kushal-tanwar-gullu-avatar.jpg" },
  { no: 9,  name: "Rhiya Yadav",           displayName: "Rhiya Ahir",     imageUrl: "" },
  { no: 10, name: "Love Gill",             displayName: "Love Gill",       imageUrl: "https://bigboss20.in/images/love-gill-avatar.jpg" },
  { no: 11, name: "Rohed Khan",            displayName: "Rohed Khan",      imageUrl: "https://bigboss20.in/images/rohed-khan-avatar.jpg" },
  { no: 12, name: "Isha Rikhi",            displayName: "Isha Rikhi",      imageUrl: "https://bigboss20.in/images/isha-rikhi-avatar.jpg" },
  { no: 13, name: "Mahhi Vij",             displayName: "Mahhi Vij",       imageUrl: "https://bigboss20.in/images/mahhi-vij-avatar.jpg" },
  { no: 14, name: "Aasif Khan",            displayName: "Aasif Khan",      imageUrl: "https://bigboss20.in/images/aasif-khan-avatar.jpg" },
  { no: 15, name: "Rhiti Tiwari",          displayName: "Rhiti Tiwari",    imageUrl: "https://bigboss20.in/images/rhiti-tiwari-avatar.jpg" },
  { no: 16, name: "Kanika Mann",           displayName: "Kanika Mann",     imageUrl: "https://bigboss20.in/images/kanika-mann-avatar.jpg" },
  { no: 17, name: "Tanmay Singh",          displayName: "ScoutOP",         imageUrl: "https://bigboss20.in/images/tanmay-singh-scoutop-avatar.jpg" },
];
