import { createCanvas, loadImage } from "@napi-rs/canvas";
import { readFile } from "node:fs/promises";
import { config } from "./config.mjs";
import { state, stats } from "./state.mjs";
import { runtime } from "./runtime.mjs";
import { on } from "./events.mjs";
import { startFrameServer, publishFrame, stopFrameServer } from "./frame-server.mjs";
import {
  getEvents,
  interactiveState,
  getTopViewers,
  prune,
  tickScreens,
  getScreenTransition,
  screenLabel,
  getSelectedContestant,
  isMenuVisible
} from "./interactive.mjs";

const BASE_W = 1080, BASE_H = 1920;
const W = config.renderWidth, H = config.renderHeight;
const sx = W / BASE_W, sy = H / BASE_H, sc = Math.min(sx, sy);
const px = v => v * sx, py = v => v * sy, ps = v => v * sc;

const canvas = createCanvas(W, H);
const ctx = canvas.getContext("2d", { alpha: false });
const oldSceneCanvas = createCanvas(W, H);
const oldCtx = oldSceneCanvas.getContext("2d", { alpha: false });
const newSceneCanvas = createCanvas(W, H);
const newCtx = newSceneCanvas.getContext("2d", { alpha: false });

const SCREEN_ORDER = ["main", "race", "stats", "supporters", "menu", "events"];
let running = false;
let bgImage = null;
let contestantImages = new Map();
let lastDraw = Date.now();
let capturedTransitionKey = "";
const shownVotes = new Map();
const shownRaceVotes = new Map();
const seeded = new Set();

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const ease = (k, dt) => 1 - Math.exp(-k * clamp(dt || 0, 0, 0.1));

function safeWeight(w) {
  if (typeof w === "number") return Math.min(900, Math.max(100, Math.round(w / 100) * 100));
  const str = String(w ?? "").toLowerCase().trim();
  if (str === "bold" || str === "normal") return str;
  const num = parseInt(str, 10);
  if (!isNaN(num)) return Math.min(900, Math.max(100, Math.round(num / 100) * 100));
  return 700;
}

function rr(c, x, y, w, h, r = 14) {
  c.beginPath();
  c.roundRect(px(x), py(y), ps(w), ps(h), ps(r));
}

function text(v, x, y, size, color, weight = 700, align = "left") {
  textC(ctx, v, x, y, size, color, weight, align);
}

function textC(c, v, x, y, size, color, weight = 700, align = "left") {
  const w = safeWeight(weight);
  const sz = Math.max(8, Math.round(ps(size)));
  c.font = `${w} ${sz}px "Segoe UI", "Segoe UI Emoji", Arial, sans-serif`;
  c.fillStyle = color;
  c.textAlign = align;
  c.textBaseline = "alphabetic";
  c.fillText(String(v ?? ""), px(x), py(y));
}

function fit(v, n) {
  const s = String(v ?? "");
  return s.length > n ? `${s.slice(0, n - 1)}…` : s;
}

function palette(themeName = state.theme) {
  if (themeName === "light") {
    return {
      theme: "light",
      bg: "#f8f9fa",
      bgTop: "#fff8ea",
      bgBot: "#f3f5f8",
      panel: "rgba(255, 255, 255, 0.96)",
      card: "#ffffff",
      cardBorder: "#e2e8f0",
      cardShadow: "rgba(15, 23, 42, 0.08)",
      text: "#0f172a",
      titleText: "#10203b",
      muted: "#64748b",
      line: "#e2e8f0",
      gold: "#d49a18",
      goldBright: "#f59e0b",
      goldMetallic: "#eab308",
      gold3dDark: "#a16207",
      navyPill: "#0b1a30",
      barBg: "#e2e8f0",
      cyan: "#0284c7",
      pink: "#db2777",
      green: "#16a34a",
      red: "#dc2626",
      purple: "#9333ea",
      rankGradients: [
        ["#facc15", "#eab308"], // 1 Gold
        ["#38bdf8", "#0284c7"], // 2 Blue
        ["#f472b6", "#db2777"], // 3 Pink
        ["#4ade80", "#16a34a"], // 4 Green
        ["#c084fc", "#9333ea"], // 5 Purple
        ["#f87171", "#dc2626"]  // 6 Red
      ]
    };
  }
  return {
    theme: "dark",
    bg: "#030712",
    bgTop: "#081325",
    bgBot: "#02050c",
    panel: "rgba(8, 17, 33, 0.96)",
    card: "rgba(10, 20, 38, 0.95)",
    cardBorder: "rgba(148, 163, 184, 0.18)",
    cardShadow: "rgba(0, 0, 0, 0.6)",
    text: "#f8fafc",
    titleText: "#ffffff",
    muted: "#94a3b8",
    line: "rgba(148, 163, 184, 0.2)",
    gold: "#f5c542",
    goldBright: "#fbbf24",
    goldMetallic: "#ffd700",
    gold3dDark: "#b45309",
    navyPill: "#081528",
    barBg: "#17263c",
    cyan: "#38bdf8",
    pink: "#f472b6",
    green: "#4ade80",
    red: "#f87171",
    purple: "#c084fc",
    rankGradients: [
      ["#fbbf24", "#d97706"], // 1 Gold
      ["#38bdf8", "#0284c7"], // 2 Blue
      ["#f472b6", "#db2777"], // 3 Pink
      ["#4ade80", "#16a34a"], // 4 Green
      ["#c084fc", "#9333ea"], // 5 Purple
      ["#f87171", "#dc2626"]  // 6 Red
    ]
  };
}

let bgDarkCanvas = null;
let bgLightCanvas = null;

function buildPreRenderedBackdrop(theme) {
  const p = palette(theme);
  const cv = createCanvas(W, H);
  const cx = cv.getContext("2d", { alpha: false });

  cx.fillStyle = p.bg;
  cx.fillRect(0, 0, W, H);

  // Gradient backdrop
  const grad = cx.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, p.bgTop);
  grad.addColorStop(0.45, p.bg);
  grad.addColorStop(1, p.bgBot);
  cx.fillStyle = grad;
  cx.fillRect(0, 0, W, H);

  // Background photo pre-scaled and pre-composited
  if (bgImage) {
    const s = Math.max(W / bgImage.width, H / bgImage.height);
    const dw = bgImage.width * s, dh = bgImage.height * s;
    cx.save();
    cx.globalAlpha = theme === "light" ? 0.08 : 0.20;
    cx.drawImage(bgImage, (W - dw) / 2, (H - dh) / 2, dw, dh);
    cx.restore();
  }

  // Radiant golden glow behind top/hero
  const rad = cx.createRadialGradient(px(540), py(210), ps(20), px(540), py(210), ps(550));
  if (theme === "light") {
    rad.addColorStop(0, "rgba(251, 191, 36, 0.25)");
    rad.addColorStop(0.5, "rgba(245, 158, 11, 0.08)");
    rad.addColorStop(1, "transparent");
  } else {
    rad.addColorStop(0, "rgba(245, 197, 66, 0.22)");
    rad.addColorStop(0.5, "rgba(217, 119, 6, 0.08)");
    rad.addColorStop(1, "transparent");
  }
  cx.fillStyle = rad;
  cx.fillRect(0, 0, W, py(700));

  return cv;
}

async function loadBackground() {
  for (const path of [config.backgroundImage, "assets/bb20_bg.jpg"].filter(Boolean)) {
    try {
      bgImage = await loadImage(await readFile(path));
      break;
    } catch {}
  }
  bgDarkCanvas = buildPreRenderedBackdrop("dark");
  bgLightCanvas = buildPreRenderedBackdrop("light");
}

export function setContestantImages(m) {
  contestantImages = m;
}

function drawBackground(c, p, now) {
  const bg = p.theme === "light" ? bgLightCanvas : bgDarkCanvas;
  if (bg) {
    c.drawImage(bg, 0, 0);
  } else {
    c.fillStyle = p.bg;
    c.fillRect(0, 0, W, H);
  }

  // Volumetric sweeping light ray from top
  const rayAngle = Math.sin(now * 0.0004) * 0.15;
  const gRay = c.createLinearGradient(px(540), 0, px(540 + Math.sin(rayAngle) * 900), py(1200));
  const rayAlpha = p.theme === "light" ? 0.04 : 0.08;
  gRay.addColorStop(0, `rgba(251, 191, 36, ${rayAlpha * 1.5})`);
  gRay.addColorStop(0.6, `rgba(251, 191, 36, ${rayAlpha * 0.5})`);
  gRay.addColorStop(1, "transparent");
  c.fillStyle = gRay;
  c.beginPath();
  c.moveTo(px(540), 0);
  c.lineTo(px(540 + Math.sin(rayAngle - 0.08) * 1100), py(1200));
  c.lineTo(px(540 + Math.sin(rayAngle + 0.08) * 1100), py(1200));
  c.closePath();
  c.fill();

  // Floating ambient bokeh orbs
  for (let i = 0; i < 3; i++) {
    const bx = (i * 357 + Math.sin(now * 0.0004 + i) * 60) % 1080;
    const by = (i * 411 + Math.cos(now * 0.0003 + i) * 70 + 400) % 1400;
    const bRad = ps(20 + i * 8);
    const bAlpha = 0.04 + 0.03 * Math.sin(now * 0.001 + i);
    c.fillStyle = p.theme === "light" ? `rgba(245, 158, 11, ${bAlpha})` : `rgba(251, 191, 36, ${bAlpha})`;
    c.beginPath();
    c.arc(px(bx), py(by), bRad, 0, Math.PI * 2);
    c.fill();
  }

  // Golden starlight sparkles
  for (let i = 0; i < 14; i++) {
    const x = (i * 157 + Math.sin(now * 0.0006 + i * 2) * 35) % 1080;
    const y = (i * 217 + (now * 0.02 * (i % 3 + 1))) % 1800;
    const alpha = (0.2 + 0.6 * Math.sin(now * 0.002 + i));
    c.fillStyle = p.theme === "light"
      ? `rgba(217, 119, 6, ${alpha * 0.2})`
      : `rgba(251, 191, 36, ${alpha * 0.35})`;
    c.beginPath();
    c.arc(px(x), py(y), ps(2 + (i % 2)), 0, Math.PI * 2);
    c.fill();
  }
}

function drawTopBar(c, p, now) {
  const y = 28, h = 64;

  // Pulsing glow behind LIVE pill
  const livePulse = 0.5 + 0.5 * Math.sin(now * 0.006);
  c.fillStyle = "#ef233c";
  rr(c, 44, y, 170, h, h / 2);
  c.fill();
  c.strokeStyle = `rgba(239, 35, 60, ${0.3 + 0.5 * livePulse})`;
  c.lineWidth = ps(2 + livePulse * 2);
  rr(c, 44, y, 170, h, h / 2);
  c.stroke();
  // Play triangle
  c.fillStyle = "#ffffff";
  c.beginPath();
  c.moveTo(px(68), py(y + 19));
  c.lineTo(px(68), py(y + 45));
  c.lineTo(px(90), py(y + 32));
  c.closePath();
  c.fill();
  textC(c, "LIVE", 98, y + 44, 25, "#ffffff", 800);

  // Stream Duration counter
  const uptime = Math.max(0, Math.floor((now - runtime.startedAt) / 1000));
  const hh = String(Math.floor(uptime / 3600)).padStart(2, "0");
  const mm = String(Math.floor(uptime / 60) % 60).padStart(2, "0");
  const ss = String(uptime % 60).padStart(2, "0");
  textC(c, `${hh}:${mm}:${ss}`, 248, y + 44, 28, p.text, 700);

  // Live Viewer Count Badge — positioned directly below LIVE logo
  const rawViewers = runtime.chat.viewerCount || 0;
  const viewersCount = rawViewers > 0 ? rawViewers : state.uniqueVoters;
  const countStr = viewersCount >= 1000000
    ? `${(viewersCount / 1000000).toFixed(1)}M`
    : viewersCount >= 1000
    ? `${(viewersCount / 1000).toFixed(1)}K`
    : String(viewersCount || "--");

  const vBadgeX = 44, vBadgeY = 100, vBadgeW = 170, vBadgeH = 34;
  c.fillStyle = p.theme === "light" ? "rgba(255, 255, 255, 0.94)" : "rgba(10, 20, 38, 0.90)";
  rr(c, vBadgeX, vBadgeY, vBadgeW, vBadgeH, vBadgeH / 2);
  c.fill();
  c.strokeStyle = p.theme === "light" ? "#e2e8f0" : "rgba(245, 197, 66, 0.35)";
  c.lineWidth = ps(1.5);
  rr(c, vBadgeX, vBadgeY, vBadgeW, vBadgeH, vBadgeH / 2);
  c.stroke();

  // Eye icon inside viewer badge
  const eX = vBadgeX + 24, eY = vBadgeY + vBadgeH / 2;
  c.strokeStyle = p.goldBright;
  c.fillStyle = p.goldBright;
  c.lineWidth = ps(1.6);
  c.beginPath();
  c.moveTo(px(eX - 9), py(eY));
  c.quadraticCurveTo(px(eX), py(eY - 6), px(eX + 9), py(eY));
  c.quadraticCurveTo(px(eX), py(eY + 6), px(eX - 9), py(eY));
  c.stroke();
  c.beginPath();
  c.arc(px(eX), py(eY), ps(3), 0, Math.PI * 2);
  c.fill();

  textC(c, `${countStr} watching`, vBadgeX + 42, vBadgeY + 23, 16, p.text, 750);

  // Live Audio Studio EQ Visualizer (5 jumping bars)
  const eqX = 470, eqY = y + 44;
  const eqColors = [p.goldBright, p.cyan, p.pink, p.cyan, p.goldBright];
  for (let i = 0; i < 5; i++) {
    const freq = 0.0055 + (i * 0.0014);
    const barHeight = ps(7 + Math.abs(Math.sin(now * freq + i * 0.95)) * 26);
    const bx = eqX + i * 11;
    c.fillStyle = eqColors[i];
    rr(c, bx, eqY - (barHeight / sc), 6, (barHeight / sc), 3);
    c.fill();
    c.fillStyle = "#ffffff";
    c.fillRect(px(bx), py(eqY - (barHeight / sc)), ps(6), ps(2));
  }
  const onAirPulse = 0.5 + 0.5 * Math.sin(now * 0.005);
  c.save();
  c.fillStyle = p.goldBright;
  c.globalAlpha = 0.75 + 0.25 * onAirPulse;
  textC(c, "ON AIR", 542, y + 43, 17, p.goldBright, 800);
  c.restore();

  // Theme Pill Toggle (Right)
  const tw = 250, tx = 1080 - 44 - tw;
  c.fillStyle = p.theme === "light" ? "#ffffff" : "rgba(15, 23, 42, 0.9)";
  rr(c, tx, y, tw, h, h / 2);
  c.fill();
  c.strokeStyle = p.theme === "light" ? "#cbd5e1" : "rgba(245, 197, 66, 0.4)";
  c.lineWidth = ps(1.8);
  rr(c, tx, y, tw, h, h / 2);
  c.stroke();

  if (p.theme === "light") {
    textC(c, "Theme: LIGHT", tx + tw / 2 - 12, y + 43, 21, p.titleText, 700, "center");
    // Draw vector sun
    const sx0 = tx + tw - 42, sy0 = y + h / 2;
    c.fillStyle = p.goldBright;
    c.beginPath();
    c.arc(px(sx0), py(sy0), ps(7), 0, Math.PI * 2);
    c.fill();
    c.strokeStyle = p.goldBright;
    c.lineWidth = ps(1.5);
    for (let i = 0; i < 8; i++) {
      const a = (i * Math.PI) / 4;
      c.beginPath();
      c.moveTo(px(sx0 + Math.cos(a) * 9), py(sy0 + Math.sin(a) * 9));
      c.lineTo(px(sx0 + Math.cos(a) * 13), py(sy0 + Math.sin(a) * 13));
      c.stroke();
    }
  } else {
    textC(c, "Theme: DARK", tx + tw / 2 - 10, y + 43, 21, p.text, 700, "center");
    // Draw vector crescent moon
    const mx = tx + tw - 42, my = y + h / 2;
    c.fillStyle = p.goldBright;
    c.beginPath();
    c.arc(px(mx), py(my), ps(8), 0, Math.PI * 2);
    c.fill();
    c.fillStyle = "rgba(15, 23, 42, 0.9)";
    c.beginPath();
    c.arc(px(mx + 3), py(my - 2), ps(6.5), 0, Math.PI * 2);
    c.fill();
  }
}

function drawEye(c, p, cx, cy, scale = 1, now = Date.now()) {
  c.save();
  c.translate(px(cx), py(cy));
  c.scale(sc * scale, sc * scale);

  const pulse = 1 + Math.sin(now * 0.003) * 0.025;
  c.scale(pulse, pulse);

  // Outer glowing aura
  const aura = c.createRadialGradient(0, 0, 40, 0, 0, 180);
  aura.addColorStop(0, "rgba(245, 197, 66, 0.35)");
  aura.addColorStop(1, "transparent");
  c.fillStyle = aura;
  c.beginPath();
  c.arc(0, 0, 180, 0, Math.PI * 2);
  c.fill();

  // Outer golden eyelid shape
  c.beginPath();
  c.moveTo(-160, 0);
  c.quadraticCurveTo(0, -115, 160, 0);
  c.quadraticCurveTo(0, 115, -160, 0);
  c.closePath();
  c.strokeStyle = p.goldBright;
  c.lineWidth = 10;
  c.stroke();

  // Secondary inner eyelid ring
  c.beginPath();
  c.moveTo(-138, 0);
  c.quadraticCurveTo(0, -90, 138, 0);
  c.quadraticCurveTo(0, 90, -138, 0);
  c.closePath();
  c.strokeStyle = p.gold3dDark;
  c.lineWidth = 4;
  c.stroke();

  // Golden eyelash rays radiating outwards
  c.strokeStyle = p.goldBright;
  c.lineWidth = 3.5;
  for (let a = -70; a <= 70; a += 14) {
    const rad = (a * Math.PI) / 180;
    const lenTop = 18 + Math.cos(rad) * 12;
    const x0 = Math.sin(rad) * 135;
    const y0 = -Math.cos(rad) * 80;
    c.beginPath();
    c.moveTo(x0, y0);
    c.lineTo(x0 * 1.15, y0 - lenTop);
    c.stroke();
  }

  // Iris circle
  c.beginPath();
  c.arc(0, 0, 68, 0, Math.PI * 2);
  const irisGrad = c.createRadialGradient(-10, -10, 4, 0, 0, 70);
  irisGrad.addColorStop(0, "#a5f3fc");
  irisGrad.addColorStop(0.25, "#38bdf8");
  irisGrad.addColorStop(0.65, "#0284c7");
  irisGrad.addColorStop(1, "#082f49");
  c.fillStyle = irisGrad;
  c.fill();
  c.strokeStyle = p.goldMetallic;
  c.lineWidth = 6;
  c.stroke();

  // Geometric radial lines inside iris
  c.strokeStyle = "rgba(255, 255, 255, 0.35)";
  c.lineWidth = 1.5;
  for (let i = 0; i < 16; i++) {
    const ang = (i * Math.PI) / 8;
    c.beginPath();
    c.moveTo(Math.cos(ang) * 22, Math.sin(ang) * 22);
    c.lineTo(Math.cos(ang) * 64, Math.sin(ang) * 64);
    c.stroke();
  }

  // Dark pupil
  c.beginPath();
  c.arc(0, 0, 26, 0, Math.PI * 2);
  c.fillStyle = "#020617";
  c.fill();

  // Central golden starburst inside pupil with dynamic rotation
  for (let i = 0; i < 8; i++) {
    const ang = (i * Math.PI) / 4 + now * 0.0018;
    c.beginPath();
    c.moveTo(0, 0);
    c.lineTo(Math.cos(ang) * 16, Math.sin(ang) * 16);
    c.strokeStyle = "#fbbf24";
    c.lineWidth = 2.5;
    c.stroke();
  }

  // Specular light reflection glint with subtle micro-bob
  const glintBob = Math.sin(now * 0.003) * 1.5;
  c.beginPath();
  c.arc(-14 + glintBob, -14 - glintBob, 9, 0, Math.PI * 2);
  c.fillStyle = "rgba(255, 255, 255, 0.92)";
  c.fill();

  c.restore();
}

function drawGlint(c, x, y, size, now, color = "#ffffff") {
  const rot = now * 0.003;
  c.save();
  c.translate(px(x), py(y));
  c.rotate(rot);
  c.fillStyle = color;
  c.beginPath();
  c.moveTo(0, -ps(size));
  c.quadraticCurveTo(0, 0, ps(size * 0.28), 0);
  c.quadraticCurveTo(0, 0, 0, ps(size));
  c.quadraticCurveTo(0, 0, -ps(size * 0.28), 0);
  c.quadraticCurveTo(0, 0, 0, -ps(size));
  c.closePath();
  c.fill();
  c.restore();
}

const NAV_SCREENS = [
  { id: "main", num: "1", label: "VOTING" },
  { id: "race", num: "2", label: "RACE" },
  { id: "stats", num: "3", label: "STATS" },
  { id: "supporters", num: "4", label: "FANS" },
  { id: "menu", num: "5", label: "MENU" },
  { id: "events", num: "6", label: "EVENTS" }
];

function drawNavTabs(c, p, now, currentScreen, tr = null) {
  const tabY = 366, tabH = 36, tabW = 152, gap = 8;
  const totalW = NAV_SCREENS.length * tabW + (NAV_SCREENS.length - 1) * gap; // 952
  const startX = 540 - totalW / 2; // 64

  let activeIdx = NAV_SCREENS.findIndex(s => s.id === currentScreen);
  if (activeIdx < 0) activeIdx = 0;

  // Compute smooth animated indicator position during screen transition
  let indicatorX = startX + activeIdx * (tabW + gap);
  if (tr && tr.from !== tr.to) {
    const fromIdx = NAV_SCREENS.findIndex(s => s.id === tr.from);
    const toIdx = NAV_SCREENS.findIndex(s => s.id === tr.to);
    if (fromIdx >= 0 && toIdx >= 0) {
      const t = clamp(tr.t, 0, 1);
      const eased = 0.5 * (1 - Math.cos(Math.PI * t));
      const fromX = startX + fromIdx * (tabW + gap);
      const toX = startX + toIdx * (tabW + gap);
      indicatorX = fromX + (toX - fromX) * eased;
    }
  }

  // Draw background containers for all 6 tabs
  NAV_SCREENS.forEach((s, idx) => {
    const tx = startX + idx * (tabW + gap);
    c.fillStyle = p.theme === "light" ? "rgba(255, 255, 255, 0.82)" : "rgba(15, 23, 42, 0.65)";
    rr(c, tx, tabY, tabW, tabH, tabH / 2);
    c.fill();
    c.strokeStyle = p.theme === "light" ? "#e2e8f0" : "rgba(148, 163, 184, 0.22)";
    c.lineWidth = ps(1.2);
    rr(c, tx, tabY, tabW, tabH, tabH / 2);
    c.stroke();
  });

  // Draw sliding active golden pill
  const aGrad = c.createLinearGradient(px(indicatorX), 0, px(indicatorX + tabW), 0);
  if (p.theme === "light") {
    aGrad.addColorStop(0, "#f59e0b");
    aGrad.addColorStop(1, "#d97706");
  } else {
    aGrad.addColorStop(0, "#fbbf24");
    aGrad.addColorStop(1, "#d97706");
  }
  c.save();
  c.fillStyle = aGrad;
  rr(c, indicatorX, tabY, tabW, tabH, tabH / 2);
  c.fill();

  // Glowing outline on active tab
  c.strokeStyle = p.theme === "light" ? "#b45309" : "rgba(254, 240, 138, 0.85)";
  c.lineWidth = ps(1.8);
  rr(c, indicatorX, tabY, tabW, tabH, tabH / 2);
  c.stroke();

  // Subtle sparkle glint on active tab
  drawGlint(c, indicatorX + tabW - 14, tabY + 8, 5, now * 2, "#ffffff");
  c.restore();

  // Draw text labels for all tabs
  NAV_SCREENS.forEach((s, idx) => {
    const tx = startX + idx * (tabW + gap);
    const cx = tx + tabW / 2;
    // Determine distance to active indicator to smoothly transition text color
    const dist = Math.abs(indicatorX - tx);
    const activeFraction = Math.max(0, 1 - dist / (tabW + gap));
    const isLit = activeFraction > 0.45;

    const label = `${s.num}: ${s.label}`;
    if (isLit) {
      const textColor = p.theme === "light" ? "#ffffff" : "#0a1426";
      textC(c, label, cx, tabY + 24, 15, textColor, 900, "center");
    } else {
      const textColor = p.theme === "light" ? "#475569" : "#94a3b8";
      textC(c, label, cx, tabY + 24, 15, textColor, 750, "center");
    }
  });
}

function drawHero(c, p, now, subtitle = "LIVE VOTING", tr = null) {
  // Eye in center
  drawEye(c, p, 540, 172, 0.86, now);

  // Stacked side text on the top right with traveling sequential wave
  const sideY = 130;
  const words = ["WATCH", "VOTE", "SUPPORT", "YOUR", "FAVOURITE!"];
  const activeIdx = Math.floor((now * 0.0028) % words.length);
  words.forEach((w, i) => {
    const isLit = (i === activeIdx);
    if (isLit) {
      textC(c, w, 895, sideY + i * 23, 19, p.goldBright, 950, "center");
    } else {
      const sideColor = p.theme === "light" ? p.titleText : p.goldBright;
      textC(c, w, 895, sideY + i * 23, 19, sideColor, 700, "center");
    }
  });

  // 3D Metallic "BIGG BOSS" Title
  const titleY = 256;
  c.save();
  const textVal = "BIGG BOSS";
  const size = 56;
  const layers = [
    { dy: 5, col: p.gold3dDark },
    { dy: 3, col: "#92400e" },
    { dy: 1.5, col: "#b45309" }
  ];
  for (const l of layers) {
    textC(c, textVal, 540, titleY + l.dy, size, l.col, 900, "center");
  }
  const tGrad = c.createLinearGradient(0, py(titleY - size), 0, py(titleY));
  tGrad.addColorStop(0, "#fffbeb");
  tGrad.addColorStop(0.35, "#fde68a");
  tGrad.addColorStop(0.7, "#f59e0b");
  tGrad.addColorStop(1, "#b45309");
  textC(c, textVal, 540, titleY, size, tGrad, 900, "center");

  // Rotating diamond star glints on Bigg Boss title corners
  const glintAlpha = 0.4 + 0.6 * Math.abs(Math.sin(now * 0.003));
  c.save();
  c.globalAlpha = glintAlpha;
  drawGlint(c, 290, titleY - 26, 8, now, p.goldBright);
  drawGlint(c, 790, titleY - 26, 8, now + 1200, p.goldBright);
  c.restore();

  // Smooth specular sparkle moving across BIGG BOSS title
  const sheenCycle = 3600;
  const sheenT = (now % sheenCycle) / 1200;
  if (sheenT <= 1.0) {
    const sxPos = 260 + sheenT * 560;
    drawGlint(c, sxPos, titleY - size / 2, 7, now * 2, "#ffffff");
  }
  c.restore();

  // "LIVE VOTING" Blue Pill with circulating gold dashed outline
  const pillW = 330, pillH = 36, pillX = 540 - pillW / 2, pillY = 278;
  c.fillStyle = p.navyPill;
  rr(c, pillX, pillY, pillW, pillH, pillH / 2);
  c.fill();

  c.save();
  c.strokeStyle = p.goldBright;
  c.lineWidth = ps(2);
  c.setLineDash([ps(12), ps(6)]);
  c.lineDashOffset = -now * 0.04;
  rr(c, pillX, pillY, pillW, pillH, pillH / 2);
  c.stroke();
  c.restore();

  textC(c, subtitle, 540, pillY + 25, 19, p.goldBright, 800, "center");

  // Subtitle: "YOUR VOTE COUNTS!  VOTE NOW!"
  const subColor = p.theme === "light" ? p.titleText : p.goldBright;
  textC(c, "YOUR VOTE COUNTS!  VOTE NOW!", 540, 344, 19, subColor, 800, "center");

  // Screen Navigation Tabs Bar
  drawNavTabs(c, p, now, interactiveState().screen, tr);
}

function drawAvatar(c, no, x, y, r, p, img) {
  c.save();
  c.beginPath();
  c.arc(px(x), py(y), ps(r), 0, Math.PI * 2);
  c.clip();

  const actualImg = img || contestantImages.get(Number(no));
  if (actualImg) {
    const iw = actualImg.width || 1;
    const ih = actualImg.height || 1;
    const s = Math.max((r * 2) / iw, (r * 2) / ih);
    const dw = iw * s, dh = ih * s;
    c.drawImage(actualImg, px(x - dw / 2), py(y - dh / 2), ps(dw), ps(dh));
  } else {
    // High quality procedural portrait
    const skins = ["#f5d0b5", "#e8b894", "#dfa680", "#f3cfb3", "#d99d75", "#efc29e"];
    const hairs = ["#171717", "#261c14", "#1c1917", "#2e2118", "#18181b", "#27272a"];
    const shirts = ["#1e293b", "#334155", "#0f172a", "#1e1b4b", "#312e81", "#1e3a8a"];

    const skin = skins[(no - 1) % skins.length];
    const hair = hairs[(no - 1) % hairs.length];
    const shirt = shirts[(no - 1) % shirts.length];
    const isFemale = (no === 2 || no === 3 || no === 4 || no === 9 || no === 12 || no === 13 || no === 15 || no === 16);

    // Shirt background
    c.fillStyle = shirt;
    c.fillRect(px(x - r), py(y), ps(r * 2), ps(r));

    // Face
    c.fillStyle = skin;
    c.beginPath();
    c.arc(px(x), py(y - 4), ps(r * 0.58), 0, Math.PI * 2);
    c.fill();

    // Neck
    c.fillRect(px(x - r * 0.22), py(y + 8), ps(r * 0.44), ps(r * 0.35));

    // Hair
    c.fillStyle = hair;
    if (isFemale) {
      c.beginPath();
      c.arc(px(x), py(y - 10), ps(r * 0.65), Math.PI * 0.8, Math.PI * 2.2);
      c.fill();
      c.fillRect(px(x - r * 0.62), py(y - 6), ps(r * 0.24), ps(r * 0.85));
      c.fillRect(px(x + r * 0.38), py(y - 6), ps(r * 0.24), ps(r * 0.85));
    } else {
      c.beginPath();
      c.arc(px(x), py(y - 12), ps(r * 0.6), Math.PI * 0.85, Math.PI * 2.15);
      c.fill();
      c.fillStyle = "rgba(0, 0, 0, 0.25)";
      c.beginPath();
      c.arc(px(x), py(y + 2), ps(r * 0.48), 0, Math.PI);
      c.fill();
    }

    // Eyes
    c.fillStyle = "#0f172a";
    c.beginPath();
    c.arc(px(x - r * 0.2), py(y - 5), ps(2.8), 0, Math.PI * 2);
    c.arc(px(x + r * 0.2), py(y - 5), ps(2.8), 0, Math.PI * 2);
    c.fill();

    // Smile
    c.strokeStyle = "#0f172a";
    c.lineWidth = ps(2);
    c.beginPath();
    c.arc(px(x), py(y + 3), ps(6), 0.15 * Math.PI, 0.85 * Math.PI);
    c.stroke();
  }

  c.restore();

  // Rim border
  c.strokeStyle = p.theme === "light" ? "#cbd5e1" : p.goldBright;
  c.lineWidth = ps(2);
  c.beginPath();
  c.arc(px(x), py(y), ps(r + 1), 0, Math.PI * 2);
  c.stroke();
}

function drawVoteRow(c, p, item, rank, totalVotes, maxVotes, now, y) {
  const h = 132, w = 1000, x = 40;
  const colors = p.rankGradients[rank % p.rankGradients.length];

  // Card drop shadow (instant geometric Skia fill)
  c.fillStyle = p.cardShadow;
  rr(c, x, y + 4, w, h, 20);
  c.fill();

  // Card background
  c.fillStyle = p.card;
  rr(c, x, y, w, h, 20);
  c.fill();

  // Card outline border
  c.strokeStyle = p.cardBorder;
  c.lineWidth = ps(1.5);
  rr(c, x, y, w, h, 20);
  c.stroke();

  // 1. Rank Circle Badge (Left)
  const rankX = x + 54, rankY = y + h / 2, rankR = 33;
  const rGrad = c.createLinearGradient(px(rankX), py(rankY - rankR), px(rankX), py(rankY + rankR));
  rGrad.addColorStop(0, colors[0]);
  rGrad.addColorStop(1, colors[1]);
  c.fillStyle = rGrad;
  c.beginPath();
  c.arc(px(rankX), py(rankY), ps(rankR), 0, Math.PI * 2);
  c.fill();
  const rankNumColor = (rank === 0 && p.theme === "light") ? "#78350f" : "#ffffff";
  textC(c, String(rank + 1), rankX, rankY + 11, 30, rankNumColor, 800, "center");

  if (rank === 0) {
    drawGlint(c, rankX + 22, rankY - 22, 8, now, p.goldBright);
  }

  // 2. Contestant Avatar with rank-specific auras for Top 3
  const avX = x + 146, avY = y + h / 2, avR = 42;
  if (rank === 0) {
    const wavePhase = (now * 0.0018) % 1;
    const r1 = avR + wavePhase * 16;
    c.save();
    c.strokeStyle = p.goldBright;
    c.globalAlpha = Math.max(0, 0.75 * (1 - wavePhase));
    c.lineWidth = ps(2);
    c.beginPath();
    c.arc(px(avX), py(avY), ps(r1), 0, Math.PI * 2);
    c.stroke();
    // Radiant breathing golden halo
    const haloPulse = 0.5 + 0.5 * Math.sin(now * 0.004);
    const aGrad = c.createRadialGradient(px(avX), py(avY), ps(avR * 0.8), px(avX), py(avY), ps(avR + 22));
    aGrad.addColorStop(0, `rgba(245, 197, 66, ${0.45 * haloPulse})`);
    aGrad.addColorStop(1, "transparent");
    c.fillStyle = aGrad;
    c.beginPath();
    c.arc(px(avX), py(avY), ps(avR + 22), 0, Math.PI * 2);
    c.fill();
    c.restore();
  } else if (rank === 1) {
    // Silver/Cyan Frost breathing halo for #2
    const haloPulse = 0.5 + 0.5 * Math.sin(now * 0.004 + 1);
    c.save();
    const aGrad = c.createRadialGradient(px(avX), py(avY), ps(avR * 0.8), px(avX), py(avY), ps(avR + 18));
    aGrad.addColorStop(0, `rgba(56, 189, 248, ${0.35 * haloPulse})`);
    aGrad.addColorStop(1, "transparent");
    c.fillStyle = aGrad;
    c.beginPath();
    c.arc(px(avX), py(avY), ps(avR + 18), 0, Math.PI * 2);
    c.fill();
    c.restore();
  } else if (rank === 2) {
    // Rose/Bronze breathing halo for #3
    const haloPulse = 0.5 + 0.5 * Math.sin(now * 0.004 + 2);
    c.save();
    const aGrad = c.createRadialGradient(px(avX), py(avY), ps(avR * 0.8), px(avX), py(avY), ps(avR + 18));
    aGrad.addColorStop(0, `rgba(244, 114, 182, ${0.32 * haloPulse})`);
    aGrad.addColorStop(1, "transparent");
    c.fillStyle = aGrad;
    c.beginPath();
    c.arc(px(avX), py(avY), ps(avR + 18), 0, Math.PI * 2);
    c.fill();
    c.restore();
  }
  const img = contestantImages.get(item.no);
  drawAvatar(c, item.no, avX, avY, avR, p, img);

  // 3. Vote Command Badge in front of Contestant Name
  const cmdW = 104, cmdH = 30, cmdX = x + 210, cmdY = y + 25;
  const isLead = (rank === 0);

  c.save();
  if (isLead) {
    const cg = c.createLinearGradient(px(cmdX), 0, px(cmdX + cmdW), 0);
    cg.addColorStop(0, "#fbbf24");
    cg.addColorStop(1, "#f59e0b");
    c.fillStyle = cg;
    rr(c, cmdX, cmdY, cmdW, cmdH, 9);
    c.fill();
    c.strokeStyle = "#ffffff";
    c.lineWidth = ps(1.5);
    rr(c, cmdX, cmdY, cmdW, cmdH, 9);
    c.stroke();
    textC(c, `!vote ${item.no}`, cmdX + cmdW / 2, cmdY + 21, 16.5, "#0f172a", 950, "center");
  } else {
    c.fillStyle = p.theme === "light" ? "rgba(2, 132, 199, 0.12)" : "rgba(14, 165, 233, 0.20)";
    rr(c, cmdX, cmdY, cmdW, cmdH, 9);
    c.fill();
    c.strokeStyle = p.theme === "light" ? "#0284c7" : "#38bdf8";
    c.lineWidth = ps(1.5);
    rr(c, cmdX, cmdY, cmdW, cmdH, 9);
    c.stroke();
    textC(c, `!vote ${item.no}`, cmdX + cmdW / 2, cmdY + 21, 16.5, p.theme === "light" ? "#0369a1" : "#38bdf8", 900, "center");
  }
  c.restore();

  // Contestant Name placed right next to command badge
  const nameX = cmdX + cmdW + 12;
  const nameStr = fit(item.displayName || item.name, 16);
  textC(c, nameStr, nameX, y + 49, 27, p.text, 800);

  // Smooth vote number animation
  const oldV = shownVotes.get(item.no) ?? (item.votes || 0);
  const dt = clamp((now - lastDraw) / 1000, 0, 0.1);
  const curV = isNaN(oldV) ? (item.votes || 0) : (oldV + ((item.votes || 0) - oldV) * ease(8, dt));
  shownVotes.set(item.no, curV);

  // 4. Vote Count & Live Badge
  const votesStr = Math.round(curV).toLocaleString();
  textC(c, votesStr, x + 760, y + 52, 26, p.text, 700, "right");

  // Dynamic "HOT" tag if recently voted
  const isRecentVote = (state.chatVoteFlashContestant === item.no && (now - state.chatVoteFlashAt < 5000));
  if (isRecentVote) {
    const hotPulse = 0.6 + 0.4 * Math.sin(now * 0.008);
    c.save();
    c.font = `800 ${Math.max(8, Math.round(ps(27)))}px "Segoe UI", Arial, sans-serif`;
    const nameMeasure = c.measureText(nameStr).width / sx;
    const hotX = Math.min(nameX + nameMeasure + 12, x + 680);
    c.fillStyle = `rgba(239, 68, 68, ${0.85 * hotPulse})`;
    rr(c, hotX, y + 29, 66, 22, 11);
    c.fill();
    textC(c, "HOT 🔥", hotX + 33, y + 45, 12, "#ffffff", 900, "center");
    c.restore();
  }

  // 5. Percentage Box & Risk Indicator (Far Right)
  const pct = totalVotes > 0 ? (item.votes / totalVotes) * 100 : (item.pct || 0);
  const boxW = 120, boxH = 56, boxX = x + w - boxW - 20, boxY = y + (h - boxH) / 2;
  c.strokeStyle = p.line;
  c.lineWidth = ps(1.8);
  rr(c, boxX, boxY, boxW, boxH, 12);
  c.stroke();

  textC(c, `${pct.toFixed(1)}%`, boxX + boxW / 2, boxY + 37, 26, p.text, 800, "center");

  // Eviction danger indicator for bottom 2 contestants
  const totalCount = config.contestants?.length || 17;
  const isDangerRank = (rank >= Math.max(4, totalCount - 2));
  if (isDangerRank) {
    const dangerPulse = 0.7 + 0.3 * Math.sin(now * 0.006 + rank);
    c.save();
    c.fillStyle = `rgba(239, 68, 68, ${0.18 * dangerPulse})`;
    c.strokeStyle = "#ef4444";
    c.lineWidth = ps(1.2);
    rr(c, boxX - 88, boxY + 12, 80, 32, 8);
    c.fill();
    c.stroke();
    textC(c, "⚠️ RISK", boxX - 48, boxY + 33, 12.5, "#ef4444", 900, "center");
    c.restore();
  }

  // 6. Colored Progress Bar (Below Name & Count)
  const barX = x + 215, barY = y + 76, barW = 545, barH = 17;
  c.fillStyle = p.barBg;
  rr(c, barX, barY, barW, barH, barH / 2);
  c.fill();
  const ratio = maxVotes > 0 ? clamp(curV / maxVotes, 0.04, 1) : clamp((pct || 0) / 100, 0.04, 1);
  const fillW = Math.max(barH, Math.min(barW, barW * (isNaN(ratio) ? 0.04 : ratio)));
  const gradEnd = Math.max(px(barX + 2), px(barX + fillW));
  const pGrad = c.createLinearGradient(px(barX), 0, gradEnd, 0);
  pGrad.addColorStop(0, colors[0]);
  pGrad.addColorStop(1, colors[1]);
  c.fillStyle = pGrad;
  rr(c, barX, barY, fillW, barH, barH / 2);
  c.fill();

  // Animated specular gloss wave across progress bar
  if (fillW > 24) {
    const sweepW = 60;
    const sweepPos = barX + ((now * 0.18 + rank * 40) % (fillW + sweepW * 2)) - sweepW;
    c.save();
    c.beginPath();
    c.roundRect(px(barX), py(barY), ps(fillW), ps(barH), ps(barH / 2));
    c.clip();
    const gloss = c.createLinearGradient(px(sweepPos), 0, px(sweepPos + sweepW), 0);
    gloss.addColorStop(0, "rgba(255, 255, 255, 0)");
    gloss.addColorStop(0.5, "rgba(255, 255, 255, 0.55)");
    gloss.addColorStop(1, "rgba(255, 255, 255, 0)");
    c.fillStyle = gloss;
    c.fillRect(px(sweepPos), py(barY), ps(sweepW), ps(barH));
    c.restore();
  }

  // Leader breathing golden aura & floating crown
  if (rank === 0) {
    const leadPulse = 0.5 + 0.5 * Math.sin(now * 0.005);
    c.strokeStyle = p.goldBright;
    c.lineWidth = ps(2.2 + leadPulse * 1.5);
    rr(c, x, y, w, h, 20);
    c.stroke();

    // Floating bobbing crown above avatar
    const bob = Math.sin(now * 0.004) * 3.5;
    drawCrown(c, avX, avY - avR - 11 + bob, 12, p.goldBright);
    drawGlint(c, avX, avY - avR - 22 + bob, 6, now + 600, "#ffffff");
  } else if (rank === 1) {
    drawGlint(c, rankX + 22, rankY - 22, 6, now + 300, "#38bdf8");
  } else if (rank === 2) {
    drawGlint(c, rankX + 22, rankY - 22, 6, now + 600, "#f472b6");
  }

  // Live vote flash notification
  const isFlashing = (state.chatVoteFlashContestant === item.no && (now - state.chatVoteFlashAt < 2200));
  if (isFlashing) {
    const age = now - state.chatVoteFlashAt;
    const fade = Math.max(0, 1 - age / 2200);

    // Golden glow halo on the entire card
    c.save();
    c.globalAlpha = fade * 0.6;
    c.shadowColor = p.goldBright;
    c.shadowBlur = ps(18);
    c.strokeStyle = p.goldBright;
    c.lineWidth = ps(3.2 * fade);
    rr(c, x, y, w, h, 20);
    c.stroke();
    c.restore();

    c.strokeStyle = p.cyan;
    c.lineWidth = ps(3.2 * fade);
    rr(c, x, y, w, h, 20);
    c.stroke();

    // Spawn sparkle burst at the row position on the first tick
    seedVoteSparkle(item.no, y, now);

    // Rising floating +1 VOTE badge with glow
    const floatY = y + 22 - (age / 2200) * 40;
    c.save();
    c.globalAlpha = fade;
    // Glow behind badge
    c.shadowColor = p.cyan;
    c.shadowBlur = ps(10);
    const badgeGrad = c.createLinearGradient(px(x + 655), 0, px(x + 753), 0);
    badgeGrad.addColorStop(0, p.cyan);
    badgeGrad.addColorStop(1, p.goldBright);
    c.fillStyle = badgeGrad;
    rr(c, x + 655, floatY - 18, 98, 28, 14);
    c.fill();
    c.restore();
    c.save();
    c.globalAlpha = fade;
    textC(c, "+1 VOTE ⚡", x + 704, floatY + 1, 15, "#ffffff", 900, "center");
    c.restore();
  }
}

function drawBottomStats(c, p, now = Date.now()) {
  const y = 1350, h = 130, w = 316, gap = 26;
  const totalVotes = state.totalAcceptedVotes || 44344;
  const uniqueVoters = state.uniqueVoters || 12876;
  const timeLeft = state.timeLeftText || config.timeLeftText || "2D 5H 45M";

  const cards = [
    { x: 40, label: "TOTAL VOTES", val: Number(totalVotes).toLocaleString(), icon: "chart" },
    { x: 40 + w + gap, label: "UNIQUE VOTERS", val: Number(uniqueVoters).toLocaleString(), icon: "users" },
    { x: 40 + (w + gap) * 2, label: "TIME LEFT", val: timeLeft, icon: "clock" }
  ];

  cards.forEach(cd => {
    c.fillStyle = p.card;
    rr(c, cd.x, y, w, h, 20);
    c.fill();
    c.strokeStyle = p.cardBorder;
    c.lineWidth = ps(1.5);
    rr(c, cd.x, y, w, h, 20);
    c.stroke();

    const icX = cd.x + 48, icY = y + h / 2;
    if (cd.icon === "chart") {
      c.fillStyle = p.goldBright;
      rr(c, icX - 16, icY + 24 - 14, 8, 14, 3);
      c.fill();
      rr(c, icX - 4, icY + 24 - 22, 8, 22, 3);
      c.fill();
      rr(c, icX + 8, icY + 24 - 32, 8, 32, 3);
      c.fill();
    } else if (cd.icon === "users") {
      c.fillStyle = p.theme === "light" ? p.goldBright : "#38bdf8";
      c.beginPath();
      c.arc(px(icX - 6), py(icY - 6), ps(10), 0, Math.PI * 2);
      c.fill();
      c.beginPath();
      c.arc(px(icX - 6), py(icY + 20), ps(18), Math.PI, Math.PI * 2);
      c.fill();
      c.beginPath();
      c.arc(px(icX + 12), py(icY - 2), ps(8), 0, Math.PI * 2);
      c.fill();
      c.beginPath();
      c.arc(px(icX + 12), py(icY + 20), ps(14), Math.PI, Math.PI * 2);
      c.fill();
    } else {
      c.strokeStyle = p.theme === "light" ? p.text : "#f43f5e";
      c.lineWidth = ps(2.5);
      c.beginPath();
      c.arc(px(icX), py(icY), ps(20), 0, Math.PI * 2);
      c.stroke();
      // Static hour hand at 10 o'clock
      c.beginPath();
      c.moveTo(px(icX), py(icY));
      c.lineTo(px(icX - 7), py(icY - 11));
      c.stroke();
      // Static minute hand at 2 o'clock (10 mins)
      c.strokeStyle = p.goldBright;
      c.lineWidth = ps(2);
      c.beginPath();
      c.moveTo(px(icX), py(icY));
      c.lineTo(px(icX + 11), py(icY - 9));
      c.stroke();
      // Center pivot
      c.fillStyle = p.goldBright;
      c.beginPath();
      c.arc(px(icX), py(icY), ps(2.5), 0, Math.PI * 2);
      c.fill();
    }

    textC(c, cd.label, cd.x + 94, y + 48, 17, p.muted, 700);
    textC(c, cd.val, cd.x + 94, y + 95, 30, p.text, 800);
  });
}

function drawCrown(c, x, y, size = 12, color = "#f59e0b") {
  c.save();
  c.fillStyle = color;
  c.beginPath();
  const left = px(x - size), right = px(x + size), bottom = py(y + size * 0.7);
  const topMid = py(y - size * 0.7), topL = py(y - size * 0.4), topR = py(y - size * 0.4);
  const dipL = py(y + size * 0.1), dipR = py(y + size * 0.1);
  c.moveTo(left, bottom);
  c.lineTo(left, topL);
  c.lineTo(px(x - size * 0.45), dipL);
  c.lineTo(px(x), topMid);
  c.lineTo(px(x + size * 0.45), dipR);
  c.lineTo(right, topR);
  c.lineTo(right, bottom);
  c.closePath();
  c.fill();
  c.restore();
}

function drawFooter(c, p) {
  const y = 1515;

  c.strokeStyle = p.line;
  c.lineWidth = ps(1);
  c.beginPath();
  c.moveTo(px(40), py(y));
  c.lineTo(px(1040), py(y));
  c.stroke();

  const midY = y + 40;
  textC(c, "BIGG BOSS 24/7 LIVE", 160, midY, 20, p.text, 800, "center");
  drawCrown(c, 375, midY - 6, 12, p.goldBright);
  textC(c, "\"BADI BAATEIN, BADA SHOW!\"", 540, midY, 20, p.goldBright, 800, "center");
  textC(c, "STAY TUNED!", 920, midY, 20, p.text, 800, "center");

  // Command prompt strip
  const tipY = y + 80;
  c.fillStyle = p.theme === "light" ? "rgba(241, 245, 249, 0.9)" : "rgba(15, 23, 42, 0.85)";
  rr(c, 40, tipY, 1000, 52, 14);
  c.fill();
  c.strokeStyle = p.line;
  c.lineWidth = ps(1.2);
  rr(c, 40, tipY, 1000, 52, 14);
  c.stroke();

  textC(c, "CHAT: !vote <1-17>  •  !wheel  •  !battle <1 2>  •  !dice  •  !coin  •  !slot  •  !bomb  •  !hype  •  !screen", 540, tipY + 33, 16, p.muted, 700, "center");
}

// ---------------------- SCREENS ---------------------- //

function drawVoteScreenContent(c, p, now) {
  const ranking = stats();
  const total = Math.max(1, state.totalAcceptedVotes);
  const leaderVotes = Math.max(1, ranking[0]?.votes || 1);

  // Auto-cycle pages every 8.5s so all 17 contestants are displayed with their real photos!
  const totalContestants = ranking.length;
  const pageSize = 6;
  const totalPages = Math.max(1, Math.ceil(totalContestants / pageSize));
  const pageIdx = Math.floor((now / 8500) % totalPages);
  const pageStart = pageIdx * pageSize;
  const visible = ranking.slice(pageStart, pageStart + pageSize);

  const rowY = 428, rowH = 142, gap = 8;
  visible.forEach((item, i) => {
    drawVoteRow(c, p, item, pageStart + i, total, leaderVotes, now, rowY + i * (rowH + gap));
  });

  drawBottomStats(c, p, now);
}

function drawVoteScreen(c, p, now) {
  drawHero(c, p, now, "LIVE VOTING");
  drawVoteScreenContent(c, p, now);
}

function drawRaceScreenContent(c, p, now) {
  const ranking = stats();
  const max = Math.max(1, ranking[0]?.votes || 1);
  const top10 = ranking.slice(0, 9);

  const rowY = 428, rowH = 92, gap = 6;
  top10.forEach((item, i) => {
    const y = rowY + i * (rowH + gap);
    const colors = p.rankGradients[i % p.rankGradients.length];

    c.fillStyle = p.card;
    rr(c, 40, y, 1000, rowH, 16);
    c.fill();
    c.strokeStyle = i === 0 ? p.goldBright : p.cardBorder;
    c.lineWidth = ps(i === 0 ? 2 : 1.2);
    rr(c, 40, y, 1000, rowH, 16);
    c.stroke();

    // Rank
    textC(c, `#${i + 1}`, 82, y + 54, 26, i === 0 ? p.goldBright : p.text, 800, "center");

    // Avatar
    drawAvatar(c, item.no, 155, y + rowH / 2, 30, p, contestantImages.get(item.no));

    // Command pill badge in front of name
    const cmdW = 92, cmdH = 26, cmdX = 205, cmdY = y + 18;
    c.save();
    if (i === 0) {
      const cg = c.createLinearGradient(px(cmdX), 0, px(cmdX + cmdW), 0);
      cg.addColorStop(0, "#fbbf24");
      cg.addColorStop(1, "#f59e0b");
      c.fillStyle = cg;
      rr(c, cmdX, cmdY, cmdW, cmdH, 8);
      c.fill();
      textC(c, `!vote ${item.no}`, cmdX + cmdW / 2, cmdY + 18, 14.5, "#0f172a", 950, "center");
    } else {
      c.fillStyle = p.theme === "light" ? "rgba(2, 132, 199, 0.12)" : "rgba(14, 165, 233, 0.20)";
      rr(c, cmdX, cmdY, cmdW, cmdH, 8);
      c.fill();
      c.strokeStyle = p.theme === "light" ? "#0284c7" : "#38bdf8";
      c.lineWidth = ps(1.2);
      rr(c, cmdX, cmdY, cmdW, cmdH, 8);
      c.stroke();
      textC(c, `!vote ${item.no}`, cmdX + cmdW / 2, cmdY + 18, 14.5, p.theme === "light" ? "#0369a1" : "#38bdf8", 900, "center");
    }
    c.restore();

    // Name placed right after command badge
    textC(c, fit(item.displayName || item.name, 15), cmdX + cmdW + 10, y + 38, 22, p.text, 800);

    // Smooth race vote interpolation
    const oldV = shownRaceVotes.get(item.no) ?? (item.votes || 0);
    const dt = clamp((now - lastDraw) / 1000, 0, 0.1);
    const curV = isNaN(oldV) ? (item.votes || 0) : (oldV + ((item.votes || 0) - oldV) * ease(8, dt));
    shownRaceVotes.set(item.no, curV);

    const votesStr = Math.round(curV).toLocaleString();
    textC(c, `${votesStr} votes`, 880, y + 42, 21, p.text, 700, "right");

    if (i === 0) {
      drawCrown(c, 925, y + 36, 10, p.goldBright);
      drawGlint(c, 925, y + 26, 5, now, "#ffffff");
      textC(c, "LEADER", 1005, y + 42, 16, p.goldBright, 800, "right");
    } else {
      const gapToLead = Math.max(0, (ranking[0]?.votes || 0) - (item.votes || 0));
      textC(c, `-${gapToLead.toLocaleString()}`, 1005, y + 42, 16, p.red, 700, "right");
    }

    // Mini progress bar with smooth eased length
    const barW = 780, barH = 12;
    c.fillStyle = p.barBg;
    rr(c, 205, y + 58, barW, barH, barH / 2);
    c.fill();
    const pct = Math.min(1, Math.max(0.02, curV / max));
    const fillW = Math.max(barH, barW * pct);
    c.fillStyle = colors[0];
    rr(c, 205, y + 58, fillW, barH, barH / 2);
    c.fill();
    if (i < 3 && fillW > 40) {
      const sw = 40;
      const sp = 205 + ((now * (0.14 + i * 0.02)) % (fillW + sw * 2)) - sw;
      c.save();
      c.beginPath();
      c.roundRect(px(205), py(y + 58), ps(fillW), ps(barH), ps(barH / 2));
      c.clip();
      const rGlint = c.createLinearGradient(px(sp), 0, px(sp + sw), 0);
      rGlint.addColorStop(0, "rgba(255, 255, 255, 0)");
      rGlint.addColorStop(0.5, "rgba(255, 255, 255, 0.4)");
      rGlint.addColorStop(1, "rgba(255, 255, 255, 0)");
      c.fillStyle = rGlint;
      c.fillRect(px(sp), py(y + 58), ps(sw), ps(barH));
      c.restore();
    }
  });

  // More contestants summary box
  const rest = ranking.slice(9);
  if (rest.length) {
    const boxY = 1320, boxH = 68;
    c.fillStyle = p.card;
    rr(c, 40, boxY, 1000, boxH, 14);
    c.fill();
    c.strokeStyle = p.cardBorder;
    rr(c, 40, boxY, 1000, boxH, 14);
    c.stroke();
    const listStr = rest.slice(0, 5).map((x, idx) => `#${idx + 10} ${fit(x.displayName || x.name, 9)} (!vote ${x.no})`).join("   •   ");
    textC(c, listStr, 540, boxY + 42, 16, p.muted, 700, "center");
  }
}

function drawRaceScreen(c, p, now) {
  drawHero(c, p, now, "RANK RACE");
  drawRaceScreenContent(c, p, now);
}

function recentVoteRate() {
  const now = Date.now();
  return state.recentVotes.filter(v => now - (v.at || 0) < 60000).length;
}

function drawStatsScreenContent(c, p, now) {
  const cards = [
    { x: 40, y: 428, w: 485, h: 140, label: "TOTAL VOTES", val: Number(state.totalAcceptedVotes || 0).toLocaleString(), col: p.goldBright },
    { x: 555, y: 428, w: 485, h: 140, label: "UNIQUE VOTERS", val: Number(state.uniqueVoters || 0).toLocaleString(), col: p.cyan },
    { x: 40, y: 590, w: 485, h: 140, label: "VOTES / MINUTE", val: String(recentVoteRate()), col: p.pink },
    { x: 555, y: 590, w: 485, h: 140, label: "CHAT MESSAGES", val: Number(state.totalChatMessages || 0).toLocaleString(), col: p.green }
  ];

  cards.forEach(cd => {
    c.fillStyle = p.card;
    rr(c, cd.x, cd.y, cd.w, cd.h, 18);
    c.fill();
    c.strokeStyle = p.cardBorder;
    rr(c, cd.x, cd.y, cd.w, cd.h, 18);
    c.stroke();

    textC(c, cd.label, cd.x + 28, cd.y + 44, 18, p.muted, 700);
    textC(c, cd.val, cd.x + 28, cd.y + 102, 40, p.text, 800);

    c.fillStyle = cd.col;
    c.fillRect(px(cd.x + 28), py(cd.y + cd.h - 10), ps(cd.w - 56), ps(4));
  });

  // Leader Spotlight & Lead Margin
  const ranking = stats(), leader = ranking[0], second = ranking[1];
  const spotY = 755, spotH = 260;
  c.fillStyle = p.card;
  rr(c, 40, spotY, 1000, spotH, 20);
  c.fill();
  c.strokeStyle = p.goldBright;
  c.lineWidth = ps(2);
  rr(c, 40, spotY, 1000, spotH, 20);
  c.stroke();

  drawCrown(c, 75, spotY + 38, 12, p.goldBright);
  textC(c, "CURRENT LEADER", 100, spotY + 45, 18, p.goldBright, 800);
  if (leader) drawAvatar(c, leader.no, 125, spotY + 115, 44, p);

  // Command badge in front of leader name
  const lCmdW = 96, lCmdH = 28;
  const lCmdX = 185, lCmdY = spotY + 84;
  c.save();
  const lcg = c.createLinearGradient(px(lCmdX), 0, px(lCmdX + lCmdW), 0);
  lcg.addColorStop(0, "#fbbf24");
  lcg.addColorStop(1, "#f59e0b");
  c.fillStyle = lcg;
  rr(c, lCmdX, lCmdY, lCmdW, lCmdH, 8);
  c.fill();
  textC(c, `!vote ${leader?.no || 1}`, lCmdX + lCmdW / 2, lCmdY + 20, 15, "#0f172a", 950, "center");
  c.restore();

  textC(c, leader?.displayName || leader?.name || "Contestant", lCmdX + lCmdW + 12, spotY + 107, 34, p.text, 900);
  textC(c, `${Number(leader?.votes || 0).toLocaleString()} votes`, 185, spotY + 144, 22, p.muted, 700);

  const leadGap = Math.max(0, (leader?.votes || 0) - (second?.votes || 0));
  textC(c, "LEAD OVER #2", 640, spotY + 45, 18, p.muted, 800);
  textC(c, `+${leadGap.toLocaleString()}`, 640, spotY + 105, 42, p.goldBright, 900);
  const secondCmd = second?.no ? `(!vote ${second.no})` : "";
  textC(c, `vs ${second?.displayName || second?.name || "2nd"} ${secondCmd}`, 640, spotY + 148, 20, p.cyan, 700);

  // Chat Energy Meter
  const energy = clamp(Math.round(Math.min(100, recentVoteRate() * 10 + (state.totalChatMessages % 50) * 2)), 8, 100);
  textC(c, `CHAT ENERGY: ${energy}%`, 75, spotY + 205, 17, p.text, 800);
  c.fillStyle = p.barBg;
  rr(c, 75, spotY + 218, 890, 18, 9);
  c.fill();
  const eg = c.createLinearGradient(px(75), 0, px(75 + 890 * (energy / 100)), 0);
  eg.addColorStop(0, p.pink);
  eg.addColorStop(1, p.cyan);
  c.fillStyle = eg;
  rr(c, 75, spotY + 218, Math.max(18, 890 * (energy / 100)), 18, 9);
  c.fill();

  // Recent Live Activity Ticker
  const actY = 1045, actH = 275;
  c.fillStyle = p.card;
  rr(c, 40, actY, 1000, actH, 20);
  c.fill();
  c.strokeStyle = p.cardBorder;
  rr(c, 40, actY, 1000, actH, 20);
  c.stroke();

  textC(c, "LIVE CHAT ACTIVITY", 75, actY + 44, 18, p.goldBright, 800);
  const recent = state.recentChat.slice(-4).reverse();
  if (!recent.length) {
    textC(c, "Waiting for chat messages...", 540, actY + 150, 22, p.muted, 700, "center");
  } else {
    recent.forEach((m, idx) => {
      const cy = actY + 84 + idx * 42;
      textC(c, fit(m.name, 16), 75, cy, 20, p.goldBright, 800);
      textC(c, fit(m.text, 54), 260, cy, 20, p.text, 600);
    });
  }

  drawBottomStats(c, p, now);
}

function drawStatsScreen(c, p, now) {
  drawHero(c, p, now, "LIVE STATS");
  drawStatsScreenContent(c, p, now);
}

function drawSupportersScreenContent(c, p, now) {
  const top = getTopViewers();

  const boardY = 428, boardH = 690;
  c.fillStyle = p.card;
  rr(c, 40, boardY, 1000, boardH, 20);
  c.fill();
  c.strokeStyle = p.cardBorder;
  rr(c, 40, boardY, 1000, boardH, 20);
  c.stroke();

  drawCrown(c, 75, boardY + 42, 12, p.goldBright);
  textC(c, "CHAT SUPPORTER LEADERBOARD", 100, boardY + 48, 20, p.goldBright, 800);
  textC(c, "Most active voters and chat participants", 75, boardY + 80, 16, p.muted, 600);

  if (!top.length) {
    textC(c, "Waiting for viewer interactions...", 540, boardY + 340, 24, p.muted, 700, "center");
    textC(c, "Type !vote <1-6> in live chat to appear here!", 540, boardY + 390, 20, p.goldBright, 700, "center");
  } else {
    top.slice(0, 5).forEach((v, idx) => {
      const y = boardY + 115 + idx * 105;

      c.fillStyle = idx === 0 ? (p.theme === "light" ? "#fffbeb" : "rgba(245, 197, 66, 0.08)") : p.theme === "light" ? "#f8fafc" : "rgba(255, 255, 255, 0.02)";
      rr(c, 65, y, 950, 88, 16);
      c.fill();
      c.strokeStyle = idx === 0 ? p.goldBright : p.line;
      rr(c, 65, y, 950, 88, 16);
      c.stroke();

      // Medal circle badge
      const mCol = p.rankGradients[idx % p.rankGradients.length];
      const mGrad = c.createLinearGradient(px(86), py(y + 20), px(134), py(y + 68));
      mGrad.addColorStop(0, mCol[0]);
      mGrad.addColorStop(1, mCol[1]);
      c.fillStyle = mGrad;
      c.beginPath();
      c.arc(px(110), py(y + 44), ps(22), 0, Math.PI * 2);
      c.fill();
      textC(c, String(idx + 1), 110, y + 52, 22, "#ffffff", 800, "center");

      textC(c, fit(v.name, 22), 170, y + 42, 24, p.text, 800);
      textC(c, `${v.interactions} interactions`, 170, y + 70, 16, p.muted, 600);

      const maxInter = Math.max(1, top[0].interactions);
      const pct = v.interactions / maxInter;
      const barW = 380, barH = 14;
      c.fillStyle = p.barBg;
      rr(c, 560, y + 38, barW, barH, barH / 2);
      c.fill();
      c.fillStyle = idx === 0 ? p.goldBright : p.cyan;
      rr(c, 560, y + 38, Math.max(barH, barW * pct), barH, barH / 2);
      c.fill();

      textC(c, `${Math.round(pct * 100)}%`, 985, y + 51, 19, p.text, 800, "right");
    });
  }

  // MVP Spotlight
  const mvpY = 1145, mvpH = 175;
  c.fillStyle = p.card;
  rr(c, 40, mvpY, 1000, mvpH, 20);
  c.fill();
  c.strokeStyle = p.goldBright;
  c.lineWidth = ps(2);
  rr(c, 40, mvpY, 1000, mvpH, 20);
  c.stroke();

  const mvp = top[0];
  drawCrown(c, 75, mvpY + 36, 12, p.goldBright);
  textC(c, "CHAT MVP OF THE STREAM", 100, mvpY + 44, 18, p.goldBright, 800);
  textC(c, mvp ? mvp.name : "Bigg Boss Fan Club", 75, mvpY + 95, 36, p.text, 900);
  textC(c, mvp ? `${mvp.interactions} total interactions recorded` : "Vote & participate in chat to win the MVP crown!", 75, mvpY + 138, 20, p.muted, 700);

  drawBottomStats(c, p, now);
}

function drawSupportersScreen(c, p, now) {
  drawHero(c, p, now, "TOP SUPPORTERS");
  drawSupportersScreenContent(c, p, now);
}

function drawMenuScreenContent(c, p, now) {
  const curScreen = interactiveState().screen;

  const menuItems = [
    { id: "main", num: "1", title: "LIVE VOTING", desc: "Top 6 live voting board & percentages", cmd: "!screen main" },
    { id: "race", num: "2", title: "RANK RACE", desc: "Full contestant ranking & live gaps", cmd: "!screen race" },
    { id: "stats", num: "3", title: "LIVE STATS", desc: "Vote rate, chat energy & analytics", cmd: "!screen stats" },
    { id: "supporters", num: "4", title: "TOP SUPPORTERS", desc: "Chat MVP & active viewer leaderboard", cmd: "!screen supporters" },
    { id: "events", num: "5", title: "LIVE EVENTS", desc: "Real-time interactions & milestones", cmd: "!screen events" },
    { id: "theme", num: "6", title: "THEME SWITCH", desc: `Current: ${state.theme.toUpperCase()} (switch with !dark / !light)`, cmd: "!theme dark" }
  ];

  const startY = 428, itemH = 120, gap = 12;
  menuItems.forEach((item, i) => {
    const y = startY + i * (itemH + gap);
    const isActive = (item.id === curScreen);

    c.fillStyle = isActive ? (p.theme === "light" ? "#fffbeb" : "rgba(245, 197, 66, 0.12)") : p.card;
    rr(c, 40, y, 1000, itemH, 18);
    c.fill();

    c.strokeStyle = isActive ? p.goldBright : p.cardBorder;
    c.lineWidth = ps(isActive ? 2.5 : 1.2);
    rr(c, 40, y, 1000, itemH, 18);
    c.stroke();

    // Colored circle badge with number
    const bColor = p.rankGradients[i % p.rankGradients.length];
    c.fillStyle = bColor[0];
    c.beginPath();
    c.arc(px(88), py(y + itemH / 2), ps(24), 0, Math.PI * 2);
    c.fill();
    textC(c, item.num, 88, y + itemH / 2 + 9, 24, "#ffffff", 800, "center");

    // Title & description
    textC(c, item.title, 140, y + 48, 24, isActive ? p.goldBright : p.text, 800);
    textC(c, item.desc, 140, y + 84, 18, p.muted, 600);

    // Command box
    const cmdW = 200, cmdH = 46, cmdX = 1000 - cmdW;
    c.fillStyle = p.barBg;
    rr(c, cmdX, y + (itemH - cmdH) / 2, cmdW, cmdH, 10);
    c.fill();
    textC(c, item.cmd, cmdX + cmdW / 2, y + (itemH - cmdH) / 2 + 30, 18, p.cyan, 800, "center");

    if (isActive) {
      const actPulse = 0.5 + 0.5 * Math.sin(now * 0.008);
      c.save();
      c.fillStyle = p.goldBright;
      c.beginPath();
      c.arc(px(cmdX - 85), py(y + (itemH / 2)), ps(5 + actPulse * 2.5), 0, Math.PI * 2);
      c.fill();
      textC(c, "ACTIVE", cmdX - 18, y + 68, 16, p.goldBright, 800, "right");
      c.restore();
    }
  });

  // Auto carousel indicator
  const autoY = 1250, autoH = 68;
  c.fillStyle = p.card;
  rr(c, 40, autoY, 1000, autoH, 16);
  c.fill();
  c.strokeStyle = p.cardBorder;
  rr(c, 40, autoY, 1000, autoH, 16);
  c.stroke();

  const isAuto = interactiveState().screenAuto;
  textC(c, `Auto Rotation: ${isAuto ? "ENABLED (slides every 20s)" : "MANUAL CONTROL"}  •  Toggle with !auto on / !auto off`, 540, autoY + 42, 19, isAuto ? p.green : p.muted, 700, "center");

  drawBottomStats(c, p, now);
}

function drawMenuScreen(c, p, now) {
  drawHero(c, p, now, "STREAM MENU");
  drawMenuScreenContent(c, p, now);
}

function drawEventsScreenContent(c, p, now) {
  const events = getEvents(now).slice(-6).reverse();

  const feedY = 428, feedH = 890;
  c.fillStyle = p.card;
  rr(c, 40, feedY, 1000, feedH, 20);
  c.fill();
  c.strokeStyle = p.cardBorder;
  rr(c, 40, feedY, 1000, feedH, 20);
  c.stroke();

  drawCrown(c, 75, feedY + 44, 12, p.goldBright);
  textC(c, "LIVE INTERACTION FEED", 100, feedY + 50, 20, p.goldBright, 800);

  if (!events.length) {
    textC(c, "Waiting for the next Bigg Boss live event...", 540, feedY + 420, 24, p.muted, 700, "center");
    textC(c, "Type !drop, !heart, !gift, !boom, or !vote in chat!", 540, feedY + 470, 20, p.goldBright, 700, "center");
  } else {
    events.forEach((e, idx) => {
      const y = feedY + 80 + idx * 125;
      const age = Math.max(0, now - e.createdAt);
      const remain = Math.max(0, e.durationMs - age);

      c.fillStyle = idx === 0 ? (p.theme === "light" ? "#fffbeb" : "rgba(245, 197, 66, 0.08)") : "rgba(255, 255, 255, 0.02)";
      rr(c, 65, y, 950, 108, 16);
      c.fill();
      c.strokeStyle = idx === 0 ? p.goldBright : p.line;
      rr(c, 65, y, 950, 108, 16);
      c.stroke();

      const icon = {
        vote: "⚡", combo: "🔥", milestone: "🎉", battle: "⚔",
        boom: "💥", gift: "🎁", heart: "❤️", rain: "🌧",
        crown: "👑", zap: "⚡", fire: "🔥", star: "⭐",
        dice: "🎲", coin: "🪙", slot: "🎰", mvp: "🏆", shoutout: "👋"
      }[e.type] || "✨";

      textC(c, icon, 115, y + 66, 36, p.text, 700, "center");
      textC(c, e.type.toUpperCase(), 175, y + 42, 16, p.goldBright, 800);
      textC(c, fit(e.name || e.candidateName || "Bigg Boss", 26), 175, y + 76, 28, p.text, 800);
      textC(c, `${Math.ceil(remain / 1000)}s`, 985, y + 62, 16, p.muted, 700, "right");
    });
  }

  drawBottomStats(c, p, now);
}

function drawEventsScreen(c, p, now) {
  drawHero(c, p, now, "LIVE EVENTS");
  drawEventsScreenContent(c, p, now);
}

function drawScreenContent(screen, targetCtx, p, now) {
  if (screen === "main") drawVoteScreenContent(targetCtx, p, now);
  else if (screen === "race") drawRaceScreenContent(targetCtx, p, now);
  else if (screen === "stats") drawStatsScreenContent(targetCtx, p, now);
  else if (screen === "supporters") drawSupportersScreenContent(targetCtx, p, now);
  else if (screen === "menu") drawMenuScreenContent(targetCtx, p, now);
  else if (screen === "events") drawEventsScreenContent(targetCtx, p, now);
  else drawVoteScreenContent(targetCtx, p, now);
}

function drawScene(screen, now, targetCtx = ctx) {
  const p = palette();
  drawBackground(targetCtx, p, now);
  drawTopBar(targetCtx, p, now);
  drawHero(targetCtx, p, now, screenLabel(screen));
  drawScreenContent(screen, targetCtx, p, now);
  drawFooter(targetCtx, p);
  drawInteractive(targetCtx, p, now);
}

function seedParticles(e, now) {
  if (seeded.has(e.id)) return;
  if (seeded.size > 2000) seeded.clear();
  seeded.add(e.id);
  const s = interactiveState();

  // Type-specific spawn configs
  const cfg = {
    drop:        { count: 40, colors: ["#fbbf24", "#f59e0b", "#38bdf8", "#f472b6", "#ffffff"], cx: 540, cy: 1340, spread: 400, speedMin: 90, speedMax: 300, maxLife: 2400, gravity: 85, sizeMin: 6, sizeMax: 16, shape: "star" },
    rain:        { count: 55, colors: ["#38bdf8", "#a5f3fc", "#7dd3fc", "#e0f2fe", "#f472b6"], cx: 540, cy: 100,  spread: 500, speedMin: 60,  speedMax: 220, maxLife: 2800, gravity: 90,  sizeMin: 6,  sizeMax: 14, shape: "drop"   },
    boom:        { count: 65, colors: ["#ef4444", "#f97316", "#fbbf24", "#ffffff", "#fb923c"], cx: 540, cy: 900,  spread: 60,  speedMin: 180, speedMax: 500, maxLife: 1600, gravity: 120, sizeMin: 5,  sizeMax: 16, shape: "spark"  },
    heart:       { count: 36, colors: ["#f472b6", "#fb7185", "#fda4af", "#ff4d6d", "#fbbf24"], cx: 540, cy: 960,  spread: 340, speedMin: 30,  speedMax: 150, maxLife: 2400, gravity: -40, sizeMin: 10, sizeMax: 20, shape: "heart"  },
    milestone:   { count: 80, colors: ["#fbbf24", "#f472b6", "#38bdf8", "#4ade80", "#c084fc", "#ffffff"], cx: 540, cy: 750, spread: 400, speedMin: 100, speedMax: 400, maxLife: 3000, gravity: 95,  sizeMin: 6,  sizeMax: 18, shape: "star"   },
    vote:        { count: 22, colors: ["#fbbf24", "#ffffff", "#38bdf8", "#f59e0b", "#fde68a"], cx: 540, cy: 860,  spread: 200, speedMin: 80,  speedMax: 280, maxLife: 1600, gravity: 80,  sizeMin: 5,  sizeMax: 12, shape: "star"   },
    wheel:       { count: 40, colors: ["#fbbf24", "#c084fc", "#38bdf8", "#4ade80", "#f472b6"], cx: 540, cy: 860,  spread: 300, speedMin: 100, speedMax: 360, maxLife: 2400, gravity: 85,  sizeMin: 6,  sizeMax: 16, shape: "star"   },
    bomb:        { count: 70, colors: ["#ef4444", "#fbbf24", "#fb923c", "#1e293b", "#ffffff"], cx: 540, cy: 900,  spread: 40,  speedMin: 250, speedMax: 620, maxLife: 1800, gravity: 150, sizeMin: 4,  sizeMax: 14, shape: "spark"  },
    hype:        { count: 45, colors: ["#ef4444", "#f97316", "#fbbf24", "#ec4899", "#ffffff"], cx: 540, cy: 820,  spread: 380, speedMin: 80,  speedMax: 300, maxLife: 2200, gravity: 60,  sizeMin: 7,  sizeMax: 18, shape: "star"   },
    confetti:    { count: 90, colors: ["#fbbf24", "#38bdf8", "#f472b6", "#4ade80", "#c084fc", "#ef4444", "#fb923c"], cx: 540, cy: 0, spread: 680, speedMin: 60, speedMax: 280, maxLife: 3400, gravity: 120, sizeMin: 5, sizeMax: 15, shape: "rect"  },
    fireworks:   { count: 60, colors: ["#fbbf24", "#38bdf8", "#f472b6", "#4ade80", "#ffffff"], cx: 540, cy: 500, spread: 500, speedMin: 120, speedMax: 420, maxLife: 2400, gravity: 70,  sizeMin: 4,  sizeMax: 12, shape: "spark"  },
    lightning:   { count: 30, colors: ["#38bdf8", "#7dd3fc", "#bfdbfe", "#ffffff", "#fbbf24"], cx: 540, cy: 960,  spread: 120, speedMin: 60,  speedMax: 280, maxLife: 1200, gravity: 20,  sizeMin: 4,  sizeMax: 10, shape: "spark"  },
    combo:       { count: 30, colors: ["#fbbf24", "#f472b6", "#38bdf8", "#ffffff"],            cx: 540, cy: 900,  spread: 180, speedMin: 60,  speedMax: 240, maxLife: 1600, gravity: 75,  sizeMin: 5,  sizeMax: 12, shape: "star"   },
    gift:        { count: 28, colors: ["#fbbf24", "#f472b6", "#4ade80", "#38bdf8", "#ffffff"], cx: 540, cy: 700,  spread: 200, speedMin: 50,  speedMax: 200, maxLife: 2000, gravity: 70,  sizeMin: 6,  sizeMax: 14, shape: "star"   },
  };

  const def = cfg[e.type] || { count: 20, colors: ["#fbbf24", "#38bdf8", "#f472b6", "#ffffff", "#f59e0b"], cx: 540, cy: 900, spread: 260, speedMin: 50, speedMax: 240, maxLife: 1600, gravity: 80, sizeMin: 6, sizeMax: 12, shape: "star" };

  for (let i = 0; i < def.count; i++) {
    const a = Math.random() * Math.PI * 2;
    const sp = def.speedMin + Math.random() * (def.speedMax - def.speedMin);
    const cx = def.cx + (Math.random() - 0.5) * def.spread;
    const cy = def.cy + (Math.random() - 0.5) * (def.spread * 0.4);
    s.particles.push({
      eventId: e.id,
      born: now,
      x: cx,
      y: cy,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp - (def.gravity * 0.5),
      gravity: def.gravity,
      life: 0,
      max: def.maxLife * (0.7 + Math.random() * 0.6),
      size: def.sizeMin + Math.random() * (def.sizeMax - def.sizeMin),
      color: def.colors[i % def.colors.length],
      shape: def.shape,
      rot: Math.random() * Math.PI * 2,
      rotV: (Math.random() - 0.5) * 0.2
    });
  }
  if (s.particles.length > 450) s.particles.splice(0, s.particles.length - 450);
}

function seedVoteSparkle(contestantNo, rowY, now) {
  const s = interactiveState();
  const key = `vsp-${contestantNo}-${Math.round(now / 800)}`;
  if (seeded.has(key)) return;
  seeded.add(key);
  const colors = ["#fbbf24", "#ffffff", "#38bdf8", "#f59e0b", "#fde68a"];
  const cx = 540 + (Math.random() - 0.5) * 600;
  const cy = rowY + 66;
  for (let i = 0; i < 14; i++) {
    const a = Math.random() * Math.PI * 2;
    const sp = 50 + Math.random() * 160;
    s.particles.push({
      born: now,
      x: cx, y: cy,
      vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 40,
      gravity: 60,
      life: 0, max: 900 + Math.random() * 600,
      size: 4 + Math.random() * 7,
      color: colors[i % colors.length],
      shape: "star",
      rot: Math.random() * Math.PI * 2,
      rotV: (Math.random() - 0.5) * 0.15
    });
  }
  if (s.particles.length > 450) s.particles.splice(0, s.particles.length - 450);
}

function drawInteractive(targetCtx, p, now) {
  const events = getEvents(now), s = interactiveState();
  if (s.particles.length > 0) {
    s.particles = s.particles.filter(q => (now - (q.born || now)) <= q.max);
  }

  for (const e of events) {
    seedParticles(e, now);
    const age = now - e.createdAt, t = clamp(age / e.durationMs, 0, 1);
    if (e.type === "drop") {
      // Robust X position spread across entire screen (180 to 900)
      let hVal = 0;
      const hashStr = `${e.id}:${e.userId || ""}:${e.name || ""}:${e.contestant || 0}`;
      for (let ci = 0; ci < hashStr.length; ci++) hVal = (hVal * 37 + hashStr.charCodeAt(ci)) >>> 0;
      const baseX = 180 + (hVal % 720);
      const sway = Math.sin(t * Math.PI * 6) * 32;
      const x = baseX + sway;
      const y = 140 + Math.pow(t, 1.15) * 1240;
      const contestantNo = e.contestant || e.payload?.contestant || 0;
      const isLanded = t > 0.84;
      const tilt = Math.cos(t * Math.PI * 6) * 0.10;

      targetCtx.save();

      // 1. Landing touchdown shockwave + smoke/sparks
      if (isLanded) {
        const landT = (t - 0.84) / 0.16;
        const ringR = 25 + landT * 220;
        targetCtx.save();
        targetCtx.strokeStyle = `rgba(251, 191, 36, ${Math.max(0, 1 - landT)})`;
        targetCtx.lineWidth = ps(4 * (1 - landT));
        targetCtx.beginPath();
        targetCtx.ellipse(px(x), py(y + 44), ps(ringR), ps(ringR * 0.35), 0, 0, Math.PI * 2);
        targetCtx.stroke();

        // Upward golden light pillar beam on landing
        const bGrad = targetCtx.createLinearGradient(px(x - 30), 0, px(x + 30), 0);
        bGrad.addColorStop(0, "rgba(251, 191, 36, 0)");
        bGrad.addColorStop(0.5, `rgba(251, 191, 36, ${0.45 * (1 - landT)})`);
        bGrad.addColorStop(1, "rgba(251, 191, 36, 0)");
        targetCtx.fillStyle = bGrad;
        targetCtx.fillRect(px(x - 30), py(y - 300), ps(60), ps(344));
        targetCtx.restore();
      }

      targetCtx.translate(px(x), py(y));
      if (!isLanded) targetCtx.rotate(tilt);

      // 2. Billowing Parachute Canopy (above crate)
      if (!isLanded) {
        const paraW = 160, paraH = 85, paraY = -150;

        // Parachute suspension rigging cords
        targetCtx.strokeStyle = "rgba(255, 255, 255, 0.65)";
        targetCtx.lineWidth = ps(1.5);
        targetCtx.beginPath();
        targetCtx.moveTo(px(-paraW * 0.48), py(paraY + paraH));
        targetCtx.lineTo(px(-40), py(-42));
        targetCtx.moveTo(px(-paraW * 0.18), py(paraY + paraH));
        targetCtx.lineTo(px(-15), py(-42));
        targetCtx.moveTo(px(paraW * 0.18), py(paraY + paraH));
        targetCtx.lineTo(px(15), py(-42));
        targetCtx.moveTo(px(paraW * 0.48), py(paraY + paraH));
        targetCtx.lineTo(px(40), py(-42));
        targetCtx.stroke();

        // Canopy dome
        const cGrad = targetCtx.createLinearGradient(px(-paraW / 2), 0, px(paraW / 2), 0);
        cGrad.addColorStop(0, "#ef4444");
        cGrad.addColorStop(0.3, "#f59e0b");
        cGrad.addColorStop(0.7, "#fbbf24");
        cGrad.addColorStop(1, "#ef4444");
        targetCtx.fillStyle = cGrad;
        targetCtx.beginPath();
        targetCtx.moveTo(px(-paraW / 2), py(paraY + paraH));
        targetCtx.quadraticCurveTo(px(0), py(paraY - 15), px(paraW / 2), py(paraY + paraH));
        targetCtx.quadraticCurveTo(px(paraW * 0.25), py(paraY + paraH - 12), px(0), py(paraY + paraH));
        targetCtx.quadraticCurveTo(px(-paraW * 0.25), py(paraY + paraH - 12), px(-paraW / 2), py(paraY + paraH));
        targetCtx.closePath();
        targetCtx.fill();
        targetCtx.strokeStyle = "#ffffff";
        targetCtx.lineWidth = ps(2.2);
        targetCtx.stroke();

        drawGlint(targetCtx, 0, paraY + 8, 7, now, "#ffffff");
      }

      // 3. Golden Airdrop Supply Crate (88x88)
      const crateSize = 88;
      const crX = -crateSize / 2, crY = -crateSize / 2;

      // Drop shadow
      targetCtx.fillStyle = "rgba(0, 0, 0, 0.45)";
      rr(targetCtx, crX + 4, crY + 6, crateSize, crateSize, 18);
      targetCtx.fill();

      // Crate metallic golden body
      const crGrad = targetCtx.createLinearGradient(px(crX), py(crY), px(crX + crateSize), py(crY + crateSize));
      crGrad.addColorStop(0, "#fbbf24");
      crGrad.addColorStop(0.5, "#d97706");
      crGrad.addColorStop(1, "#92400e");
      targetCtx.fillStyle = crGrad;
      rr(targetCtx, crX, crY, crateSize, crateSize, 18);
      targetCtx.fill();

      // Border & metal rim
      targetCtx.strokeStyle = "#fef08a";
      targetCtx.lineWidth = ps(2.8);
      rr(targetCtx, crX, crY, crateSize, crateSize, 18);
      targetCtx.stroke();

      // Inner metal brackets
      targetCtx.strokeStyle = "rgba(255, 255, 255, 0.4)";
      targetCtx.lineWidth = ps(1.5);
      targetCtx.beginPath();
      targetCtx.moveTo(px(crX + 12), py(crY + 12));
      targetCtx.lineTo(px(crX + crateSize - 12), py(crY + crateSize - 12));
      targetCtx.moveTo(px(crX + crateSize - 12), py(crY + 12));
      targetCtx.lineTo(px(crX + 12), py(crY + crateSize - 12));
      targetCtx.stroke();

      // Contestant avatar OR emoji in center of crate
      if (contestantNo > 0) {
        const cImg = contestantImages.get(contestantNo);
        drawAvatar(targetCtx, contestantNo, 0, 0, 30, p, cImg);
        // Golden name banner below crate
        const cName = fit(e.payload?.candidateName || config.contestants[contestantNo - 1]?.displayName || `#${contestantNo}`, 12);
        targetCtx.fillStyle = "#0f172a";
        rr(targetCtx, -55, crY + crateSize + 4, 110, 24, 12);
        targetCtx.fill();
        targetCtx.strokeStyle = p.goldBright;
        targetCtx.lineWidth = ps(1.5);
        rr(targetCtx, -55, crY + crateSize + 4, 110, 24, 12);
        targetCtx.stroke();
        textC(targetCtx, cName, 0, crY + crateSize + 21, 13.5, "#ffffff", 900, "center");
      } else {
        const dropIcon = e.payload?.emoji || e.emoji || "🎈";
        textC(targetCtx, dropIcon, 0, 15, 38, "#ffffff", 900, "center");
        // Label pill
        targetCtx.fillStyle = "#0f172a";
        rr(targetCtx, -50, crY + crateSize + 4, 100, 22, 11);
        targetCtx.fill();
        targetCtx.strokeStyle = p.goldBright;
        targetCtx.lineWidth = ps(1.5);
        rr(targetCtx, -50, crY + crateSize + 4, 100, 22, 11);
        targetCtx.stroke();
        textC(targetCtx, "AIRDROP", 0, crY + crateSize + 20, 13, p.goldBright, 900, "center");
      }

      // Viewer Name Tag (floating above crate)
      targetCtx.fillStyle = "rgba(15, 23, 42, 0.9)";
      rr(targetCtx, -65, crY - 30, 130, 24, 12);
      targetCtx.fill();
      targetCtx.strokeStyle = p.goldBright;
      targetCtx.lineWidth = ps(1.5);
      rr(targetCtx, -65, crY - 30, 130, 24, 12);
      targetCtx.stroke();
      textC(targetCtx, `🪂 ${fit(e.name || "Viewer", 12)}`, 0, crY - 14, 13, "#ffffff", 900, "center");

      drawGlint(targetCtx, crX + crateSize - 12, crY + 12, 7, now, "#ffffff");
      targetCtx.restore();
    } else if (e.type === "gift") {
      const sway = Math.sin(t * Math.PI * 3) * 14;
      const y = 240 + (t * t) * 980;

      targetCtx.save();
      // Fast geometric drop shadow
      targetCtx.fillStyle = "rgba(0, 0, 0, 0.4)";
      rr(targetCtx, 540 - 35 + sway, y - 35 + 4, 70, 70, 16);
      targetCtx.fill();
      targetCtx.fillStyle = p.goldBright;
      rr(targetCtx, 540 - 35 + sway, y - 35, 70, 70, 16);
      targetCtx.fill();
      targetCtx.strokeStyle = "#ffffff";
      targetCtx.lineWidth = ps(2.5);
      rr(targetCtx, 540 - 35 + sway, y - 35, 70, 70, 16);
      targetCtx.stroke();
      textC(targetCtx, "GIFT", 540 + sway, y + 7, 18, "#000000", 900, "center");
      drawGlint(targetCtx, 540 + sway + 20, y - 20, 7, now, "#ffffff");
      targetCtx.restore();
    } else if (e.type === "boom") {
      const r = 40 + t * 240;
      targetCtx.save();
      targetCtx.globalAlpha = 1 - t;
      targetCtx.strokeStyle = p.red;
      targetCtx.lineWidth = ps(10);
      targetCtx.beginPath();
      targetCtx.arc(px(540), py(950), ps(r), 0, Math.PI * 2);
      targetCtx.stroke();
      textC(targetCtx, "💥", 540, 970, 64, p.red, 700, "center");
    } else if (e.type === "battle") {
      const aNo = e.payload?.a || e.contestant || 1;
      const bNo = e.payload?.b || 2;
      const aCont = config.contestants[aNo - 1] || { displayName: `Contestant ${aNo}`, votes: 0 };
      const bCont = config.contestants[bNo - 1] || { displayName: `Contestant ${bNo}`, votes: 0 };
      const aVotes = state.contestants[String(aNo)]?.votes ?? aCont.votes ?? 0;
      const bVotes = state.contestants[String(bNo)]?.votes ?? bCont.votes ?? 0;
      const aPct = (aVotes + bVotes > 0) ? (aVotes / (aVotes + bVotes)) : 0.5;

      const cardW = 960, cardH = 370, cardX = 540 - cardW / 2, cardY = 680;
      const fade = t < 0.08 ? clamp(0.7 + (t / 0.08) * 0.3, 0, 1) : t > 0.88 ? clamp((1 - t) / 0.12, 0, 1) : 1;

      targetCtx.save();
      targetCtx.globalAlpha = fade;

      // Dimming backdrop
      targetCtx.fillStyle = "rgba(0, 0, 0, 0.65)";
      targetCtx.fillRect(0, 0, W, H);

      // Fast geometric card drop shadow
      targetCtx.fillStyle = "rgba(0, 0, 0, 0.55)";
      rr(targetCtx, cardX, cardY + 8, cardW, cardH, 24);
      targetCtx.fill();
      targetCtx.fillStyle = p.theme === "light" ? "#ffffff" : "#0d1322";
      rr(targetCtx, cardX, cardY, cardW, cardH, 24);
      targetCtx.fill();

      // Fiery Gold Border
      targetCtx.strokeStyle = p.goldBright;
      targetCtx.lineWidth = ps(3.5);
      rr(targetCtx, cardX, cardY, cardW, cardH, 24);
      targetCtx.stroke();

      drawGlint(targetCtx, 340, cardY + 42, 8, now, p.goldBright);
      drawGlint(targetCtx, 740, cardY + 42, 8, now + 800, p.goldBright);
      textC(targetCtx, "1v1 BATTLE ARENA", 540, cardY + 48, 28, p.goldBright, 950, "center");
      textC(targetCtx, "WHO DESERVES TO STAY IN BIGG BOSS?", 540, cardY + 76, 16, p.muted, 700, "center");

      // Left Fighter (A)
      drawAvatar(targetCtx, aNo, cardX + 130, cardY + 165, 52, p);
      textC(targetCtx, fit(aCont.displayName || aCont.name, 14), cardX + 130, cardY + 248, 22, p.text, 800, "center");
      textC(targetCtx, `${aVotes.toLocaleString()} VOTES`, cardX + 130, cardY + 276, 19, p.goldBright, 800, "center");
      textC(targetCtx, `!vote ${aNo}`, cardX + 130, cardY + 304, 18, p.cyan, 900, "center");

      // VS in middle
      const vsPulse = 1 + 0.1 * Math.sin(now * 0.01);
      targetCtx.save();
      textC(targetCtx, "VS", 540, cardY + 175, 42 * vsPulse, p.red, 950, "center");
      drawGlint(targetCtx, 540, cardY + 135, 9, now, p.goldBright);
      targetCtx.restore();

      // Right Fighter (B)
      drawAvatar(targetCtx, bNo, cardX + cardW - 130, cardY + 165, 52, p);
      textC(targetCtx, fit(bCont.displayName || bCont.name, 14), cardX + cardW - 130, cardY + 248, 22, p.text, 800, "center");
      textC(targetCtx, `${bVotes.toLocaleString()} VOTES`, cardX + cardW - 130, cardY + 276, 19, p.goldBright, 800, "center");
      textC(targetCtx, `!vote ${bNo}`, cardX + cardW - 130, cardY + 304, 18, p.cyan, 900, "center");

      // Tug-of-war meter
      const barW = 440, barH = 22, barX = 540 - barW / 2, barY = cardY + 215;
      targetCtx.fillStyle = p.barBg;
      rr(targetCtx, barX, barY, barW, barH, barH / 2);
      targetCtx.fill();

      const fillA = Math.max(barH / 2, Math.min(barW - barH / 2, barW * aPct));
      targetCtx.fillStyle = p.cyan;
      rr(targetCtx, barX, barY, fillA, barH, barH / 2);
      targetCtx.fill();

      targetCtx.fillStyle = p.pink;
      rr(targetCtx, barX + fillA, barY, barW - fillA, barH, barH / 2);
      targetCtx.fill();

      targetCtx.fillStyle = "#ffffff";
      targetCtx.beginPath();
      targetCtx.arc(px(barX + fillA), py(barY + barH / 2), ps(13), 0, Math.PI * 2);
      targetCtx.fill();
      targetCtx.strokeStyle = p.navyPill;
      targetCtx.lineWidth = ps(3);
      targetCtx.stroke();

      textC(targetCtx, `${Math.round(aPct * 100)}%`, barX - 15, barY + 17, 17, p.cyan, 800, "right");
      textC(targetCtx, `${Math.round((1 - aPct) * 100)}%`, barX + barW + 15, barY + 17, 17, p.pink, 800, "left");

      textC(targetCtx, "TYPE !vote <no> IN CHAT TO BACK YOUR FIGHTER!", 540, cardY + 342, 17, p.goldBright, 800, "center");
      targetCtx.restore();
    } else if (e.type === "dice") {
      const roll = e.payload?.roll || 6;
      const isRolling = age < 1200;
      const curVal = isRolling ? (1 + Math.floor((now / 80) % 6)) : roll;
      const cardW = 560, cardH = 290, cardX = 540 - cardW / 2, cardY = 740;
      const fade = t < 0.08 ? clamp(0.7 + (t / 0.08) * 0.3, 0, 1) : t > 0.88 ? clamp((1 - t) / 0.12, 0, 1) : 1;

      targetCtx.save();
      targetCtx.globalAlpha = fade;

      targetCtx.fillStyle = "rgba(0, 0, 0, 0.65)";
      targetCtx.fillRect(0, 0, W, H);

      // Fast geometric drop shadow
      targetCtx.fillStyle = "rgba(0, 0, 0, 0.55)";
      rr(targetCtx, cardX, cardY + 8, cardW, cardH, 22);
      targetCtx.fill();
      targetCtx.fillStyle = p.theme === "light" ? "#ffffff" : "#0d1322";
      rr(targetCtx, cardX, cardY, cardW, cardH, 22);
      targetCtx.fill();

      targetCtx.strokeStyle = p.goldBright;
      targetCtx.lineWidth = ps(2.5);
      rr(targetCtx, cardX, cardY, cardW, cardH, 22);
      targetCtx.stroke();

      drawGlint(targetCtx, cardX + 50, cardY + 38, 7, now, p.goldBright);
      drawGlint(targetCtx, cardX + cardW - 50, cardY + 38, 7, now + 600, p.goldBright);
      textC(targetCtx, "CHAT DICE ROLL", 540, cardY + 44, 24, p.goldBright, 800, "center");

      const diceSize = 100, diceX = 540 - diceSize / 2, diceY = cardY + 68;
      const rot = isRolling ? Math.sin(now * 0.03) * 0.25 : 0;
      targetCtx.save();
      targetCtx.translate(px(540), py(diceY + diceSize / 2));
      targetCtx.rotate(rot);
      targetCtx.translate(-px(540), -py(diceY + diceSize / 2));

      targetCtx.fillStyle = "#f8fafc";
      rr(targetCtx, diceX, diceY, diceSize, diceSize, 18);
      targetCtx.fill();
      targetCtx.strokeStyle = "#cbd5e1";
      targetCtx.lineWidth = ps(3);
      rr(targetCtx, diceX, diceY, diceSize, diceSize, 18);
      targetCtx.stroke();

      const drawPip = (pxPos, pyPos) => {
        targetCtx.fillStyle = (curVal === 1 || curVal === 4) ? "#dc2626" : "#0f172a";
        targetCtx.beginPath();
        targetCtx.arc(px(pxPos), py(pyPos), ps(7.5), 0, Math.PI * 2);
        targetCtx.fill();
      };
      const mid = diceX + diceSize / 2, midY = diceY + diceSize / 2;
      const left = diceX + 26, right = diceX + diceSize - 26;
      const top = diceY + 26, bot = diceY + diceSize - 26;

      if (curVal % 2 === 1) drawPip(mid, midY);
      if (curVal > 1) { drawPip(left, top); drawPip(right, bot); }
      if (curVal >= 4) { drawPip(right, top); drawPip(left, bot); }
      if (curVal === 6) { drawPip(left, midY); drawPip(right, midY); }
      targetCtx.restore();

      textC(targetCtx, `${e.name || "Viewer"} rolled ${isRolling ? "..." : curVal}!`, 540, cardY + 215, 24, p.text, 800, "center");
      textC(targetCtx, isRolling ? "Rolling the dice..." : (curVal === 6 ? "LUCKY SIX!" : "Try your luck with !dice"), 540, cardY + 252, 17, p.goldBright, 700, "center");
      targetCtx.restore();
    } else if (e.type === "coin") {
      const flip = e.payload?.flip || "HEADS";
      const isSpinning = age < 1200;
      const cardW = 560, cardH = 290, cardX = 540 - cardW / 2, cardY = 740;
      const fade = t < 0.08 ? clamp(0.7 + (t / 0.08) * 0.3, 0, 1) : t > 0.88 ? clamp((1 - t) / 0.12, 0, 1) : 1;

      targetCtx.save();
      targetCtx.globalAlpha = fade;

      targetCtx.fillStyle = "rgba(0, 0, 0, 0.65)";
      targetCtx.fillRect(0, 0, W, H);

      // Fast geometric drop shadow
      targetCtx.fillStyle = "rgba(0, 0, 0, 0.55)";
      rr(targetCtx, cardX, cardY + 8, cardW, cardH, 22);
      targetCtx.fill();
      targetCtx.fillStyle = p.theme === "light" ? "#ffffff" : "#0d1322";
      rr(targetCtx, cardX, cardY, cardW, cardH, 22);
      targetCtx.fill();

      targetCtx.strokeStyle = p.goldBright;
      targetCtx.lineWidth = ps(2.5);
      rr(targetCtx, cardX, cardY, cardW, cardH, 22);
      targetCtx.stroke();

      drawGlint(targetCtx, cardX + 50, cardY + 38, 7, now, p.goldBright);
      drawGlint(targetCtx, cardX + cardW - 50, cardY + 38, 7, now + 600, p.goldBright);
      textC(targetCtx, "CHAT COIN FLIP", 540, cardY + 44, 24, p.goldBright, 800, "center");

      const coinR = 48, coinCx = 540, coinCy = cardY + 120;
      const scaleX = isSpinning ? Math.cos(age * 0.02) : 1;

      targetCtx.save();
      targetCtx.translate(px(coinCx), py(coinCy));
      targetCtx.scale(scaleX, 1);
      targetCtx.translate(-px(coinCx), -py(coinCy));

      const cGrad = targetCtx.createLinearGradient(px(coinCx - coinR), py(coinCy - coinR), px(coinCx + coinR), py(coinCy + coinR));
      cGrad.addColorStop(0, "#fbbf24");
      cGrad.addColorStop(0.5, "#d97706");
      cGrad.addColorStop(1, "#b45309");
      targetCtx.fillStyle = cGrad;
      targetCtx.beginPath();
      targetCtx.arc(px(coinCx), py(coinCy), ps(coinR), 0, Math.PI * 2);
      targetCtx.fill();

      targetCtx.strokeStyle = "#fef08a";
      targetCtx.lineWidth = ps(3);
      targetCtx.beginPath();
      targetCtx.arc(px(coinCx), py(coinCy), ps(coinR - 5), 0, Math.PI * 2);
      targetCtx.stroke();

      const letter = isSpinning ? (Math.sin(age * 0.02) > 0 ? "H" : "T") : (flip === "HEADS" ? "H" : "T");
      textC(targetCtx, letter, coinCx, coinCy + 14, 40, "#ffffff", 950, "center");
      targetCtx.restore();

      textC(targetCtx, `${e.name || "Viewer"} flipped ${isSpinning ? "..." : flip}!`, 540, cardY + 215, 24, p.text, 800, "center");
      textC(targetCtx, isSpinning ? "Flipping in the air..." : "Test your fate with !coin", 540, cardY + 252, 17, p.goldBright, 700, "center");
      targetCtx.restore();
    } else if (e.type === "slot") {
      const symbols = ["🍒", "🍋", "🔔", "💎", "7️⃣"];
      const s1 = (age < 600) ? symbols[Math.floor((now / 90) % symbols.length)] : (e.payload?.s1 || "7️⃣");
      const s2 = (age < 1100) ? symbols[Math.floor((now / 90) % symbols.length)] : (e.payload?.s2 || "7️⃣");
      const s3 = (age < 1600) ? symbols[Math.floor((now / 90) % symbols.length)] : (e.payload?.s3 || "7️⃣");
      const isDone = age >= 1600;
      const isWin = isDone && e.payload?.win;

      const cardW = 620, cardH = 310, cardX = 540 - cardW / 2, cardY = 730;
      const fade = t < 0.08 ? clamp(0.7 + (t / 0.08) * 0.3, 0, 1) : t > 0.88 ? clamp((1 - t) / 0.12, 0, 1) : 1;

      targetCtx.save();
      targetCtx.globalAlpha = fade;

      targetCtx.fillStyle = "rgba(0, 0, 0, 0.65)";
      targetCtx.fillRect(0, 0, W, H);

      // Fast geometric drop shadow
      targetCtx.fillStyle = "rgba(0, 0, 0, 0.55)";
      rr(targetCtx, cardX, cardY + 8, cardW, cardH, 22);
      targetCtx.fill();
      targetCtx.fillStyle = p.theme === "light" ? "#ffffff" : "#0d1322";
      rr(targetCtx, cardX, cardY, cardW, cardH, 22);
      targetCtx.fill();

      targetCtx.strokeStyle = isWin ? p.goldBright : p.cardBorder;
      targetCtx.lineWidth = ps(3);
      rr(targetCtx, cardX, cardY, cardW, cardH, 22);
      targetCtx.stroke();

      drawGlint(targetCtx, cardX + 60, cardY + 38, 7, now, p.goldBright);
      drawGlint(targetCtx, cardX + cardW - 60, cardY + 38, 7, now + 600, p.goldBright);
      textC(targetCtx, "VEGAS SLOT MACHINE", 540, cardY + 44, 24, p.goldBright, 800, "center");

      const reelW = 120, reelH = 90, reelY = cardY + 70;
      [s1, s2, s3].forEach((sym, rIdx) => {
        const rx = cardX + 70 + rIdx * 170;
        targetCtx.fillStyle = p.barBg;
        rr(targetCtx, rx, reelY, reelW, reelH, 14);
        targetCtx.fill();
        targetCtx.strokeStyle = p.line;
        targetCtx.lineWidth = ps(2);
        rr(targetCtx, rx, reelY, reelW, reelH, 14);
        targetCtx.stroke();
        textC(targetCtx, sym, rx + reelW / 2, reelY + 62, 44, p.text, 700, "center");
      });

      if (isWin) {
        textC(targetCtx, "JACKPOT WINNER!", 540, cardY + 215, 28, p.goldBright, 950, "center");
        textC(targetCtx, `Congratulations ${e.name || "Viewer"}!`, 540, cardY + 255, 20, p.text, 800, "center");
      } else {
        textC(targetCtx, `${e.name || "Viewer"} rolled the slots!`, 540, cardY + 215, 22, p.text, 800, "center");
        textC(targetCtx, isDone ? "Try again with !slot" : "Spinning reels...", 540, cardY + 252, 17, p.goldBright, 700, "center");
      }
      targetCtx.restore();
    } else if (e.type === "shoutout") {
      const msg = e.payload?.message || "BIGG BOSS 24/7 LIVE!";
      const cardW = 920, cardH = 220, cardX = 540 - cardW / 2, cardY = 770;
      const fade = t < 0.08 ? clamp(0.7 + (t / 0.08) * 0.3, 0, 1) : t > 0.88 ? clamp((1 - t) / 0.12, 0, 1) : 1;

      targetCtx.save();
      targetCtx.globalAlpha = fade;

      targetCtx.fillStyle = "rgba(0, 0, 0, 0.65)";
      targetCtx.fillRect(0, 0, W, H);

      // Fast geometric drop shadow
      targetCtx.fillStyle = "rgba(0, 0, 0, 0.55)";
      rr(targetCtx, cardX, cardY + 8, cardW, cardH, 20);
      targetCtx.fill();

      const sGrad = targetCtx.createLinearGradient(px(cardX), py(cardY), px(cardX + cardW), py(cardY + cardH));
      sGrad.addColorStop(0, p.theme === "light" ? "#fffbeb" : "#1e1b4b");
      sGrad.addColorStop(1, p.theme === "light" ? "#fef3c7" : "#0d1322");
      targetCtx.fillStyle = sGrad;
      rr(targetCtx, cardX, cardY, cardW, cardH, 20);
      targetCtx.fill();

      targetCtx.strokeStyle = p.goldBright;
      targetCtx.lineWidth = ps(3);
      rr(targetCtx, cardX, cardY, cardW, cardH, 20);
      targetCtx.stroke();

      drawCrown(targetCtx, cardX + 60, cardY + 44, 14, p.goldBright);
      textC(targetCtx, "VIP FAN SHOUTOUT", 540, cardY + 48, 24, p.goldBright, 800, "center");
      textC(targetCtx, `"${fit(msg, 55)}"`, 540, cardY + 115, 28, p.text, 900, "center");
      textC(targetCtx, `— ${fit(e.name || "Viewer", 24)}`, cardX + cardW - 60, cardY + 175, 20, p.goldBright, 800, "right");
      targetCtx.restore();
    } else if (e.type === "wheel") {
      const winner = e.payload?.winner || "🌟 2X VOTE";
      const options = e.payload?.options || ["🌟 2X VOTE", "💎 500 PTS", "👑 VIP FAN", "⚡ BOOST", "🔥 HYPE", "🎁 MYSTERY", "🎯 CROWN", "🏆 JACKPOT"];
      const spinDuration = 3200;
      const isSpinning = age < spinDuration;
      const spinProgress = Math.min(1, age / spinDuration);
      const easedSpin = 1 - Math.pow(1 - spinProgress, 3);
      const totalAngle = (e.payload?.finalAngle || (Math.PI * 8)) * easedSpin;

      const cardW = 660, cardH = 430, cardX = 540 - cardW / 2, cardY = 650;
      const fade = t < 0.08 ? clamp(0.7 + (t / 0.08) * 0.3, 0, 1) : t > 0.88 ? clamp((1 - t) / 0.12, 0, 1) : 1;

      targetCtx.save();
      targetCtx.globalAlpha = fade;

      targetCtx.fillStyle = "rgba(0, 0, 0, 0.65)";
      targetCtx.fillRect(0, 0, W, H);

      targetCtx.fillStyle = "rgba(0, 0, 0, 0.55)";
      rr(targetCtx, cardX, cardY + 8, cardW, cardH, 24);
      targetCtx.fill();

      targetCtx.fillStyle = p.theme === "light" ? "#ffffff" : "#0d1322";
      rr(targetCtx, cardX, cardY, cardW, cardH, 24);
      targetCtx.fill();

      targetCtx.strokeStyle = p.goldBright;
      targetCtx.lineWidth = ps(3);
      rr(targetCtx, cardX, cardY, cardW, cardH, 24);
      targetCtx.stroke();

      drawGlint(targetCtx, cardX + 50, cardY + 36, 7, now, p.goldBright);
      drawGlint(targetCtx, cardX + cardW - 50, cardY + 36, 7, now + 600, p.goldBright);
      textC(targetCtx, "LUCKY FORTUNE WHEEL", 540, cardY + 42, 25, p.goldBright, 900, "center");

      const wheelCx = 540, wheelCy = cardY + 200, wheelR = 120;
      const segAngle = (Math.PI * 2) / options.length;
      const wedgeColors = ["#ef4444", "#f59e0b", "#10b981", "#06b6d4", "#6366f1", "#ec4899", "#8b5cf6", "#f97316"];

      targetCtx.save();
      targetCtx.translate(px(wheelCx), py(wheelCy));
      targetCtx.rotate(totalAngle);

      for (let sIdx = 0; sIdx < options.length; sIdx++) {
        const aStart = sIdx * segAngle;
        const aEnd = aStart + segAngle;
        targetCtx.fillStyle = wedgeColors[sIdx % wedgeColors.length];
        targetCtx.beginPath();
        targetCtx.moveTo(0, 0);
        targetCtx.arc(0, 0, ps(wheelR), aStart, aEnd);
        targetCtx.closePath();
        targetCtx.fill();
        targetCtx.strokeStyle = "#ffffff";
        targetCtx.lineWidth = ps(1.5);
        targetCtx.stroke();
      }

      targetCtx.fillStyle = "#0f172a";
      targetCtx.beginPath();
      targetCtx.arc(0, 0, ps(26), 0, Math.PI * 2);
      targetCtx.fill();
      targetCtx.strokeStyle = p.goldBright;
      targetCtx.lineWidth = ps(3);
      targetCtx.stroke();
      targetCtx.restore();

      targetCtx.fillStyle = "#ef4444";
      targetCtx.beginPath();
      targetCtx.moveTo(px(wheelCx), py(wheelCy - wheelR + 10));
      targetCtx.lineTo(px(wheelCx - 14), py(wheelCy - wheelR - 18));
      targetCtx.lineTo(px(wheelCx + 14), py(wheelCy - wheelR - 18));
      targetCtx.closePath();
      targetCtx.fill();
      targetCtx.strokeStyle = "#ffffff";
      targetCtx.lineWidth = ps(2);
      targetCtx.stroke();

      if (!isSpinning) {
        textC(targetCtx, winner, 540, cardY + 355, 30, p.goldBright, 950, "center");
        textC(targetCtx, `Congratulations ${e.name || "Viewer"}! 🏆`, 540, cardY + 395, 20, p.text, 800, "center");
        drawGlint(targetCtx, 540, cardY + 355, 10, now, "#ffffff");
      } else {
        textC(targetCtx, "SPINNING THE WHEEL...", 540, cardY + 355, 24, p.cyan, 800, "center");
        textC(targetCtx, `${e.name || "Viewer"} is testing their luck!`, 540, cardY + 395, 18, p.muted, 700, "center");
      }
      targetCtx.restore();
    } else if (e.type === "bomb") {
      const isDetonated = age >= 900;
      targetCtx.save();
      if (!isDetonated) {
        const shake = Math.sin(now * 0.06) * 6;
        const bCx = 540 + shake, bCy = 900;
        targetCtx.fillStyle = "rgba(0, 0, 0, 0.4)";
        targetCtx.beginPath();
        targetCtx.arc(px(bCx), py(bCy), ps(55), 0, Math.PI * 2);
        targetCtx.fill();

        targetCtx.fillStyle = "#1e293b";
        targetCtx.beginPath();
        targetCtx.arc(px(bCx), py(bCy), ps(50), 0, Math.PI * 2);
        targetCtx.fill();
        targetCtx.strokeStyle = "#475569";
        targetCtx.lineWidth = ps(3);
        targetCtx.stroke();

        targetCtx.strokeStyle = "#f59e0b";
        targetCtx.lineWidth = ps(4);
        targetCtx.beginPath();
        targetCtx.moveTo(px(bCx), py(bCy - 50));
        targetCtx.quadraticCurveTo(px(bCx + 25), py(bCy - 80), px(bCx + 35), py(bCy - 90));
        targetCtx.stroke();
        drawGlint(targetCtx, bCx + 35, bCy - 90, 9, now * 3, "#ef4444");

        textC(targetCtx, "💣 INCOMING BOMB!", bCx, bCy + 85, 26, "#ef4444", 900, "center");
      } else {
        const blastAge = age - 900;
        const blastT = blastAge / (e.durationMs - 900);
        const blastFade = Math.max(0, 1 - blastT);
        const r1 = ps(blastT * 480);
        const r2 = ps(blastT * 320);

        targetCtx.globalAlpha = blastFade;
        targetCtx.strokeStyle = "#f59e0b";
        targetCtx.lineWidth = ps(8 * blastFade);
        targetCtx.beginPath();
        targetCtx.arc(px(540), py(900), r1, 0, Math.PI * 2);
        targetCtx.stroke();

        targetCtx.strokeStyle = "#ef4444";
        targetCtx.lineWidth = ps(14 * blastFade);
        targetCtx.beginPath();
        targetCtx.arc(px(540), py(900), r2, 0, Math.PI * 2);
        targetCtx.stroke();

        textC(targetCtx, "💥 KABOOM! 💥", 540, 900, 52, "#ffffff", 950, "center");
        textC(targetCtx, `${e.name || "Viewer"} detonated the chat!`, 540, 955, 24, p.goldBright, 800, "center");
      }
      targetCtx.restore();
    } else if (e.type === "hype") {
      const cardW = 780, cardH = 140, cardX = 540 - cardW / 2, cardY = 820;
      const fade = t < 0.08 ? clamp(0.7 + (t / 0.08) * 0.3, 0, 1) : t > 0.88 ? clamp((1 - t) / 0.12, 0, 1) : 1;
      targetCtx.save();
      targetCtx.globalAlpha = fade;

      const hGrad = targetCtx.createLinearGradient(px(cardX), 0, px(cardX + cardW), 0);
      hGrad.addColorStop(0, "rgba(239, 68, 68, 0.95)");
      hGrad.addColorStop(0.5, "rgba(245, 158, 11, 0.95)");
      hGrad.addColorStop(1, "rgba(236, 72, 153, 0.95)");
      targetCtx.fillStyle = hGrad;
      rr(targetCtx, cardX, cardY, cardW, cardH, 20);
      targetCtx.fill();

      targetCtx.strokeStyle = "#ffffff";
      targetCtx.lineWidth = ps(3);
      rr(targetCtx, cardX, cardY, cardW, cardH, 20);
      targetCtx.stroke();

      // Pulsing glow border on hype
      const hypePulse = 0.5 + 0.5 * Math.sin(now * 0.015);
      targetCtx.strokeStyle = `rgba(251, 191, 36, ${0.4 + 0.6 * hypePulse})`;
      targetCtx.lineWidth = ps(3 + hypePulse * 2);
      rr(targetCtx, cardX, cardY, cardW, cardH, 20);
      targetCtx.stroke();

      drawGlint(targetCtx, cardX + 60, cardY + 70, 10, now, "#ffffff");
      drawGlint(targetCtx, cardX + cardW - 60, cardY + 70, 10, now + 500, "#ffffff");
      textC(targetCtx, "🚀 HYPE TRAIN SURGE! 🔥", 540, cardY + 54, 32, "#ffffff", 950, "center");
      textC(targetCtx, `Activated by ${e.name || "Viewer"} • Vote multiplier active!`, 540, cardY + 102, 22, "#fef08a", 800, "center");
      targetCtx.restore();
    } else if (e.type === "confetti") {
      // Full-screen confetti shower - particles handle the visuals
      // Just show a brief banner at top
      if (age < 1200) {
        const cFade = age < 200 ? age / 200 : age > 900 ? (1200 - age) / 300 : 1;
        targetCtx.save();
        targetCtx.globalAlpha = cFade;
        const confW = 780, confH = 90, confX = 540 - confW / 2, confY = 160;
        const cg = targetCtx.createLinearGradient(px(confX), 0, px(confX + confW), 0);
        cg.addColorStop(0, "rgba(251, 191, 36, 0.9)");
        cg.addColorStop(0.5, "rgba(244, 114, 182, 0.9)");
        cg.addColorStop(1, "rgba(56, 189, 248, 0.9)");
        targetCtx.fillStyle = cg;
        rr(targetCtx, confX, confY, confW, confH, 20);
        targetCtx.fill();
        textC(targetCtx, `🎉 CONFETTI PARTY — ${e.name || "Viewer"} 🎉`, 540, confY + 58, 28, "#ffffff", 950, "center");
        targetCtx.restore();
      }
    } else if (e.type === "fireworks") {
      // Multiple firework bursts radiating from screen
      const fBase = 380 + Math.sin(now * 0.007) * 200;
      const fx = 540 + Math.cos(now * 0.005) * 250;
      targetCtx.save();
      const fFade = t < 0.1 ? t / 0.1 : t > 0.85 ? (1 - t) / 0.15 : 1;
      targetCtx.globalAlpha = fFade;
      for (let fi = 0; fi < 4; fi++) {
        const fRad = 30 + t * 160 + fi * 40;
        const fAlpha = Math.max(0, (0.7 - t) * (1 - fi * 0.2));
        const fColors = ["#fbbf24", "#f472b6", "#38bdf8", "#4ade80"];
        targetCtx.globalAlpha = fFade * fAlpha;
        targetCtx.strokeStyle = fColors[fi];
        targetCtx.lineWidth = ps(4 - fi);
        targetCtx.beginPath();
        targetCtx.arc(px(fx + fi * 18 - 27), py(fBase + fi * 12 - 18), ps(fRad), 0, Math.PI * 2);
        targetCtx.stroke();
      }
      targetCtx.globalAlpha = fFade;
      textC(targetCtx, `🎆 FIREWORKS — ${e.name || "Viewer"} 🎆`, 540, 240, 30, "#fbbf24", 950, "center");
      targetCtx.restore();
    } else if (e.type === "lightning") {
      // Electric lightning bolt animation
      const lFade = t < 0.1 ? t / 0.1 : t > 0.8 ? (1 - t) / 0.2 : 1;
      targetCtx.save();
      targetCtx.globalAlpha = lFade;
      // Screen blue-white flash
      if (t < 0.15) {
        targetCtx.fillStyle = `rgba(148, 220, 255, ${0.12 * (1 - t / 0.15)})`;
        targetCtx.fillRect(0, 0, W, H);
      }
      // Draw zigzag lightning bolts
      const lColors = ["#38bdf8", "#bfdbfe", "#7dd3fc"];
      for (let li = 0; li < 3; li++) {
        const lx = 300 + li * 240;
        targetCtx.strokeStyle = lColors[li];
        targetCtx.lineWidth = ps(3 - li);
        targetCtx.shadowColor = "#38bdf8";
        targetCtx.shadowBlur = ps(12);
        targetCtx.beginPath();
        let cx2 = lx, cy2 = 180;
        targetCtx.moveTo(px(cx2), py(cy2));
        for (let seg = 0; seg < 7; seg++) {
          cx2 += (Math.random() - 0.5) * 60;
          cy2 += 100 + Math.random() * 80;
          targetCtx.lineTo(px(cx2), py(cy2));
        }
        targetCtx.stroke();
        targetCtx.shadowBlur = 0;
      }
      textC(targetCtx, `⚡ LIGHTNING STRIKE — ${e.name || "Viewer"} ⚡`, 540, 850, 28, "#38bdf8", 950, "center");
      targetCtx.restore();
    }
  }

  for (const q of s.particles) {
    if (!q.born) q.born = now;
    const age = now - q.born;
    q.life = age;
    if (age > q.max) continue;

    const dt = 0.016;
    q.x += q.vx * dt;
    q.y += q.vy * dt;
    q.vy += (q.gravity ?? 65) * dt;
    q.vx *= 0.995;  // gentle air friction
    if (q.rotV) q.rot = (q.rot || 0) + q.rotV;

    const alpha = Math.max(0, 1 - (age / q.max));
    const sz = Math.max(2, q.size * (0.6 + 0.4 * (1 - age / q.max)));

    targetCtx.save();
    targetCtx.globalAlpha = alpha;

    const shape = q.shape || "star";
    if (shape === "star" || shape === "spark") {
      drawGlint(targetCtx, q.x, q.y, sz * 0.65, now + q.born, q.color || p.goldBright);
    } else if (shape === "heart") {
      targetCtx.save();
      targetCtx.translate(px(q.x), py(q.y));
      targetCtx.fillStyle = q.color || "#f472b6";
      const hs = ps(sz * 0.55);
      targetCtx.beginPath();
      targetCtx.moveTo(0, -hs * 0.4);
      targetCtx.bezierCurveTo(hs * 0.6, -hs, hs, hs * 0.2, 0, hs);
      targetCtx.bezierCurveTo(-hs, hs * 0.2, -hs * 0.6, -hs, 0, -hs * 0.4);
      targetCtx.fill();
      targetCtx.restore();
    } else if (shape === "rect") {
      // Confetti rectangle
      targetCtx.save();
      targetCtx.translate(px(q.x), py(q.y));
      targetCtx.rotate(q.rot || 0);
      targetCtx.fillStyle = q.color || p.goldBright;
      const rw = ps(sz * 0.5), rh = ps(sz * 1.2);
      targetCtx.fillRect(-rw / 2, -rh / 2, rw, rh);
      targetCtx.restore();
    } else if (shape === "drop") {
      targetCtx.fillStyle = q.color || "#38bdf8";
      targetCtx.beginPath();
      targetCtx.arc(px(q.x), py(q.y), ps(sz * 0.4), 0, Math.PI * 2);
      targetCtx.fill();
    } else {
      // Fallback circle
      targetCtx.fillStyle = q.color || p.goldBright;
      targetCtx.beginPath();
      targetCtx.arc(px(q.x), py(q.y), ps(Math.max(2, sz * 0.4)), 0, Math.PI * 2);
      targetCtx.fill();
    }

    targetCtx.restore();
  }

  if (s.announcement) {
    const a = s.announcement, t = (now - a.at) / a.durationMs;
    if (t < 1) {
      const y = 380 - Math.sin(Math.min(1, t) * Math.PI) * 16;
      targetCtx.fillStyle = p.theme === "light" ? "rgba(255, 255, 255, 0.96)" : "rgba(10, 20, 38, 0.96)";
      rr(targetCtx, 105, y, 870, 130, 22);
      targetCtx.fill();
      targetCtx.strokeStyle = p.goldBright;
      targetCtx.lineWidth = ps(2);
      rr(targetCtx, 105, y, 870, 130, 22);
      targetCtx.stroke();
      textC(targetCtx, a.name, 540, y + 42, 16, p.goldBright, 800, "center");
      textC(targetCtx, a.text, 540, y + 88, 24, p.text, 800, "center");
    }
  }
}

function resetCanvasState(c) {
  try { c.setTransform(1, 0, 0, 1, 0, 0); } catch {}
  c.globalAlpha = 1;
  c.globalCompositeOperation = "source-over";
  c.shadowBlur = 0;
  c.shadowOffsetX = 0;
  c.shadowOffsetY = 0;
}

function transitionDirection(from, to) {
  const a = SCREEN_ORDER.indexOf(from);
  const b = SCREEN_ORDER.indexOf(to);
  return b >= a ? 1 : -1;
}

function drawMainFrame(now, targetCtx = ctx) {
  const s = interactiveState();
  if (!s.screenTransition) tickScreens(now, config.screenIntervalMs);

  const screen = s.screen;
  const tr = getScreenTransition(now);
  const p = palette();

  resetCanvasState(targetCtx);

  // 1. Persistent background
  drawBackground(targetCtx, p, now);

  // 2. Persistent live top bar (with viewer count below LIVE, live clock, 5-bar EQ, theme toggle)
  drawTopBar(targetCtx, p, now);

  // 3. Persistent hero (Eye, Bigg Boss 3D title, subtitle pill, call-to-action, navigation tabs)
  drawHero(targetCtx, p, now, screenLabel(screen), tr);

  // 4. Content Area (Between tabs and bottom) with 3D depth scale-zoom & laser streak
  if (tr && tr.from !== tr.to) {
    const t = clamp(tr.t, 0, 1);
    // Smooth zero-jerk cosine ease
    const eased = 0.5 * (1 - Math.cos(Math.PI * t));
    const dir = transitionDirection(tr.from, tr.to);

    // Dynamic per-frame rendering of both screens so live elements continue updating
    oldCtx.clearRect(0, 0, W, H);
    drawScreenContent(tr.from, oldCtx, p, now);

    newCtx.clearRect(0, 0, W, H);
    drawScreenContent(tr.to, newCtx, p, now);

    const clipY = py(412);
    const clipH = py(1510) - clipY;
    const midY = clipY + clipH / 2;

    // Outgoing screen: gentle scale-down (1.0 -> 0.92) + horizontal slide + fade
    const oldScale = 1.0 - eased * 0.08;
    const oldSlideX = -dir * W * eased * 0.70;
    targetCtx.save();
    targetCtx.beginPath();
    targetCtx.rect(0, clipY, W, clipH);
    targetCtx.clip();
    targetCtx.globalAlpha = Math.max(0, 1 - eased * 1.18);
    targetCtx.translate(W / 2 + oldSlideX, midY);
    targetCtx.scale(oldScale, oldScale);
    targetCtx.translate(-W / 2, -midY);
    targetCtx.drawImage(oldSceneCanvas, 0, 0);
    targetCtx.restore();

    // Incoming screen: gentle scale-up (0.92 -> 1.0) + horizontal glide + fade
    const newScale = 0.92 + eased * 0.08;
    const newSlideX = dir * W * (1 - eased) * 0.70;
    targetCtx.save();
    targetCtx.beginPath();
    targetCtx.rect(0, clipY, W, clipH);
    targetCtx.clip();
    targetCtx.globalAlpha = Math.min(1, eased * 1.25);
    targetCtx.translate(W / 2 + newSlideX, midY);
    targetCtx.scale(newScale, newScale);
    targetCtx.translate(-W / 2, -midY);
    targetCtx.drawImage(newSceneCanvas, 0, 0);
    targetCtx.restore();

    // Traveling golden laser beam / reveal streak across the transition boundary
    const beamProgress = dir > 0 ? eased : (1 - eased);
    const beamX = beamProgress * W;
    const beamW = 75;
    targetCtx.save();
    targetCtx.beginPath();
    targetCtx.rect(0, clipY, W, clipH);
    targetCtx.clip();
    const bGrad = targetCtx.createLinearGradient(beamX - beamW, 0, beamX + beamW, 0);
    bGrad.addColorStop(0, "rgba(251, 191, 36, 0)");
    bGrad.addColorStop(0.5, `rgba(255, 255, 255, ${0.55 * Math.sin(t * Math.PI)})`);
    bGrad.addColorStop(1, "rgba(251, 191, 36, 0)");
    targetCtx.fillStyle = bGrad;
    targetCtx.fillRect(beamX - beamW, clipY, beamW * 2, clipH);
    targetCtx.restore();
  } else {
    drawScreenContent(screen, targetCtx, p, now);
  }

  // 5. Persistent anchored footer ticker at bottom
  drawFooter(targetCtx, p);

  // 6. Interactive overlays and particles on top
  drawInteractive(targetCtx, p, now);
  resetCanvasState(targetCtx);
}

export async function initRenderer() {
  await loadBackground();
  if (contestantImages.size === 0) {
    for (let no = 1; no <= 17; no++) {
      try {
        const buf = await readFile(`assets/contestants/${no}.jpg`);
        const img = await loadImage(buf);
        contestantImages.set(no, img);
      } catch {}
    }
  }
  startFrameServer();
  lastDraw = Date.now();
  drawMainFrame(Date.now());
  try {
    publishFrame(canvas.toBuffer("image/jpeg", config.jpegQuality));
  } catch {}
}

const PIPELINE_DEPTH = 2;
const pipelineCanvases = [canvas, createCanvas(W, H)];
const pipelineCtxs = [ctx, pipelineCanvases[1].getContext("2d", { alpha: false })];
let pipelineIdx = 0;
let pendingPublish = Promise.resolve();

export async function startRenderer() {
  await initRenderer();
  running = true;
  return await new Promise(resolve => {
    const frameInterval = 1000 / config.renderFps;
    let next = performance.now();
    let isDrawing = false;

    const tick = () => {
      if (!running) return resolve();
      const now = performance.now();

      if (now >= next && !isDrawing) {
        isDrawing = true;
        const curCanvas = pipelineCanvases[pipelineIdx];
        const curCtx = pipelineCtxs[pipelineIdx];
        pipelineIdx = (pipelineIdx + 1) % PIPELINE_DEPTH;

        drawMainFrame(Date.now(), curCtx);

        // Async parallel hardware-threaded JPEG encoding
        const encodePromise = curCanvas.encode("jpeg", config.jpegQuality);
        pendingPublish = pendingPublish
          .then(() => encodePromise)
          .then(buf => {
            publishFrame(buf);
            runtime.renderer.frames++;
            runtime.renderer.lastFrameAt = Date.now();
          })
          .catch(err => {
            runtime.renderer.dropped++;
          });

        lastDraw = Date.now();
        isDrawing = false;

        next += frameInterval;
        if (next < now - frameInterval) {
          next = now;
        }
      }

      const diff = next - performance.now();
      if (diff >= 16) {
        setTimeout(tick, Math.max(1, Math.floor(diff - 12)));
      } else {
        setImmediate(tick);
      }
    };
    tick();
  });
}

export async function stopRenderer() {
  running = false;
  stopFrameServer();
}

export { drawScene, drawMainFrame, canvas, ctx, drawBackground, drawTopBar, drawHero, drawVoteScreen, drawVoteRow, drawBottomStats, drawFooter, palette };
