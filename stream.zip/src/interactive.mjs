import { emit } from './events.mjs';
import { runtime } from './runtime.mjs';
import { config } from './config.mjs';

const MAX_EVENTS = 120;
const MAX_PARTICLES = 450;
const USER_WINDOW_MS = 10000;
const USER_MAX_EVENTS = 30;
const GLOBAL_WINDOW_MS = 1000;
const GLOBAL_MAX_EVENTS = 120;
const SCREEN_NAMES = ['main', 'race', 'stats', 'supporters', 'menu', 'events'];
const SCREEN_LABELS = { main: 'LIVE VOTING', race: 'RANK RACE', stats: 'LIVE STATS', supporters: 'TOP SUPPORTERS', menu: 'STREAM MENU', events: 'LIVE EVENTS' };
const userBuckets = new Map();
const globalTimes = [];

const clean = v => String(v ?? '').trim().slice(0, 80);
const clamp = (v,a,b)=>Math.max(a,Math.min(b,v));

function ensure(){
  if(!runtime.interactive) runtime.interactive={events:[],particles:[],announcement:null,combo:new Map(),musicEnabled:true,topViewers:new Map(),lastEventAt:0,screen:'main',screenAuto:true,screenIndex:0,screenTransition:null,screenOverrideUntil:0,screenOverride:'events',selectedContestant:0,menuUntil:0};
  const s=runtime.interactive;
  s.screen ??= 'main'; s.screenAuto ??= true; s.screenIndex ??= SCREEN_NAMES.indexOf(s.screen)||0;
  s.screenTransition ??= null; s.screenOverrideUntil ??= 0; s.screenOverride ??= 'events'; s.selectedContestant ??= 0; s.menuUntil ??= 0;
  return s;
}

export function interactiveState(){ return ensure(); }

function allow(userId, type='event') {
  const now=Date.now();
  const bucketKey=`${userId||'anon'}:${type}`;
  const u=userBuckets.get(bucketKey)||[];
  while(u.length && now-u[0]>USER_WINDOW_MS) u.shift();
  if(u.length>=USER_MAX_EVENTS) {
    console.warn(`[interactive] rate-limit reached for ${bucketKey} (${u.length}/${USER_MAX_EVENTS})`);
    return false;
  }
  u.push(now); userBuckets.set(bucketKey,u);
  while(globalTimes.length && now-globalTimes[0]>GLOBAL_WINDOW_MS) globalTimes.shift();
  if(globalTimes.length>=GLOBAL_MAX_EVENTS) {
    console.warn(`[interactive] global rate-limit reached (${globalTimes.length}/${GLOBAL_MAX_EVENTS})`);
    return false;
  }
  globalTimes.push(now);
  return true;
}

function addEvent(event){
  const s=ensure();
  const e={id:`${Date.now()}-${Math.random().toString(36).slice(2,8)}`,createdAt:Date.now(),durationMs:Math.max(600,event.durationMs||3200),...event};
  s.events.push(e); if(s.events.length>MAX_EVENTS) s.events.splice(0,s.events.length-MAX_EVENTS);
  s.lastEventAt=e.createdAt;
  if(['milestone','battle','overtake'].includes(e.type)) { s.screenOverride='events'; s.screenOverrideUntil=e.createdAt+Math.min(9000,e.durationMs+1500); }
  emit('interactive',e);
  return e;
}

export function viewerEvent({userId,name,type,contestant=0,emoji='',payload={},durationMs=0}){
  if(!allow(userId,type)) return false;
  const n=clean(name)||'Viewer';
  const s=ensure();
  const key=String(userId||n);
  s.topViewers.set(key,{id:key,name:n,interactions:(s.topViewers.get(key)?.interactions||0)+1,lastAt:Date.now()});
  if(Number(contestant)>0) s.selectedContestant=Number(contestant);
  addEvent({type,userId:key,name:n,contestant:Number(contestant)||0,emoji:emoji||'',payload,durationMs});
  return true;
}

export function voteEvent({userId,name,contestant,candidateName}){
  const n=clean(name)||'Viewer';
  const s=ensure();
  const key=String(userId||n);
  const old=s.combo.get(Number(contestant));
  const now=Date.now();
  const combo=old && now-old.at<6000 ? old.count+1 : 1;
  s.combo.set(Number(contestant),{count:combo,at:now,name:candidateName});
  s.topViewers.set(key,{id:key,name:n,interactions:(s.topViewers.get(key)?.interactions||0)+1,lastAt:now});
  s.selectedContestant=Number(contestant);
  addEvent({type:'vote',userId:key,name:n,contestant:Number(contestant),candidateName,durationMs:3800,combo});
  if(combo>=3) addEvent({type:'combo',contestant:Number(contestant),candidateName,count:combo,durationMs:2500});
  emit('vote-announcement',{name:n,candidateName,contestant:Number(contestant)});
}

export function prune(now=Date.now()){
  const s=ensure();
  s.events=s.events.filter(e=>now-e.createdAt<e.durationMs);
  for(const [k,v] of s.combo) if(now-v.at>9000) s.combo.delete(k);
  if(s.announcement && now-s.announcement.at>s.announcement.durationMs) s.announcement=null;
  if(s.particles.length) s.particles=s.particles.filter(q=>(now-(q.born||now))<=q.max);
  if(s.particles.length>MAX_PARTICLES) s.particles.splice(0,s.particles.length-MAX_PARTICLES);
  for(const [k,v] of s.topViewers) if(now-v.lastAt>1000*60*60*24*7) s.topViewers.delete(k);
  if(userBuckets.size>5000){ for(const [k,v] of userBuckets) if(!v.length || now-v[v.length-1]>USER_WINDOW_MS*4) userBuckets.delete(k); }
}

export function getEvents(now=Date.now()){prune(now);return ensure().events;}
export function getTopViewers(){return [...ensure().topViewers.values()].sort((a,b)=>(b.interactions-a.interactions)||(b.lastAt-a.lastAt)).slice(0,5);}
export function setAnnouncement(text,name='Bigg Boss',durationMs=3800){ensure().announcement={text:String(text).slice(0,180),name:String(name).slice(0,60),at:Date.now(),durationMs};}
export function setMusicEnabled(v){ensure().musicEnabled=Boolean(v); emit('music',{enabled:Boolean(v)});}
export function isMusicEnabled(){return ensure().musicEnabled!==false;}

export function milestone(total){
  const milestones=[1000,5000,10000,25000,50000,100000,250000,500000,1000000];
  const m=milestones.find(x=>total===x);
  if(m) addEvent({type:'milestone',value:m,durationMs:5200});
}

export function normalizeScreen(v){
  const x=String(v||'').toLowerCase().trim();
  if(['vote','voting','home','main','1'].includes(x)) return 'main';
  if(['race','rank','ranking','leaderboard','2'].includes(x)) return 'race';
  if(['stat','stats','statistics','analytics','3'].includes(x)) return 'stats';
  if(['support','supporters','top','mvp','4'].includes(x)) return 'supporters';
  if(['menu','guide','screens','help','5'].includes(x)) return 'menu';
  if(['event','events','interactive','6'].includes(x)) return 'events';
  return SCREEN_NAMES.includes(x)?x:null;
}

export function screenLabel(screen){return SCREEN_LABELS[normalizeScreen(screen)||'main'];}

export function setScreen(screen,{manual=true,overrideMs=0,contestant=0,userId=null}={}){
  const s=ensure();
  const next=normalizeScreen(screen);
  if(!next) return false;
  if(manual && userId && !allow(userId,'screen')) return false;
  const current=s.screen;
  if(current===next){
    if(contestant) s.selectedContestant=Number(contestant);
    if(manual) s.screenAuto=false;
    return true;
  }
  s.screenTransition={from:current,to:next,startedAt:Date.now(),durationMs:config.screenTransitionMs};
  s.screen=next;
  s.screenIndex=SCREEN_NAMES.indexOf(next);
  if(contestant) s.selectedContestant=Number(contestant);
  if(manual) s.screenAuto=false;
  if(overrideMs>0) s.screenOverrideUntil=Date.now()+overrideMs;
  emit('screen',{screen:next,manual});
  return true;
}

export function nextScreen(userId=null){
  const s=ensure();
  return setScreen(SCREEN_NAMES[(s.screenIndex+1)%SCREEN_NAMES.length],{manual:true,userId});
}
export function previousScreen(userId=null){
  const s=ensure();
  return setScreen(SCREEN_NAMES[(s.screenIndex-1+SCREEN_NAMES.length)%SCREEN_NAMES.length],{manual:true,userId});
}
export function setScreenAuto(enabled,userId=null){
  if(userId&&!allow(userId,'screen-auto')) return ensure().screenAuto!==false;
  const s=ensure(); s.screenAuto=Boolean(enabled); if(enabled) s.screenIndex=SCREEN_NAMES.indexOf(s.screen)||0;
  emit('screen-auto',{enabled:s.screenAuto}); return s.screenAuto;
}
export function isScreenAuto(){return ensure().screenAuto!==false;}
export function getScreenNames(){return [...SCREEN_NAMES];}

export function tickScreens(now=Date.now(),intervalMs=20000){
  const s=ensure();
  if(s.screenOverrideUntil && now>=s.screenOverrideUntil) s.screenOverrideUntil=0;
  if(!s.screenAuto || s.screenOverrideUntil>now) return s.screen;
  if(!s._nextAutoAt) s._nextAutoAt=now+Math.max(5000,intervalMs);
  if(now>=s._nextAutoAt){
    const next=SCREEN_NAMES[(s.screenIndex+1)%SCREEN_NAMES.length];
    setScreen(next,{manual:false});
    s._nextAutoAt=now+Math.max(5000,intervalMs);
  }
  return s.screen;
}

export function getScreenTransition(now=Date.now()){
  const s=ensure();
  const tr=s.screenTransition;
  if(!tr) return null;
  const t=clamp((now-tr.startedAt)/tr.durationMs,0,1);
  if(t>=1){s.screenTransition=null;return null;}
  return {...tr,t};
}

export function getSelectedContestant(){ return ensure().selectedContestant || 0; }
export function setMenu(durationMs=7000,userId=null){
  if(userId&&!allow(userId,'menu'))return false;
  ensure().menuUntil=Date.now()+Math.max(1000,durationMs);
  setScreen('menu', { manual: true, userId });
  emit('menu',{});
  return true;
}
export function isMenuVisible(now=Date.now()){return ensure().menuUntil>now;}
