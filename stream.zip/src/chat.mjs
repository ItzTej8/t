import { Masterchat, stringify } from "@stu43005/masterchat";
import { config } from "./config.mjs";
import { addChat, acceptVote, saveState, setOwner, state, stats, setVoting, setTheme } from "./state.mjs";
import { runtime } from "./runtime.mjs";
import { viewerEvent, voteEvent, setAnnouncement, setMusicEnabled, setScreen, nextScreen, previousScreen, setScreenAuto, setMenu } from "./interactive.mjs";
import { setBgMusicVolume, getBgMusicVolume } from "./frame-server.mjs";

const sleep = ms => new Promise(r => setTimeout(r, ms));
const clean = value => String(value ?? "").replace(/[\u200b\u200c\u200d]/g, "").replace(/\s+/g, " ").trim();
const idOf = a => a?.authorChannelId || a?.channelId || a?.author?.channelId || a?.author?.id || a?.authorExternalChannelId || a?.user?.channelId || a?.user?.id || null;
const ownerOf = a => Boolean(a?.isChatOwner || a?.isOwner || a?.authorIsChatOwner || a?.author?.isChatOwner || a?.author?.isOwner);
const modOf = a => Boolean(a?.isChatModerator || a?.isModerator || a?.authorIsChatModerator || a?.author?.isChatModerator || a?.author?.isModerator);

// Flexible vote regex matches !vote 2, !vote2, vote 2, vote2, !vote #2, !vote 2 ❤️, etc.
const voteRe = /^\s*!?vote(?:\s+contestant)?\s*#?\s*(\d+)/i;

function textFromRuns(value) {
  if (!value) return "";
  if (typeof value === "string") return value;
  if (Array.isArray(value)) return value.map(textFromRuns).join("");
  if (typeof value === "object") {
    if (typeof value.simpleText === "string") return value.simpleText;
    if (typeof value.text === "string") return value.text;
    if (Array.isArray(value.runs)) return value.runs.map(r => r?.text || r?.emoji?.emojiId || "").join("");
  }
  return "";
}

function findRenderer(value) {
  if (!value || typeof value !== "object") return null;
  if (value.liveChatTextMessageRenderer) return value.liveChatTextMessageRenderer;
  if (value.addChatItemAction?.item?.liveChatTextMessageRenderer) return value.addChatItemAction.item.liveChatTextMessageRenderer;
  if (Array.isArray(value)) {
    for (const v of value) { const found = findRenderer(v); if (found) return found; }
  } else {
    for (const v of Object.values(value)) {
      if (v && typeof v === "object") { const found = findRenderer(v); if (found) return found; }
    }
  }
  return null;
}

function stringifySafe(value) {
  const direct = textFromRuns(value);
  if (direct) return direct;
  try { return clean(stringify(value)); } catch {}
  return "";
}

function extractChat(action) {
  const renderer = findRenderer(action);
  const candidates = [renderer, action?.addChatItemAction?.item, action?.item, action].filter(Boolean);
  const message = clean(renderer ? stringifySafe(renderer.message) : candidates.map(c => stringifySafe(c.message ?? c.messageRuns ?? c.text ?? c.messageText)).find(Boolean) || "");
  const author = clean(renderer?.authorName ? textFromRuns(renderer.authorName) : candidates.map(c => textFromRuns(c.authorName) || c.author?.name || c.user?.name || c.author?.displayName).find(Boolean) || "Viewer");
  const id = renderer?.authorExternalChannelId || renderer?.authorChannelId || candidates.map(idOf).find(Boolean) || null;
  const owner = candidates.some(ownerOf);
  const mod = candidates.some(modOf);
  const messageId = renderer?.id || candidates.map(c => c.id || c.messageId || c.chatId).find(Boolean) || null;
  return { message, author, id: id ? String(id) : null, owner, mod, messageId };
}

function fallbackVoteId(action, author, message, messageId) {
  const raw = `${messageId || ""}\u0000${author}\u0000${message}\u0000${action?.timestampUsec || Date.now()}`;
  let h = 2166136261;
  for (let i = 0; i < raw.length; i++) { h ^= raw.charCodeAt(i); h = Math.imul(h, 16777619); }
  return `anon:${(h >>> 0).toString(16)}:${Date.now()}`;
}

function admin(id, owner, mod) { return Boolean(id && (owner || mod || config.adminChannelIds.includes(String(id)))); }

async function resolveLiveVideoId(channelId) {
  if (!channelId) return null;
  try {
    const res = await fetch(`https://www.youtube.com/channel/${channelId}/live`, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9"
      }
    });
    const html = await res.text();
    const canonicalMatch = html.match(/<link\s+rel="canonical"\s+href="https:\/\/www\.youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})"/i);
    const videoIdMatch = html.match(/"videoId":"([a-zA-Z0-9_-]{11})"/);
    const isLive = html.includes('"isLive":true') || html.includes('"isLiveBroadcast":true');
    const id = canonicalMatch?.[1] || videoIdMatch?.[1];
    if (id && isLive) return id;
  } catch {}
  return null;
}

async function pollViewerCount(videoId, signal) {
  // Poll YouTube's public API for live viewer count every 60 seconds
  while (!signal.aborted) {
    try {
      const url = `https://www.youtube.com/watch?v=${videoId}`;
      const res = await fetch(url, {
        headers: { "User-Agent": "Mozilla/5.0", "Accept-Language": "en-US" }
      });
      const html = await res.text();
      // YouTube embeds viewCount in the page as JSON
      const m = html.match(/"viewCount":"(\d+)"/) ||
                html.match(/"concurrentViewers":"(\d+)"/) ||
                html.match(/"visitorData":"[^"]*"[^}]*"viewCount":"(\d+)"/);
      if (m && Number(m[1]) > 0) {
        runtime.chat.viewerCount = Number(m[1]);
      }
    } catch { /* ignore fetch errors */ }
    // Wait 60 seconds between polls
    await new Promise(r => {
      const t = setTimeout(r, 60000);
      signal.addEventListener("abort", () => { clearTimeout(t); r(); }, { once: true });
    });
  }
}

export function startChatLoop({ signal }) {
  return (async () => {
    let delay = 5000;
    let activeVideoId = config.videoId || null;
    let viewerPollStarted = false;

    while (!signal.aborted) {
      if (!activeVideoId) {
        activeVideoId = await resolveLiveVideoId(config.channelId);
        if (!activeVideoId) {
          runtime.chat.status = "unconfigured";
          console.log(`[chat] no videoId configured; checking channel ${config.channelId} for live stream in 15s`);
          await sleep(15000);
          continue;
        }
      }

      // Start background viewer count poller once we have a video ID
      if (!viewerPollStarted) {
        viewerPollStarted = true;
        pollViewerCount(activeVideoId, signal).catch(() => {});
      }

      let mc = null;
      runtime.chat.status = "connecting";
      try {
        mc = await Masterchat.init(activeVideoId);
        if (signal.aborted) break;

        if (!mc.isLive) {
          const discovered = await resolveLiveVideoId(config.channelId);
          if (discovered && discovered !== activeVideoId) {
            console.log(`[chat] video ${activeVideoId} is not live; auto-detected active live stream: ${discovered}`);
            activeVideoId = discovered;
            try { mc?.stop?.(); } catch {}
            continue;
          }
          runtime.chat.status = "waiting";
          runtime.chat.lastError = `Video ${activeVideoId} is not live yet`;
          console.log(`[chat] video ${activeVideoId} is not live yet; checking again in 30s`);
          await sleep(30000);
          continue;
        }

        const iterable = mc?.iterate?.() || mc?.iter?.();
        if (!iterable?.[Symbol.asyncIterator]) throw new Error("Masterchat chat iterator is unavailable");

        runtime.chat.status = "connected";
        runtime.chat.lastError = null;
        delay = 3000;
        console.log(`[chat] connected to live chat for ${activeVideoId} ("${mc.title || "Live"}") — vote parser armed`);

        for await (const batch of iterable) {
          if (signal.aborted) break;

          // Extract live viewer count from batch metadata (Masterchat exposes this)
          const vc = batch?.viewerCount ?? batch?.liveViewerCount ?? batch?.videoDetails?.viewCount;
          if (typeof vc === "number" && vc > 0) {
            runtime.chat.viewerCount = vc;
          } else if (typeof vc === "string" && Number(vc) > 0) {
            runtime.chat.viewerCount = Number(vc);
          }

          // Unpack action items from the batch yielded by Masterchat
          const actions = Array.isArray(batch?.actions) ? batch.actions : (batch ? [batch] : []);
          for (const action of actions) {
            if (!action) continue;
            try {
              const type = action?.type || action?.actionType;
              const isChat = type === "addChatItemAction" || type === "addSuperChatItemAction" || action.liveChatTextMessageRenderer || action.addChatItemAction;
              if (type && !isChat) continue;

              let author = action.authorName || action.author?.name;
              let message = typeof action.message === "string" ? action.message : (action.message ? stringifySafe(action.message) : "");
              let id = action.authorChannelId || action.author?.channelId || action.authorExternalChannelId;
              let owner = Boolean(action.isOwner || action.isChatOwner);
              let mod = Boolean(action.isModerator || action.isChatModerator);

              // Fallback to raw extractor if needed
              if (!message || !author) {
                const extracted = extractChat(action);
                if (!message) message = extracted.message;
                if (!author) author = extracted.author;
                if (!id) id = extracted.id;
                if (!owner) owner = extracted.owner;
                if (!mod) mod = extracted.mod;
              }

              message = clean(message);
              author = clean(author || "Viewer");
              if (!message) continue;
              id = id ? String(id) : fallbackVoteId(action, author, message, action.id);

              runtime.chat.lastEventAt = Date.now();
              if (config.adminChannelIds.includes(String(id))) setOwner(id, author);
              addChat(author, message);

              const voteMatch = message.match(voteRe);
              if (voteMatch) {
                const contestant = parseInt(voteMatch[1], 10);
                runtime.chat.lastVoteCandidate = { author, contestant, at: Date.now() };
                if (Number.isInteger(contestant) && contestant >= 1 && contestant <= config.contestants.length) {
                  if (acceptVote(id, contestant, author)) {
                    const cName = config.contestants[contestant - 1]?.displayName || config.contestants[contestant - 1]?.name || `#${contestant}`;
                    console.log(`[vote] ${author} voted for #${contestant} (${cName}) (+1, unlimited)`);
                    voteEvent({ userId:id, name:author, contestant, candidateName:cName });
                    setAnnouncement(`${author} has voted for ${cName}.`, "LIVE VOTE", 3600);
                    void saveState();
                  } else {
                    console.warn(`[vote] rejected ${author} -> #${contestant}; votingOpen=${state.votingOpen}`);
                  }
                  continue;
                }
                console.warn(`[vote] invalid contestant number ${contestant}: "${message}"`);
                continue;
              }

              function resolveContestant(q) {
                if (!q) return null;
                const num = parseInt(q, 10);
                if (Number.isInteger(num) && num >= 1 && num <= config.contestants.length) return num;
                const cleanQ = String(q).toLowerCase().replace(/[^a-z0-9]/g, "");
                for (const cand of config.contestants) {
                  const d = (cand.displayName || "").toLowerCase().replace(/[^a-z0-9]/g, "");
                  const n = (cand.name || "").toLowerCase().replace(/[^a-z0-9]/g, "");
                  if (d.includes(cleanQ) || n.includes(cleanQ) || (cleanQ.length >= 3 && cleanQ.includes(d))) return cand.no;
                }
                return null;
              }

              // Flexible command parsing: supports !cmd, /cmd, or bare keyword (e.g. drop, bomb, vol, wheel)
              const trimmed = message.trim();
              const parts = trimmed.split(/\s+/);
              let cmdToken = (parts[0] || "").toLowerCase();
              if (cmdToken.startsWith("!") || cmdToken.startsWith("/")) {
                cmdToken = cmdToken.slice(1);
              }
              const arg = (parts[1] || "").toLowerCase();
              const rawArg = parts.slice(1).join(" ");
              const target = resolveContestant(parts[1]);
              const themePublic = config.publicThemeCommands || admin(id, owner, mod);
              const musicPublic = config.publicMusicCommands || admin(id, owner, mod);

              const KNOWN_COMMANDS = new Set([
                "help", "theme", "dark", "light", "music", "vol", "volume", "louder", "quieter", "softer",
                "screen", "next", "prev", "previous", "auto", "menu", "profile",
                "drop", "boom", "bomb", "nuke", "heart", "rain", "gift", "crown", "zap", "fire", "flame", "cheer",
                "star", "support", "target", "battle", "vs", "dice", "coin", "slot", "wheel", "spin",
                "hype", "confetti", "party", "fireworks", "fw", "lightning", "zap2", "shoutout",
                "random", "mvp", "event", "close", "open", "status"
              ]);

              const isExplicitCmd = message.startsWith("!") || message.startsWith("/");
              if (!isExplicitCmd && !KNOWN_COMMANDS.has(cmdToken)) continue;

              if (cmdToken === "help") {
                console.log(`[chat] ${author}: ${config.voteCommand} 1 ... ${config.contestants.length} | !drop <1-17/emoji> | !vol <1-100> | !wheel | !dice | !coin | !bomb | !screen <name> | !theme dark/light`);
              }
              else if (themePublic && (cmdToken === "dark" || (cmdToken === "theme" && arg === "dark"))) {
                setTheme("dark"); void saveState(); console.log(`[theme] ${author} switched stream to DARK`);
                setAnnouncement(`${author} switched stream to DARK mode 🌙`, "THEME", 2500);
              }
              else if (themePublic && (cmdToken === "light" || (cmdToken === "theme" && arg === "light"))) {
                setTheme("light"); void saveState(); console.log(`[theme] ${author} switched stream to LIGHT`);
                setAnnouncement(`${author} switched stream to LIGHT mode ☀️`, "THEME", 2500);
              }
              else if (musicPublic && cmdToken === "music" && (arg === "off" || arg === "stop" || arg === "mute")) {
                setMusicEnabled(false); console.log(`[music] ${author} requested music OFF`);
                setAnnouncement(`🔇 Music turned OFF by ${author}`, "AUDIO", 2500);
              }
              else if (musicPublic && cmdToken === "music" && (arg === "on" || arg === "start" || arg === "play")) {
                setMusicEnabled(true); console.log(`[music] ${author} requested music ON`);
                setAnnouncement(`🔊 Music turned ON by ${author}`, "AUDIO", 2500);
              }
              // Chat volume controls: !vol 75, !volume 50, !music 80, !music vol 90
              else if (musicPublic && (cmdToken === "vol" || cmdToken === "volume" || (cmdToken === "music" && (arg === "vol" || arg === "volume" || /^\d+$/.test(arg))))) {
                let vStr = arg;
                if (cmdToken === "music" && (arg === "vol" || arg === "volume")) vStr = (parts[2] || "").toLowerCase();
                const pct = parseInt(vStr, 10);
                if (!isNaN(pct)) {
                  const targetVol = Math.max(0.05, Math.min(1.0, pct / 100));
                  setBgMusicVolume(targetVol);
                  const displayPct = Math.round(targetVol * 100);
                  setAnnouncement(`🔊 ${author} set music volume to ${displayPct}%`, "AUDIO LEVEL", 3000);
                  console.log(`[audio] ${author} set music volume to ${displayPct}%`);
                } else {
                  const cur = Math.round(getBgMusicVolume() * 100);
                  setAnnouncement(`🔊 Music volume: ${cur}% (Use !vol 1-100)`, "AUDIO LEVEL", 3000);
                }
              }
              else if (musicPublic && (cmdToken === "louder" || (cmdToken === "music" && arg === "louder"))) {
                const cur = getBgMusicVolume();
                const next = Math.min(1.0, cur + 0.15);
                setBgMusicVolume(next);
                const displayPct = Math.round(next * 100);
                setAnnouncement(`🔊 ${author} turned volume up to ${displayPct}%`, "AUDIO LEVEL", 3000);
              }
              else if (musicPublic && (cmdToken === "quieter" || cmdToken === "softer" || (cmdToken === "music" && (arg === "quieter" || arg === "softer")))) {
                const cur = getBgMusicVolume();
                const next = Math.max(0.05, cur - 0.15);
                setBgMusicVolume(next);
                const displayPct = Math.round(next * 100);
                setAnnouncement(`🔉 ${author} turned volume down to ${displayPct}%`, "AUDIO LEVEL", 3000);
              }
              else if (config.publicScreenCommands && cmdToken === "screen") {
                const screenArg = arg || "main";
                if (screenArg === "profile") {
                  const n = resolveContestant(parts[2]);
                  if (n) {
                    setScreen("main", { manual: true, contestant: n, userId: id });
                    viewerEvent({ userId: id, name: author, type: "support", contestant: n });
                    setAnnouncement(`${author} opened ${config.contestants[n - 1]?.displayName || `Contestant ${n}`} profile.`, "SCREEN", 3000);
                  }
                } else if (setScreen(screenArg, { manual: true, userId: id })) {
                  setAnnouncement(`${author} switched to ${screenArg.toUpperCase()} screen.`, "SCREEN", 2400);
                  console.log(`[screen] ${author} -> ${screenArg}`);
                }
              }
              else if (config.publicScreenCommands && cmdToken === "next") {
                nextScreen(id);
                setAnnouncement(`${author} moved to next screen ⏩`, "SCREEN", 2200);
              }
              else if (config.publicScreenCommands && (cmdToken === "prev" || cmdToken === "previous")) {
                previousScreen(id);
                setAnnouncement(`${author} moved to previous screen ⏪`, "SCREEN", 2200);
              }
              else if (config.publicScreenCommands && cmdToken === "auto" && (arg === "on" || arg === "off")) {
                const on = setScreenAuto(arg === "on", id);
                setAnnouncement(`Screen auto-rotation ${on ? "enabled" : "disabled"}.`, "SCREEN", 2600);
              }
              else if (config.publicScreenCommands && cmdToken === "menu") {
                setMenu(7000, id);
                setAnnouncement(`${author} opened live screen menu.`, "SCREEN MENU", 2600);
              }
              else if (config.publicScreenCommands && cmdToken === "profile") {
                const n = resolveContestant(parts[1]);
                if (n) {
                  setScreen("main", { manual: true, contestant: n, userId: id });
                  viewerEvent({ userId: id, name: author, type: "support", contestant: n });
                  setAnnouncement(`${author} opened ${config.contestants[n - 1]?.displayName || `Contestant ${n}`} profile.`, "CONTESTANT PROFILE", 3000);
                }
              }
              // !drop command: handles contestants (e.g. !drop 8), emojis (!drop 🎈), or custom text
              else if (cmdToken === "drop") {
                const contestantTarget = resolveContestant(parts[1]);
                let em = rawArg || "🎈";
                let contestantNo = contestantTarget || 0;
                let cName = "";
                if (contestantNo > 0) {
                  cName = config.contestants[contestantNo - 1]?.displayName || `#${contestantNo}`;
                  em = "🪂";
                }
                if (viewerEvent({
                  userId: id,
                  name: author,
                  type: "drop",
                  contestant: contestantNo,
                  emoji: em,
                  payload: { emoji: em, contestant: contestantNo, candidateName: cName },
                  durationMs: 4800
                })) {
                  if (contestantNo > 0) {
                    setAnnouncement(`🪂 ${author} called in a Supply Drop for ${cName}!`, "AIRDROP", 3600);
                    console.log(`[interactive] ${author} called in a contestant drop for #${contestantNo} (${cName})`);
                  } else {
                    setAnnouncement(`🎈 ${author} released a balloon airdrop!`, "AIRDROP", 3200);
                    console.log(`[interactive] ${author} dropped ${em}`);
                  }
                }
              }
              else if (cmdToken === "boom") {
                if (viewerEvent({ userId: id, name: author, type: "boom" })) console.log(`[interactive] ${author} BOOM`);
              }
              else if (cmdToken === "bomb" || cmdToken === "nuke") {
                if (viewerEvent({ userId: id, name: author, type: "bomb", durationMs: 4200 })) {
                  setAnnouncement(`💣 ${author} DETONATED A SCREEN BOMB!`, "BOMB EXPLOSION", 3500);
                  console.log(`[interactive] ${author} detonated bomb`);
                }
              }
              else if (cmdToken === "heart") {
                if (viewerEvent({ userId: id, name: author, type: "heart", emoji: "❤️" })) {
                  setAnnouncement(`❤️ ${author} sent a shower of love!`, "LOVE SHOWER", 3000);
                  console.log(`[interactive] ${author} heart storm`);
                }
              }
              else if (cmdToken === "rain") {
                const em = rawArg || "❤️";
                if (viewerEvent({ userId: id, name: author, type: "rain", emoji: em, payload: { emoji: em } })) {
                  setAnnouncement(`🌧️ ${author} started an emoji rain!`, "EMOJI RAIN", 3000);
                  console.log(`[interactive] ${author} emoji rain ${em}`);
                }
              }
              else if (cmdToken === "gift") {
                if (viewerEvent({ userId: id, name: author, type: "gift", emoji: "🎁" })) {
                  setAnnouncement(`🎁 ${author} sent a Mystery Gift!`, "MYSTERY GIFT", 3200);
                  console.log(`[interactive] ${author} mystery gift`);
                }
              }
              else if (cmdToken === "crown") {
                if (target) {
                  const cName = config.contestants[target - 1]?.displayName;
                  viewerEvent({ userId: id, name: author, type: "crown", contestant: target, emoji: "👑", durationMs: 4500 });
                  setAnnouncement(`${author} crowned ${cName}! 👑`, "FAN CROWN", 3500);
                }
              }
              else if (cmdToken === "zap") {
                if (target) {
                  const cName = config.contestants[target - 1]?.displayName;
                  viewerEvent({ userId: id, name: author, type: "zap", contestant: target, emoji: "⚡", durationMs: 4500 });
                  setAnnouncement(`${author} electric zapped ${cName}! ⚡`, "POWER ZAP", 3500);
                }
              }
              else if (cmdToken === "fire" || cmdToken === "flame" || cmdToken === "cheer") {
                if (target) {
                  const cName = config.contestants[target - 1]?.displayName;
                  viewerEvent({ userId: id, name: author, type: "fire", contestant: target, emoji: "🔥", durationMs: 4500 });
                  setAnnouncement(`🔥 ${author} cheered for ${cName}!`, "FAN CHEER", 3500);
                }
              }
              else if (cmdToken === "star") {
                if (target) {
                  const cName = config.contestants[target - 1]?.displayName;
                  viewerEvent({ userId: id, name: author, type: "star", contestant: target, emoji: "⭐", durationMs: 4500 });
                  setAnnouncement(`${author} gave a golden star to ${cName}! ⭐`, "GOLDEN STAR", 3500);
                }
              }
              else if (cmdToken === "support" || cmdToken === "target") {
                if (target) viewerEvent({ userId: id, name: author, type: "support", contestant: target });
              }
              else if (cmdToken === "battle" || cmdToken === "vs") {
                const bTarget = resolveContestant(parts[2]);
                if (target && bTarget && target !== bTarget) {
                  const aName = config.contestants[target - 1]?.displayName || `#${target}`;
                  const bName = config.contestants[bTarget - 1]?.displayName || `#${bTarget}`;
                  viewerEvent({ userId: id, name: author, type: "battle", contestant: target, payload: { a: target, b: bTarget }, durationMs: 8000 });
                  setAnnouncement(`⚔️ 1v1 BATTLE: ${aName} VS ${bName}! Vote now!`, "BATTLE ARENA", 5500);
                }
              }
              else if (cmdToken === "dice") {
                const roll = 1 + Math.floor(Math.random() * 6);
                viewerEvent({ userId: id, name: author, type: "dice", payload: { roll }, durationMs: 4500 });
                setAnnouncement(`${author} rolled a ${roll}! 🎲`, "CHAT DICE", 3500);
                console.log(`[interactive] ${author} rolled dice: ${roll}`);
              }
              else if (cmdToken === "coin") {
                const flip = Math.random() > 0.5 ? "HEADS" : "TAILS";
                viewerEvent({ userId: id, name: author, type: "coin", payload: { flip }, durationMs: 4500 });
                setAnnouncement(`${author} flipped ${flip}! 🪙`, "COIN FLIP", 3500);
                console.log(`[interactive] ${author} flipped coin: ${flip}`);
              }
              else if (cmdToken === "slot") {
                const symbols = ["🍒", "🍋", "🔔", "💎", "7️⃣"];
                const s1 = symbols[Math.floor(Math.random() * symbols.length)];
                const s2 = symbols[Math.floor(Math.random() * symbols.length)];
                const s3 = symbols[Math.floor(Math.random() * symbols.length)];
                const win = (s1 === s2 && s2 === s3);
                viewerEvent({ userId: id, name: author, type: "slot", payload: { s1, s2, s3, win }, durationMs: 4500 });
                setAnnouncement(`${author} rolled [${s1} ${s2} ${s3}] ${win ? "JACKPOT! 🏆" : ""}`, "SLOT MACHINE", 3800);
                console.log(`[interactive] ${author} played slots: ${s1} ${s2} ${s3} (win=${win})`);
              }
              else if (cmdToken === "wheel" || cmdToken === "spin") {
                const options = [
                  "🌟 2X VOTE", "💎 500 PTS", "👑 VIP FAN", "⚡ BOOST",
                  "🔥 HYPE", "🎁 MYSTERY", "🎯 CROWN", "🏆 JACKPOT"
                ];
                const winIdx = Math.floor(Math.random() * options.length);
                const winner = options[winIdx];
                const spins = 4;
                const finalAngle = spins * Math.PI * 2 + (winIdx * (Math.PI * 2 / options.length)) + (Math.PI / options.length);
                viewerEvent({ userId: id, name: author, type: "wheel", payload: { winner, winIdx, finalAngle, options }, durationMs: 5500 });
                setAnnouncement(`${author} spun the wheel: ${winner}!`, "FORTUNE WHEEL", 4500);
                console.log(`[interactive] ${author} spun wheel: ${winner}`);
              }
              else if (cmdToken === "hype") {
                viewerEvent({ userId: id, name: author, type: "hype", durationMs: 4500 });
                setAnnouncement(`🚀 ${author} TRIGGERED THE HYPE TRAIN!`, "HYPE TRAIN", 3500);
                console.log(`[interactive] ${author} triggered hype`);
              }
              else if (cmdToken === "confetti" || cmdToken === "party") {
                viewerEvent({ userId: id, name: author, type: "confetti", durationMs: 5500 });
                setAnnouncement(`🎉 ${author} LAUNCHED CONFETTI!`, "CONFETTI PARTY", 3800);
                console.log(`[interactive] ${author} launched confetti`);
              }
              else if (cmdToken === "fireworks" || cmdToken === "fw") {
                viewerEvent({ userId: id, name: author, type: "fireworks", durationMs: 5000 });
                setAnnouncement(`🎆 ${author} FIRED OFF FIREWORKS!`, "FIREWORKS", 3800);
                console.log(`[interactive] ${author} launched fireworks`);
              }
              else if (cmdToken === "lightning" || cmdToken === "zap2") {
                viewerEvent({ userId: id, name: author, type: "lightning", durationMs: 3500 });
                setAnnouncement(`⚡ ${author} CALLED DOWN LIGHTNING!`, "LIGHTNING", 3000);
                console.log(`[interactive] ${author} called lightning`);
              }
              else if (cmdToken === "shoutout") {
                const shoutMsg = rawArg ? clean(rawArg).slice(0, 75) : "BIGG BOSS 24/7 FAN!";
                viewerEvent({ userId: id, name: author, type: "shoutout", payload: { message: shoutMsg }, durationMs: 5500 });
                setAnnouncement(`${author}: "${shoutMsg}"`, "VIP SHOUTOUT", 5000);
                console.log(`[interactive] ${author} shoutout: "${shoutMsg}"`);
              }
              else if (cmdToken === "random") {
                const pick = 1 + Math.floor(Math.random() * config.contestants.length);
                viewerEvent({ userId: id, name: author, type: "random", contestant: pick });
              }
              else if (cmdToken === "mvp") {
                viewerEvent({ userId: id, name: author, type: "mvp" });
              }
              else if (cmdToken === "event") {
                const types = ["drop", "heart", "gift", "boom", "star", "wheel", "dice"];
                const type = types[Math.floor(Math.random() * types.length)];
                viewerEvent({ userId: id, name: author, type, emoji: type === "drop" ? "🎈" : type === "heart" ? "❤️" : type === "gift" ? "🎁" : type === "star" ? "⭐" : "✨" });
              }
              else if (admin(id, owner, mod) && cmdToken === "close") {
                setVoting(false); void saveState();
                setAnnouncement(`🔒 Voting has been CLOSED by Admin`, "VOTING STATUS", 3500);
              }
              else if (admin(id, owner, mod) && cmdToken === "open") {
                setVoting(true); void saveState();
                setAnnouncement(`🔓 Voting has been OPENED by Admin`, "VOTING STATUS", 3500);
              }
            } catch (error) {
              runtime.chat.lastError = `message: ${error.message}`;
              console.error(`[chat] message handler: ${error.stack || error.message}`);
            }
          }
        }
      } catch (e) {
        runtime.chat.status = "error";
        runtime.chat.lastError = e?.message || String(e);
        const isChatDisabled = /disabled|unavailable|members-only/i.test(runtime.chat.lastError);
        if (isChatDisabled) {
          console.warn(`[chat] live chat is unavailable or disabled for ${activeVideoId}; retrying in 30s`);
          delay = 30000;
        } else if (!signal.aborted) {
          console.error(`[chat] ${runtime.chat.lastError}; retrying in ${Math.round(delay/1000)}s`);
        }
      } finally {
        runtime.chat.reconnects++;
        try { mc?.stop?.(); } catch {}
        mc = null;
      }
      if (signal.aborted) break;
      runtime.chat.status = "waiting";
      await sleep(delay);
      delay = Math.min(delay * 2, 60000);
    }
    runtime.chat.status = "stopped";
  })();
}
