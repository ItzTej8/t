import http from "node:http";
import { config } from "./config.mjs";
import { runtime } from "./runtime.mjs";
import { on } from "./events.mjs";
import { isMusicEnabled } from "./interactive.mjs";

const boundary = "bbframe";
let server = null;
let latest = null;
const clients = new Set();
const audioClients = new Set();

// --- Audio Synthesizer & Real-time Mixer ---
const AUDIO_SAMPLE_RATE = 44100;
const INITIAL_BUFFER_SECONDS = 1.5;
const INITIAL_BUFFER_SAMPLES = Math.floor(AUDIO_SAMPLE_RATE * INITIAL_BUFFER_SECONDS);
const silencePool = Buffer.alloc(AUDIO_SAMPLE_RATE * 2 * 4); // 2 seconds pre-allocated silence

// Pre-synthesize celebratory Golden Fanfare Chime for votes
const VOTE_FANFARE_DURATION = 1.1;
const voteFanfareSamples = Math.floor(AUDIO_SAMPLE_RATE * VOTE_FANFARE_DURATION);
const voteFanfarePcm = new Int16Array(voteFanfareSamples * 2);

for (let i = 0; i < voteFanfareSamples; i++) {
  const t = i / AUDIO_SAMPLE_RATE;
  let sL = 0, sR = 0;

  // Punchy bass kick at attack (t < 0.14)
  if (t < 0.14) {
    const kFreq = 125 - (t / 0.14) * 70;
    const kick = Math.sin(2 * Math.PI * kFreq * t) * Math.exp(-t * 28) * 0.45;
    sL += kick;
    sR += kick;
  }

  // Ascending 5-note broadcast fanfare arpeggio (C5 -> E5 -> G5 -> C6 -> E6)
  const notes = [
    { t0: 0.00, dur: 0.30, freq: 523.25, pan: -0.4 },
    { t0: 0.09, dur: 0.30, freq: 659.25, pan: -0.2 },
    { t0: 0.18, dur: 0.32, freq: 783.99, pan: 0.1 },
    { t0: 0.27, dur: 0.38, freq: 1046.50, pan: 0.25 },
    { t0: 0.36, dur: 0.72, freq: 1318.51, pan: 0.4 }
  ];

  for (const n of notes) {
    if (t >= n.t0 && t < n.t0 + n.dur) {
      const nt = t - n.t0;
      const att = Math.min(1, nt / 0.005);
      const dec = Math.exp(-nt * (n === notes[4] ? 3.8 : 8.5));
      const tone = (
        Math.sin(2 * Math.PI * n.freq * nt) * 0.48 +
        Math.sin(2 * Math.PI * (n.freq * 2) * nt) * 0.28 +
        Math.sin(2 * Math.PI * (n.freq * 3) * nt) * 0.14
      ) * att * dec;

      const panL = 0.5 * (1 - n.pan);
      const panR = 0.5 * (1 + n.pan);
      sL += tone * panL;
      sR += tone * panR;
    }
  }

  // Crystalline bell sparkle shimmer (t >= 0.36 to end)
  if (t >= 0.36) {
    const st = t - 0.36;
    const sDec = Math.exp(-st * 5.0);
    const shL = (Math.sin(2 * Math.PI * 2637 * st) * 0.15 + Math.sin(2 * Math.PI * 3951 * st) * 0.10) * sDec;
    const shR = (Math.sin(2 * Math.PI * 2637 * (st + 0.0012)) * 0.15 + Math.sin(2 * Math.PI * 3951 * (st - 0.0012)) * 0.10) * sDec;
    sL += shL;
    sR += shR;
  }

  voteFanfarePcm[i * 2] = Math.max(-32767, Math.min(32767, Math.round(sL * 25000)));
  voteFanfarePcm[i * 2 + 1] = Math.max(-32767, Math.min(32767, Math.round(sR * 25000)));
}

// Pre-synthesize Bomb Explosion sound effect
const BOMB_SOUND_DURATION = 1.2;
const bombSamples = Math.floor(AUDIO_SAMPLE_RATE * BOMB_SOUND_DURATION);
const bombPcm = new Int16Array(bombSamples * 2);
for (let i = 0; i < bombSamples; i++) {
  const t = i / AUDIO_SAMPLE_RATE;
  const boom = Math.sin(2 * Math.PI * Math.max(25, 80 - t * 50) * t) * Math.exp(-t * 4.2);
  const noise = (Math.random() * 2 - 1) * Math.exp(-t * 8.5) * 0.35;
  const s = Math.max(-1, Math.min(1, boom + noise));
  bombPcm[i * 2] = Math.round(s * 25000);
  bombPcm[i * 2 + 1] = Math.round(s * 25000);
}

// Confetti shimmer: rising metallic chime cluster
const CONFETTI_DUR = 1.0;
const confettiSamples = Math.floor(AUDIO_SAMPLE_RATE * CONFETTI_DUR);
const confettiPcm = new Int16Array(confettiSamples * 2);
for (let i = 0; i < confettiSamples; i++) {
  const t = i / AUDIO_SAMPLE_RATE;
  const notes = [1047, 1319, 1568, 2093];
  let s = 0;
  for (let n = 0; n < notes.length; n++) {
    const t0 = n * 0.08;
    if (t >= t0) {
      const nt = t - t0;
      s += Math.sin(2 * Math.PI * notes[n] * nt) * Math.exp(-nt * 5.5) * 0.28;
    }
  }
  const shimmer = Math.sin(2 * Math.PI * 3500 * t) * Math.exp(-t * 8) * 0.08;
  const val = Math.max(-32767, Math.min(32767, Math.round((s + shimmer) * 24000)));
  confettiPcm[i * 2] = val;
  confettiPcm[i * 2 + 1] = val;
}

// Fireworks whistle+burst: ascending whistle then explosion pop
const FIREWORKS_DUR = 1.2;
const fireworksSamples = Math.floor(AUDIO_SAMPLE_RATE * FIREWORKS_DUR);
const fireworksPcm = new Int16Array(fireworksSamples * 2);
for (let i = 0; i < fireworksSamples; i++) {
  const t = i / AUDIO_SAMPLE_RATE;
  let s = 0;
  // Ascending whistle 0-0.4s
  if (t < 0.4) {
    const freq = 400 + (t / 0.4) * 2400;
    s += Math.sin(2 * Math.PI * freq * t) * 0.25;
  }
  // Pop burst at 0.42s
  if (t >= 0.42 && t < 0.70) {
    const bt = t - 0.42;
    s += Math.sin(2 * Math.PI * Math.max(20, 120 - bt * 200) * bt) * Math.exp(-bt * 18) * 0.55;
    s += (Math.random() * 2 - 1) * Math.exp(-bt * 20) * 0.3;
  }
  // Sparkle tail 0.55s+
  if (t >= 0.55) {
    const st = t - 0.55;
    s += (Math.sin(2 * Math.PI * 2093 * st) * 0.12 + Math.sin(2 * Math.PI * 3136 * st) * 0.08) * Math.exp(-st * 6);
  }
  const val = Math.max(-32767, Math.min(32767, Math.round(s * 24000)));
  fireworksPcm[i * 2] = val;
  fireworksPcm[i * 2 + 1] = val;
}

// Lightning crack: sharp noise burst + electric shimmer
const LIGHTNING_DUR = 0.7;
const lightningSamples = Math.floor(AUDIO_SAMPLE_RATE * LIGHTNING_DUR);
const lightningPcm = new Int16Array(lightningSamples * 2);
for (let i = 0; i < lightningSamples; i++) {
  const t = i / AUDIO_SAMPLE_RATE;
  const crack = (Math.random() * 2 - 1) * Math.exp(-t * 28) * 0.8;
  const rumble = Math.sin(2 * Math.PI * Math.max(20, 60 - t * 40) * t) * Math.exp(-t * 6) * 0.35;
  const electric = (Math.sin(2 * Math.PI * 1200 * t) + Math.sin(2 * Math.PI * 800 * t)) * Math.exp(-t * 14) * 0.15;
  const s = Math.max(-1, Math.min(1, crack + rumble + electric));
  const val = Math.round(s * 26000);
  lightningPcm[i * 2] = val;
  lightningPcm[i * 2 + 1] = val;
}

// Drop whoosh + touchdown chime
const DROP_DUR = 0.9;
const dropSamples = Math.floor(AUDIO_SAMPLE_RATE * DROP_DUR);
const dropPcm = new Int16Array(dropSamples * 2);
for (let i = 0; i < dropSamples; i++) {
  const t = i / AUDIO_SAMPLE_RATE;
  let s = 0;
  // Descending whistle 0-0.45s
  if (t < 0.45) {
    const freq = 1800 - (t / 0.45) * 1200;
    s += Math.sin(2 * Math.PI * freq * t) * 0.22;
    s += (Math.random() * 2 - 1) * 0.05 * (1 - t / 0.45);
  } else {
    // Touchdown chime chord at 0.45s
    const ct = t - 0.45;
    const chime = (Math.sin(2 * Math.PI * 1046.5 * ct) * 0.25 + Math.sin(2 * Math.PI * 1318.5 * ct) * 0.2 + Math.sin(2 * Math.PI * 1567.98 * ct) * 0.15) * Math.exp(-ct * 6.5);
    s += chime;
  }
  const val = Math.max(-32767, Math.min(32767, Math.round(s * 25000)));
  dropPcm[i * 2] = val;
  dropPcm[i * 2 + 1] = val;
}

// Wheel clicking ratchet (1.4s)
const WHEEL_DUR = 1.4;
const wheelSamples = Math.floor(AUDIO_SAMPLE_RATE * WHEEL_DUR);
const wheelPcm = new Int16Array(wheelSamples * 2);
for (let i = 0; i < wheelSamples; i++) {
  const t = i / AUDIO_SAMPLE_RATE;
  // Ticks that start fast (25Hz) and slow down to 4Hz
  const tickRate = Math.max(4, 25 * (1 - Math.pow(t / WHEEL_DUR, 1.8)));
  const phase = (t * tickRate) % 1.0;
  const click = phase < 0.08 ? (Math.sin(2 * Math.PI * 880 * phase) * Math.exp(-phase * 80) * 0.4 + (Math.random() * 2 - 1) * 0.15) : 0;
  const val = Math.max(-32767, Math.min(32767, Math.round(click * 24000)));
  wheelPcm[i * 2] = val;
  wheelPcm[i * 2 + 1] = val;
}

// Dice clatter rattle (0.8s)
const DICE_DUR = 0.8;
const diceSamples = Math.floor(AUDIO_SAMPLE_RATE * DICE_DUR);
const dicePcm = new Int16Array(diceSamples * 2);
for (let i = 0; i < diceSamples; i++) {
  const t = i / AUDIO_SAMPLE_RATE;
  const decay = Math.exp(-t * 5.0);
  const click = (Math.random() * 2 - 1) * (Math.sin(t * 70) > 0.6 ? 0.35 : 0.04) * decay;
  const thud = Math.sin(2 * Math.PI * 140 * t) * Math.exp(-t * 9) * 0.3;
  const val = Math.max(-32767, Math.min(32767, Math.round((click + thud) * 25000)));
  dicePcm[i * 2] = val;
  dicePcm[i * 2 + 1] = val;
}

// Vegas Slot Jackpot / Arpeggio Chime (1.2s)
const SLOT_DUR = 1.2;
const slotSamples = Math.floor(AUDIO_SAMPLE_RATE * SLOT_DUR);
const slotPcm = new Int16Array(slotSamples * 2);
for (let i = 0; i < slotSamples; i++) {
  const t = i / AUDIO_SAMPLE_RATE;
  const notes = [523.25, 659.25, 783.99, 1046.5, 1318.51, 1567.98];
  const step = Math.floor(t / 0.15) % notes.length;
  const noteT = t % 0.15;
  const tone = Math.sin(2 * Math.PI * notes[step] * noteT) * Math.exp(-noteT * 7) * 0.35;
  const shimmer = Math.sin(2 * Math.PI * (notes[step] * 2) * noteT) * 0.12 * Math.exp(-noteT * 10);
  const val = Math.max(-32767, Math.min(32767, Math.round((tone + shimmer) * 26000)));
  slotPcm[i * 2] = val;
  slotPcm[i * 2 + 1] = val;
}

// Procedural ambient broadcast tension & rhythm music loop (4.0s seamless loop)
const BG_LOOP_DURATION = 4.0;
const bgLoopSamples = Math.floor(AUDIO_SAMPLE_RATE * BG_LOOP_DURATION);
const bgLoopPcm = new Int16Array(bgLoopSamples * 2);
for (let i = 0; i < bgLoopSamples; i++) {
  const t = i / AUDIO_SAMPLE_RATE;
  const beat = t % 1.0;
  const kick = beat < 0.10 ? Math.sin(2 * Math.PI * (85 - beat * 350) * beat) * Math.exp(-beat * 32) * 0.16 : 0;
  const bar = Math.floor(t);
  const rootFreq = bar === 0 ? 146.83 : bar === 1 ? 116.54 : bar === 2 ? 130.81 : 146.83;
  const pad = (
    Math.sin(2 * Math.PI * rootFreq * t) * 0.06 +
    Math.sin(2 * Math.PI * (rootFreq * 1.5) * t) * 0.035 +
    Math.sin(2 * Math.PI * (rootFreq * 2) * t) * 0.025
  ) * (0.85 + 0.15 * Math.sin(2 * Math.PI * 0.25 * t));
  const tickPhase = t % 0.25;
  const tick = tickPhase < 0.015 ? (Math.random() * 2 - 1) * Math.exp(-tickPhase * 180) * 0.03 : 0;
  const sample = kick + pad + tick;
  bgLoopPcm[i * 2] = Math.max(-32767, Math.min(32767, Math.round(sample * 16000)));
  bgLoopPcm[i * 2 + 1] = Math.max(-32767, Math.min(32767, Math.round(sample * 16000)));
}

let activeSounds = [];
let bgLoopSampleIndex = 0;
let bgMusicVolume = 0.55; // Default volume: clear & pleasant, not too quiet

export function setBgMusicVolume(vol) {
  const v = Math.max(0.05, Math.min(1.0, Number(vol) || 0.55));
  bgMusicVolume = v;
  console.log(`[audio] background music volume set to ${Math.round(bgMusicVolume * 100)}%`);
  return bgMusicVolume;
}

export function getBgMusicVolume() {
  return bgMusicVolume;
}

const SAMPLES_PER_FRAME = Math.round(AUDIO_SAMPLE_RATE / config.fps);
const frameSilenceBuf = Buffer.alloc(SAMPLES_PER_FRAME * 4);

export function playVoteSound() {
  if (!isMusicEnabled()) return;
  activeSounds.push({ pcm: voteFanfarePcm, offset: 0, volume: 1.0 });
  if (activeSounds.length > 8) activeSounds.shift();
}

export function playDropSound() {
  if (!isMusicEnabled()) return;
  activeSounds.push({ pcm: dropPcm, offset: 0, volume: 1.0 });
  if (activeSounds.length > 8) activeSounds.shift();
}

export function playWheelTickSound() {
  if (!isMusicEnabled()) return;
  activeSounds.push({ pcm: wheelPcm, offset: 0, volume: 0.9 });
  if (activeSounds.length > 8) activeSounds.shift();
}

export function playDiceRattleSound() {
  if (!isMusicEnabled()) return;
  activeSounds.push({ pcm: dicePcm, offset: 0, volume: 1.0 });
  if (activeSounds.length > 8) activeSounds.shift();
}

export function playSlotJackpotSound() {
  if (!isMusicEnabled()) return;
  activeSounds.push({ pcm: slotPcm, offset: 0, volume: 1.0 });
  if (activeSounds.length > 8) activeSounds.shift();
}

export function playBombSound() {
  if (!isMusicEnabled()) return;
  activeSounds.push({ pcm: bombPcm, offset: 0, volume: 1.0 });
  if (activeSounds.length > 8) activeSounds.shift();
}

export function playConfettiSound() {
  if (!isMusicEnabled()) return;
  activeSounds.push({ pcm: confettiPcm, offset: 0, volume: 0.9 });
  if (activeSounds.length > 8) activeSounds.shift();
}

export function playFireworksSound() {
  if (!isMusicEnabled()) return;
  activeSounds.push({ pcm: fireworksPcm, offset: 0, volume: 1.0 });
  if (activeSounds.length > 8) activeSounds.shift();
}

export function playLightningSound() {
  if (!isMusicEnabled()) return;
  activeSounds.push({ pcm: lightningPcm, offset: 0, volume: 1.0 });
  if (activeSounds.length > 8) activeSounds.shift();
}

// Auto-trigger sound whenever a vote is accepted in the system
on("vote", (vote) => {
  playVoteSound();
});

on("interactive", (e) => {
  if (e.type === "drop") playDropSound();
  else if (e.type === "wheel" || e.type === "spin") playWheelTickSound();
  else if (e.type === "dice") playDiceRattleSound();
  else if (e.type === "slot") playSlotJackpotSound();
  else if (e.type === "bomb") playBombSound();
  else if (e.type === "confetti") playConfettiSound();
  else if (e.type === "fireworks") playFireworksSound();
  else if (e.type === "lightning") playLightningSound();
});

let lastAudioSentAt = Date.now();
let audioHeartbeatTimer = null;

function ensureAudioHeartbeat() {
  if (!audioHeartbeatTimer) {
    audioHeartbeatTimer = setInterval(() => {
      if (audioClients.size === 0) return;
      const gapMs = Date.now() - lastAudioSentAt;
      if (gapMs >= 40) {
        const samples = Math.min(AUDIO_SAMPLE_RATE, Math.floor((gapMs / 1000) * AUDIO_SAMPLE_RATE));
        if (samples > 0) sendAudioFrame(samples);
      }
    }, 25);
  }
}

function sendAudioFrame(neededSamples = SAMPLES_PER_FRAME) {
  if (audioClients.size === 0) return;
  lastAudioSentAt = Date.now();

  const chunkPcm = new Int16Array(neededSamples * 2);
  const musicOn = isMusicEnabled();

  for (let i = 0; i < neededSamples; i++) {
    let sumL = 0, sumR = 0;

    // Ambient TV studio music bed (at dynamic bgMusicVolume)
    if (musicOn) {
      sumL += bgLoopPcm[bgLoopSampleIndex * 2] * bgMusicVolume;
      sumR += bgLoopPcm[bgLoopSampleIndex * 2 + 1] * bgMusicVolume;
      bgLoopSampleIndex = (bgLoopSampleIndex + 1) % bgLoopSamples;
    }

    // Overlay active vote / explosion / fanfare sound effects
    for (const snd of activeSounds) {
      if (snd.offset + 1 < snd.pcm.length) {
        sumL += snd.pcm[snd.offset] * snd.volume;
        sumR += snd.pcm[snd.offset + 1] * snd.volume;
        snd.offset += 2;
      }
    }

    chunkPcm[i * 2] = Math.max(-32767, Math.min(32767, Math.round(sumL)));
    chunkPcm[i * 2 + 1] = Math.max(-32767, Math.min(32767, Math.round(sumR)));
  }

  activeSounds = activeSounds.filter(snd => snd.offset < snd.pcm.length);
  const chunkBuf = Buffer.from(chunkPcm.buffer);

  for (const client of [...audioClients]) {
    if (client.closed || !client.res.writable) {
      audioClients.delete(client);
      continue;
    }
    if (client.res.writableLength > 500_000) continue;
    try {
      client.res.write(chunkBuf);
      client.samplesSent += neededSamples;
    } catch {
      client.closed = true;
      try { client.res.destroy(); } catch {}
      audioClients.delete(client);
    }
  }
}

function remove(client, reason = "unknown") {
  const had = clients.has(client);
  clients.delete(client);
  runtime.encoder.inputClients = clients.size;
  if (had) {
    console.warn(`[mjpeg] client disconnected (${reason}); remaining clients: ${clients.size}`);
  }
}

function send(client, frame) {
  if (client.closed || !client.res.writable) return;

  // Real-time backpressure management for live streaming:
  // If the TCP send buffer has > 2MB queued (~25 frames / 0.8s),
  // skip writing this frame to prevent buffer bloat and latency buildup.
  if (client.res.writableLength > 1_200_000) {
    runtime.renderer.dropped++;
    if (client.backedUpSince) {
      if (Date.now() - client.backedUpSince > 20000) {
        console.error(`[mjpeg] client unresponsive for 20s (${client.res.writableLength} bytes unconsumed); disconnecting`);
        client.closed = true;
        try { client.res.destroy(); } catch {}
        remove(client, "unresponsive-client-timeout");
      }
    } else {
      client.backedUpSince = Date.now();
    }
    return;
  }
  client.backedUpSince = 0;

  try {
    const chunk = Buffer.concat([
      Buffer.from(`--${boundary}\r\nContent-Type: image/jpeg\r\nContent-Length: ${frame.length}\r\nCache-Control: no-cache\r\n\r\n`),
      frame,
      Buffer.from("\r\n")
    ]);
    client.res.write(chunk);
    runtime.encoder.lastInputFrameAt = Date.now();
  } catch (error) {
    console.error(`[mjpeg] client write error: ${error.message}`);
    client.closed = true;
    try { client.res.destroy(); } catch {}
    remove(client, `write-error: ${error.message}`);
    runtime.encoder.lastError = `MJPEG client write: ${error.message}`;
  }
}

export function startFrameServer() {
  if (server) return server;
  server = http.createServer((req, res) => {
    req.on("error", () => {});
    res.on("error", () => {});
    res.socket?.setNoDelay?.(true);

    if (req.url === "/health") {
      res.writeHead(200, { "Content-Type": "application/json", "Cache-Control": "no-cache" });
      res.end(JSON.stringify({ ok: true, clients: clients.size, audioClients: audioClients.size, hasFrame: Boolean(latest) }));
      return;
    }

    if (req.url === "/audio") {
      res.writeHead(200, {
        "Content-Type": "audio/l16; rate=44100; channels=2",
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Connection": "keep-alive",
      });
      res.flushHeaders?.();
      const client = { req, res, closed: false, samplesSent: 0 };
      res.setTimeout(0);
      req.setTimeout(0);

      // Pre-send initial buffer to prime FFmpeg's audio buffer
      const initBuf = silencePool.subarray(0, INITIAL_BUFFER_SAMPLES * 4);
      res.write(initBuf);
      client.samplesSent += INITIAL_BUFFER_SAMPLES;

      audioClients.add(client);
      console.log(`[audio] client connected (total: ${audioClients.size})`);
      ensureAudioHeartbeat();

      req.on("close", () => { client.closed = true; audioClients.delete(client); });
      res.on("close", () => { client.closed = true; audioClients.delete(client); });
      req.on("error", () => { client.closed = true; audioClients.delete(client); });
      res.on("error", () => { client.closed = true; audioClients.delete(client); });
      return;
    }

    if (req.url !== "/mjpeg") {
      res.writeHead(404, { "Content-Type": "text/plain" });
      res.end("not found\n");
      return;
    }

    res.writeHead(200, {
      "Content-Type": `multipart/x-mixed-replace; boundary=${boundary}`,
      "Cache-Control": "no-cache, no-store, must-revalidate",
      "Pragma": "no-cache",
      "Connection": "keep-alive",
      "Access-Control-Allow-Origin": "*",
    });
    res.flushHeaders?.();
    const client = { res, req, blocked: false, closed: false, drainTimer: null };
    res.setTimeout(0);
    req.setTimeout(0);
    clients.add(client);
    runtime.encoder.inputClients = clients.size;

    req.on("aborted", () => { client.closed = true; remove(client, "req-aborted"); });
    res.on("close", () => { client.closed = true; remove(client, "res-close"); });
    req.on("error", (e) => { client.closed = true; remove(client, `req-error: ${e?.message}`); });
    res.on("error", (e) => { client.closed = true; remove(client, `res-error: ${e?.message}`); });

    if (latest) send(client, latest);
  });

  server.on("error", error => {
    runtime.encoder.lastError = `MJPEG server: ${error.message}`;
    console.error(`[mjpeg] server error: ${error.message}`);
  });

  server.listen(config.frameServerPort, "127.0.0.1", () => {
    runtime.encoder.inputUrl = `http://127.0.0.1:${config.frameServerPort}/mjpeg`;
    console.log(`[mjpeg] input server http://127.0.0.1:${config.frameServerPort}/mjpeg`);
    console.log(`[audio] input server http://127.0.0.1:${config.frameServerPort}/audio`);
  });
  return server;
}

export function publishFrame(frame) {
  latest = frame;
  runtime.renderer.lastFramePublishedAt = Date.now();
  for (const client of [...clients]) send(client, frame);
  sendAudioFrame();
}

export function stopFrameServer() {
  for (const client of [...clients]) {
    client.closed = true;
    if (client.drainTimer) clearTimeout(client.drainTimer);
    try { client.res.destroy(); } catch {}
  }
  clients.clear();

  for (const client of [...audioClients]) {
    client.closed = true;
    try { client.res.destroy(); } catch {}
  }
  audioClients.clear();
  if (audioHeartbeatTimer) {
    clearInterval(audioHeartbeatTimer);
    audioHeartbeatTimer = null;
  }

  runtime.encoder.inputClients = 0;
  latest = null;
  if (server) {
    try { server.close(); } catch {}
    server = null;
  }
}
