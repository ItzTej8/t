import { spawn } from "node:child_process";
import { appendFile, mkdir } from "node:fs/promises";
import { dirname } from "node:path";
import { config } from "./config.mjs";
import { runtime } from "./runtime.mjs";
import { emit } from "./events.mjs";

const kbps = v => {
  const m = String(v).match(/^(\d+(?:\.\d+)?)([kKmM]?)$/);
  if (!m) return 2500;
  const n = Number(m[1]);
  return Math.round(m[2].toLowerCase() === "m" ? n * 1000 : n);
};

let logReady = null;
async function ensureLog() {
  if (!logReady) logReady = mkdir(dirname(config.ffmpegLogFile), { recursive: true }).catch(() => {});
  await logReady;
}
function pushTail(line) {
  runtime.encoder.stderrTail.push(line.slice(-1500));
  if (runtime.encoder.stderrTail.length > config.ffmpegLogLines) runtime.encoder.stderrTail.splice(0, runtime.encoder.stderrTail.length - config.ffmpegLogLines);
}
async function persistStderr(line) {
  try { await ensureLog(); await appendFile(config.ffmpegLogFile, `${new Date().toISOString()} ${line}\n`); } catch {}
}

export function createEncoder() {
  const out = `${config.rtmpUrl}/${config.streamKey}`;
  const br = kbps(config.bitrate);
  const scale = config.renderWidth === config.width && config.renderHeight === config.height
    ? null : `scale=${config.width}:${config.height}:flags=fast_bilinear`;
  const vfilters = [`fps=fps=${config.fps}:round=near`, "setpts=PTS-STARTPTS"];
  if (scale) vfilters.push(scale);

  const args = [
    "-hide_banner", "-nostdin", "-loglevel", "info", "-progress", "pipe:2",
    "-fflags", "+nobuffer+genpts",
    "-use_wallclock_as_timestamps", "1",
    "-r", String(config.renderFps),
    "-thread_queue_size", "2048", "-f", "mpjpeg", "-i", `http://127.0.0.1:${config.frameServerPort}/mjpeg`,
  ];
  if (config.audioFile) {
    args.push(
      "-thread_queue_size", "2048", "-stream_loop", "-1", "-re", "-i", config.audioFile,
      "-thread_queue_size", "2048", "-f", "s16le", "-ar", "44100", "-ac", "2", "-i", `http://127.0.0.1:${config.frameServerPort}/audio`,
      "-filter_complex", `[1:a]volume=${config.audioVolume}[bg];[bg][2:a]amix=inputs=2:duration=first:dropout_transition=2[aout]`,
      "-map", "0:v:0", "-map", "[aout]",
    );
  } else {
    args.push(
      "-thread_queue_size", "2048", "-f", "s16le", "-ar", "44100", "-ac", "2", "-i", `http://127.0.0.1:${config.frameServerPort}/audio`,
      "-map", "0:v:0", "-map", "1:a:0",
    );
  }

  args.push(
    "-vf", vfilters.join(","),
    "-r", String(config.fps),
  );

  if (config.videoCodec === "h264_mf" && process.platform === "win32") {
    args.push(
      "-c:v", "h264_mf",
      "-scenario", "live_streaming",
      "-rate_control", "cbr",
      "-b:v", config.bitrate,
      "-g", String(config.fps * config.gopSeconds),
      "-pix_fmt", "yuv420p",
    );
  } else {
    args.push(
      "-c:v", "libx264",
      "-preset", config.preset,
      "-tune", "zerolatency",
      "-threads", String(config.encoderThreads),
      "-pix_fmt", "yuv420p",
      "-b:v", config.bitrate,
      "-minrate", config.bitrate,
      "-maxrate", config.bitrate,
      "-bufsize", config.bitrate,
      "-x264-params", "nal-hrd=cbr:force-cfr=1",
      "-g", String(config.fps * config.gopSeconds),
      "-keyint_min", String(config.fps * config.gopSeconds),
      "-sc_threshold", "0",
    );
  }

  args.push(
    "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
    "-af", "aresample=async=1000:first_pts=0",
    "-flvflags", "no_duration_filesize",
    "-f", "flv", out,
  );

  console.log(`[ffmpeg] codec=${config.videoCodec} command=${["ffmpeg", ...args].map(v => /live2\//.test(v) ? "<RTMP_URL>/<STREAM_KEY>" : v).join(" ")}`);
  const child = spawn("ffmpeg", args, { stdio: ["ignore", "ignore", "pipe"], windowsHide: true });
  child._bb = { closed: false, stopping: false, spawned: false, stderrBuffer: "" };
  runtime.encoder.status = "starting";
  runtime.encoder.pid = child.pid ?? null;
  runtime.encoder.starts++;
  runtime.encoder.startedAt = Date.now();
  runtime.encoder.lastProgressAt = Date.now();
  runtime.encoder.lastVideoProgressAt = Date.now();
  runtime.encoder.lastFrameNumber = 0;
  runtime.encoder.lastProgressSeconds = 0;
  runtime.encoder.lastOutputTimeSeconds = 0;
  runtime.encoder.outputStartedAt = 0;
  runtime.encoder.connectedHint = false;
  runtime.encoder.lastSpeed = null;
  runtime.encoder.lastError = null;
  runtime.encoder.stderrTail = [];
  runtime.encoder.exitReason = null;

  child.stderr.setEncoding("utf8");
  child.stderr.on("data", chunk => {
    child._bb.stderrBuffer += String(chunk);
    const lines = child._bb.stderrBuffer.split(/\r?\n/);
    child._bb.stderrBuffer = lines.pop() ?? "";
    for (const raw of lines.map(x => x.trim()).filter(Boolean)) {
      const eq = raw.indexOf("=");
      if (eq > 0) {
        const key = raw.slice(0, eq).toLowerCase();
        const value = raw.slice(eq + 1).trim();
        if (key === "frame") {
          const fn = parseInt(value, 10);
          if (Number.isFinite(fn)) {
            if (fn > (runtime.encoder.lastFrameNumber || 0)) {
              runtime.encoder.lastFrameNumber = fn;
              runtime.encoder.lastVideoProgressAt = Date.now();
            }
          }
          continue;
        }
        if (key === "out_time_ms" || key === "out_time_us") {
          const seconds = Number(value) / 1_000_000;
          if (Number.isFinite(seconds) && seconds > 0) {
            runtime.encoder.lastProgressSeconds = seconds;
            runtime.encoder.lastOutputTimeSeconds = seconds;
            runtime.encoder.lastProgressAt = Date.now();
            runtime.encoder.connectedHint = true;
            if (!runtime.encoder.outputStartedAt) {
              runtime.encoder.outputStartedAt = Date.now();
              console.log(`[ffmpeg] YouTube live ingest connected! Stream time: ${seconds.toFixed(1)}s`);
            }
          }
          continue;
        }
        if (key === "speed") {
          runtime.encoder.lastSpeed = value;
          continue;
        }
        if (key === "fps") {
          runtime.encoder.lastFps = value;
          continue;
        }
        if (["dup_frames", "drop_frames", "total_size", "progress", "bitrate", "stream_0_0_q"].includes(key)) {
          continue;
        }
      }

      pushTail(raw);
      void persistStderr(raw);
      const isError = /error|failed|invalid|abort|fatal|broken|denied/i.test(raw);
      if (isError) {
        runtime.encoder.lastError = raw.slice(-1500);
        console.error(`[ffmpeg] ${raw}`);
      } else if (raw.startsWith("Output #0") || raw.startsWith("Stream mapping") || raw.includes("Conversion failed")) {
        console.log(`[ffmpeg] ${raw}`);
      }
    }
  });
  child.once("spawn", () => { child._bb.spawned = true; runtime.encoder.status = "running"; });
  child.once("error", error => {
    runtime.encoder.status = "error";
    runtime.encoder.lastError = error.message;
    runtime.encoder.exitReason = `process-error:${error.code || error.message}`;
    console.error(`[ffmpeg] process error: ${error.code || "ERROR"}: ${error.message}`);
  });
  child.once("close", (code, signal) => {
    child._bb.closed = true;
    runtime.encoder.status = "stopped";
    runtime.encoder.lastExitCode = code;
    runtime.encoder.lastSignal = signal;
    runtime.encoder.exitReason = `code=${code ?? "null"} signal=${signal ?? "none"}`;
    runtime.encoder.pid = null;
    if (!child._bb.stopping || code !== 0 || signal) {
      runtime.encoder.lastError ||= `closed code=${code ?? "null"} signal=${signal ?? "none"}`;
      console.error(`[ffmpeg] exited code=${code ?? "null"} signal=${signal ?? "none"}`);
    } else console.log(`[ffmpeg] stopped cleanly code=${code ?? 0}`);
    emit("encoder-closed", { code, signal, stopping: child._bb.stopping });
  });
  console.log(`[ffmpeg] started pid=${child.pid ?? "?"} input=mjpeg@${config.renderFps} output=${config.fps}fps bitrate=${config.bitrate}`);
  return child;
}

export async function stopEncoder(child) {
  if (!child || child._bb?.stopping) return;
  child._bb.stopping = true;
  await new Promise(resolve => {
    if (child._bb.closed) return resolve();
    let done = false;
    const finish = () => { if (done) return; done = true; clearTimeout(termTimer); clearTimeout(killTimer); child.removeListener("close", finish); resolve(); };
    child.once("close", finish);
    const termTimer = setTimeout(() => { try { if (!child._bb.closed) child.kill("SIGTERM"); } catch {} }, 1000);
    const killTimer = setTimeout(() => { try { if (!child._bb.closed) child.kill("SIGKILL"); } catch {} finish(); }, 5000);
  });
}
