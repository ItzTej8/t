import { config, validateConfig } from "./config.mjs";
import { loadImage } from "@napi-rs/canvas";
import { loadState, saveState } from "./state.mjs";
import { startChatLoop } from "./chat.mjs";
import { initRenderer, startRenderer, stopRenderer, setContestantImages } from "./renderer.mjs";
import { loadContestantImages } from "./image-cache.mjs";
import { startHealthServer } from "./health.mjs";
import { startWatchdog } from "./watchdog.mjs";
import { startEncoderSupervisor } from "./encoder-supervisor.mjs";
import { runtime } from "./runtime.mjs";
import { acquireInstanceLock, releaseInstanceLock } from "./instance-lock.mjs";
import { startEvictionMonitor, stopEvictionMonitor } from "./eviction-monitor.mjs";
const controller=new AbortController();let shutdownPromise=null;
async function main(){await acquireInstanceLock();const v=validateConfig();if(v.errors.length){v.errors.forEach(e=>console.error(`[config] ${e}`));await releaseInstanceLock();process.exitCode=1;return;}v.warnings.forEach(w=>console.warn(`[config] ${w}`));await loadState();const images=await loadContestantImages();const imageMap=new Map();for(const [no,file] of images){try{imageMap.set(no,await loadImage(await Bun.file(file).arrayBuffer()));}catch(e){console.warn(`[images] decode ${no}: ${e.message}`);}}setContestantImages(imageMap);startEvictionMonitor(config.contestants);const health=startHealthServer();console.log("==========================================");console.log(" Bigg Boss VPS Canvas Live — MULTI-SCREEN 10.1");console.log(` output ${config.width}x${config.height}@${config.fps}`);console.log(` render ${config.renderWidth}x${config.renderHeight}`);console.log(` resolution: STREAM_RESOLUTION=${config.streamResolution} | RENDER_RESOLUTION=${config.renderResolution}`);console.log(" voting: UNLIMITED PER USER — every valid command counts");console.log("==========================================");
await initRenderer();
startChatLoop({signal:controller.signal}).catch(e=>{if(!controller.signal.aborted)console.error(`[chat] fatal ${e.message}`);});
const encoderStop=startEncoderSupervisor();
const watchdogStop=startWatchdog({signal:controller.signal,onMemoryPressure:()=>void shutdown("memory-pressure")});
try{await startRenderer();}finally{stopEvictionMonitor();watchdogStop();await encoderStop();controller.abort();await stopRenderer();await saveState();health.stop();await releaseInstanceLock();}}
async function shutdown(signal){if(shutdownPromise)return shutdownPromise;shutdownPromise=(async()=>{runtime.stopping=true;console.log(`[main] ${signal}`);controller.abort();await stopRenderer();await saveState();await releaseInstanceLock();process.exit(signal==="memory-pressure"?1:0);})();return shutdownPromise;}
process.on("SIGINT",()=>void shutdown("SIGINT"));process.on("SIGTERM",()=>void shutdown("SIGTERM"));
process.on("uncaughtException",e=>{
  const code=e?.code;
  const recoverable=["EPIPE","ECONNRESET","ETIMEDOUT","ECONNABORTED","ENOTFOUND","EAI_AGAIN","UND_ERR_SOCKET"];
  if(recoverable.includes(code)){
    console.warn(`[main] recovered transient network/socket error (${code}): ${e.message}`);
    return;
  }
  console.error(`[main] uncaught ${e.stack||e.message}`);
  void shutdown("uncaughtException");
});process.on("unhandledRejection",e=>console.error(`[main] rejection ${e?.stack||e}`));main().catch(e=>{console.error(`[main] fatal ${e.stack||e.message}`);void shutdown("fatal")});
