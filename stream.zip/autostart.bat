@echo off
cd /d "c:\Users\hp\Desktop\Projects\GSPN\stream\stream"
start /min powershell.exe -ExecutionPolicy Bypass -WindowStyle Minimized -File "c:\Users\hp\Desktop\Projects\GSPN\stream\stream\run-247.ps1"
