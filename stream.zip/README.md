# Bigg Boss VPS Canvas Live — BunJS 10.0 / Season 20 / Multi-Screen 24x7

A production-oriented vertical YouTube Live renderer built with **BunJS + @napi-rs/canvas + FFmpeg + Masterchat**.

## What changed in 10.0

The stream is now a **multi-screen broadcast engine**. It is still one YouTube Live stream / one FFmpeg ingest, but the content inside the video can slide between different broadcast panels.

### Screens

1. **LIVE VOTING** — main contestant voting layout, top contestants, vote counts, percentages and progress bars.
2. **LIVE STATS** — total votes, unique voters, recent vote rate, chat activity, current leader and recent chat.
3. **RANK RACE** — full ranking race with animated bars and live gaps.
4. **TOP SUPPORTERS** — viewer interaction leaderboard and MVP activity.
5. **LIVE EVENTS** — interactive event feed and milestone activity.
6. **CONTESTANT PROFILE** — temporary profile overlay opened by `!profile N`.
7. **STREAM MENU** — temporary menu opened by `!menu`.

The screen transitions use a horizontal slide animation so the broadcast behaves like a TV/app carousel rather than a hard scene cut.

## YouTube chat screen controls

```text
!screen main
!screen stats
!screen race
!screen supporters
!screen events
!profile 3
!next
!prev
!auto on
!auto off
!menu
```

### Automatic screen rotation

By default the stream automatically rotates through the five primary screens.

```env
SCREEN_INTERVAL_MS=20000
SCREEN_TRANSITION_MS=650
PUBLIC_SCREEN_COMMANDS=true
```

Set `SCREEN_INTERVAL_MS=30000` for 30-second scenes, for example.

A manual `!screen ...`, `!next` or `!prev` command disables automatic rotation. Use `!auto on` to resume automatic rotation.

Major events such as milestones and battles temporarily prioritize the **LIVE EVENTS** screen.

## Theme

The visual language follows the supplied dark/light Bigg Boss reference style.

```text
!theme dark
!theme light
!dark
!light
```

## Voting

```text
!vote 1
!vote 2
...
!vote 17
```

Votes are unlimited per viewer while voting is open. SQLite persists all accepted votes.

## Interactive commands

```text
!drop 🎈
!heart
!rain ❤️
!gift
!boom
!crown 3
!zap 3
!fire 3
!star 3
!support 3
!target 3
!battle 3 7
!dice
!coin
!slot
!random
!mvp
!shoutout
!event
```

Vote streaks, vote milestones, interactive particles, announcements and event overlays remain enabled.

## 24x7 reliability

- Linux automatically uses `libx264`; do not use `h264_mf` on Debian.
- FFmpeg is supervised and restarted after actual encoder failure.
- Bun is supervised by systemd with `Restart=always`.
- SQLite persists votes.
- YouTube chat reconnects automatically.
- Frame input is served locally over MJPEG.
- Memory and encoder watchdogs remain active.
- The service is designed to survive SSH disconnects and VPS reboots.

## Debian installation

1. Install Bun and FFmpeg.
2. Extract this project.
3. Edit `.env` and replace the YouTube placeholders.
4. Run:

```bash
bun install
bun run check
./service-manager.sh install
./service-manager.sh status
```

Follow logs with:

```bash
./service-manager.sh logs
```

or:

```bash
journalctl -u bigg-boss-vps-canvas.service -f
```

Do not run a second copy with `bun start` while systemd is already managing the service.

## Health endpoint

The local health server is available at:

```text
http://127.0.0.1:8787/health
http://127.0.0.1:8787/status
http://127.0.0.1:8787/stats
```

The JSON response includes the current broadcast screen, automatic rotation state, encoder status, renderer state, vote totals and runtime information.

## Resolution

The packaged defaults are:

```env
STREAM_RESOLUTION=1080x1920
RENDER_RESOLUTION=720x1280
```

You can change both independently, for example:

```env
STREAM_RESOLUTION=720x1280
RENDER_RESOLUTION=720x1280
```

## Security

The packaged `.env` contains placeholders only. Never publish a real YouTube stream key inside the ZIP. If a real stream key was exposed previously during troubleshooting, regenerate it in YouTube Studio.


## Multi-screen 10.1 reference layout

The main `LIVE VOTING` screen follows the supplied dark/light reference: top LIVE bar, Bigg Boss eye hero, single-column six-contestant board, three summary cards, music strip, and footer. The remaining contestants are available on `RANK RACE`.

Screen transitions use the actual render canvas dimensions (`W`/`H`) and isolated source canvases, with explicit transform/compositing reset on every frame to prevent zoomed/corrupted frames during slides.

Reference footer values can be configured with `TIME_LEFT_TEXT` and `NOW_PLAYING_TEXT`.
