Contestant images are cached automatically on first startup into data/contestant-images/.

The build references public poster URLs from bigboss20.in for the current Bigg Boss 20 contestant catalog.
The site states it is an unofficial fan site and is not affiliated with Bigg Boss, Colors TV or JioHotstar.
Verify image/broadcast rights before using contestant photographs in a public stream.
