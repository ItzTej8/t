#!/usr/bin/env bash
set -euo pipefail
exec bun run src/index.mjs
