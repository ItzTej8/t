import { writeFile } from "node:fs/promises";
const res = await fetch("https://bigboss20.in/images/bigg-boss-20-contestants-group.jpg", {
  headers: { "User-Agent": "Mozilla/5.0", "Referer": "https://bigboss20.in/" }
});
console.log("Group status:", res.status);
if (res.ok) {
  const buf = Buffer.from(await res.arrayBuffer());
  await writeFile("scratch/group.jpg", buf);
  console.log("Saved scratch/group.jpg", buf.length);
}
