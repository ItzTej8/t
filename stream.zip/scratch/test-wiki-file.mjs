import { writeFile } from "node:fs/promises";
import { join } from "node:path";

async function run() {
  const titles = [
    { no: 4, file: "File:Arishfa Khan in 2017.jpg" },
    { no: 4, file: "File:Arishfa Khan.jpg" }
  ];
  for (const item of titles) {
    const url = `https://commons.wikimedia.org/w/api.php?action=query&titles=${encodeURIComponent(item.file)}&prop=imageinfo&iiprop=url&format=json`;
    const res = await fetch(url, { headers: { "User-Agent": "BiggBossLiveStream/1.0 (https://github.com/biggboss; contact: stream@live.tv)" } });
    const data = await res.json();
    const pages = data.query?.pages || {};
    for (const p of Object.values(pages)) {
      const imgUrl = p.imageinfo?.[0]?.url;
      if (imgUrl) {
        console.log("Found:", imgUrl);
        const imgRes = await fetch(imgUrl, { headers: { "User-Agent": "BiggBossLiveStream/1.0 (https://github.com/biggboss; contact: stream@live.tv)" } });
        if (imgRes.ok) {
          const buf = Buffer.from(await imgRes.arrayBuffer());
          const dest = join("assets", "contestants", `${item.no}.jpg`);
          await writeFile(dest, buf);
          console.log(`Saved ${dest} (${buf.length} bytes)`);
          return;
        }
      }
    }
  }
}
run();
