import { contestants } from "../src/contestants.mjs";
import { writeFile } from "node:fs/promises";
import { join } from "node:path";

async function fetchWiki() {
  for (const c of contestants) {
    const queries = [c.name, c.displayName];
    let found = false;
    for (const q of queries) {
      try {
        const url = `https://en.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(q)}&prop=pageimages&format=json&pithumbsize=600`;
        const res = await fetch(url, {
          headers: {
            "User-Agent": "BiggBossLiveStream/1.0 (https://github.com/biggboss; contact: contact@streamlive.tv)"
          }
        });
        if (!res.ok) continue;
        const data = await res.json();
        const pages = data.query?.pages || {};
        const p = Object.values(pages)[0];
        if (p?.thumbnail?.source) {
          const imgUrl = p.thumbnail.source;
          console.log(`[found] ${c.no} ${c.displayName}: ${imgUrl}`);
          const imgRes = await fetch(imgUrl, {
            headers: {
              "User-Agent": "BiggBossLiveStream/1.0 (https://github.com/biggboss; contact: contact@streamlive.tv)"
            }
          });
          if (imgRes.ok) {
            const buf = Buffer.from(await imgRes.arrayBuffer());
            if (buf.length > 2000) {
              const dest = join("assets", "contestants", `${c.no}.jpg`);
              await writeFile(dest, buf);
              console.log(`[saved] ${dest} (${buf.length} bytes)`);
              found = true;
              break;
            }
          }
        }
      } catch (err) {
        console.warn(`[err] ${c.displayName} query "${q}": ${err.message}`);
      }
    }
    if (!found) {
      console.log(`[missing] ${c.no} ${c.displayName}`);
    }
  }
}

fetchWiki();
