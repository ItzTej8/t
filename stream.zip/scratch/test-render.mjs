import { writeFile } from 'node:fs/promises';
import { initRenderer, drawMainFrame, canvas } from '../src/renderer.mjs';
import { viewerEvent, setScreen, interactiveState } from '../src/interactive.mjs';
import { setBgMusicVolume, getBgMusicVolume } from '../src/frame-server.mjs';
import { state } from '../src/state.mjs';

async function main() {
  console.log('Testing volume control...');
  console.log('Initial volume:', getBgMusicVolume());
  setBgMusicVolume(0.85);
  console.log('Updated volume:', getBgMusicVolume());
  if (Math.round(getBgMusicVolume() * 100) !== 85) throw new Error('Volume set failed');

  console.log('Initializing renderer...');
  await initRenderer();

  // Test 1: Main vote screen with hot badge & risk tags (page 0: ranks 1-6)
  state.chatVoteFlashContestant = 1;
  state.chatVoteFlashAt = Date.now();
  setScreen('main', { manual: true });
  const tPage0 = Math.floor(Date.now() / 25500) * 25500;
  drawMainFrame(tPage0); // guaranteed page 0: ranks 1-6
  const buf1 = canvas.toBuffer('image/jpeg', 85);
  await writeFile('C:/Users/hp/.gemini/antigravity-ide/brain/1a9977a5-caf6-4568-a5e9-63433de420d0/preview_main_voting_p1.jpg', buf1);
  console.log('Saved preview_main_voting_p1.jpg');

  // Test 1b: Race screen
  interactiveState().screenTransition = null;
  setScreen('race', { manual: true });
  interactiveState().screenTransition = null;
  drawMainFrame(tPage0);
  const bufRace = canvas.toBuffer('image/jpeg', 85);
  await writeFile('C:/Users/hp/.gemini/antigravity-ide/brain/1a9977a5-caf6-4568-a5e9-63433de420d0/preview_race_commands.jpg', bufRace);
  console.log('Saved preview_race_commands.jpg');

  // Test 2: Supply drop animation with contestant #8 (Gullu)
  viewerEvent({
    userId: 'test-user-1',
    name: 'XLoss',
    type: 'drop',
    contestant: 8,
    emoji: '🪂',
    payload: { emoji: '🪂', contestant: 8, candidateName: 'Gullu' },
    durationMs: 4800
  });
  // Simulate mid-air drop
  drawMainFrame(Date.now() + 1800);
  // Test 2b: Emoji Balloon drop animation
  viewerEvent({
    userId: 'test-user-3',
    name: 'Tejesh',
    type: 'drop',
    contestant: 0,
    emoji: '🎈',
    payload: { emoji: '🎈', contestant: 0 },
    durationMs: 4800
  });
  drawMainFrame(Date.now() + 1900);
  const buf2b = canvas.toBuffer('image/jpeg', 85);
  await writeFile('C:/Users/hp/.gemini/antigravity-ide/brain/1a9977a5-caf6-4568-a5e9-63433de420d0/preview_drop_balloon.jpg', buf2b);
  console.log('Saved preview_drop_balloon.jpg');

  // Test 3: Screen transition with 3D depth and laser streak
  interactiveState().screenTransition = {
    from: 'main',
    to: 'race',
    startedAt: Date.now(),
    durationMs: 650
  };
  drawMainFrame(Date.now() + 325); // exactly 50% transition
  const buf3 = canvas.toBuffer('image/jpeg', 85);
  await writeFile('C:/Users/hp/.gemini/antigravity-ide/brain/1a9977a5-caf6-4568-a5e9-63433de420d0/preview_transition_scale.jpg', buf3);
  console.log('Saved preview_transition_scale.jpg');

  // Test 4: Fortune wheel
  interactiveState().screenTransition = null;
  viewerEvent({
    userId: 'test-user-2',
    name: 'Tej',
    type: 'wheel',
    payload: {
      winner: '🏆 JACKPOT',
      winIdx: 7,
      finalAngle: Math.PI * 9.5,
      options: ['🌟 2X VOTE', '💎 500 PTS', '👑 VIP FAN', '⚡ BOOST', '🔥 HYPE', '🎁 MYSTERY', '🎯 CROWN', '🏆 JACKPOT']
    },
    durationMs: 5500
  });
  drawMainFrame(Date.now() + 4000); // wheel stopped, jackpot showing
  const buf4 = canvas.toBuffer('image/jpeg', 85);
  await writeFile('C:/Users/hp/.gemini/antigravity-ide/brain/1a9977a5-caf6-4568-a5e9-63433de420d0/preview_wheel_anim.jpg', buf4);
  console.log('Saved preview_wheel_anim.jpg');

  console.log('All test frames rendered successfully!');
  process.exit(0);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
