import { writeFile } from "node:fs/promises";

async function run() {
  const url = "https://commons.wikimedia.org/w/api.php?action=query&titles=File:Natasha_Suri_Portrait.JPG&prop=imageinfo&iiprop=url&format=json";
  const res = await fetch(url, { headers: { "User-Agent": "BiggBossLiveStream/1.0" } });
  const data = await res.json();
  const page = Object.values(data.query.pages)[0];
  const imgUrl = page?.imageinfo?.[0]?.url;
  if (imgUrl) {
    const imgRes = await fetch(imgUrl, { headers: { "User-Agent": "BiggBossLiveStream/1.0" } });
    if (imgRes.ok) {
      const buf = Buffer.from(await imgRes.arrayBuffer());
      await writeFile("assets/contestants/9.jpg", buf);
      console.log("Saved assets/contestants/9.jpg", buf.length);
    }
  }
}
run();
