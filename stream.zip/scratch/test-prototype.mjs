import { createCanvas, loadImage } from "@napi-rs/canvas";
import { writeFile, readFile } from "node:fs/promises";

const BASE_W = 1080, BASE_H = 1920;
// Test at 720x1280 (the configured render resolution)
const W = 720, H = 1280;
const sx = W / BASE_W, sy = H / BASE_H, sc = Math.min(sx, sy);
const px = v => v * sx, py = v => v * sy, ps = v => v * sc;

function safeWeight(w) {
  if (typeof w === 'number') return Math.min(900, Math.max(100, Math.round(w / 100) * 100));
  const str = String(w).toLowerCase().trim();
  if (str === 'bold' || str === 'normal') return str;
  const num = parseInt(str, 10);
  if (!isNaN(num)) return Math.min(900, Math.max(100, Math.round(num / 100) * 100));
  return 700;
}

function rr(c, x, y, w, h, r = 14) {
  c.beginPath();
  c.roundRect(px(x), py(y), ps(w), ps(h), ps(r));
}

function textC(c, v, x, y, size, color, weight = 700, align = "left") {
  const w = safeWeight(weight);
  const sz = Math.max(8, Math.round(ps(size)));
  c.font = `${w} ${sz}px "Segoe UI", Arial, sans-serif`;
  c.fillStyle = color;
  c.textAlign = align;
  c.textBaseline = "alphabetic";
  c.fillText(String(v ?? ""), px(x), py(y));
}

function palette(theme) {
  if (theme === "light") {
    return {
      theme: "light",
      bg: "#f8f9fa",
      bgTop: "#fff8ea",
      bgBot: "#f3f5f8",
      panel: "rgba(255, 255, 255, 0.96)",
      card: "#ffffff",
      cardBorder: "#e2e8f0",
      cardShadow: "rgba(15, 23, 42, 0.08)",
      text: "#0f172a",
      titleText: "#10203b",
      muted: "#64748b",
      line: "#e2e8f0",
      gold: "#d49a18",
      goldBright: "#f59e0b",
      goldMetallic: "#eab308",
      gold3dDark: "#a16207",
      navyPill: "#0b1a30",
      barBg: "#e2e8f0",
      rankGradients: [
        ["#facc15", "#eab308"], // 1 Gold
        ["#38bdf8", "#0284c7"], // 2 Blue
        ["#f472b6", "#db2777"], // 3 Pink
        ["#4ade80", "#16a34a"], // 4 Green
        ["#c084fc", "#9333ea"], // 5 Purple
        ["#f87171", "#dc2626"]  // 6 Red
      ]
    };
  }
  return {
    theme: "dark",
    bg: "#030712",
    bgTop: "#081325",
    bgBot: "#02050c",
    panel: "rgba(8, 17, 33, 0.96)",
    card: "rgba(10, 20, 38, 0.95)",
    cardBorder: "rgba(148, 163, 184, 0.18)",
    cardShadow: "rgba(0, 0, 0, 0.6)",
    text: "#f8fafc",
    titleText: "#ffffff",
    muted: "#94a3b8",
    line: "rgba(148, 163, 184, 0.2)",
    gold: "#f5c542",
    goldBright: "#fbbf24",
    goldMetallic: "#ffd700",
    gold3dDark: "#b45309",
    navyPill: "#081528",
    barBg: "#17263c",
    rankGradients: [
      ["#fbbf24", "#d97706"], // 1 Gold
      ["#38bdf8", "#0284c7"], // 2 Blue
      ["#f472b6", "#db2777"], // 3 Pink
      ["#4ade80", "#16a34a"], // 4 Green
      ["#c084fc", "#9333ea"], // 5 Purple
      ["#f87171", "#dc2626"]  // 6 Red
    ]
  };
}

function drawBackground(c, p, now) {
  // Base background fill
  c.fillStyle = p.bg;
  c.fillRect(0, 0, W, H);

  // Gradient backdrop
  const grad = c.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, p.bgTop);
  grad.addColorStop(0.4, p.bg);
  grad.addColorStop(1, p.bgBot);
  c.fillStyle = grad;
  c.fillRect(0, 0, W, H);

  // Radiant golden glow behind top/hero
  const rad = c.createRadialGradient(px(540), py(220), ps(20), px(540), py(220), ps(550));
  if (p.theme === "light") {
    rad.addColorStop(0, "rgba(251, 191, 36, 0.25)");
    rad.addColorStop(0.5, "rgba(245, 158, 11, 0.08)");
    rad.addColorStop(1, "transparent");
  } else {
    rad.addColorStop(0, "rgba(245, 197, 66, 0.20)");
    rad.addColorStop(0.5, "rgba(217, 119, 6, 0.07)");
    rad.addColorStop(1, "transparent");
  }
  c.fillStyle = rad;
  c.fillRect(0, 0, W, py(700));

  // Golden starlight sparkles
  c.save();
  for (let i = 0; i < 28; i++) {
    const x = (i * 97 + Math.sin(now * 0.0006 + i * 2) * 35) % 1080;
    const y = (i * 137 + (now * 0.02 * (i % 3 + 1))) % 1800;
    const alpha = (0.2 + 0.6 * Math.sin(now * 0.002 + i));
    c.fillStyle = p.theme === "light"
      ? `rgba(217, 119, 6, ${alpha * 0.15})`
      : `rgba(251, 191, 36, ${alpha * 0.25})`;
    c.beginPath();
    c.arc(px(x), py(y), ps(1.5 + (i % 3)), 0, Math.PI * 2);
    c.fill();
  }
  c.restore();
}

function drawTopBar(c, p, now) {
  const y = 32, h = 68;

  // LIVE Pill Badge
  c.fillStyle = "#ef233c";
  rr(c, 48, y, 175, h, h / 2);
  c.fill();
  // Play triangle
  c.fillStyle = "#ffffff";
  c.beginPath();
  c.moveTo(px(72), py(y + 20));
  c.lineTo(px(72), py(y + 48));
  c.lineTo(px(94), py(y + 34));
  c.closePath();
  c.fill();
  textC(c, "LIVE", 104, y + 46, 26, "#ffffff", 800);

  // Stream Duration (02:14:36)
  textC(c, "02:14:36", 260, y + 47, 30, p.text, 700);

  // Viewers Count (1.2K)
  // Draw people icon
  c.fillStyle = p.muted;
  c.beginPath();
  c.arc(px(468), py(y + 30), ps(9), 0, Math.PI * 2);
  c.fill();
  c.beginPath();
  c.arc(px(468), py(y + 54), ps(15), Math.PI, Math.PI * 2);
  c.fill();

  textC(c, "1.2K", 495, y + 47, 28, p.text, 700);

  // Theme Pill Toggle (Right)
  const tw = 270, tx = 1080 - 48 - tw;
  c.fillStyle = p.theme === "light" ? "#ffffff" : "rgba(15, 23, 42, 0.9)";
  rr(c, tx, y, tw, h, h / 2);
  c.fill();
  c.strokeStyle = p.theme === "light" ? "#cbd5e1" : "rgba(245, 197, 66, 0.4)";
  c.lineWidth = ps(2);
  rr(c, tx, y, tw, h, h / 2);
  c.stroke();

  if (p.theme === "light") {
    textC(c, "Theme: LIGHT ☀️", tx + tw / 2, y + 45, 22, p.titleText, 700, "center");
  } else {
    textC(c, "Theme: DARK 🌙", tx + tw / 2, y + 45, 22, p.text, 700, "center");
  }
}

function drawEye(c, p, cx, cy, scale = 1, now = Date.now()) {
  c.save();
  c.translate(px(cx), py(cy));
  c.scale(sc * scale, sc * scale);

  const pulse = 1 + Math.sin(now * 0.003) * 0.025;
  c.scale(pulse, pulse);

  // Outer glowing aura
  const aura = c.createRadialGradient(0, 0, 40, 0, 0, 180);
  aura.addColorStop(0, "rgba(245, 197, 66, 0.35)");
  aura.addColorStop(1, "transparent");
  c.fillStyle = aura;
  c.beginPath();
  c.arc(0, 0, 180, 0, Math.PI * 2);
  c.fill();

  // Outer golden eyelid shape
  c.beginPath();
  c.moveTo(-160, 0);
  c.quadraticCurveTo(0, -115, 160, 0);
  c.quadraticCurveTo(0, 115, -160, 0);
  c.closePath();
  c.strokeStyle = p.goldBright;
  c.lineWidth = 10;
  c.stroke();

  // Secondary inner eyelid ring
  c.beginPath();
  c.moveTo(-138, 0);
  c.quadraticCurveTo(0, -90, 138, 0);
  c.quadraticCurveTo(0, 90, -138, 0);
  c.closePath();
  c.strokeStyle = p.gold3dDark;
  c.lineWidth = 4;
  c.stroke();

  // Golden eyelash rays radiating from top and bottom
  c.strokeStyle = p.goldBright;
  c.lineWidth = 3.5;
  for (let a = -70; a <= 70; a += 14) {
    const rad = (a * Math.PI) / 180;
    const lenTop = 18 + Math.cos(rad) * 12;
    const x0 = Math.sin(rad) * 135;
    const y0 = -Math.cos(rad) * 80;
    c.beginPath();
    c.moveTo(x0, y0);
    c.lineTo(x0 * 1.15, y0 - lenTop);
    c.stroke();
  }

  // Iris circle
  c.beginPath();
  c.arc(0, 0, 68, 0, Math.PI * 2);
  const irisGrad = c.createRadialGradient(-10, -10, 4, 0, 0, 70);
  irisGrad.addColorStop(0, "#a5f3fc");
  irisGrad.addColorStop(0.25, "#38bdf8");
  irisGrad.addColorStop(0.65, "#0284c7");
  irisGrad.addColorStop(1, "#082f49");
  c.fillStyle = irisGrad;
  c.fill();
  c.strokeStyle = p.goldMetallic;
  c.lineWidth = 6;
  c.stroke();

  // Geometric radial lines inside iris
  c.strokeStyle = "rgba(255, 255, 255, 0.35)";
  c.lineWidth = 1.5;
  for (let i = 0; i < 16; i++) {
    const ang = (i * Math.PI) / 8;
    c.beginPath();
    c.moveTo(Math.cos(ang) * 22, Math.sin(ang) * 22);
    c.lineTo(Math.cos(ang) * 64, Math.sin(ang) * 64);
    c.stroke();
  }

  // Dark pupil
  c.beginPath();
  c.arc(0, 0, 26, 0, Math.PI * 2);
  c.fillStyle = "#020617";
  c.fill();

  // Central golden starburst inside pupil
  c.fillStyle = "#ffedd5";
  for (let i = 0; i < 8; i++) {
    const ang = (i * Math.PI) / 4 + now * 0.001;
    c.beginPath();
    c.moveTo(0, 0);
    c.lineTo(Math.cos(ang) * 16, Math.sin(ang) * 16);
    c.strokeStyle = "#fbbf24";
    c.lineWidth = 2.5;
    c.stroke();
  }

  // Specular light reflection glint
  c.beginPath();
  c.arc(-14, -14, 9, 0, Math.PI * 2);
  c.fillStyle = "rgba(255, 255, 255, 0.9)";
  c.fill();

  c.restore();
}

function drawHero(c, p, now, subtitle = "LIVE VOTING") {
  // Eye in center
  drawEye(c, p, 540, 205, 0.95, now);

  // Stacked side text on the top right
  const sideY = 160;
  const sideColor = p.theme === "light" ? p.titleText : p.goldBright;
  const words = ["WATCH", "VOTE", "SUPPORT", "YOUR", "FAVOURITE!"];
  words.forEach((w, i) => {
    textC(c, w, 890, sideY + i * 28, 22, sideColor, 800, "center");
  });

  // 3D Metallic "BIGG BOSS" Title
  const titleY = 300;
  c.save();
  // 3D extrusion shadows
  const textVal = "BIGG BOSS";
  const size = 68;
  const layers = [
    { dy: 6, col: p.gold3dDark },
    { dy: 4, col: "#92400e" },
    { dy: 2, col: "#b45309" }
  ];
  for (const l of layers) {
    textC(c, textVal, 540, titleY + l.dy, size, l.col, 900, "center");
  }
  // Metallic gradient face
  const tGrad = c.createLinearGradient(0, py(titleY - size), 0, py(titleY));
  tGrad.addColorStop(0, "#fffbeb");
  tGrad.addColorStop(0.35, "#fde68a");
  tGrad.addColorStop(0.7, "#f59e0b");
  tGrad.addColorStop(1, "#b45309");
  textC(c, textVal, 540, titleY, size, tGrad, 900, "center");
  c.restore();

  // "LIVE VOTING" Blue Pill
  const pillW = 380, pillH = 50, pillX = 540 - pillW / 2, pillY = 328;
  c.fillStyle = p.navyPill;
  rr(c, pillX, pillY, pillW, pillH, pillH / 2);
  c.fill();
  c.strokeStyle = p.goldBright;
  c.lineWidth = ps(2.5);
  rr(c, pillX, pillY, pillW, pillH, pillH / 2);
  c.stroke();
  textC(c, subtitle, 540, pillY + 35, 25, p.goldBright, 800, "center");

  // Subtitle: "YOUR VOTE COUNTS!  VOTE NOW!"
  const subColor = p.theme === "light" ? p.titleText : p.goldBright;
  textC(c, "YOUR VOTE COUNTS!  VOTE NOW!", 540, 420, 24, subColor, 800, "center");
}

function drawAvatar(c, no, x, y, r, p) {
  c.save();
  c.beginPath();
  c.arc(px(x), py(y), ps(r), 0, Math.PI * 2);
  c.clip();

  // High quality procedural portrait
  const skins = ["#f5d0b5", "#e8b894", "#dfa680", "#f3cfb3", "#d99d75", "#efc29e"];
  const hairs = ["#171717", "#261c14", "#1c1917", "#2e2118", "#18181b", "#27272a"];
  const shirts = ["#1e293b", "#334155", "#0f172a", "#1e1b4b", "#312e81", "#1e3a8a"];

  const skin = skins[(no - 1) % skins.length];
  const hair = hairs[(no - 1) % hairs.length];
  const shirt = shirts[(no - 1) % shirts.length];
  const isFemale = (no === 3 || no === 5); // Mannara, Ankita

  // Shirt background
  c.fillStyle = shirt;
  c.fillRect(px(x - r), py(y), ps(r * 2), ps(r));

  // Face
  c.fillStyle = skin;
  c.beginPath();
  c.arc(px(x), py(y - 5), ps(r * 0.58), 0, Math.PI * 2);
  c.fill();

  // Neck
  c.fillRect(px(x - r * 0.22), py(y + 8), ps(r * 0.44), ps(r * 0.35));

  // Hair
  c.fillStyle = hair;
  if (isFemale) {
    // Long hair
    c.beginPath();
    c.arc(px(x), py(y - 12), ps(r * 0.65), Math.PI * 0.8, Math.PI * 2.2);
    c.fill();
    c.fillRect(px(x - r * 0.62), py(y - 8), ps(r * 0.24), ps(r * 0.85));
    c.fillRect(px(x + r * 0.38), py(y - 8), ps(r * 0.24), ps(r * 0.85));
  } else {
    // Male hairstyle + beard
    c.beginPath();
    c.arc(px(x), py(y - 14), ps(r * 0.6), Math.PI * 0.85, Math.PI * 2.15);
    c.fill();
    // Subtle beard
    c.fillStyle = "rgba(0, 0, 0, 0.25)";
    c.beginPath();
    c.arc(px(x), py(y + 2), ps(r * 0.48), 0, Math.PI);
    c.fill();
  }

  // Eyes & smile
  c.fillStyle = "#0f172a";
  c.beginPath();
  c.arc(px(x - r * 0.2), py(y - 6), ps(2.8), 0, Math.PI * 2);
  c.arc(px(x + r * 0.2), py(y - 6), ps(2.8), 0, Math.PI * 2);
  c.fill();

  c.strokeStyle = "#0f172a";
  c.lineWidth = ps(2);
  c.beginPath();
  c.arc(px(x), py(y + 2), ps(6), 0.15 * Math.PI, 0.85 * Math.PI);
  c.stroke();

  c.restore();

  // Rim border
  c.strokeStyle = p.theme === "light" ? "#cbd5e1" : p.goldBright;
  c.lineWidth = ps(2);
  c.beginPath();
  c.arc(px(x), py(y), ps(r + 1), 0, Math.PI * 2);
  c.stroke();
}

function drawVoteRow(c, p, item, rank, totalVotes, maxVotes, now, y) {
  const h = 134, w = 1000, x = 40;
  const colors = p.rankGradients[rank % p.rankGradients.length];

  // Card background
  c.save();
  c.shadowColor = p.cardShadow;
  c.shadowBlur = ps(10);
  c.shadowOffsetY = ps(4);
  c.fillStyle = p.card;
  rr(c, x, y, w, h, 20);
  c.fill();
  c.restore();

  // Card outline border
  c.strokeStyle = p.cardBorder;
  c.lineWidth = ps(1.5);
  rr(c, x, y, w, h, 20);
  c.stroke();

  // 1. Rank Circle Badge (Left)
  const rankX = x + 54, rankY = y + h / 2, rankR = 34;
  const rGrad = c.createLinearGradient(px(rankX), py(rankY - rankR), px(rankX), py(rankY + rankR));
  rGrad.addColorStop(0, colors[0]);
  rGrad.addColorStop(1, colors[1]);
  c.fillStyle = rGrad;
  c.beginPath();
  c.arc(px(rankX), py(rankY), ps(rankR), 0, Math.PI * 2);
  c.fill();
  // Rank number
  const rankNumColor = (rank === 0 && p.theme === "light") ? "#78350f" : "#ffffff";
  textC(c, String(rank + 1), rankX, rankY + 11, 32, rankNumColor, 800, "center");

  // 2. Contestant Avatar
  const avX = x + 148, avY = y + h / 2, avR = 44;
  drawAvatar(c, item.no, avX, avY, avR, p);

  // 3. Contestant Name (Bold, Crisp)
  textC(c, item.name, x + 218, y + 54, 30, p.text, 800);

  // 4. Vote Count (Right-aligned)
  const votesStr = Number(item.votes || 0).toLocaleString();
  textC(c, votesStr, x + 760, y + 54, 26, p.text, 700, "right");

  // 5. Percentage Box (Far Right)
  const pct = totalVotes > 0 ? (item.votes / totalVotes) * 100 : item.pct || 0;
  const boxW = 120, boxH = 58, boxX = x + w - boxW - 22, boxY = y + (h - boxH) / 2;
  c.strokeStyle = p.line;
  c.lineWidth = ps(1.8);
  rr(c, boxX, boxY, boxW, boxH, 12);
  c.stroke();
  textC(c, `${Math.round(pct)}%`, boxX + boxW / 2, boxY + 39, 29, p.text, 800, "center");

  // 6. Colored Progress Bar (Below Name & Count)
  const barX = x + 218, barY = y + 78, barW = 542, barH = 18;
  // Background track
  c.fillStyle = p.barBg;
  rr(c, barX, barY, barW, barH, barH / 2);
  c.fill();
  // Colored progress fill
  const ratio = maxVotes > 0 ? Math.min(1, Math.max(0.04, item.votes / maxVotes)) : (pct / 100);
  const fillW = Math.max(barH, barW * ratio);
  const pGrad = c.createLinearGradient(px(barX), 0, px(barX + fillW), 0);
  pGrad.addColorStop(0, colors[0]);
  pGrad.addColorStop(1, colors[1]);
  c.fillStyle = pGrad;
  rr(c, barX, barY, fillW, barH, barH / 2);
  c.fill();
}

function drawBottomStats(c, p, totalVotes, uniqueVoters, timeLeft) {
  const y = 1370, h = 130, w = 316, gap = 26;
  const cards = [
    { x: 40, label: "TOTAL VOTES", val: Number(totalVotes).toLocaleString(), icon: "chart" },
    { x: 40 + w + gap, label: "UNIQUE VOTERS", val: Number(uniqueVoters).toLocaleString(), icon: "users" },
    { x: 40 + (w + gap) * 2, label: "TIME LEFT", val: timeLeft, icon: "clock" }
  ];

  cards.forEach(cd => {
    // Card box
    c.fillStyle = p.card;
    rr(c, cd.x, y, w, h, 20);
    c.fill();
    c.strokeStyle = p.cardBorder;
    c.lineWidth = ps(1.5);
    rr(c, cd.x, y, w, h, 20);
    c.stroke();

    // Icon on left
    const icX = cd.x + 48, icY = y + h / 2;
    if (cd.icon === "chart") {
      // 3 gold bars
      c.fillStyle = p.goldBright;
      rr(c, icX - 16, icY + 6, 8, 20, 3);
      c.fill();
      rr(c, icX - 4, icY - 4, 8, 30, 3);
      c.fill();
      rr(c, icX + 8, icY - 14, 8, 40, 3);
      c.fill();
    } else if (cd.icon === "users") {
      // 2 user busts
      c.fillStyle = p.theme === "light" ? p.goldBright : "#38bdf8";
      c.beginPath();
      c.arc(px(icX - 6), py(icY - 6), ps(10), 0, Math.PI * 2);
      c.fill();
      c.beginPath();
      c.arc(px(icX - 6), py(icY + 20), ps(18), Math.PI, Math.PI * 2);
      c.fill();
      c.beginPath();
      c.arc(px(icX + 12), py(icY - 2), ps(8), 0, Math.PI * 2);
      c.fill();
      c.beginPath();
      c.arc(px(icX + 12), py(icY + 20), ps(14), Math.PI, Math.PI * 2);
      c.fill();
    } else {
      // Clock
      c.strokeStyle = p.theme === "light" ? p.text : "#f43f5e";
      c.lineWidth = ps(3);
      c.beginPath();
      c.arc(px(icX), py(icY), ps(20), 0, Math.PI * 2);
      c.stroke();
      // Hands
      c.beginPath();
      c.moveTo(px(icX), py(icY));
      c.lineTo(px(icX), py(icY - 12));
      c.moveTo(px(icX), py(icY));
      c.lineTo(px(icX + 10), py(icY));
      c.stroke();
    }

    // Label & Value
    textC(c, cd.label, cd.x + 94, y + 48, 17, p.muted, 700);
    textC(c, cd.val, cd.x + 94, y + 95, 30, p.text, 800);
  });
}

function drawFooter(c, p) {
  const y = 1530, h = 60;

  // Thin separator line
  c.strokeStyle = p.line;
  c.lineWidth = ps(1);
  c.beginPath();
  c.moveTo(px(40), py(y));
  c.lineTo(px(1040), py(y));
  c.stroke();

  // Centered footer ticker
  const midY = y + 40;
  textC(c, "BIGG BOSS 24/7 LIVE", 160, midY, 20, p.text, 800, "center");
  textC(c, "👑  \"BADI BAATEIN, BADA SHOW!\"", 540, midY, 20, p.goldBright, 800, "center");
  textC(c, "STAY TUNED!", 920, midY, 20, p.text, 800, "center");
}

async function renderScreenshot(theme, outFile) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d", { alpha: false });
  const p = palette(theme);
  const now = Date.now();

  drawBackground(ctx, p, now);
  drawTopBar(ctx, p, now);
  drawHero(ctx, p, now, "LIVE VOTING");

  const sampleContestants = [
    { no: 1, name: "Abhishek", votes: 12548, pct: 28 },
    { no: 2, name: "Munawar", votes: 10234, pct: 23 },
    { no: 3, name: "Mannara", votes: 8761, pct: 20 },
    { no: 4, name: "Arun", votes: 6543, pct: 15 },
    { no: 5, name: "Ankita", votes: 4321, pct: 10 },
    { no: 6, name: "Vicky", votes: 1987, pct: 4 }
  ];

  const totalVotes = 44344;
  const uniqueVoters = 12876;
  const timeLeft = "2D 5H 45M";
  const maxVotes = sampleContestants[0].votes;

  const rowY = 460, rowH = 144, gap = 8;
  sampleContestants.forEach((cItem, i) => {
    drawVoteRow(ctx, p, cItem, i, totalVotes, maxVotes, now, rowY + i * (rowH + gap));
  });

  drawBottomStats(ctx, p, totalVotes, uniqueVoters, timeLeft);
  drawFooter(ctx, p);

  const buf = canvas.toBuffer("image/jpeg", 95);
  await writeFile(outFile, buf);
  console.log(`Rendered ${theme} -> ${outFile} (${buf.length} bytes)`);
}

async function run() {
  await renderScreenshot("light", "scratch/output_light.jpg");
  await renderScreenshot("dark", "scratch/output_dark.jpg");
}
run();
