import { writeFile, stat } from "node:fs/promises";
import { join } from "node:path";

const candidates = [
  { no: 3, query: "Uditi Singh" },
  { no: 4, query: "Arishfa Khan" },
  { no: 5, query: "Aman Gandhi actor" },
  { no: 6, query: "Qazi Touqeer" },
  { no: 7, query: "Harsh Machare" },
  { no: 8, query: "Kushal Tanwar" },
  { no: 9, query: "Rhiya Yadav" },
  { no: 10, query: "Love Gill actress" },
  { no: 11, query: "Rohed Khan" },
  { no: 15, query: "Rhiti Tiwari" },
  { no: 17, query: "ScoutOP Tanmay Singh" }
];

async function run() {
  for (const item of candidates) {
    const dest = join("assets", "contestants", `${item.no}.jpg`);
    try {
      await stat(dest);
      console.log(`Already have ${item.no}`);
      continue;
    } catch {}

    const url = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrsearch=${encodeURIComponent(item.query)}&prop=imageinfo&iiprop=url&format=json`;
    try {
      const res = await fetch(url, { headers: { "User-Agent": "BiggBossLiveStream/1.0 (https://github.com/biggboss; contact: stream@live.tv)" } });
      const data = await res.json();
      const pages = data.query?.pages || {};
      for (const p of Object.values(pages)) {
        const imgUrl = p.imageinfo?.[0]?.url;
        if (imgUrl && !imgUrl.endsWith(".svg") && !imgUrl.endsWith(".pdf") && !imgUrl.endsWith(".ogg")) {
          console.log(`Trying ${item.no} -> ${imgUrl}`);
          const imgRes = await fetch(imgUrl, { headers: { "User-Agent": "BiggBossLiveStream/1.0 (https://github.com/biggboss; contact: stream@live.tv)" } });
          if (imgRes.ok) {
            const buf = Buffer.from(await imgRes.arrayBuffer());
            if (buf.length > 5000) {
              await writeFile(dest, buf);
              console.log(`Saved ${dest} (${buf.length} bytes)`);
              break;
            }
          }
        }
      }
    } catch (e) {
      console.log(`Error ${item.no}: ${e.message}`);
    }
  }
}
run();
