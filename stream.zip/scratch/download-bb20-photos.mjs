import { writeFile } from "node:fs/promises";
import { join } from "node:path";

const mapping = [
  { no: 1,  name: "Mary Kom",      url: "https://bigboss20.in/images/mc-mary-kom-avatar.jpg" },
  { no: 2,  name: "Amrapali",      url: "https://bigboss20.in/images/aamrapali-dubey-avatar.jpg" },
  { no: 3,  name: "Uditi Singh",   url: "https://bigboss20.in/images/uditi-singh-avatar.jpg" },
  { no: 4,  name: "Arishfa Khan",  url: "https://bigboss20.in/images/arishfa-khan-avatar.jpg" },
  { no: 5,  name: "Aman Gandhi",   url: "https://bigboss20.in/images/aman-gandhi-avatar.jpg" },
  { no: 6,  name: "Qazi Touqeer",  url: "https://bigboss20.in/images/qazi-ahmad-tauqeer-avatar.jpg" },
  { no: 7,  name: "Yung DSA",      url: "https://bigboss20.in/images/harsh-machare-yung-dsa-avatar.jpg" },
  { no: 8,  name: "Gullu",         url: "https://bigboss20.in/images/kushal-tanwar-gullu-avatar.jpg" },
  { no: 9,  name: "Rhiya Ahir",    url: "https://bigboss20.in/images/rhiya-ahir-avatar.jpg" },
  { no: 10, name: "Love Gill",     url: "https://bigboss20.in/images/love-gill-avatar.jpg" },
  { no: 11, name: "Rohed Khan",    url: "https://bigboss20.in/images/rohed-khan-avatar.jpg" },
  { no: 12, name: "Isha Rikhi",    url: "https://bigboss20.in/images/isha-rikhi-avatar.jpg" },
  { no: 13, name: "Mahhi Vij",     url: "https://bigboss20.in/images/mahhi-vij-avatar.jpg" },
  { no: 14, name: "Aasif Khan",    url: "https://bigboss20.in/images/aasif-khan-avatar.jpg" },
  { no: 15, name: "Rhiti Tiwari",  url: "https://bigboss20.in/images/rhiti-tiwari-avatar.jpg" },
  { no: 16, name: "Kanika Mann",   url: "https://bigboss20.in/images/kanika-mann-avatar.jpg" },
  { no: 17, name: "ScoutOP",       url: "https://bigboss20.in/images/tanmay-singh-scoutop-avatar.jpg" },
];

async function run() {
  for (const item of mapping) {
    const dest = join("assets", "contestants", `${item.no}.jpg`);
    console.log(`Downloading ${item.no}: ${item.name} from ${item.url}...`);
    try {
      const res = await fetch(item.url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
          "Referer": "https://bigboss20.in/"
        }
      });
      if (!res.ok) {
        console.warn(`HTTP ${res.status} for ${item.no}`);
        continue;
      }
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length > 1000) {
        await writeFile(dest, buf);
        console.log(`  Saved ${dest} (${buf.length} bytes)`);
      } else {
        console.warn(`  File too small: ${buf.length}`);
      }
    } catch (e) {
      console.error(`  Failed: ${e.message}`);
    }
  }
}
run();
