import { createCanvas } from "@napi-rs/canvas";
import { writeFile } from "node:fs/promises";
import { state } from "./src/state.mjs";
import { config } from "./src/config.mjs";
import { setScreen, interactiveState } from "./src/interactive.mjs";
import * as renderer from "./src/renderer.mjs";

console.log("Testing all screens and slide transition...");

const W = config.renderWidth, H = config.renderHeight;
const canvas = createCanvas(W, H);
const ctx = canvas.getContext("2d", { alpha: false });

const screens = ["main", "race", "stats", "supporters", "menu", "events"];

async function run() {
  for (const theme of ["dark", "light"]) {
    state.theme = theme;
    for (const screen of screens) {
      setScreen(screen, { manual: true });
      // Render to test canvas
      const testCanvas = createCanvas(W, H);
      const testCtx = testCanvas.getContext("2d", { alpha: false });
      // Draw frame
      // We can call drawMainFrame or test individual scenes
      interactiveState().screen = screen;
      interactiveState().screenTransition = null;
      // Let's call renderer's internal or test script
    }
  }
}
