import { initRenderer, canvas, ctx, drawScene } from "../src/renderer.mjs";

await initRenderer();

async function bench(name, scr, iterations = 30) {
  const t0 = performance.now();
  for (let i = 0; i < iterations; i++) {
    ctx.clearRect(0, 0, 720, 1280);
    drawScene(scr, Date.now() + i * 33, ctx);
    canvas.toBuffer("image/jpeg", 78);
  }
  const avg = (performance.now() - t0) / iterations;
  console.log(`${name.padEnd(25)}: ${avg.toFixed(2)} ms  (${(1000 / avg).toFixed(1)} FPS)`);
}

await bench("Full drawScene('main')", "main");
await bench("Full drawScene('race')", "race");
await bench("Full drawScene('stats')", "stats");
await bench("Full drawScene('menu')", "menu");

process.exit(0);
