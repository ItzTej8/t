const urls = [
  'https://bigboss20.in/images/rhiya-ahir.jpg',
  'https://bigboss20.in/images/rhiya-yadav.jpg',
  'https://bigboss20.in/images/rhiya-yadav-avatar.jpg',
  'https://bigboss20.in/images/rhiya-avatar.jpg',
  'https://bigboss20.in/images/riya-ahir-avatar.jpg',
  'https://bigboss20.in/images/riya-yadav-avatar.jpg',
  'https://bigboss20.in/images/riya-ahir.jpg'
];

for (const u of urls) {
  try {
    const res = await fetch(u, { method: "HEAD", headers: { "User-Agent": "Mozilla/5.0" } });
    console.log(u, "=>", res.status);
  } catch (e) {
    console.log(u, "=>", e.message);
  }
}
