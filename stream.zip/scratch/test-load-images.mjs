import { loadContestantImages } from "../src/image-cache.mjs";

const m = await loadContestantImages();
console.log("Loaded count:", m.size);
for (const [k, v] of m) {
  console.log(`Contestant ${k} -> ${v}`);
}
