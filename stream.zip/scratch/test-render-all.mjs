import { writeFile } from "node:fs/promises";
import { state } from "../src/state.mjs";
import { config } from "../src/config.mjs";
import { setScreen, interactiveState } from "../src/interactive.mjs";
import { drawScene, drawMainFrame, initRenderer, canvas, ctx } from "../src/renderer.mjs";
import { viewerEvent } from "../src/interactive.mjs";

console.log("Starting full render test across all screens and transitions...");

const screens = ["main", "race", "stats", "supporters", "menu", "events"];

async function testScreens() {
  await initRenderer();
  for (const theme of ["light", "dark"]) {
    state.theme = theme;
    for (const scr of screens) {
      interactiveState().screen = scr;
      interactiveState().screenTransition = null;
      drawScene(scr, Date.now(), ctx);
      const buf = canvas.toBuffer("image/jpeg", 90);
      const filename = `scratch/${theme}_${scr}.jpg`;
      await writeFile(filename, buf);
      console.log(`Saved ${filename} (${buf.length} bytes)`);
    }
  }

  // Test slide transition from main to race at 50%
  state.theme = "dark";
  interactiveState().screen = "race";
  interactiveState().screenTransition = {
    from: "main",
    to: "race",
    startedAt: Date.now() - 300,
    durationMs: 600
  };
  drawMainFrame(Date.now());
  const slideBuf = canvas.toBuffer("image/jpeg", 90);
  await writeFile("scratch/slide_transition_50pct.jpg", slideBuf);
  console.log(`Saved scratch/slide_transition_50pct.jpg (${slideBuf.length} bytes)`);

  // Test interactive battle card
  interactiveState().screenTransition = null;
  interactiveState().screen = "main";
  viewerEvent({
    userId: "test1",
    name: "Aman Fan",
    type: "battle",
    contestant: 1,
    payload: { a: 1, b: 2 },
    durationMs: 8000
  });
  drawScene("main", Date.now(), ctx);
  const battleBuf = canvas.toBuffer("image/jpeg", 90);
  await writeFile("scratch/dark_battle.jpg", battleBuf);
  console.log(`Saved scratch/dark_battle.jpg (${battleBuf.length} bytes)`);

  console.log("All renders completed successfully!");
}

testScreens().catch(err => {
  console.error("Test failed:", err);
  process.exit(1);
});
