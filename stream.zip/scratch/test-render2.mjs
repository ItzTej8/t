import { createCanvas } from "@napi-rs/canvas";
import { writeFile } from "node:fs/promises";
import { config } from "../src/config.mjs";

const BASE_W=1080, BASE_H=1920, W=config.renderWidth, H=config.renderHeight;
const sx=W/BASE_W, sy=H/BASE_H, sc=Math.min(sx,sy);
const px=v=>v*sx, py=v=>v*sy, ps=v=>v*sc;
const canvas=createCanvas(W,H); const ctx=canvas.getContext("2d",{alpha:false});

function text(v,x,y,size,color,weight=700,align="left"){
  ctx.font=`${weight} ${ps(size)}px "Segoe UI",Arial,sans-serif`;
  ctx.fillStyle=color;
  ctx.textAlign=align;
  ctx.textBaseline="alphabetic";
  ctx.fillText(String(v),px(x),py(y));
}

ctx.fillStyle = '#030811';
ctx.fillRect(0,0,W,H);
text("BIGG BOSS", 540, 268, 48, '#fff', 950, "center");
text("WATCH", 170, 194, 17, '#f3c247', 900, "center");

const buf = canvas.toBuffer("image/jpeg", 90);
await writeFile("scratch/test_out.jpg", buf);
console.log("Wrote scratch/test_out.jpg, size:", buf.length);
