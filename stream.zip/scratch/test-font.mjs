import { createCanvas } from '@napi-rs/canvas';
const c = createCanvas(720, 1280);
const ctx = c.getContext('2d');
ctx.font = '950 20px Segoe UI,Arial,sans-serif';
console.log('font 950:', ctx.font);
ctx.font = 'bold 20px Arial';
console.log('font bold:', ctx.font);
