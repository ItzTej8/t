import { createCanvas } from '@napi-rs/canvas';
const c = createCanvas(300, 300);
const ctx = c.getContext('2d');
ctx.font = '36px "Segoe UI Emoji", "Segoe UI", Arial, sans-serif';
ctx.fillText('🎈 ❤️ 🎁 👑 ⚡ 🔥 ⭐ 🎲 🪙 🎰 💣', 10, 50);
console.log('Buffer bytes:', c.toBuffer('image/png').length);
