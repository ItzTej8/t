import { readFileSync } from "node:fs";

const content = readFileSync("C:/Users/hp/.gemini/antigravity-ide/brain/1a9977a5-caf6-4568-a5e9-63433de420d0/.system_generated/steps/446/content.md", "utf8");
const matches = content.match(/images\/[a-zA-Z0-9\-_]+\.jpg/g) || [];
console.log("Found images:", [...new Set(matches)]);
