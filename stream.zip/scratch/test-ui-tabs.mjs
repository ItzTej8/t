import { writeFile } from "node:fs/promises";
import { initRenderer, drawMainFrame, canvas } from "../src/renderer.mjs";
import { setScreen, setScreenAuto } from "../src/interactive.mjs";
import { setTheme, state } from "../src/state.mjs";
import { runtime } from "../src/runtime.mjs";

const ARTIFACT_DIR = "C:/Users/hp/.gemini/antigravity-ide/brain/1a9977a5-caf6-4568-a5e9-63433de420d0";

async function run() {
  await initRenderer();
  runtime.chat.viewerCount = 1420; // 1.4K watching
  setScreenAuto(false);

  // 1. Light Theme - Main Screen
  setTheme("light");
  setScreen("main", { manual: true });
  drawMainFrame(Date.now());
  const bufLightMain = canvas.toBuffer("image/jpeg", 85);
  await writeFile(`${ARTIFACT_DIR}/preview_light_main.jpg`, bufLightMain);
  console.log("Saved preview_light_main.jpg");

  // 2. Light Theme - Race Screen (The one the user sent in the screenshot!)
  setScreen("race", { manual: true });
  drawMainFrame(Date.now() + 1000); // after transition finished
  const bufLightRace = canvas.toBuffer("image/jpeg", 85);
  await writeFile(`${ARTIFACT_DIR}/preview_light_race.jpg`, bufLightRace);
  console.log("Saved preview_light_race.jpg");

  // 3. Dark Theme - Main Screen
  setTheme("dark");
  setScreen("main", { manual: true });
  drawMainFrame(Date.now() + 2000);
  const bufDarkMain = canvas.toBuffer("image/jpeg", 85);
  await writeFile(`${ARTIFACT_DIR}/preview_dark_main.jpg`, bufDarkMain);
  console.log("Saved preview_dark_main.jpg");

  // 4. Smooth Transition Frame (50% slide & fade from main to race)
  setScreen("race", { manual: true });
  // Simulate transition at t=0.5 (halfway through 650ms transition)
  const now = Date.now();
  const s = (await import("../src/interactive.mjs")).interactiveState();
  s.screenTransition = { from: "main", to: "race", startedAt: now - 325, durationMs: 650 };
  drawMainFrame(now);
  const bufTrans = canvas.toBuffer("image/jpeg", 85);
  await writeFile(`${ARTIFACT_DIR}/preview_transition.jpg`, bufTrans);
  console.log("Saved preview_transition.jpg");

  process.exit(0);
}

run().catch(e => { console.error(e); process.exit(1); });
