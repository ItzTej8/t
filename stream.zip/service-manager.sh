#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SERVICE="bigg-boss-vps-canvas.service"
APP="/opt/bigg-boss-vps-canvas"
cmd="${1:-status}"
case "$cmd" in
  install)
    sudo mkdir -p "$APP"
    sudo cp -a "$ROOT/." "$APP/"
    sudo chown -R admin:admin "$APP"
    sudo cp "$APP/systemd-bigg-boss.service" "/etc/systemd/system/$SERVICE"
    sudo systemctl daemon-reload
    sudo systemctl enable "$SERVICE"
    sudo systemctl restart "$SERVICE"
    sudo systemctl --no-pager --full status "$SERVICE" || true
    ;;
  start) sudo systemctl start "$SERVICE" ;;
  stop) sudo systemctl stop "$SERVICE" ;;
  restart) sudo systemctl restart "$SERVICE" ;;
  status) sudo systemctl --no-pager --full status "$SERVICE" || true ;;
  logs) sudo journalctl -u "$SERVICE" -f ;;
  log-tail) sudo journalctl -u "$SERVICE" -n 120 --no-pager ;;
  enable) sudo systemctl enable "$SERVICE" ;;
  disable) sudo systemctl disable "$SERVICE" ;;
  *) echo "Usage: $0 {install|start|stop|restart|status|logs|log-tail|enable|disable}"; exit 2 ;;
esac
