# Bigg Boss 24/7 Live Stream — Debian VPS Deployment Guide

## Requirements
| Requirement | Details |
|---|---|
| **OS** | Debian 11/12 or Ubuntu 22/24 |
| **RAM** | 2 GB minimum, 4 GB recommended |
| **CPU** | 2 vCPU minimum (for ffmpeg + canvas render) |
| **Disk** | 5 GB free |
| **Network** | Stable upload ≥ 4 Mbps |
| **Software** | git, curl (pre-installed on most VPS) |

---

## Step-by-Step Deployment

### 1. Upload project to your VPS

**Option A — rsync from your Windows PC:**
```bash
# Run this from your Windows PC (Git Bash or WSL)
rsync -avz --exclude='node_modules' --exclude='.git' --exclude='data/*.sqlite*' \
  /c/Users/hp/Desktop/Projects/GSPN/stream/stream/ \
  root@YOUR_VPS_IP:/tmp/bigg-boss-upload/
```

**Option B — git clone (if you have a git repo):**
```bash
# On the VPS
git clone https://github.com/your-repo/bigg-boss-live.git /tmp/bigg-boss-upload
```

**Option C — scp zip:**
```bash
# On Windows PC, zip the folder then:
scp bigg-boss-live.zip root@YOUR_VPS_IP:/tmp/
# On VPS:
cd /tmp && unzip bigg-boss-live.zip -d bigg-boss-upload
```

---

### 2. Run the deploy script

SSH into your VPS and run:

```bash
cd /tmp/bigg-boss-upload
chmod +x deploy-debian.sh
sudo ./deploy-debian.sh
```

This single script does **everything**:
- ✅ Installs `ffmpeg`, `bun`, canvas native libs, fonts
- ✅ Creates a dedicated `biggboss` user (security isolation)
- ✅ Copies project to `/opt/bigg-boss-live`
- ✅ Installs npm deps with `bun install`
- ✅ Installs systemd service (auto-start on boot + auto-restart on crash)
- ✅ Sets up log rotation

---

### 3. Configure your stream key

```bash
sudo nano /opt/bigg-boss-live/.env
```

Update these lines with your actual values:
```env
YOUTUBE_STREAM_KEY=your-actual-stream-key-here
YOUTUBE_VIDEO_ID=your-video-id-here
YOUTUBE_CHANNEL_ID=your-channel-id-here
```

Then restart the stream:
```bash
sudo systemctl restart bigg-boss-live
```

---

## Service Management

| Command | Description |
|---|---|
| `sudo systemctl status bigg-boss-live` | Check if stream is running |
| `sudo journalctl -u bigg-boss-live -f` | Watch live logs |
| `sudo journalctl -u bigg-boss-live -n 200` | Last 200 log lines |
| `sudo systemctl restart bigg-boss-live` | Restart the stream |
| `sudo systemctl stop bigg-boss-live` | Stop the stream |
| `sudo systemctl start bigg-boss-live` | Start the stream |
| `sudo systemctl disable bigg-boss-live` | Disable auto-start on boot |
| `sudo systemctl enable bigg-boss-live` | Re-enable auto-start on boot |

---

## Auto-Restart Behavior

The systemd service is configured with:

```ini
Restart=always          # restart on any crash/exit
RestartSec=5            # wait 5s before restarting
StartLimitIntervalSec=0 # no limit on number of restarts
OOMPolicy=restart       # restart even if killed by OOM killer
```

This means:
- ✅ **Crash** → restarts in 5 seconds automatically
- ✅ **VPS reboot** → starts automatically (enabled with `WantedBy=multi-user.target`)
- ✅ **OOM kill** (out of memory) → restarts in 5 seconds
- ✅ **YouTube disconnect** → internal reconnect logic handles it

---

## Updating Code

After making code changes on your Windows PC, run this from Windows (Git Bash / WSL):

```bash
rsync -avz --exclude='node_modules' --exclude='.git' --exclude='data/' \
  /c/Users/hp/Desktop/Projects/GSPN/stream/stream/ \
  root@YOUR_VPS_IP:/tmp/bigg-boss-update/

# Then on the VPS:
ssh root@YOUR_VPS_IP
cd /tmp/bigg-boss-update
sudo ./update.sh
```

Or use the included `update.sh` script which handles the restart automatically.

---

## Viewing Logs

```bash
# Live tail (follow)
sudo journalctl -u bigg-boss-live -f

# Last 100 lines
sudo journalctl -u bigg-boss-live -n 100 --no-pager

# Filter only errors
sudo journalctl -u bigg-boss-live -p err -n 50 --no-pager

# Since last boot
sudo journalctl -u bigg-boss-live -b --no-pager

# Today's logs
sudo journalctl -u bigg-boss-live --since today --no-pager
```

---

## File Structure on VPS

```
/opt/bigg-boss-live/
├── src/                  # Source code
├── assets/               # Background image, contestant photos
├── data/                 # State files, vote DB (auto-created)
│   ├── state.json        # Vote state (persisted across restarts)
│   ├── votes.sqlite      # SQLite vote database
│   └── contestant-images/ # Cached contestant images
├── logs/                 # Log files (rotated daily, kept 7 days)
├── .env                  # Your config — KEEP THIS PRIVATE
└── node_modules/         # npm deps (installed by deploy script)

/etc/systemd/system/
└── bigg-boss-live.service  # Systemd unit file

/etc/logrotate.d/
└── bigg-boss-live          # Log rotation config
```

---

## Troubleshooting

### Stream not starting
```bash
sudo journalctl -u bigg-boss-live -n 50 --no-pager
# Look for: "YOUTUBE_STREAM_KEY is not configured"
sudo nano /opt/bigg-boss-live/.env
sudo systemctl restart bigg-boss-live
```

### ffmpeg not found
```bash
which ffmpeg
# If not found:
sudo apt-get install -y ffmpeg
```

### Canvas / node_modules errors
```bash
cd /opt/bigg-boss-live
sudo -u biggboss bun install
sudo systemctl restart bigg-boss-live
```

### Check memory usage
```bash
sudo systemctl status bigg-boss-live
# Look for "Memory:" line
```

### Service keeps restarting every 5 seconds
```bash
# Check the actual error
sudo journalctl -u bigg-boss-live -n 30 --no-pager
# Most common: bad stream key in .env
```
