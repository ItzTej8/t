#!/usr/bin/env bash
set -euo pipefail
APP_DIR=/opt/bigg-boss-vps-canvas
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
sudo mkdir -p "$APP_DIR"
sudo cp -a "$SCRIPT_DIR/." "$APP_DIR/"
sudo chown -R admin:admin "$APP_DIR"
sudo cp "$APP_DIR/systemd-bigg-boss.service" /etc/systemd/system/bigg-boss-vps-canvas.service
sudo systemctl daemon-reload
sudo systemctl enable --now bigg-boss-vps-canvas.service
sudo systemctl status bigg-boss-vps-canvas.service --no-pager
