import { config, validateConfig } from "./config.mjs";
import { loadState, state, resetRound, saveState } from "./state.mjs";
import { runChatLoop } from "./chat.mjs";
import { startRenderer, stopRenderer } from "./renderer.mjs";
import { getHealth } from "./health.mjs";

let stopping = false;

async function shutdown(signal) {
  if (stopping) return;
  stopping = true;
  console.log(`[main] received ${signal}`);
  stopRenderer();
  try { await saveState(); } catch (e) { console.error("[main] save:", e); }
  process.exit(0);
}

async function main() {
  validateConfig();
  await loadState();

  console.log("==========================================");
  console.log(" Bigg Boss Bun Live");
  console.log(` ${config.width}x${config.height}@${config.fps}`);
  console.log("==========================================");

  await startRenderer();

  Bun.serve({
    hostname: "127.0.0.1",
    port: Number(process.env.HEALTH_PORT || 8787),
    fetch() { return Response.json(getHealth()); }
  });
  console.log(`[health] 127.0.0.1:${process.env.HEALTH_PORT || 8787}`);

  setInterval(async () => {
    if (stopping) return;

    const elapsed = Math.floor(
      (Date.now() - state.roundStartedAt) / 1000
    );

    if (elapsed >= config.voteDuration) {
      console.log(`[vote] round ${state.round} finished`);
      resetRound();
      await saveState();
    }
  }, 1000);

  runChatLoop({
    onChat() {},
    onVote(event) {
      console.log(
        `[vote] accepted ${event.name} -> ${event.contestant}`
      );
    }
  }).catch(error => console.error("[chat-loop]", error));

  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("SIGTERM", () => shutdown("SIGTERM"));

  console.log("[main] live engine started");
}

main().catch(error => {
  console.error(error);
  process.exit(1);
});
