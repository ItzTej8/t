import { config } from "./config.mjs";
import { addChat, acceptVote, saveState, setOwner } from "./state.mjs";

let masterchatApiPromise;

async function loadMasterchat() {
  if (!masterchatApiPromise) {
    masterchatApiPromise = import("@stu43005/masterchat").then(mod => {
      if (!mod.Masterchat) throw new Error("Masterchat export not found in @stu43005/masterchat");
      return mod;
    });
  }
  return masterchatApiPromise;
}

function authorId(action) {
  return action.authorChannelId || action.channelId || action.author?.channelId || action.author?.id || null;
}

function owner(action) {
  return Boolean(action.isChatOwner || action.isOwner || action.authorIsChatOwner || action.author?.isChatOwner);
}

function moderator(action) {
  return Boolean(action.isChatModerator || action.isModerator || action.author?.isChatModerator);
}

function parseVote(text) {
  const escaped = config.voteCommand.replace(/[.*+?^${}()|[\\]\\]/g, "\\$&");
  const match = String(text).match(new RegExp(`^\\s*${escaped}\\s+(\\d+)\\s*$`, "i"));
  return match ? Number(match[1]) : null;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function youtubeStatus(videoId) {
  const url = `https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}`;
  const response = await fetch(url, {
    headers: {
      "User-Agent": config.youtubeUserAgent,
      "Accept-Language": "en-US,en;q=0.9"
    }
  });

  if (!response.ok) throw new Error(`YouTube HTTP ${response.status}`);
  const html = await response.text();
  const marker = '"playabilityStatus":';
  const start = html.indexOf(marker);
  if (start < 0) return { status: "UNKNOWN", reason: "playabilityStatus not present" };

  const objectStart = start + marker.length;
  let depth = 0;
  let inString = false;
  let escaped = false;
  let end = -1;

  for (let i = objectStart; i < html.length; i++) {
    const ch = html[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') { inString = true; continue; }
    if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) { end = i + 1; break; }
    }
  }

  if (end < 0) return { status: "UNKNOWN", reason: "invalid playabilityStatus" };

  try {
    const parsed = JSON.parse(html.slice(objectStart, end));
    return {
      status: parsed.status || "UNKNOWN",
      reason: parsed.reason || "",
      pollDelayMs: Number(parsed.liveStreamability?.liveStreamabilityRenderer?.pollDelayMs || 0)
    };
  } catch {
    return { status: "UNKNOWN", reason: "could not parse playabilityStatus" };
  }
}

function retryDelay(attempt, status) {
  if (status === "LIVE_STREAM_OFFLINE") return Math.min(60000, Math.max(10000, 10000 * 2 ** Math.min(attempt, 3)));
  return Math.min(60000, 5000 * 2 ** Math.min(attempt, 3));
}

export async function runChatLoop({ onChat, onVote }) {
  let attempt = 0;
  let lastStatusLog = "";

  while (true) {
    try {
      const status = await youtubeStatus(config.videoId);
      const statusKey = `${status.status}:${status.reason}`;

      if (status.status !== "OK") {
        if (statusKey !== lastStatusLog) {
          console.log(`[chat] YouTube status: ${status.status}${status.reason ? ` — ${status.reason}` : ""}`);
          lastStatusLog = statusKey;
        }
        const delay = Math.max(retryDelay(attempt, status.status), status.pollDelayMs || 0);
        attempt++;
        await sleep(delay);
        continue;
      }

      lastStatusLog = "";
      console.log(`[chat] connecting to ${config.videoId}`);
      const { Masterchat, stringify } = await loadMasterchat();
      const mc = await Masterchat.init(config.videoId);
      attempt = 0;
      console.log("[chat] connected");

      try {
        // `iterate()` returns an async iterable, not an Array/iterator with `.filter()`.
        // Filter actions inside the async loop so this works with the actual
        // @stu43005/masterchat 2.x runtime.
        for await (const action of mc.iterate()) {
          if (!action || action.type !== "addChatItemAction") continue;

          const text = stringify(action.message ?? action.messageRuns ?? "");
          const name = action.authorName || action.author?.name || "Viewer";
          const id = authorId(action);
          const isOwner = owner(action);
          const isModerator = moderator(action);

          if (isOwner && id) setOwner(id, name);
          addChat(name, text);

          const vote = parseVote(text);
          if (vote !== null && id && acceptVote(id, vote, name)) {
            console.log(`[vote] ${name} -> ${vote}`);
            onVote?.({ contestant: vote, name, userId: id });
            await saveState();
          }

          onChat?.({ name, text, userId: id, isOwner, isModerator });
        }
      } finally {
        try { mc.stop?.(); } catch {}
        try { mc.destroy?.(); } catch {}
      }

      console.warn("[chat] stream iterator ended; reconnecting");
      attempt++;
      await sleep(retryDelay(attempt, "ENDED"));
    } catch (error) {
      const message = error?.message || String(error);
      console.error(`[chat] disconnected: ${message}`);
      const delay = retryDelay(attempt, "ERROR");
      attempt++;
      console.log(`[chat] retrying in ${Math.ceil(delay / 1000)}s`);
      await sleep(delay);
    }
  }
}
