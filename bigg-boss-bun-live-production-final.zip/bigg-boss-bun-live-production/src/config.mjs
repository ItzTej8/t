const csv = (value, fallback) =>
  String(value ?? fallback).split(",").map(x => x.trim()).filter(Boolean);

export const config = {
  width: Number(process.env.WIDTH || 1080),
  height: Number(process.env.HEIGHT || 1920),
  fps: Number(process.env.FPS || 30),
  bitrate: process.env.BITRATE || "3500k",
  preset: process.env.PRESET || "superfast",
  encoderThreads: Number(process.env.ENCODER_THREADS || 3),
  gopSeconds: Number(process.env.GOP_SECONDS || 2),
  rtmpUrl: process.env.YOUTUBE_RTMP_URL || "rtmp://a.rtmp.youtube.com/live2",
  streamKey: process.env.YOUTUBE_STREAM_KEY || "",
  videoId: process.env.YOUTUBE_VIDEO_ID || "",
  voteCommand: process.env.VOTE_COMMAND || "!vote",
  voteDuration: Number(process.env.VOTE_DURATION_SECONDS || 60),
  contestants: csv(process.env.CONTESTANTS, "Contestant 1,Contestant 2,Contestant 3,Contestant 4"),
  backgroundMode: process.env.BACKGROUND_MODE || "generated",
  backgroundImage: process.env.BACKGROUND_IMAGE || "assets/background/background.jpg",
  dataFile: "data/state.json",
  youtubeUserAgent: process.env.YOUTUBE_USER_AGENT || "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/151.0.0.0 Safari/537.36"
};

export function validateConfig() {
  const errors = [];
  if (!config.streamKey || config.streamKey.includes("PUT_YOUR")) errors.push("YOUTUBE_STREAM_KEY");
  if (!config.videoId) errors.push("YOUTUBE_VIDEO_ID");
  if (config.width % 2 || config.height % 2) errors.push("WIDTH and HEIGHT must be even");
  if (!config.contestants.length) errors.push("CONTESTANTS");
  if (errors.length) throw new Error(`Missing/invalid configuration: ${errors.join(", ")}`);
}
