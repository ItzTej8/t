import fs from "node:fs/promises";
import { config } from "./config.mjs";

export let state;

function initialState() {
  return { version: 2, createdAt: new Date().toISOString(), round: 1, roundStartedAt: Date.now(), ownerChannelId: null, ownerName: null, totals: Object.fromEntries(config.contestants.map((_, i) => [String(i + 1), 0])), voters: {}, recentChat: [], recentVotes: [], totalAcceptedVotes: 0, lastVote: null, lastVoteAt: 0 };
}

export async function loadState() {
  await fs.mkdir("data", { recursive: true });
  try {
    state = JSON.parse(await fs.readFile(config.dataFile, "utf8"));
    state.totals ??= {}; state.voters ??= {}; state.recentChat ??= []; state.recentVotes ??= [];
    state.round ??= 1; state.roundStartedAt ??= Date.now(); state.totalAcceptedVotes ??= 0;
    state.lastVote ??= null; state.lastVoteAt ??= 0;
    for (let i = 1; i <= config.contestants.length; i++) state.totals[String(i)] ??= 0;
  } catch { state = initialState(); await saveState(); }
}

export async function saveState() { await fs.writeFile(config.dataFile, JSON.stringify(state, null, 2)); }
export function resetRound() { state.round++; state.roundStartedAt = Date.now(); state.voters = {}; state.recentChat = []; state.recentVotes = []; state.lastVote = null; state.lastVoteAt = 0; }
export function acceptVote(userId, contestant, name = "Viewer") {
  if (!userId || !Number.isInteger(contestant) || contestant < 1 || contestant > config.contestants.length || state.voters[userId]) return false;
  state.voters[userId] = contestant;
  state.totals[String(contestant)]++;
  state.totalAcceptedVotes++;
  state.lastVote = { contestant, name: String(name).slice(0, 28), at: Date.now() };
  state.lastVoteAt = Date.now();
  state.recentVotes.push(state.lastVote);
  state.recentVotes = state.recentVotes.slice(-12);
  return true;
}
export function addChat(name, text) {
  state.recentChat.push({ name: String(name || "Viewer").replace(/\s+/g, " ").slice(0, 24), text: String(text || "").replace(/\s+/g, " ").slice(0, 88), time: Date.now() });
  state.recentChat = state.recentChat.slice(-5);
}
export function setOwner(channelId, name) { if (channelId) { state.ownerChannelId = channelId; state.ownerName = name || state.ownerName; } }
export function stats() {
  const rows = config.contestants.map((name, i) => ({ no: i + 1, name, votes: Number(state.totals[String(i + 1)] || 0) }));
  const total = rows.reduce((sum, r) => sum + r.votes, 0);
  return rows.map(r => ({ ...r, total, pct: total ? r.votes / total : 0 })).sort((a, b) => b.votes - a.votes);
}
