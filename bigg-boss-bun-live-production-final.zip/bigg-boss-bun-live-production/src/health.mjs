import { state } from "./state.mjs";
export function getHealth(){return {uptimeSeconds:Math.floor(process.uptime()),round:state?.round??0,totalVotes:state?.totalAcceptedVotes??0,memoryMB:Math.round(process.memoryUsage().rss/1024/1024)}}
