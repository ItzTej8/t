import fs from "node:fs/promises";

await fs.mkdir("data", { recursive: true });
await fs.mkdir("assets/contestants", { recursive: true });
await fs.mkdir("assets/background", { recursive: true });

console.log("Project directories ready.");
