import { createCanvas, loadImage } from "@napi-rs/canvas";
import { spawn } from "node:child_process";
import { access } from "node:fs/promises";
import { config } from "./config.mjs";
import { state, stats } from "./state.mjs";

const W=config.width,H=config.height,FPS=config.fps;
const canvas=createCanvas(W,H),ctx=canvas.getContext("2d");
let ffmpegProcess=null,ffmpegInput=null,running=false,loopRunning=false,backgroundImage=null;
const contestantImages=new Map(),barSpring=new Map(),cardSpring=new Map();
const COLORS=["#ff3d71","#35d5e5","#a78bfa","#f59e0b","#22c55e","#f43f5e","#06b6d4"];
const particles=Array.from({length:34},(_,i)=>({x:(i*193)%W,y:(i*317)%H,size:1+(i%4),speed:.15+(i%5)*.07,phase:i*.77}));
const exists=async f=>{try{await access(f);return true}catch{return false}};
const color=i=>COLORS[i%COLORS.length],clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),lerp=(a,b,t)=>a+(b-a)*t,fmt=v=>Number(v||0).toLocaleString("en-IN");
const hex=(c,a)=>c+Math.round(clamp(a,0,1)*255).toString(16).padStart(2,"0");
function rr(x,y,w,h,r){ctx.beginPath();ctx.roundRect(x,y,w,h,r)}

async function loadAssets(){
  if(config.backgroundMode==="image"&&await exists(config.backgroundImage)){try{backgroundImage=await loadImage(config.backgroundImage)}catch(e){console.error("[renderer] background:",e.message)}}
  for(let i=1;i<=config.contestants.length;i++){
    barSpring.set(i,{value:0,target:0});cardSpring.set(i,{value:1,target:1});
    const file=`assets/contestants/${i}.png`;
    if(await exists(file)){try{contestantImages.set(i,await loadImage(file))}catch{contestantImages.set(i,null)}}else contestantImages.set(i,null);
  }
}

function background(time){
  const s=time/1000,p=.5+.5*Math.sin(s*.8),g=ctx.createLinearGradient(0,0,W,H);
  g.addColorStop(0,"#050714");g.addColorStop(.45,p>.5?"#14152d":"#091a2b");g.addColorStop(1,"#03040a");ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
  if(backgroundImage){ctx.save();ctx.globalAlpha=.1;const k=Math.max(W/backgroundImage.width,H/backgroundImage.height),iw=backgroundImage.width*k,ih=backgroundImage.height*k;ctx.drawImage(backgroundImage,(W-iw)/2+Math.sin(s*.025)*18,(H-ih)/2+Math.cos(s*.021)*12,iw,ih);ctx.restore()}
  for(const q of particles){q.y-=q.speed;if(q.y<-20)q.y=H+20;ctx.globalAlpha=.04+.06*(.5+.5*Math.sin(s*1.5+q.phase));ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(q.x,q.y,q.size,0,Math.PI*2);ctx.fill()}ctx.globalAlpha=1;
  for(let i=0;i<3;i++){const x=W*(.15+.7*(.5+.5*Math.sin(s*.055+i*2.1))),y=H*(.15+.7*(.5+.5*Math.cos(s*.045+i*1.8))),r=230+Math.sin(s*.5+i)*35,g2=ctx.createRadialGradient(x,y,0,x,y,r);g2.addColorStop(0,hex(color(i),.055));g2.addColorStop(1,hex(color(i),0));ctx.fillStyle=g2;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill()}
}

function top(time){
  rr(45,38,W-90,155,32);ctx.fillStyle="rgba(9,13,27,.82)";ctx.fill();ctx.strokeStyle="rgba(255,255,255,.08)";ctx.lineWidth=2;ctx.stroke();
  ctx.fillStyle="#fff";ctx.font="900 54px DejaVu Sans";ctx.fillText("BIGG BOSS",72,92);ctx.fillStyle="#aab5ce";ctx.font="600 25px DejaVu Sans";ctx.fillText(`LIVE VOTING • ROUND ${state.round}`,75,143);
  rr(W-215,74,135,55,27);ctx.fillStyle="rgba(255,49,92,.14)";ctx.fill();ctx.globalAlpha=.7+.3*Math.sin(time/220);ctx.fillStyle="#ff315c";ctx.beginPath();ctx.arc(W-187,101,8,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;ctx.fillStyle="#fff";ctx.font="900 23px DejaVu Sans";ctx.fillText("LIVE",W-169,102);
}
function instruction(){rr(55,215,W-110,102,28);ctx.fillStyle="rgba(10,14,28,.9)";ctx.fill();ctx.fillStyle="#c8d0e2";ctx.font="600 27px DejaVu Sans";ctx.fillText("Vote in YouTube chat",90,257);ctx.fillStyle="#7ee7f5";ctx.font="900 32px DejaVu Sans";ctx.fillText(`${config.voteCommand} 1 / 2 / 3 ...`,90,294)}
function section(){ctx.fillStyle="#7d8aa8";ctx.font="700 21px DejaVu Sans";ctx.fillText("LIVE RESULTS",65,345);ctx.fillStyle="#fff";ctx.font="800 21px DejaVu Sans";ctx.textAlign="right";ctx.fillText(`${fmt(state.totalAcceptedVotes)} TOTAL VOTES`,W-65,345);ctx.textAlign="left"}

function contestants(time){
  const rows=stats(),max=Math.max(1,...rows.map(r=>r.votes));
  rows.forEach((r,i)=>{
    const y=370+i*225,bar=barSpring.get(r.no),card=cardSpring.get(r.no),leader=r.votes===max&&max>0;
    bar.target=r.votes/max;bar.value=lerp(bar.value,bar.target,.13);card.target=leader?1.012:1;card.value=lerp(card.value,card.target,.08);
    const scale=card.value||1,cx=W/2,bw0=W-110,cw=bw0*scale,cx0=cx-cw/2;
    rr(cx0,y,cw,184,32);ctx.fillStyle="rgba(13,18,35,.93)";ctx.fill();ctx.strokeStyle=leader?hex(color(i),.45):"rgba(255,255,255,.06)";ctx.lineWidth=leader?3:2;ctx.stroke();
    ctx.fillStyle=color(i);ctx.beginPath();ctx.arc(91,y+42,22,0,Math.PI*2);ctx.fill();ctx.fillStyle="#fff";ctx.font="900 19px DejaVu Sans";ctx.textAlign="center";ctx.fillText(String(i+1),91,y+43);ctx.textAlign="left";
    const im=contestantImages.get(r.no);if(im){ctx.save();ctx.beginPath();ctx.arc(150,y+91,48,0,Math.PI*2);ctx.clip();const k=Math.max(96/im.width,96/im.height),iw=im.width*k,ih=im.height*k;ctx.drawImage(im,150-iw/2,y+91-ih/2,iw,ih);ctx.restore()}else{ctx.fillStyle=color(i);ctx.beginPath();ctx.arc(150,y+91,48,0,Math.PI*2);ctx.fill();ctx.fillStyle="#fff";ctx.font="900 30px DejaVu Sans";ctx.textAlign="center";ctx.fillText(String(r.no),150,y+92);ctx.textAlign="left"}
    ctx.fillStyle="#fff";ctx.font="900 29px DejaVu Sans";ctx.fillText(r.name,218,y+54);ctx.fillStyle="#8995b0";ctx.font="600 21px DejaVu Sans";ctx.fillText(`${fmt(r.votes)} votes`,218,y+88);
    ctx.fillStyle=color(i);ctx.font="900 31px DejaVu Sans";ctx.textAlign="right";ctx.fillText(`${(r.pct*100).toFixed(1)}%`,W-85,y+54);ctx.textAlign="left";
    const bx=218,by=y+124,track=W-305,bh=25;rr(bx,by,track,bh,13);ctx.fillStyle="#242b42";ctx.fill();const fw=track*clamp(bar.value,0,1);if(fw>1){rr(bx,by,fw,bh,13);const pg=ctx.createLinearGradient(bx,0,bx+track,0);pg.addColorStop(0,color(i));pg.addColorStop(1,"#fff");ctx.fillStyle=pg;ctx.fill();ctx.globalAlpha=.24;ctx.fillStyle="#fff";const sx=bx+((time/9+i*120)%Math.max(1,fw));ctx.fillRect(sx,by+2,Math.min(55,fw),bh-4);ctx.globalAlpha=1}
    if(leader){rr(W-250,y+103,150,36,18);ctx.fillStyle=hex(color(i),.17);ctx.fill();ctx.fillStyle=color(i);ctx.font="900 17px DejaVu Sans";ctx.textAlign="center";ctx.fillText("🔥 LEADING",W-175,y+121);ctx.textAlign="left"}
  });
}

function countdown(){
  const elapsed=Math.floor((Date.now()-state.roundStartedAt)/1000),remain=Math.max(0,config.voteDuration-(elapsed%config.voteDuration)),p=remain/Math.max(1,config.voteDuration);
  rr(55,1425,W-110,102,28);ctx.fillStyle="rgba(9,13,26,.94)";ctx.fill();ctx.fillStyle="#9aa6bf";ctx.font="700 22px DejaVu Sans";ctx.fillText("NEXT VOTING ROUND",88,1461);ctx.fillStyle=remain<=10?"#ff5277":"#7ee7f5";ctx.font="900 39px DejaVu Sans";ctx.textAlign="right";ctx.fillText(`${remain}s`,W-88,1468);ctx.textAlign="left";rr(88,1490,W-176,13,7);ctx.fillStyle="#222941";ctx.fill();rr(88,1490,(W-176)*p,13,7);ctx.fillStyle=remain<=10?"#ff5277":"#35d5e5";ctx.fill();
}
function chat(){let y=1615;ctx.fillStyle="#7784a2";ctx.font="800 19px DejaVu Sans";ctx.fillText("LIVE CHAT",65,1588);for(const m of state.recentChat.slice(-3)){rr(55,y-26,W-110,55,18);ctx.fillStyle="rgba(10,14,27,.72)";ctx.fill();const n=`${m.name}:`;ctx.fillStyle="#7ee7f5";ctx.font="700 19px DejaVu Sans";ctx.fillText(n,78,y);const nw=ctx.measureText(n).width;ctx.fillStyle="#dce2ef";ctx.font="600 18px DejaVu Sans";ctx.fillText(m.text.slice(0,58),88+nw,y);y+=58}}
function voteBurst(time){const v=state.lastVote;if(!v)return;const age=Date.now()-v.at;if(age>2600)return;const t=clamp(age/2600,0,1),idx=Math.max(0,v.contestant-1),y=1568-t*100,a=1-t;ctx.save();ctx.globalAlpha=a;rr(65,y,W-130,72,25);ctx.fillStyle="rgba(8,12,24,.96)";ctx.fill();ctx.strokeStyle=hex(color(idx),.65);ctx.lineWidth=2;ctx.stroke();ctx.fillStyle=color(idx);ctx.font="900 24px DejaVu Sans";ctx.fillText("＋1 VOTE",92,y+36);ctx.fillStyle="#fff";ctx.font="700 22px DejaVu Sans";ctx.fillText(`${v.name} → ${config.contestants[v.contestant-1]}`,235,y+36);for(let i=0;i<8;i++){const ang=i/8*Math.PI*2,rad=42+t*48;ctx.fillStyle=color(idx);ctx.beginPath();ctx.arc(W/2+Math.cos(ang)*rad,y+36+Math.sin(ang)*rad*.45,3,0,Math.PI*2);ctx.fill()}ctx.restore()}
function footer(){ctx.fillStyle="#5f6c88";ctx.font="600 18px DejaVu Sans";ctx.fillText(`24/7 LIVE • ${W}×${H} • ${FPS} FPS • TOTAL ${fmt(state.totalAcceptedVotes)}`,65,H-42)}
function frame(time){background(time);top(time);instruction();section();contestants(time);countdown();chat();voteBurst(time);footer();const data=ctx.getImageData(0,0,W,H);return Buffer.from(data.data.buffer,data.data.byteOffset,data.data.byteLength)}

function startFfmpeg(){
  if(ffmpegProcess&&ffmpegInput&&!ffmpegInput.destroyed)return;
  const args=["-hide_banner","-loglevel","warning","-f","rawvideo","-pixel_format","rgba","-video_size",`${W}x${H}`,"-framerate",String(FPS),"-i","pipe:0","-vf","format=yuv420p","-c:v","libx264","-preset",config.preset,"-threads",String(config.encoderThreads),"-tune","zerolatency","-b:v",config.bitrate,"-maxrate",config.bitrate,"-bufsize","7000k","-r",String(FPS),"-g",String(FPS*config.gopSeconds),"-keyint_min",String(FPS*config.gopSeconds),"-sc_threshold","0","-pix_fmt","yuv420p","-f","flv",`${config.rtmpUrl}/${config.streamKey}`];
  console.log("[ffmpeg] starting RTMP encoder");
  const p=spawn("ffmpeg",args,{stdio:["pipe","ignore","pipe"]});ffmpegProcess=p;ffmpegInput=p.stdin;
  p.stderr.on("data",d=>process.stdout.write(`[ffmpeg] ${d}`));p.on("error",e=>console.error("[ffmpeg] error:",e));p.on("exit",(code,signal)=>{console.error(`[ffmpeg] exited code=${code} signal=${signal}`);if(ffmpegProcess===p){ffmpegProcess=null;ffmpegInput=null}if(running)setTimeout(startFfmpeg,5000)})
}
async function renderLoop(){if(loopRunning)return;loopRunning=true;const interval=1000/FPS;let next=performance.now();try{while(running){const now=performance.now();if(now>=next){if(!ffmpegInput||ffmpegInput.destroyed){startFfmpeg();await new Promise(r=>setTimeout(r,250));next=performance.now()+interval;continue}const buf=frame(Date.now());const ok=ffmpegInput.write(buf);next+=interval;if(performance.now()-next>interval*3)next=performance.now()+interval;if(!ok)await new Promise(r=>ffmpegInput.once("drain",r));continue}await new Promise(r=>setTimeout(r,Math.max(1,Math.min(10,next-performance.now()))))}}finally{loopRunning=false}}
export async function startRenderer(){if(running)return;running=true;console.log(`[renderer] ${W}x${H}@${FPS} FPS`);await loadAssets();startFfmpeg();renderLoop().catch(e=>console.error("[renderer] loop:",e))}
export function stopRenderer(){running=false;if(ffmpegInput&&!ffmpegInput.destroyed)ffmpegInput.end();if(ffmpegProcess)ffmpegProcess.kill("SIGTERM");ffmpegInput=null;ffmpegProcess=null}
