# Bigg Boss Bun.js Vertical Live — Production/Smooth Build

OBS-free 24/7 vertical YouTube streaming engine using Bun.js, native Canvas, FFmpeg and Masterchat.

## Important

Use only video, music, logos, contestant images and other media that you own or are licensed to rebroadcast.

## What changed in v2

- Uses the actively published `@stu43005/masterchat` 2.x package instead of the old `masterchat` 1.1.0 package.
- Checks YouTube `playabilityStatus` before initializing chat.
- Correctly waits when the broadcast is upcoming/offline.
- Exponential reconnect backoff instead of reconnecting every 5 seconds forever.
- A YouTube chat failure never stops the renderer/FFmpeg stream.
- Keeps the native 1080x1920@30 renderer and low-CPU FFmpeg path.
- Persistent voting state and one vote per viewer per round.

## Install on Debian

```bash
sudo apt update
sudo apt install -y ffmpeg fonts-dejavu curl unzip
cd ~/s/t
unzip -o bigg-boss-bun-live-production.zip -d bigg-boss-bun-live-production
cd bigg-boss-bun-live-production/bigg-boss-bun-live-production
bun install
cp .env.example .env
nano .env
bun run start
```

Set `YOUTUBE_STREAM_KEY`, `YOUTUBE_VIDEO_ID`, and `CONTESTANTS`.

Vote with `!vote 1`, `!vote 2`, etc.

## Contabo 4-vCPU / 8-GB starting settings

```env
WIDTH=1080
HEIGHT=1920
FPS=30
BITRATE=3500k
PRESET=superfast
ENCODER_THREADS=3
GOP_SECONDS=2
```

If CPU is still high:

```env
PRESET=ultrafast
```

or use 720x1280:

```env
WIDTH=720
HEIGHT=1280
FPS=30
BITRATE=2500k
PRESET=superfast
```

## YouTube chat behavior

The chat connector first checks the public YouTube page. If the event is not live, it waits instead of repeatedly calling Masterchat. Once YouTube reports the broadcast as playable, it initializes Masterchat and listens for `addChatItemAction` events.

If chat disconnects while the video is streaming, FFmpeg and the renderer continue running and the chat connector reconnects with backoff.

## Health

The local health endpoint is available at:

`http://127.0.0.1:8787`

## systemd

Edit `deploy/bigg-boss-live.service`, then install it:

```bash
sudo cp deploy/bigg-boss-live.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now bigg-boss-live
sudo journalctl -u bigg-boss-live -f
```
