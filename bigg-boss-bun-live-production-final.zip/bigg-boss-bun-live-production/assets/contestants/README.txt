Optional licensed contestant images:
1.png
2.png
3.png
4.png

Numbers match contestant order in CONTESTANTS.
