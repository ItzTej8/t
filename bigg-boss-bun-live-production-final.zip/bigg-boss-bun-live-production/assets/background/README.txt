Optional licensed background:
background.jpg

Set:
BACKGROUND_MODE=image
BACKGROUND_IMAGE=assets/background/background.jpg
